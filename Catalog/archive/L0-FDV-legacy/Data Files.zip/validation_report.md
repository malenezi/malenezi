# Validation report

Automated consistency checks across the SDA-DSC-112 dataset family.

| Result | Check | Detail |
| --- | --- | --- |
| ✅ PASS | Fact grain is unique and complete (60 x 13 x 9 x 4) | 28,080 rows |
| ✅ PASS | No nulls anywhere in the clean fact table |  |
| ✅ PASS | Region keys resolve to dim_regions | 13 regions |
| ✅ PASS | Category keys resolve to dim_services |  |
| ✅ PASS | Channel keys resolve to dim_channels |  |
| ✅ PASS | Month keys resolve to dim_calendar |  |
| ✅ PASS | Adoption is one value per month x region x category segment |  |
| ✅ PASS | Percentage columns within 0-100 |  |
| ✅ PASS | CSAT within 1-5 |  |
| ✅ PASS | No negative volumes, costs or durations |  |
| ✅ PASS | unique_users never exceeds transactions |  |
| ✅ PASS | Weighted national adoption = 63.8% (deck figure) | 63.84% |
| ✅ PASS | Naive average-of-averages = 61.2% (deck figure) | 61.19% |
| ✅ PASS | The averages-of-averages gap is reproducible | 2.64pp |
| ✅ PASS | Exactly five regions exceed the 18 SAR cost target | Jazan, Najran, Al-Baha, Asir, Northern Borders |
| ✅ PASS | National cost per transaction fell 34% across the window | 25.66 -> 16.94 SAR |
| ✅ PASS | National CSAT rose 12% across the window | 3.71 -> 4.16 |
| ✅ PASS | Three regions sit more than 9pp below target (the severe laggards) | Jazan, Najran, Al-Baha |
| ✅ PASS | Five regions classed Tier 1 and all are stalled |  |
| ✅ PASS | Cost laggards and adoption laggards are the same five regions |  |
| ✅ PASS | Transaction durations reproduce fact completion times (r > 0.95) | r = 0.997 |
| ✅ PASS | Survey CSAT tracks fact CSAT by region (r > 0.75) | r = 0.927 |
| ✅ PASS | Authentication failures concentrate in the Tier 1 regions | 27% vs 17% of tickets |
| ✅ PASS | Branch visits decline across the 24-month window | 681,010 -> 527,354 visits/month |
| ✅ PASS | Every region has exactly one RLS director |  |
| ✅ PASS | Each investment option allocates the full SAR 40M |  |
| ✅ PASS | Only the targeted option lifts stalled regions to 65% by December | OPT-A 4 of 5, others 0 |
| ✅ PASS | Raw extract contains duplicate rows to remove | 180 exact duplicates |
| ✅ PASS | Raw extract has non-standard region labels | 65 distinct labels for 13 regions |
| ✅ PASS | Raw extract has missing values to handle | 747 blank or placeholder cells |
| ✅ PASS | Raw numeric columns arrive as text (separators and % signs) |  |
| ✅ PASS | Raw extract contains impossible values to quarantine | adoption above 100% and negative unit costs present |
| ✅ PASS | Raw extract contains sentinel completion times | 43 sentinel rows |

**33 of 33 checks passed.**