# SDA-DSC-112 — Complete dataset package
### Data Visualization and Storytelling · SDAIA Academy · Data Scientist Track

Every dataset required to deliver the three-day programme end to end: lectures, live demos, six hands-on labs, five case studies, knowledge checks, benchmark exercises, dashboards and the graded capstone.

**Golden thread.** All 25 datasets describe one artefact — the **Tayseer (تيسير) National Digital Services Programme**, a Vision 2030 initiative moving government service delivery from branches to digital channels. Nothing here is a throwaway example; every lab evolves the same story.

**Coverage.** July 2021 – June 2026 (60 months) · 13 administrative regions · 9 service categories · 4 delivery channels · 12.5 million transactions in the latest month.

**All data is synthetic.** Volumes, costs, names, emails and comments are generated. No real individual, entity or transaction is represented. Figures are calibrated to be *plausible* for a Saudi national service programme, not to reproduce any actual published statistic.

---

## 1. The story the data tells

This spine is deliberate — instructors should know it before Day 1, because every lab converges on it.

| | |
|---|---|
| **Situation** | National digital adoption has risen from 33.9% to **63.8%**; cost per transaction fell **34%** and satisfaction rose **12%**. |
| **Complication** | Five regions — Jazan, Najran, Al-Baha, Asir, Northern Borders — have **stalled** (under 0.08pp per month for nine months). The same five exceed the 18 SAR cost-per-transaction target. Left alone they finish December roughly 8pp short. |
| **The trap** | `AVERAGE(digital_adoption_pct)` returns **61.2%**; the correct user-weighted recomputation returns **63.8%**. The 2.6-point averages-of-averages bug is reproducible from the shipped data — Module 4 depends on it. |
| **The objection** | "Those regions are just small." The rebuttal is in the data: 15.8% of the population, digital transactions per capita 12% below national, and the highest unit cost in the country (24.6 vs 14.6 SAR). |
| **Evidence** | Support tickets show authentication failures at 27% of ticket volume in the five regions versus 17% elsewhere — a scoped, fixable root cause. |
| **The ask** | Where should the next **SAR 40 million** go? Three options are costed. Only the targeted regional option lifts stalled regions to 65% by December; the platform rebuild has the higher ceiling but lands eight months late. |

---

## 2. Dataset inventory

### Core — the golden thread (`data/core/`)

| File | Rows × cols | What it is |
|---|---|---|
| `tayseer_services.csv` | 28,080 × 12 | **The dataset.** Monthly service metrics at `month × region × service_category × channel`. Every lab loads this. |
| `tayseer_services_raw.csv` | 5,886 × 14 | Deliberately dirty 12-month extract: 180 duplicates, 65 region spellings, four date formats, text-typed numbers, four null encodings, negative costs, adoption above 100%, sentinel completion times. Answer key in `docs/`. |
| `tayseer_transactions_sample.csv` | 20,000 × 19 | Individual transactions for the last quarter — the distribution behind the averages. Durations are right-skewed with a genuine branch tail. |

### Dimensions — the star schema (`data/dimensions/`)

| File | Rows | Why it exists |
|---|---|---|
| `dim_regions.csv` | 13 | Population (per-capita denominators), readiness, tier, Arabic names, coordinates |
| `dim_services.csv` | 36 | Named services under the nine categories — the drill path `national → region → service` |
| `dim_channels.csv` | 4 | Channel unit economics and repeat rates |
| `dim_calendar.csv` | 60 | Ramadan, Hajj, term and working-day flags — the seasonality that explains every dip |

### Supporting — operations, KPIs and the decision (`data/supporting/`)

| File | Rows | Why it exists |
|---|---|---|
| `regional_scorecard_latest.csv` | 13 | One row per region: latest values, nine-month slope, do-nothing projection. The Module 2 four-panel review. |
| `kpi_targets.csv` | 10 | Formulas, thresholds, owners and an explicit **additivity flag** per KPI |
| `csat_survey_responses.csv` | 4,500 | Bilingual verbatims and NPS — qualitative evidence for narrative scenes |
| `support_tickets.csv` | 6,000 | Root causes behind the numbers — where insight generation actually happens |
| `branch_monthly.csv` | 2,928 | Branch visits, wait times and operating cost — the channel-shift cost argument |
| `investment_options.csv` | 3 | The SAR 40M options, costed on gap-closed-per-riyal, payback and delivery risk |
| `investment_option_region_allocation.csv` | 39 | Option × region allocation and projected December adoption |
| `region_directors.csv` | 13 | Row-level-security lookup for the Power BI / Tableau RLS demonstration |

### Instructional — exercises, benchmarks and assessment (`data/instructional/`)

| File | Rows | Why it exists |
|---|---|---|
| `encoding_accuracy_ranking.csv` | 7 | Cleveland–McGill hierarchy with a Tayseer example per channel (Lab 1 task 3) |
| `chart_chooser.csv` | 8 | Question type → chart, with the many-categories / many-series escalation (Lab 2) |
| `lab2_questions.csv` | 5 | The Lab 2 questions with expected chart, rationale and the insight each should yield |
| `brand_palette.csv` | 16 | Mock national brand tokens: palette type, CVD safety, contrast ratio, usage rule |
| `dashboard_usability_tests.csv` | 144 | Gauge wall vs inverted pyramid, timed — the Module 4 benchmark, as data |
| `knowledge_check_bank.csv` | 30 | All six modules' mini exercises with model answers and LO mapping |
| `qa_bank.csv` | 12 | Committee questions — hostile, data-is-wrong, off-topic — each with an answer and a bridge |
| `assessment_rubric.csv` | 11 | Weighted capstone criteria with level 1–5 descriptors |
| `rehearsal_scores.csv` | 288 | Two recorded rounds × six criteria × 24 participants (mean 54% → 86%) |
| `participants_roster.csv` | 24 | Cohort with prerequisites, tooling and delivery-language preference |

### Documentation (`docs/`)

`data_dictionary.md` · `data_dictionary.csv` (319 columns documented) · `data_quality_issue_key.csv` (instructor answer key) · `validation_report.md` (33/33 checks) · `MANIFEST.csv`

---

## 3. Where each dataset is used

| Programme element | Datasets |
|---|---|
| **Day 1 H1** — dataset tour | `tayseer_services`, `tayseer_services_raw`, all `dim_*`, `data_dictionary` |
| **M1 / Lab 1** — perception audit, five encodings | `tayseer_services`, `dim_regions`, `encoding_accuracy_ranking` |
| **M2 / Lab 2** — chart choice, four questions | `tayseer_services`, `lab2_questions`, `chart_chooser`, `tayseer_transactions_sample` (Q3 box plot), `regional_scorecard_latest` |
| **M2 case study** — regional performance review | `regional_scorecard_latest`, `dim_regions` |
| **M3 / Lab 3** — before/after redesign, RTL | `tayseer_services`, `brand_palette`, `dim_regions` (Arabic labels), `dim_calendar` |
| **M4 / Lab 4a–4b** — dashboard, cross-filter, drill, RLS | `tayseer_services`, all `dim_*`, `kpi_targets`, `region_directors`, `dim_services` (drill path) |
| **M4 case study & benchmark** | `dashboard_usability_tests`, `kpi_targets` |
| **M5 / Lab 5** — storyboard, Big Idea, BLUF | `regional_scorecard_latest`, `investment_options`, `csat_survey_responses`, `support_tickets`, `branch_monthly` |
| **M6 / Lab 6** — delivery clinic, Q&A | `qa_bank`, `investment_option_region_allocation`, `rehearsal_scores` |
| **Knowledge checks** (all modules) | `knowledge_check_bank` |
| **Capstone & scoring** | Everything above + `assessment_rubric`, `participants_roster` |

## 4. Which capability each dataset exercises

| | Cleaning | Exploration | Visualisation | KPI analysis | Storytelling | Insight | Decision |
|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| `tayseer_services` | | ● | ● | ● | ● | ● | ● |
| `tayseer_services_raw` | ● | ● | | | | | |
| `tayseer_transactions_sample` | ● | ● | ● | | | ● | |
| `dim_*` | ● | ● | ● | ● | | | |
| `regional_scorecard_latest` | | ● | ● | ● | ● | ● | ● |
| `kpi_targets` | | | ● | ● | | | ● |
| `csat_survey_responses` | ● | ● | ● | | ● | ● | |
| `support_tickets` | | ● | ● | | ● | ● | ● |
| `branch_monthly` | | ● | ● | ● | ● | ● | ● |
| `investment_options` (+allocation) | | | ● | ● | ● | | ● |
| `dashboard_usability_tests` | | ● | ● | ● | ● | | ● |
| `rehearsal_scores` / `assessment_rubric` | | ● | ● | ● | | | ● |

---

## 5. The measure rules (read before building anything)

| Rule | Columns | Consequence |
|---|---|---|
| Additive | `transactions`, `complaints` | Safe to `SUM` at any grain |
| Semi-additive | `unique_users` | Sum within a month, never across months |
| **Non-additive** | `digital_adoption_pct`, `cost_per_txn_sar`, `csat`, `avg_completion_min`, `sla_met_pct` | Never `AVERAGE` — recompute from components |

```python
import pandas as pd, numpy as np
df = pd.read_csv("data/core/tayseer_services.csv", parse_dates=["month"])

TARGET = 65.0
def national_adoption(frame):                     # percentages are NON-additive
    return frame.groupby("month").apply(
        lambda x: 100 * (x.digital_adoption_pct / 100 * x.unique_users).sum()
                  / x.unique_users.sum())

latest = df[df.month == df.month.max()]
print(round(latest.digital_adoption_pct.mean(), 1))      # 61.2  <- the bug
print(round(national_adoption(df).iloc[-1], 1))          # 63.8  <- correct
```

`digital_adoption_pct` is a **segment-level** measure at `month × region × service_category`, repeated across that segment's four channel rows. That is exactly why the naive average is wrong and why weighting by `unique_users` is right — the teaching point is built into the grain.

## 6. Integrity guarantees

`docs/validation_report.md` records 33 automated checks, all passing. Among them:

- The fact grain is unique and complete (60 × 13 × 9 × 4 = 28,080 rows), with no nulls and no orphan keys
- Weighted national adoption **63.8%** vs naive **61.2%** — the deck's figures, reproducible
- Exactly **five** regions above the 18 SAR cost target, and they are the same five that have stalled on adoption
- Cost per transaction **−34%** and CSAT **+12%** across the window
- Transaction durations reproduce fact completion times (r = 0.997); survey CSAT tracks fact CSAT by region (r = 0.93)
- Each investment option allocates exactly SAR 40M; only the targeted option clears the regional target

## 7. Bilingual and accessibility notes

Column names and keys are English throughout, per the course's delivery standard. Arabic labels ship as *values* — `region_ar`, `category_ar`, `service_name_ar`, `comment_ar`, `month_name_ar` — so Module 3's Arabic RTL rendering exercise works without translating the schema. Files are UTF-8 with BOM for clean opening in Excel and Power BI on Windows. `brand_palette.csv` carries CVD-safety and contrast columns so the colour-blind simulation step has ground truth to check against.
