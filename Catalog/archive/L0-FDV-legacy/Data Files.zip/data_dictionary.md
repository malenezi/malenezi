# Data Dictionary — SDA-DSC-112 Tayseer dataset family

**Programme:** Data Visualization and Storytelling (SDA-DSC-112) · SDAIA Academy  
**Golden thread:** the Tayseer (تيسير) National Digital Services Programme  
**Coverage:** July 2021 – June 2026 (60 months) · 13 administrative regions · 9 service categories · 4 channels  
**All data is synthetic.** No real individual, entity or transaction is represented.

## 1. Grain and joins

```
dim_calendar (month) ─┐
dim_regions  (region) ─┼─→ tayseer_services  [month × region × service_category × channel]
dim_services (category)┤        ↑ 28,080 rows, the single fact table
dim_channels (channel) ┘
```

Every other dataset joins on `region`, `month`, `service_category`, `channel` or `service_id`.

## 2. The three measure rules

| Rule | Applies to | Consequence |
| --- | --- | --- |
| Additive | `transactions`, `complaints` | Safe to SUM at any grain |
| Semi-additive | `unique_users` | Sum within a month, never across months |
| **Non-additive** | `digital_adoption_pct`, `cost_per_txn_sar`, `csat`, `avg_completion_min`, `sla_met_pct` | Never AVERAGE — recompute from components |

The deliberate teaching artefact: for the latest month, `AVERAGE(digital_adoption_pct)` returns **61.2%** while the correct user-weighted recomputation returns **63.8%**. The 2.6-point gap is the averages-of-averages bug, and it is reproducible from the shipped data.

## 3. Seasonality built into the data

| Pattern | Months | Effect |
| --- | --- | --- |
| Ramadan | Feb–Apr (shifts each year) | Overall volume −14%, branch volume −28% |
| Hajj | May–Jul (shifts each year) | Makkah and Madinah +34% |
| School enrolment | August–September | Education & Training +48% |
| Year-end renewals | December | Traffic & Transport +27% |
| Summer lull | July–August | Most categories −7% |

## 4. Reference values at the latest month (June 2026)

| Measure | Value | Target |
| --- | --- | --- |
| National digital adoption (recomputed) | 63.8% | 65% |
| National digital adoption (naive average) | 61.2% | — (wrong method) |
| National cost per transaction | 16.94 SAR | 18 SAR |
| Regions above the 18 SAR cost target | 5 | 0 |
| National CSAT | 4.16 | 4.30 |
| Monthly transactions | 12.5 million | — |
| Five-year change | CSAT +12%, cost per transaction −34% | — |

## 5. Column reference

### `data/core/tayseer_services.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `month` | str | Reporting month, first day of month (YYYY-MM-01) | Join key to dim_calendar |
| 2 | `region` | str | Administrative region (English) | Join key to dim_regions.region |
| 3 | `service_category` | str | Service family | Join key to dim_services.service_category |
| 4 | `channel` | str | Delivery channel | Join key to dim_channels.channel |
| 5 | `transactions` | integer | Completed service transactions in the segment | ADDITIVE - safe to SUM |
| 6 | `unique_users` | integer | Distinct beneficiaries in the segment | Additive within a month only; do not sum across months |
| 7 | `digital_adoption_pct` | decimal | Share of the month x region x service_category segment delivered through digital channels | NON-ADDITIVE - repeated on all four channel rows of a segment. Recompute as SUM(pct/100*unique_users)/SUM(unique_users)*100 |
| 8 | `avg_completion_min` | decimal | Mean end-to-end completion time | NON-ADDITIVE - weight by transactions; long right tail at branches |
| 9 | `cost_per_txn_sar` | decimal | Fully loaded unit cost to deliver one transaction | NON-ADDITIVE - weight by transactions |
| 10 | `csat` | decimal | Mean satisfaction score, 1-5 | NON-ADDITIVE - weight by transactions |
| 11 | `sla_met_pct` | decimal | Share of transactions inside the service-level target | NON-ADDITIVE - weight by transactions |
| 12 | `complaints` | integer | Formal complaints logged in the segment | ADDITIVE - safe to SUM |

### `data/core/tayseer_services_raw.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `month` | str | Month |  |
| 2 | `region` | str | Region |  |
| 3 | `service_category` | str | Service category |  |
| 4 | `channel` | str | Channel |  |
| 5 | `transactions` | str | Transactions |  |
| 6 | `unique_users` | str | Unique users |  |
| 7 | `digital_adoption_pct` | str | Digital adoption (%) |  |
| 8 | `avg_completion_min` | decimal | Avg completion min |  |
| 9 | `cost_per_txn_sar` | decimal | Cost per txn (sar) |  |
| 10 | `csat` | str | Csat |  |
| 11 | `sla_met_pct` | str | Sla met (%) |  |
| 12 | `complaints` | integer | Complaints |  |
| 13 | `source_system` | str | System that supplied the row | Regional uploads carry most of the defects |
| 14 | `extract_ts` | str | Extraction timestamp | Use to resolve duplicate loads - keep the latest |

### `data/core/tayseer_transactions_sample.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `transaction_id` | str | Transaction id |  |
| 2 | `transaction_ts` | str | Transaction ts |  |
| 3 | `month` | str | Month |  |
| 4 | `region` | str | Region |  |
| 5 | `region_code` | str | Region code |  |
| 6 | `service_id` | str | Service id |  |
| 7 | `service_category` | str | Service category |  |
| 8 | `channel` | str | Channel |  |
| 9 | `user_type` | str | User type |  |
| 10 | `device_os` | str | Device os |  |
| 11 | `duration_min` | decimal | Duration of the individual transaction | Right-skewed; use median or a box plot, never a bar of means |
| 12 | `wait_min` | decimal | Queue or hold time before service starts | Zero by definition for digital channels |
| 13 | `completed_flag` | integer | Completed flag |  |
| 14 | `reopened_flag` | integer | Reopened flag |  |
| 15 | `first_time_right` | integer | First time right |  |
| 16 | `assisted_by_agent` | integer | Assisted by agent |  |
| 17 | `fee_paid_sar` | integer | Fee paid (sar) |  |
| 18 | `unit_cost_sar` | decimal | Unit cost (sar) |  |
| 19 | `csat_score` | decimal | Post-transaction rating, 1-5 | NULL for ~68% of rows - survey non-response, not a data error |

### `data/dimensions/dim_calendar.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `month` | str | Month |  |
| 2 | `year` | integer | Year |  |
| 3 | `month_num` | integer | Month num |  |
| 4 | `quarter` | str | Quarter |  |
| 5 | `fiscal_quarter` | str | Fiscal quarter |  |
| 6 | `month_name_en` | str | Month name en |  |
| 7 | `month_name_ar` | str | Month name ar |  |
| 8 | `hijri_month_approx` | str | Hijri month approx |  |
| 9 | `ramadan_flag` | integer | 1 when the month overlaps Ramadan | Branch volume falls ~28%; explains the annual dip |
| 10 | `hajj_season_flag` | integer | 1 when the month overlaps Hajj | Makkah and Madinah surge ~34% |
| 11 | `eid_flag` | integer | Eid flag |  |
| 12 | `school_term_flag` | integer | School term flag |  |
| 13 | `national_day_flag` | integer | National day flag |  |
| 14 | `working_days` | integer | Working days in the month | Normalise volumes before comparing months |
| 15 | `seasonality_note` | str | Seasonality note |  |

### `data/dimensions/dim_channels.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `channel` | str | Channel |  |
| 2 | `channel_ar` | str | Channel ar |  |
| 3 | `channel_type` | str | Channel type |  |
| 4 | `is_digital` | str | Is digital |  |
| 5 | `unit_cost_2026_sar` | decimal | Unit cost 2026 (sar) |  |
| 6 | `unit_cost_2021_sar` | decimal | Unit cost 2021 (sar) |  |
| 7 | `relative_handling_time` | decimal | Handling time relative to a branch visit (branch = 1.00) |  |
| 8 | `baseline_csat` | decimal | Baseline csat |  |
| 9 | `avg_transactions_per_user` | decimal | Repeat rate used to derive unique_users from transactions |  |
| 10 | `availability_hours` | str | Availability hours |  |
| 11 | `launch_year` | integer | Launch year |  |
| 12 | `accessibility_support` | str | Accessibility support |  |

### `data/dimensions/dim_regions.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `region_code` | str | Region code |  |
| 2 | `region` | str | Region |  |
| 3 | `region_ar` | str | Region ar |  |
| 4 | `capital_en` | str | Capital en |  |
| 5 | `capital_ar` | str | Capital ar |  |
| 6 | `population_2025` | integer | Regional population estimate | Denominator for every per-capita measure |
| 7 | `households_2025` | integer | Households 2025 |  |
| 8 | `area_km2` | integer | Area km2 |  |
| 9 | `internet_penetration_pct` | decimal | Internet penetration (%) |  |
| 10 | `smartphone_penetration_pct` | decimal | Smartphone penetration (%) |  |
| 11 | `digital_readiness_index` | decimal | Composite readiness score, 0-1 | Derived from connectivity indicators |
| 12 | `service_branches` | integer | Service branches |  |
| 13 | `adoption_trend_class` | str | Rising or stalled over the last nine months | Drives the Tier 1 intervention list |
| 14 | `priority_tier` | str | Tier 1 - intervention or Tier 2 - monitor | Five Tier 1 regions |
| 15 | `lat` | decimal | Lat |  |
| 16 | `lon` | decimal | Lon |  |

### `data/dimensions/dim_services.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `service_id` | str | Service id |  |
| 2 | `service_name_en` | str | Service name en |  |
| 3 | `service_name_ar` | str | Service name ar |  |
| 4 | `service_category` | str | Service category |  |
| 5 | `category_ar` | str | Category ar |  |
| 6 | `owning_entity` | str | Owning entity |  |
| 7 | `digitally_available` | str | Digitally available |  |
| 8 | `complexity` | str | Complexity |  |
| 9 | `target_completion_min` | integer | Target completion min |  |
| 10 | `statutory_fee_sar` | integer | Statutory fee (sar) |  |
| 11 | `launch_date` | str | Launch date |  |
| 12 | `annual_volume_rank` | integer | Annual volume rank |  |

### `data/instructional/assessment_rubric.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `criterion_id` | str | Criterion id |  |
| 2 | `component` | str | Component |  |
| 3 | `criterion` | str | Criterion |  |
| 4 | `weight` | decimal | Weight |  |
| 5 | `learning_outcome` | str | Learning outcome |  |
| 6 | `level_1_descriptor` | str | Level 1 descriptor |  |
| 7 | `level_2_descriptor` | str | Level 2 descriptor |  |
| 8 | `level_3_descriptor` | str | Level 3 descriptor |  |
| 9 | `level_4_descriptor` | str | Level 4 descriptor |  |
| 10 | `level_5_descriptor` | str | Level 5 descriptor |  |

### `data/instructional/brand_palette.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `token` | str | Token |  |
| 2 | `hex` | str | Hex |  |
| 3 | `name` | str | Name |  |
| 4 | `palette_type` | str | Palette type |  |
| 5 | `colour_blind_safe` | str | Colour blind safe |  |
| 6 | `contrast_ratio_on_white` | decimal | Contrast ratio on white |  |
| 7 | `usage_rule` | str | Usage rule |  |

### `data/instructional/chart_chooser.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `question_type` | str | Question type |  |
| 2 | `tayseer_question` | str | Tayseer question |  |
| 3 | `default_chart` | str | Default chart |  |
| 4 | `if_many_categories` | str | If many categories |  |
| 5 | `if_many_series` | str | If many series |  |
| 6 | `avoid` | str | Avoid |  |
| 7 | `primary_encoding_channel` | str | Primary encoding channel |  |
| 8 | `lab2_ref` | str | Lab2 ref |  |

### `data/instructional/dashboard_usability_tests.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `test_id` | str | Test id |  |
| 2 | `participant_id` | str | Participant id |  |
| 3 | `dashboard_version` | str | Dashboard version |  |
| 4 | `task_id` | str | Task id |  |
| 5 | `task` | str | Task |  |
| 6 | `time_to_answer_sec` | decimal | Time to answer sec |  |
| 7 | `gave_up` | integer | Gave up |  |
| 8 | `answer_correct` | integer | Answer correct |  |
| 9 | `clicks_used` | integer | Clicks used |  |
| 10 | `confidence_1_5` | integer | Confidence 1 5 |  |
| 11 | `tested_on` | str | Tested on |  |
| 12 | `tester_role` | str | Tester role |  |

### `data/instructional/encoding_accuracy_ranking.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `rank` | integer | Rank |  |
| 2 | `channel_en` | str | Channel en |  |
| 3 | `channel_ar` | str | Channel ar |  |
| 4 | `decoding_accuracy` | str | Decoding accuracy |  |
| 5 | `relative_accuracy_index` | decimal | Relative accuracy index |  |
| 6 | `use_for` | str | Use for |  |
| 7 | `tayseer_example` | str | Tayseer example |  |
| 8 | `warning` | str | Warning |  |

### `data/instructional/knowledge_check_bank.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `item_id` | str | Item id |  |
| 2 | `module` | integer | Module |  |
| 3 | `question` | str | Question |  |
| 4 | `model_answer` | str | Model answer |  |
| 5 | `learning_outcome` | str | Learning outcome |  |
| 6 | `cognitive_level` | str | Cognitive level |  |
| 7 | `benchmark_pass_mark` | str | Benchmark pass mark |  |

### `data/instructional/lab2_questions.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `question_id` | str | Question id |  |
| 2 | `question` | str | Question |  |
| 3 | `question_type` | str | Question type |  |
| 4 | `columns_needed` | str | Columns needed |  |
| 5 | `expected_chart` | str | Expected chart |  |
| 6 | `rationale` | str | Rationale |  |
| 7 | `expected_insight` | str | Expected insight |  |

### `data/instructional/participants_roster.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `participant_id` | str | Participant id |  |
| 2 | `display_name` | str | Display name |  |
| 3 | `entity` | str | Entity |  |
| 4 | `job_family` | str | Job family |  |
| 5 | `years_experience` | integer | Years experience |  |
| 6 | `prerequisite_sda_fnd_104` | str | Prerequisite sda fnd 104 |  |
| 7 | `primary_tool` | str | Primary tool |  |
| 8 | `preferred_delivery_language` | str | Preferred delivery language |  |
| 9 | `pre_assessment_score_pct` | integer | Pre assessment score (%) |  |
| 10 | `cohort` | str | Cohort |  |
| 11 | `attendance_day1` | integer | Attendance day1 |  |
| 12 | `attendance_day2` | integer | Attendance day2 |  |
| 13 | `attendance_day3` | integer | Attendance day3 |  |

### `data/instructional/qa_bank.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `qa_id` | str | Qa id |  |
| 2 | `question_type` | str | Question type |  |
| 3 | `question` | str | Question |  |
| 4 | `model_answer` | str | Model answer |  |
| 5 | `bridge_back_to_big_idea` | str | Bridge back to big idea |  |
| 6 | `appendix_reference` | str | Appendix reference |  |
| 7 | `likelihood` | str | Likelihood |  |

### `data/instructional/rehearsal_scores.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `participant_id` | str | Participant id |  |
| 2 | `round` | integer | Round |  |
| 3 | `criterion` | str | Criterion |  |
| 4 | `weight` | decimal | Weight |  |
| 5 | `score_0_5` | integer | Score 0 5 |  |
| 6 | `assessor` | str | Assessor |  |
| 7 | `recorded` | str | Recorded |  |
| 8 | `round_total_pct` | integer | Round total (%) |  |
| 9 | `delta_vs_round1_pp` | integer | Delta vs round1 pp |  |
| 10 | `time_used_sec` | integer | Time used sec |  |

### `data/supporting/branch_monthly.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `month` | str | Month |  |
| 2 | `branch_id` | str | Branch id |  |
| 3 | `branch_name_en` | str | Branch name en |  |
| 4 | `branch_name_ar` | str | Branch name ar |  |
| 5 | `region` | str | Region |  |
| 6 | `region_code` | str | Region code |  |
| 7 | `city` | str | City |  |
| 8 | `branch_size` | str | Branch size |  |
| 9 | `visits` | integer | Visits |  |
| 10 | `appointments_share_pct` | decimal | Appointments share (%) |  |
| 11 | `avg_wait_min` | decimal | Avg wait min |  |
| 12 | `staff_fte` | integer | Staff fte |  |
| 13 | `operating_cost_sar` | integer | Operating cost (sar) |  |
| 14 | `cost_per_visit_sar` | decimal | Operating cost divided by visits | Rises as visits fall - fixed-cost evidence |
| 15 | `utilisation_pct` | decimal | Utilisation (%) |  |
| 16 | `self_service_kiosk` | str | Self service kiosk |  |

### `data/supporting/csat_survey_responses.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `response_id` | str | Response id |  |
| 2 | `survey_date` | str | Survey date |  |
| 3 | `month` | str | Month |  |
| 4 | `region` | str | Region |  |
| 5 | `region_code` | str | Region code |  |
| 6 | `service_category` | str | Service category |  |
| 7 | `channel` | str | Channel |  |
| 8 | `respondent_type` | str | Respondent type |  |
| 9 | `age_band` | str | Age band |  |
| 10 | `csat_1_5` | integer | Csat 1 5 |  |
| 11 | `ease_of_use_1_5` | integer | Ease of use 1 5 |  |
| 12 | `nps_0_10` | integer | Nps 0 10 |  |
| 13 | `resolved_first_contact` | integer | Resolved first contact |  |
| 14 | `would_recommend` | str | Would recommend |  |
| 15 | `sentiment` | str | Positive / Neutral / Negative derived from csat_1_5 | Use for qualitative evidence scenes |
| 16 | `comment_en` | str | Comment en |  |
| 17 | `comment_ar` | str | Free-text comment in Arabic | Synthetic; safe for RTL rendering practice |

### `data/supporting/investment_option_region_allocation.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `option_id` | str | Option id |  |
| 2 | `region` | str | Region |  |
| 3 | `region_code` | str | Region code |  |
| 4 | `in_scope` | str | In scope |  |
| 5 | `intervention_type` | str | Intervention type |  |
| 6 | `current_adoption_pct` | decimal | Current adoption (%) |  |
| 7 | `expected_gain_pp` | decimal | Expected gain pp |  |
| 8 | `projected_adoption_dec_2026_pct` | decimal | Projected adoption dec 2026 (%) |  |
| 9 | `reaches_65_by_dec` | str | Reaches 65 by dec |  |
| 10 | `users_reached_monthly` | integer | Users reached monthly |  |
| 11 | `allocation_sar` | integer | Allocation (sar) |  |
| 12 | `cost_per_pp_sar_m` | decimal | Cost per pp (sar) m |  |

### `data/supporting/investment_options.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `option_id` | str | Option id |  |
| 2 | `option_name_en` | str | Option name en |  |
| 3 | `option_name_ar` | str | Option name ar |  |
| 4 | `investment_sar` | integer | Investment (sar) |  |
| 5 | `time_to_impact_months` | integer | Time to impact months |  |
| 6 | `expected_gain_in_scope_pp` | decimal | Expected gain in scope pp |  |
| 7 | `realised_gain_by_dec_2026_pp` | decimal | Portion of the full effect delivered before the December checkpoint | Pro-rated by time to impact |
| 8 | `expected_national_gain_pp` | decimal | Expected national gain pp |  |
| 9 | `projected_national_adoption_dec_2026_pct` | decimal | Projected national adoption dec 2026 (%) |  |
| 10 | `stalled_regions_reaching_65_by_dec` | integer | How many of the five Tier 1 regions clear 65% by December | The ask is regional, so this is the deciding column |
| 11 | `regions_below_target_dec_2026` | integer | Regions below target dec 2026 |  |
| 12 | `transactions_shifted_monthly` | integer | Transactions shifted monthly |  |
| 13 | `annual_cost_saving_sar_m` | decimal | Annual cost saving (sar) m |  |
| 14 | `gap_closed_pp_per_sar_m` | decimal | National percentage points of adoption gained per SAR 1 million | The comparison metric for the capstone recommendation |
| 15 | `payback_months_incl_lag` | decimal | Payback months incl lag |  |
| 16 | `delivery_risk` | str | Delivery risk |  |
| 17 | `key_dependency` | str | Key dependency |  |
| 18 | `supporting_evidence` | str | Supporting evidence |  |

### `data/supporting/kpi_targets.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `kpi_id` | str | Kpi id |  |
| 2 | `kpi_name_en` | str | Kpi name en |  |
| 3 | `kpi_name_ar` | str | Kpi name ar |  |
| 4 | `unit` | str | Unit |  |
| 5 | `direction` | str | Direction |  |
| 6 | `grain` | str | Grain |  |
| 7 | `formula` | str | Query-time definition of the measure | Mirror this in DAX or a Tableau calculated field |
| 8 | `is_additive` | str | Whether the measure may be summed or averaged directly | 'No' means recompute from components |
| 9 | `baseline_2021` | decimal | Baseline 2021 |  |
| 10 | `current_value` | decimal | Current value |  |
| 11 | `target_2026` | decimal | Target 2026 |  |
| 12 | `threshold_red` | decimal | Threshold red |  |
| 13 | `threshold_amber` | decimal | Threshold amber |  |
| 14 | `threshold_green` | decimal | Threshold green |  |
| 15 | `owner` | str | Owner |  |
| 16 | `cadence` | str | Cadence |  |

### `data/supporting/region_directors.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `email` | str | Email |  |
| 2 | `display_name_en` | str | Display name en |  |
| 3 | `display_name_ar` | str | Display name ar |  |
| 4 | `region` | str | Region |  |
| 5 | `region_code` | str | Region code |  |
| 6 | `role_title` | str | Role title |  |
| 7 | `rls_role` | str | Rls role |  |
| 8 | `entity` | str | Entity |  |
| 9 | `reports_to` | str | Reports to |  |
| 10 | `appointed_date` | str | Appointed date |  |
| 11 | `dashboard_access_level` | str | Dashboard access level |  |
| 12 | `is_active` | integer | Is active |  |

### `data/supporting/regional_scorecard_latest.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `region` | str | Region |  |
| 2 | `region_code` | str | Region code |  |
| 3 | `region_ar` | str | Region ar |  |
| 4 | `population_2025` | integer | Population 2025 |  |
| 5 | `digital_adoption_pct` | decimal | Digital adoption (%) |  |
| 6 | `gap_to_target_pp` | decimal | Gap to target pp |  |
| 7 | `cost_per_txn_sar` | decimal | Cost per txn (sar) |  |
| 8 | `csat` | decimal | Csat |  |
| 9 | `avg_completion_min` | decimal | Avg completion min |  |
| 10 | `monthly_transactions` | integer | Monthly transactions |  |
| 11 | `monthly_unique_users` | integer | Monthly unique users |  |
| 12 | `digital_txn_per_1k_pop` | decimal | Digital transactions per 1,000 residents | Retires the 'those regions are just small' objection |
| 13 | `txn_per_1k_pop` | decimal | Txn per 1k pop |  |
| 14 | `adoption_9m_ago_pct` | decimal | Adoption 9m ago (%) |  |
| 15 | `adoption_slope_pp_per_month` | decimal | Percentage points of adoption gained per month over the last nine months | The stall detector |
| 16 | `trend_class` | str | Trend class |  |
| 17 | `priority_tier` | str | Priority tier |  |
| 18 | `projected_dec_2026_pct` | decimal | Current adoption plus six months at the current slope | Do-nothing projection |
| 19 | `reaches_target_unaided` | str | Reaches target unaided |  |

### `data/supporting/support_tickets.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `ticket_id` | str | Ticket id |  |
| 2 | `opened_ts` | str | Opened ts |  |
| 3 | `region` | str | Region |  |
| 4 | `region_code` | str | Region code |  |
| 5 | `service_category` | str | Service category |  |
| 6 | `channel` | str | Channel |  |
| 7 | `issue_category` | str | Operational issue type | Authentication dominates in the five stalled regions |
| 8 | `severity` | str | Severity |  |
| 9 | `reported_by` | str | Reported by |  |
| 10 | `resolution_hours` | decimal | Resolution hours |  |
| 11 | `sla_target_hours` | integer | Sla target hours |  |
| 12 | `reopened` | integer | Reopened |  |
| 13 | `root_cause` | str | Root cause |  |
| 14 | `resolved_by_team` | str | Resolved by team |  |
| 15 | `escalated_flag` | integer | Escalated flag |  |
| 16 | `sla_breached` | integer | 1 when resolution_hours exceeded sla_target_hours | Derived field |

### `docs/data_quality_issue_key.csv`

| # | Column | Type | Description | Notes |
| --- | --- | --- | --- | --- |
| 1 | `row_hint` | integer | Row hint |  |
| 2 | `column` | str | Column |  |
| 3 | `issue_type` | str | Issue type |  |
| 4 | `expected_fix` | str | Expected fix |  |
