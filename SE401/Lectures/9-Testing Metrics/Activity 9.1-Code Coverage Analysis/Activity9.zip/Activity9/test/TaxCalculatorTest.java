import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import junit.framework.TestCase;



public class TaxCalculatorTest extends TestCase{

    /**
     * This is a private variable which holds the tax calculator interface.
     */
    private TaxCalculatorInterface calculator;
    
    @Test
    public void testFilingStatusShouldBeCorrectFor() {
      //1
          calculator = new TaxCalculator("Mohammed Ahmed", 70, TaxCalculatorInterface.QUALIFYING_WIDOWER);
          assertEquals(calculator.getFilingStatus(), TaxCalculatorInterface.QUALIFYING_WIDOWER);
      }
    @Test
    public void testStatus() {
          calculator = new TaxCalculator("Mohammed Ahmed", 30, TaxCalculatorInterface.MARRIED_FILING_JOINTLY, 40);
          assertEquals(calculator.getFilingStatus(), TaxCalculatorInterface.MARRIED_FILING_JOINTLY);
      }
    @Test
    public void testisReturnRequiredSingleStatus() {
      //1
          calculator = new TaxCalculator("Mohammed Ahmed", 30, TaxCalculatorInterface.SINGLE);
          calculator.setGrossIncome(8949.00);
          assertEquals(calculator.isReturnRequired(), false);
          //2
          calculator = new TaxCalculator("Mohammed Ahmed", 30, TaxCalculatorInterface.SINGLE);
          calculator.setGrossIncome(8950.00);
          assertEquals(calculator.isReturnRequired(), true);
          //3
          calculator = new TaxCalculator("Mohammed Ahmed", 70, TaxCalculatorInterface.SINGLE);
          calculator.setGrossIncome(10299.00);
          assertEquals(calculator.isReturnRequired(), false);
          //4
          calculator = new TaxCalculator("Mohammed Ahmed", 70, TaxCalculatorInterface.SINGLE);
          calculator.setGrossIncome(10300.00);
          assertEquals(calculator.isReturnRequired(), true);
          //5
          calculator = new TaxCalculator("Mohammed Ahmed", 40, TaxCalculatorInterface.HEAD_OF_HOUSEHOLD);
          calculator.setGrossIncome(11499.00);
          assertEquals(calculator.isReturnRequired(), false);
         //6
          calculator = new TaxCalculator("Mohammed Ahmed", 40, TaxCalculatorInterface.HEAD_OF_HOUSEHOLD);
          calculator.setGrossIncome(11500.00);
          assertEquals(calculator.isReturnRequired(), true);
          //7
          calculator = new TaxCalculator("Mohammed Ahmed", 70, TaxCalculatorInterface.HEAD_OF_HOUSEHOLD);
          calculator.setGrossIncome(12849.00);
          assertEquals(calculator.isReturnRequired(), false);
          //8
          calculator = new TaxCalculator("Mohammed Ahmed", 70, TaxCalculatorInterface.HEAD_OF_HOUSEHOLD);
          calculator.setGrossIncome(12850.00);
          assertEquals(calculator.isReturnRequired(), true);
         //9
          calculator = new TaxCalculator("Mohammed Ahmed", 70, TaxCalculatorInterface.QUALIFYING_WIDOWER);
          calculator.setGrossIncome(15449.00);
          assertEquals(calculator.isReturnRequired(), false);
          //10
          calculator = new TaxCalculator("Mohammed Ahmed", 70, TaxCalculatorInterface.QUALIFYING_WIDOWER);
          calculator.setGrossIncome(15450.00);
          assertEquals(calculator.isReturnRequired(), true);
          
          
      }
    
    @Test
    public void testIsReturnRequiredSingleStatus() throws IllegalArgumentException {
        // 1
        calculator = new TaxCalculator("Mohammed Ahmed", 30, 
            TaxCalculatorInterface.MARRIED_FILING_JOINTLY, 40);
        calculator.setGrossIncome(17899.00);
        assertEquals(calculator.isReturnRequired(), false);
        //2
        calculator = new TaxCalculator("Mohammed Ahmed", 30, 
            TaxCalculatorInterface.MARRIED_FILING_JOINTLY, 40);
        calculator.setGrossIncome(17901.00);
        assertEquals(calculator.isReturnRequired(), true);

    }
    @Test
    public void testStandardDeductionIsCorrectForSingleStatuses() {
          calculator = new TaxCalculator("Mohammed Ahmed", 30, TaxCalculatorInterface.SINGLE);

          assertEquals(calculator.getStandardDeduction(), 5450.00, 1.00);
      }
    @Test
    public void testStandardDeductionIsCorrectForMarriedStatuses(int status, int age, int spouseAge, double standardDeduction) {
          calculator = new TaxCalculator("Mohammed Ahmed", 30, TaxCalculatorInterface.MARRIED_FILING_JOINTLY, 40);
          assertEquals(calculator.getStandardDeduction(), 10900.00, 1.00);
      }
    @Test
    public void testTaxableIncomeShouldBeCorrectForSingleStatuses() {
      
      calculator = new TaxCalculator("Mohammed Ahmed", 30, TaxCalculatorInterface.SINGLE);

      
      calculator.setGrossIncome(5450.00);
      assertEquals(calculator.getTaxableIncome(), 0.00);
    }
    @Test
    public void testTaxableIncomeShouldBeCorrectForMarriedStatuses() {
      
      calculator = new TaxCalculator("Mohammed Ahmed", 30, 
          TaxCalculatorInterface.MARRIED_FILING_JOINTLY, 29);

      calculator.setGrossIncome(26949.00);

      assertEquals(calculator.getTaxableIncome(), 16049.00);
    }
    @Test
    public void testNetTaxRateShouldBeCorrectForSingleStatuses() {
      // Arrange - Instantiate a new tax calculator without a spouse.
      calculator = new TaxCalculator("Mohammed Ahmed", 30, TaxCalculatorInterface.SINGLE);

      double netTaxRate = 0.00;
      if (5450.00 != 0) {
        netTaxRate = (0.00) / 5450.00;
      }
      calculator.setGrossIncome(5450.00);

      assertEquals(calculator.getNetTaxRate(), netTaxRate, 0.01);
    }
    @Test
    public void testGetNetTaxRateShouldBeCorrectForMarriedStatuses() {
      calculator = new TaxCalculator("Mohammed Ahmed", 30, 
          TaxCalculatorInterface.MARRIED_FILING_JOINTLY, 29);

      double netTaxRate = 0.00;
      if (26949.00 != 0) {
        netTaxRate = (16049.00) / 26949.00;
      }
      calculator.setGrossIncome(26949.00);
      assertEquals(calculator.getNetTaxRate(), netTaxRate, 0.01);
    }
    @Test
    public void testTaxDueShouldBeCorrectForSingleStatuses() {
      calculator = new TaxCalculator("Mohammed Ahmed", 30, TaxCalculatorInterface.SINGLE);
      calculator.setGrossIncome(5450.00);

      assertEquals(calculator.getTaxDue(), 0.00, 0.01);
    }
    @Test
    public void testTaxDueShouldBeCorrectForMarriedStatuses() {
      calculator = new TaxCalculator("Mohammed Ahmed", 30, 
          TaxCalculatorInterface.MARRIED_FILING_JOINTLY, 29);
      calculator.setGrossIncome(26949.00);

      assertEquals(calculator.getTaxDue(), 1604.9, 0.01);
    }
}
