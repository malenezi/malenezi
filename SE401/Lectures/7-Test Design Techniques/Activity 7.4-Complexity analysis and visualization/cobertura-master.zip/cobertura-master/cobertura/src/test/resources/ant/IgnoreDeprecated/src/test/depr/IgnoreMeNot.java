package test.depr;


public class IgnoreMeNot {
  public static void foo() {
    System.out.println("Don't Ignore Me");
  }
}
