
<hr/>

<div id="footer">
All material copyright 2005 Mark Doliner, unless otherwise noted.<br/>
<a href="http://validator.w3.org/check/referer">XHTML 1.0</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS 2</a>
</div>



</div>



</body>

</html>
