
public class Singleton {
	private static Singleton instance = new Singleton();
}
