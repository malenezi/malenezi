
public class ExternalStaticField {
	private final static ExceptionInInitializer eii = new ExceptionInInitializer();
}
