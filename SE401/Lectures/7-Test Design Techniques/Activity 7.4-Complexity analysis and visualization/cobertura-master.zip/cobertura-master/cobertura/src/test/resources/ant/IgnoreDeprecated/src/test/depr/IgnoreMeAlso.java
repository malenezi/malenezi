package test.depr;

@Deprecated
public class IgnoreMeAlso {
  public static void foo() {
    System.out.println("Ignore Me Too!");
  }
}
