package test.condition;

import junit.framework.TestCase;

public class Test extends TestCase {
}
