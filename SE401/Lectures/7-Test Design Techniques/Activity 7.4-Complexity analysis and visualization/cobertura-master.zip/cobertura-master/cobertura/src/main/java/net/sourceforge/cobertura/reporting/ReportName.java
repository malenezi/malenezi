package net.sourceforge.cobertura.reporting;

public enum ReportName {
	COVERAGE_REPORT, THRESHOLDS_REPORT, COMPLEXITY_REPORT, COMPOSITE_REPORT, NULL_REPORT
}
