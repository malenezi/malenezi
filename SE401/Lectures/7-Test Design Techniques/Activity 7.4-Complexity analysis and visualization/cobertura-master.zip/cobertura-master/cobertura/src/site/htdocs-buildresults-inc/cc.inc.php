<?php

include("${projecthome}/htdocs-buildresults-inc/util.inc.php");
include("${projecthome}/htdocs-buildresults-inc/cc_util.inc.php");
include("${projecthome}/htdocs-buildresults-inc/navigation.inc.php");

?>
