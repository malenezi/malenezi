
public class Simple {
	private int a, b;

	public void simple(int c) {
		// do some stuff
		a = c; 
		b = 2*a+c;
	}
}
