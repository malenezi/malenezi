package test.depr;

public class IgnoreMe {
  @Deprecated
  public static void foo() {
    System.out.println("Ignore Me");
  }
}
