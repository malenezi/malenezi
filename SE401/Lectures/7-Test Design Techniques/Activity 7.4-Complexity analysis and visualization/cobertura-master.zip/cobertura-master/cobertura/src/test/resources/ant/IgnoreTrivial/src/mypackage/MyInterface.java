package mypackage;

public interface MyInterface {
	public void myInterfaceMethod();
}
