// 
// Decompiled by Procyon v0.5.36
// 

package edu.msoe.se1010.winPlotter;

import java.awt.Color;
import java.awt.Point;

public class WinPlotter
{
    private SketchPad sp;
    private int width;
    private int height;
    private int xmin;
    private int ymin;
    private int xmax;
    private int ymax;
    private float xscale;
    private float yscale;
    private boolean showGrid;
    
    public WinPlotter() {
        (this.sp = new SketchPad()).setWindowTitle("A plot of something");
        final int n = 100;
        this.height = n;
        this.width = n;
        this.setPlotBoundaries(0, 0, 100, 100);
        this.showGrid = false;
    }
    
    private Point logicalToPixel(final int xlog, final int ylog) {
        final Point p = new Point();
        p.x = (int)(this.xscale * (xlog - this.xmin));
        p.y = this.height - (int)(this.yscale * (ylog - this.ymin));
        return p;
    }
    
    public void drawTo(final int x, final int y) {
        final Point p = this.logicalToPixel(x, y);
        this.sp.drawLineTo(p.x, p.y);
    }
    
    public void erase() {
        this.sp.erase();
    }
    
    public void moveTo(final int x, final int y) {
        final Point p = this.logicalToPixel(x, y);
        this.sp.moveTo(p.x, p.y);
    }
    
    public void drawPoint(final int x, final int y) {
        final Point p = this.logicalToPixel(x, y);
        this.sp.drawPointAt(p.x, p.y);
    }
    
    public void printAt(final int x, final int y, final String text) {
        final Point p = this.logicalToPixel(x, y);
        this.sp.textAt(p.x, p.y, text);
        this.sp.moveTo(p.x, p.y);
    }
    
    public void setBackgroundColor(int red, int green, int blue) {
        if (red < 0 || red > 255) {
            red = 0;
        }
        if (green < 0 || green > 255) {
            green = 0;
        }
        if (blue < 0 || blue > 255) {
            blue = 0;
        }
        final Color backColor = new Color(red, green, blue);
        this.sp.setBackgroundColor(backColor);
    }
    
    public void setPenColor(int red, int green, int blue) {
        if (red < 0 || red > 255) {
            red = 0;
        }
        if (green < 0 || green > 255) {
            green = 0;
        }
        if (blue < 0 || blue > 255) {
            blue = 0;
        }
        final Color penColor = new Color(red, green, blue);
        this.sp.setPenColor(penColor);
    }
    
    public boolean setWindowSize(final int width, final int height) {
        if (width <= 0 || height <= 0) {
            return false;
        }
        this.width = width;
        this.height = height;
        this.sp.setWindowSize(width, height);
        return true;
    }
    
    public boolean setPlotBoundaries(final int xmin, final int ymin, final int xmax, final int ymax) {
        if (xmin >= xmax || ymin >= ymax) {
            return false;
        }
        this.xmin = xmin;
        this.ymin = ymin;
        this.xmax = xmax;
        this.ymax = ymax;
        this.xscale = this.width / (float)(xmax - xmin);
        this.yscale = this.height / (float)(ymax - ymin);
        return true;
    }
    
    public boolean setGrid(final boolean showGrid, final int xinc, final int yinc, final Color gridColor) {
        if (!showGrid) {
            this.sp.setGrid(showGrid, 1, 1, Color.BLACK);
        }
        if (xinc > this.xmax - this.xmin || yinc > this.ymax - this.ymin) {
            return false;
        }
        final int gridXinc = (int)(this.xscale * xinc);
        final int gridYinc = (int)(this.yscale * yinc);
        this.sp.setGrid(showGrid, gridXinc, gridYinc, gridColor);
        return true;
    }
    
    public void setWindowTitle(final String title) {
        this.sp.setWindowTitle(title);
    }
}
