// 
// Decompiled by Procyon v0.5.36
// 

package edu.msoe.se1010.winPlotter;

import java.awt.Font;
import java.awt.Rectangle;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import java.util.ArrayList;
import java.awt.Color;
import javax.swing.JFrame;

class SketchPad extends JFrame
{
    private Color currentPenColor;
    private ArrayList items;
    private Container contentPane;
    private boolean showGrid;
    private Color backgroundColor;
    private int xinc;
    private int yinc;
    private Color gridColor;
    private DrawPanel drawPanel;
    
    public SketchPad() {
        (this.items = new ArrayList()).clear();
        super.setDefaultCloseOperation(2);
        super.setResizable(false);
        (this.contentPane = super.getContentPane()).setLayout(null);
        this.setWindowTitle("CS1010 SketchPad 1.0");
        this.add(this.drawPanel = new DrawPanel());
        this.drawPanel.setSize(200, 200);
        this.currentPenColor = Color.BLACK;
        this.backgroundColor = Color.WHITE;
        this.setWindowSize(100, 100);
        super.setLocation(10, 10);
        this.contentPane.setBackground(Color.BLACK);
        this.drawPanel.setBackground(Color.BLACK);
        super.setVisible(true);
    }
    
    public void setWindowSize(final int x, final int y) {
        super.setSize(x, y);
        this.drawPanel.setSize(x, y);
        super.validate();
        super.repaint();
    }
    
    public void erase() {
        this.items.clear();
        super.repaint();
    }
    
    public void setWindowTitle(final String title) {
        super.setTitle(title);
        super.repaint();
    }
    
    public void setPenColor(final Color c) {
        this.currentPenColor = c;
    }
    
    public void setBackgroundColor(final Color backgroundColor) {
        this.drawPanel.setBackground(backgroundColor);
        this.contentPane.setBackground(backgroundColor);
        this.backgroundColor = backgroundColor;
        super.repaint();
    }
    
    public void drawLineTo(final int x, final int y) {
        this.items.add(new DrawItem(x, y, 1, this.currentPenColor));
        super.repaint();
    }
    
    public void moveTo(final int x, final int y) {
        this.items.add(new DrawItem(x, y, 0, this.currentPenColor));
    }
    
    public void drawPointAt(final int x, final int y) {
        this.items.add(new DrawItem(x, y, 2, this.currentPenColor));
        super.repaint();
    }
    
    public void textAt(final int x, final int y, final String text) {
        this.items.add(new DrawItem(x, y, 3, this.currentPenColor, text));
        super.repaint();
    }
    
    public void setGrid(final boolean showGrid, final int xinc, final int yinc, final Color gridColor) {
        this.showGrid = showGrid;
        this.xinc = xinc;
        this.yinc = yinc;
        this.gridColor = gridColor;
    }
    
    @Override
    public void paint(final Graphics gr) {
        super.paint(gr);
    }
    
    public class DrawPanel extends JPanel
    {
        @Override
        protected void paintComponent(final Graphics g) {
            System.out.println("DrawPanel paint");
            this.doPaint(g);
        }
        
        public void doPaint(final Graphics gr) {
            System.out.println("doPainting");
            final Rectangle r = this.getBounds();
            gr.setColor(SketchPad.this.backgroundColor);
            gr.fillRect(r.x, r.y, r.width, r.height);
            if (SketchPad.this.showGrid) {
                gr.setColor(SketchPad.this.gridColor);
                for (int x = SketchPad.this.xinc; x < super.getSize().width; x += SketchPad.this.xinc) {
                    gr.drawLine(x, 0, x, super.getSize().height);
                }
                for (int y = SketchPad.this.yinc; y < super.getSize().height; y += SketchPad.this.yinc) {
                    gr.drawLine(0, y, super.getSize().width, y);
                }
            }
            int cur_x = 0;
            int cur_y = 0;
            for (int size = SketchPad.this.items.size(), i = 0; i < size; ++i) {
                final DrawItem di = SketchPad.this.items.get(i);
                switch (di.opCode) {
                    case 0: {
                        cur_x = di.x;
                        cur_y = di.y;
                        break;
                    }
                    case 1: {
                        gr.setColor(di.color);
                        gr.drawLine(cur_x, cur_y, di.x, di.y);
                        cur_x = di.x;
                        cur_y = di.y;
                        break;
                    }
                    case 2: {
                        gr.setColor(di.color);
                        gr.fillOval(di.x - 4, di.y - 4, 8, 8);
                        cur_x = di.x;
                        cur_y = di.y;
                        break;
                    }
                    case 3: {
                        gr.setColor(di.color);
                        final Font f = gr.getFont();
                        final Font f2 = f.deriveFont(12.0f);
                        gr.setFont(f2);
                        gr.drawString(di.text, di.x, di.y);
                        break;
                    }
                }
            }
        }
    }
}
