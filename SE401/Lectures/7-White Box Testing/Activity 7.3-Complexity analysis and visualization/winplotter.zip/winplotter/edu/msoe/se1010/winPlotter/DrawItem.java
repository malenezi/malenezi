// 
// Decompiled by Procyon v0.5.36
// 

package edu.msoe.se1010.winPlotter;

import java.awt.Color;

class DrawItem
{
    public static final int MOVE = 0;
    public static final int DRAW = 1;
    public static final int POINT = 2;
    public static final int TEXT = 3;
    public int opCode;
    public int x;
    public int y;
    public String text;
    public Color color;
    
    public DrawItem(final int x, final int y, final int opCode, final Color color) {
        this(x, y, opCode, color, "");
    }
    
    public DrawItem(final int x, final int y, final int opCode, final Color color, final String text) {
        this.x = 0;
        this.y = 0;
        this.x = x;
        this.y = y;
        this.opCode = opCode;
        this.color = color;
        this.text = text;
    }
}
