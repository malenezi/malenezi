package org.checkstyle.suppressionxpathfilter.abbreviationaswordinname;

public class SuppressionXpathRegressionAbbreviationAsWordInNameInterface {

    interface INTERFACE { // warn

    }

}
