package org.checkstyle.suppressionxpathfilter.annotationonsameline;

import java.util.ArrayList;
import java.util.List;

public class SuppressionXpathRegressionAnnotationOnSameLineTwo {
    @Deprecated //warn
    private List<String> names = new ArrayList<>();
}
