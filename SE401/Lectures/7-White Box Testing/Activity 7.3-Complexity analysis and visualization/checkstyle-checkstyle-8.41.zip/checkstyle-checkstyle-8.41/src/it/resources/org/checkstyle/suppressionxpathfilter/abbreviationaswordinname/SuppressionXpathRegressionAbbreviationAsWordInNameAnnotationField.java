package org.checkstyle.suppressionxpathfilter.abbreviationaswordinname;

public @interface SuppressionXpathRegressionAbbreviationAsWordInNameAnnotationField {

    String ANNOTATION_FIELD(); // warn

}
