//non-compiled with javac: Compilable with Java14
package com.puppycrawl.tools.checkstyle.checks.sizes.recordcomponentname;

/* Config: default
 */
public record SuppressionXpathRecordComponentName1(int _value) { // warn

}
