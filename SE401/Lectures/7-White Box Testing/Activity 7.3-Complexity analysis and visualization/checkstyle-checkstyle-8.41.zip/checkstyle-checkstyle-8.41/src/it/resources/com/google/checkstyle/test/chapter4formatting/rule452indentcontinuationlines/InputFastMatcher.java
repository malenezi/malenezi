package com.google.checkstyle.test.chapter4formatting.rule452indentcontinuationlines;

public class InputFastMatcher
{

    public boolean matches(char c)
    {
        // OOOO Auto-generated method stub
        return false;
    }

    public String replaceFrom(CharSequence sequence, CharSequence replacement)
    {
        // OOOO Auto-generated method stub
        return null;
    }

    public String collapseFrom(CharSequence sequence, char replacement)
    {
        // OOOO Auto-generated method stub
        return null;
    }

    public String trimFrom(CharSequence s)
    {
        // OOOO Auto-generated method stub
        return null;
    }

    public String trimLeadingFrom(CharSequence sequence)
    {
        // OOOO Auto-generated method stub
        return null;
    }

    public String trimTrailingFrom(CharSequence sequence)
    {
        // OOOO Auto-generated method stub
        return null;
    }

}
