package com.google.checkstyle.test.chapter5naming.rule521$packagenames; //warn
final class InputPackageBadName3 {}
