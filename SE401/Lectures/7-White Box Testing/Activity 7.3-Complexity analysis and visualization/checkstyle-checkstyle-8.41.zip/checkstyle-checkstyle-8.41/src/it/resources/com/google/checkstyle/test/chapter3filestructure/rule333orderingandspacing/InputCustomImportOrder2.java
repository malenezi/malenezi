package com.google.checkstyle.test.chapter3filestructure.rule333orderingandspacing;

import static java.io.File.createTempFile;
import static java.awt.Button.ABORT; //warn
import static javax.swing.WindowConstants.*;

import java.util.List;
import java.util.StringTokenizer;
import java.util.*; //warn
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.*; //warn

import com.google.checkstyle.test.chapter2filebasic.rule21filename.*; //warn
import com.google.checkstyle.test.chapter3filestructure.rule3sourcefile.*; //warn

import com.google.common.reflect.*; //warn

public class InputCustomImportOrder2 {
}
