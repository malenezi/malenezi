package org.checkstyle.suppressionxpathfilter.commentsindentation;

public class SuppressionXpathRegressionCommentsIndentationSingleLine {
    int n;
        // Comment // warn
}
