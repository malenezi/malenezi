package org.checkstyle.suppressionxpathfilter.annotationusestyle;

@Deprecated //warn
public class SuppressionXpathRegressionAnnotationUseStyleTwo {

}
