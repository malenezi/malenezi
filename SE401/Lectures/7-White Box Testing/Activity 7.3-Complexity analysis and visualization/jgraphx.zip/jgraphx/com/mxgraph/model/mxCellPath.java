// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.model;

public class mxCellPath
{
    public static String PATH_SEPARATOR;
    
    public static String create(mxICell mxICell) {
        String string = "";
        if (mxICell != null) {
            for (mxICell mxICell2 = mxICell.getParent(); mxICell2 != null; mxICell2 = mxICell.getParent()) {
                string = mxICell2.getIndex(mxICell) + mxCellPath.PATH_SEPARATOR + string;
                mxICell = mxICell2;
            }
        }
        return (string.length() > 1) ? string.substring(0, string.length() - 1) : "";
    }
    
    public static String getParentPath(final String s) {
        if (s != null) {
            final int lastIndex = s.lastIndexOf(mxCellPath.PATH_SEPARATOR);
            if (lastIndex >= 0) {
                return s.substring(0, lastIndex);
            }
            if (s.length() > 0) {
                return "";
            }
        }
        return null;
    }
    
    public static mxICell resolve(final mxICell mxICell, final String s) {
        mxICell child = mxICell;
        final String[] split = s.split(mxCellPath.PATH_SEPARATOR);
        for (int i = 0; i < split.length; ++i) {
            child = child.getChildAt(Integer.parseInt(split[i]));
        }
        return child;
    }
    
    static {
        mxCellPath.PATH_SEPARATOR = ".";
    }
}
