// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.io;

import java.util.Iterator;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import java.util.Map;
import com.mxgraph.model.mxCell;

public class mxCellCodec extends mxObjectCodec
{
    public mxCellCodec() {
        this(new mxCell(), null, new String[] { "parent", "source", "target" }, null);
    }
    
    public mxCellCodec(final Object o) {
        this(o, null, null, null);
    }
    
    public mxCellCodec(final Object o, final String[] array, final String[] array2, final Map map) {
        super(o, array, array2, map);
    }
    
    @Override
    public boolean isExcluded(final Object o, final String s, final Object o2, final boolean b) {
        return this.exclude.contains(s) || (b && s.equals("value") && o2 instanceof Node && ((Node)o2).getNodeType() == 1);
    }
    
    @Override
    public Node afterEncode(final mxCodec mxCodec, final Object o, Node importNode) {
        if (o instanceof mxCell) {
            final mxCell mxCell = (mxCell)o;
            if (mxCell.getValue() instanceof Node) {
                final Element element = (Element)importNode;
                importNode = mxCodec.getDocument().importNode((Node)mxCell.getValue(), true);
                importNode.appendChild(element);
                ((Element)importNode).setAttribute("id", element.getAttribute("id"));
                element.removeAttribute("id");
            }
        }
        return importNode;
    }
    
    @Override
    public Node beforeDecode(final mxCodec mxCodec, final Node node, final Object o) {
        Element element = (Element)node;
        if (o instanceof mxCell) {
            final mxCell mxCell = (mxCell)o;
            if (!node.getNodeName().equals("mxCell")) {
                final Node item = element.getElementsByTagName("mxCell").item(0);
                if (item != null && item.getParentNode() == node) {
                    element = (Element)item;
                    Node previousSibling2;
                    for (Node previousSibling = item.getPreviousSibling(); previousSibling != null && previousSibling.getNodeType() == 3; previousSibling = previousSibling2) {
                        previousSibling2 = previousSibling.getPreviousSibling();
                        previousSibling.getParentNode().removeChild(previousSibling);
                    }
                    Node previousSibling3;
                    for (Node nextSibling = item.getNextSibling(); nextSibling != null && nextSibling.getNodeType() == 3; nextSibling = previousSibling3) {
                        previousSibling3 = nextSibling.getPreviousSibling();
                        nextSibling.getParentNode().removeChild(nextSibling);
                    }
                    item.getParentNode().removeChild(item);
                }
                else {
                    element = null;
                }
                final Element value = (Element)node.cloneNode(true);
                mxCell.setValue(value);
                final String attribute = value.getAttribute("id");
                if (attribute != null) {
                    mxCell.setId(attribute);
                    value.removeAttribute("id");
                }
            }
            else {
                mxCell.setId(((Element)node).getAttribute("id"));
            }
            if (element != null && this.idrefs != null) {
                final Iterator<Object> iterator = (Iterator<Object>)this.idrefs.iterator();
                while (iterator.hasNext()) {
                    final String value2 = String.valueOf(iterator.next());
                    final String attribute2 = element.getAttribute(value2);
                    if (attribute2 != null && attribute2.length() > 0) {
                        element.removeAttribute(value2);
                        Object o2 = mxCodec.objects.get(attribute2);
                        if (o2 == null) {
                            o2 = mxCodec.lookup(attribute2);
                        }
                        if (o2 == null) {
                            final Node elementById = mxCodec.getElementById(attribute2);
                            if (elementById != null) {
                                mxObjectCodec codec = mxCodecRegistry.getCodec(elementById.getNodeName());
                                if (codec == null) {
                                    codec = this;
                                }
                                o2 = codec.decode(mxCodec, elementById);
                            }
                        }
                        this.setFieldValue(o, value2, o2);
                    }
                }
            }
        }
        return element;
    }
}
