// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import com.mxgraph.util.mxConstants;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Cursor;
import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.Point;
import javax.swing.JComponent;
import java.awt.Rectangle;
import com.mxgraph.view.mxCellState;
import com.mxgraph.swing.mxGraphComponent;

public class mxCellHandler
{
    protected mxGraphComponent graphComponent;
    protected mxCellState state;
    protected Rectangle[] handles;
    protected boolean labelMovable;
    protected boolean handlesVisible;
    protected transient JComponent preview;
    protected transient Point start;
    protected transient int index;
    
    public mxCellHandler(final mxGraphComponent graphComponent, final mxCellState state) {
        this.handlesVisible = true;
        this.graphComponent = graphComponent;
        this.state = state;
        final String label = graphComponent.getGraph().getLabel(state.getCell());
        this.labelMovable = (graphComponent.getGraph().isLabelMovable(state.getCell()) && label != null && label.length() > 0);
        this.handles = this.createHandles();
    }
    
    public boolean isLabelMovable() {
        return this.labelMovable;
    }
    
    public boolean isHandlesVisible() {
        return this.handlesVisible;
    }
    
    public void setHandlesVisible(final boolean handlesVisible) {
        this.handlesVisible = handlesVisible;
    }
    
    public boolean isLabel(final int n) {
        return n == this.getHandleCount() - 1;
    }
    
    protected Rectangle[] createHandles() {
        return null;
    }
    
    protected int getHandleCount() {
        return (this.handles != null) ? this.handles.length : 0;
    }
    
    public mxCellState getState() {
        return this.state;
    }
    
    public String getToolTipText(final MouseEvent mouseEvent) {
        return null;
    }
    
    protected int getIndexAt(final int x, final int y) {
        if (this.handles != null && this.handlesVisible) {
            final Rectangle r = new Rectangle(x, y, 1, 1);
            for (int i = this.handles.length - 1; i >= 0; --i) {
                if (this.isHandleVisible(i) && this.handles[i].intersects(r)) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public void mousePressed(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed()) {
            final int index = this.getIndexAt(mouseEvent.getX(), mouseEvent.getY());
            if (!this.isIgnoredEvent(mouseEvent) && index >= 0) {
                this.start(mouseEvent, index);
                mouseEvent.consume();
            }
        }
    }
    
    public void start(final MouseEvent mouseEvent, final int index) {
        this.index = index;
        this.start = mouseEvent.getPoint();
        this.preview = this.createPreview();
        this.graphComponent.getControl().add(this.preview, 0);
    }
    
    protected boolean isIgnoredEvent(final MouseEvent mouseEvent) {
        return this.graphComponent.isEditEvent(mouseEvent);
    }
    
    protected JComponent createPreview() {
        return null;
    }
    
    public void mouseDragged(final MouseEvent mouseEvent) {
    }
    
    public void mouseReleased(final MouseEvent mouseEvent) {
        this.reset();
    }
    
    public void reset() {
        if (this.preview != null) {
            this.preview.setVisible(false);
            this.preview.getParent().remove(this.preview);
            this.preview = null;
        }
        this.start = null;
    }
    
    public void mouseMoved(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.handles != null) {
            final int index = this.getIndexAt(mouseEvent.getX(), mouseEvent.getY());
            if (index >= 0) {
                final Cursor cursor = this.getCursor(mouseEvent, index);
                if (cursor != null) {
                    this.graphComponent.getControl().setCursor(cursor);
                    mouseEvent.consume();
                }
                else {
                    this.graphComponent.getControl().setCursor(mxConnectionHandler.DEFAULT_CURSOR);
                }
            }
        }
    }
    
    protected Cursor getCursor(final MouseEvent mouseEvent, final int n) {
        return null;
    }
    
    public void paint(final Graphics graphics) {
        if (this.handles != null && this.handlesVisible) {
            for (int i = 0; i < this.handles.length; ++i) {
                if (this.isHandleVisible(i)) {
                    graphics.setColor(this.getHandleFillColor(i));
                    graphics.fillRect(this.handles[i].x, this.handles[i].y, this.handles[i].width, this.handles[i].height);
                    graphics.setColor(this.getHandleBorderColor(i));
                    graphics.drawRect(this.handles[i].x, this.handles[i].y, this.handles[i].width - 1, this.handles[i].height - 1);
                }
            }
        }
    }
    
    protected boolean isHandleVisible(final int n) {
        return !this.isLabel(n) || this.isLabelMovable();
    }
    
    protected Color getHandleFillColor(final int n) {
        if (this.isLabel(n)) {
            return mxConstants.LABEL_HANDLE_FILLCOLOR;
        }
        return mxConstants.HANDLE_FILLCOLOR;
    }
    
    protected Color getHandleBorderColor(final int n) {
        return mxConstants.HANDLE_BORDERCOLOR;
    }
}
