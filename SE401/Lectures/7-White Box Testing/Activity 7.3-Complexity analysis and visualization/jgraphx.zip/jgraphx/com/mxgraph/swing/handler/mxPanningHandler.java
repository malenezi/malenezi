// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import java.awt.Component;
import java.awt.Point;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.swing.util.mxMouseControl;

public class mxPanningHandler extends mxMouseControl
{
    protected mxGraphComponent graphComponent;
    protected transient Point start;
    protected boolean panningEnabled;
    
    public mxPanningHandler(final mxGraphComponent graphComponent) {
        this.panningEnabled = true;
        this.graphComponent = graphComponent;
        graphComponent.getControl().add(this);
        graphComponent.getControl().addMouseListener(this);
        graphComponent.getControl().addMouseMotionListener(this);
    }
    
    public boolean isPanningEnabled() {
        return this.panningEnabled;
    }
    
    public void setPanningEnabled(final boolean panningEnabled) {
        this.panningEnabled = panningEnabled;
    }
    
    @Override
    public void mousePressed(final MouseEvent mouseEvent) {
        if (this.isPanningEnabled() && !mouseEvent.isConsumed() && this.graphComponent.isPanningEvent(mouseEvent) && !mouseEvent.isPopupTrigger()) {
            this.start = mouseEvent.getPoint();
        }
    }
    
    @Override
    public void mouseDragged(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.start != null) {
            final int n = mouseEvent.getX() - this.start.x;
            final int n2 = mouseEvent.getY() - this.start.y;
            final Rectangle viewRect = this.graphComponent.getViewport().getViewRect();
            this.graphComponent.getControl().scrollRectToVisible(new Rectangle(viewRect.x + ((n > 0) ? 0 : viewRect.width) - n, viewRect.y + ((n2 > 0) ? 0 : viewRect.height) - n2, 1, 1));
            mouseEvent.consume();
        }
    }
    
    @Override
    public void mouseReleased(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.start != null && this.graphComponent.isSignificant(Math.abs(this.start.x - mouseEvent.getX()), Math.abs(this.start.y - mouseEvent.getY()))) {
            mouseEvent.consume();
        }
        this.start = null;
    }
}
