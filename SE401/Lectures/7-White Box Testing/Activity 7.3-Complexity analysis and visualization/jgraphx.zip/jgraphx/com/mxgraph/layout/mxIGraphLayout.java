// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.layout;

public interface mxIGraphLayout
{
    void execute(final Object p0);
    
    void move(final Object p0, final double p1, final double p2);
}
