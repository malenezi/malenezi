// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.io;

import com.mxgraph.model.mxCell;
import org.w3c.dom.Element;
import com.mxgraph.model.mxCellPath;
import com.mxgraph.model.mxICell;
import org.w3c.dom.Node;
import com.mxgraph.util.mxUtils;
import java.util.Hashtable;
import org.w3c.dom.Document;

public class mxCodec
{
    protected Document document;
    protected Hashtable objects;
    protected boolean encodeDefaults;
    
    public mxCodec() {
        this(mxUtils.createDocument());
    }
    
    public mxCodec(Document document) {
        this.objects = new Hashtable();
        this.encodeDefaults = false;
        if (document == null) {
            document = mxUtils.createDocument();
        }
        this.document = document;
    }
    
    public boolean isEncodeDefaults() {
        return this.encodeDefaults;
    }
    
    public void setEncodeDefaults(final boolean encodeDefaults) {
        this.encodeDefaults = encodeDefaults;
    }
    
    public Document getDocument() {
        return this.document;
    }
    
    public Object putObject(final String key, final Object value) {
        return this.objects.put(key, value);
    }
    
    public Object getObject(final String key) {
        Object o = null;
        if (key != null) {
            o = this.objects.get(key);
            if (o == null) {
                o = this.lookup(key);
                if (o == null) {
                    final Node elementById = this.getElementById(key);
                    if (elementById != null) {
                        o = this.decode(elementById);
                    }
                }
            }
        }
        return o;
    }
    
    public Object lookup(final String s) {
        return null;
    }
    
    public Node getElementById(final String s) {
        return this.getElementById(s, null);
    }
    
    public Node getElementById(final String str, String str2) {
        if (str2 == null) {
            str2 = "id";
        }
        return mxUtils.selectSingleNode(this.document, "//*[@" + str2 + "='" + str + "']");
    }
    
    public String getId(final Object o) {
        String s = null;
        if (o != null) {
            s = this.reference(o);
            if (s == null && o instanceof mxICell) {
                s = ((mxICell)o).getId();
                if (s == null) {
                    s = mxCellPath.create((mxICell)o);
                    if (s.length() == 0) {
                        s = "root";
                    }
                }
            }
        }
        return s;
    }
    
    public String reference(final Object o) {
        return null;
    }
    
    public Node encode(final Object o) {
        Node node = null;
        if (o != null) {
            final String name = mxCodecRegistry.getName(o.getClass());
            final mxObjectCodec codec = mxCodecRegistry.getCodec(name);
            if (codec != null) {
                node = codec.encode(this, o);
            }
            else if (o instanceof Node) {
                node = ((Node)o).cloneNode(true);
            }
            else {
                System.err.println("No codec for " + name);
            }
        }
        return node;
    }
    
    public Object decode(final Node node) {
        return this.decode(node, null);
    }
    
    public Object decode(final Node node, final Object o) {
        Object o2 = null;
        if (node != null && node.getNodeType() == 1) {
            final mxObjectCodec codec = mxCodecRegistry.getCodec(node.getNodeName());
            try {
                if (codec != null) {
                    o2 = codec.decode(this, node, o);
                }
                else {
                    o2 = node.cloneNode(true);
                    ((Element)o2).removeAttribute("as");
                }
            }
            catch (Exception ex) {
                System.err.println("Cannot decode " + node.getNodeName() + ": " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        return o2;
    }
    
    public void encodeCell(final mxICell mxICell, final Node node, final boolean b) {
        node.appendChild(this.encode(mxICell));
        if (b) {
            for (int childCount = mxICell.getChildCount(), i = 0; i < childCount; ++i) {
                this.encodeCell(mxICell.getChildAt(i), node, b);
            }
        }
    }
    
    public mxICell decodeCell(final Node node, final boolean b) {
        mxICell mxICell = null;
        if (node != null && node.getNodeType() == 1) {
            mxICell = (mxICell)mxCodecRegistry.getCodec(mxCodecRegistry.getName(mxCell.class)).decode(this, node);
            if (b) {
                final mxICell parent = mxICell.getParent();
                if (parent != null) {
                    parent.insert(mxICell);
                }
                final mxICell terminal = mxICell.getTerminal(true);
                if (terminal != null) {
                    terminal.insertEdge(mxICell, true);
                }
                final mxICell terminal2 = mxICell.getTerminal(false);
                if (terminal2 != null) {
                    terminal2.insertEdge(mxICell, false);
                }
            }
        }
        return mxICell;
    }
    
    public static void setAttribute(final Node node, final String s, final Object obj) {
        if (node.getNodeType() == 1 && s != null && obj != null) {
            ((Element)node).setAttribute(s, String.valueOf(obj));
        }
    }
}
