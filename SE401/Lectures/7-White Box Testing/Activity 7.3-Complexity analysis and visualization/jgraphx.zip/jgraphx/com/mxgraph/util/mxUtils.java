// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.util;

import org.w3c.dom.NamedNodeMap;
import javax.xml.transform.Transformer;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import java.io.OutputStream;
import javax.xml.transform.stream.StreamResult;
import java.io.ByteArrayOutputStream;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.TransformerFactory;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.xml.sax.InputSource;
import java.io.StringReader;
import javax.imageio.ImageIO;
import java.net.URL;
import org.w3c.dom.Node;
import javax.swing.text.html.HTMLDocument;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.security.MessageDigest;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.awt.Color;
import com.mxgraph.model.mxIGraphModel;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.image.BufferedImage;
import java.awt.Rectangle;
import java.awt.Dimension;
import javax.swing.text.StyledDocument;
import java.awt.geom.Rectangle2D;
import java.awt.FontMetrics;
import java.awt.Font;
import java.awt.geom.AffineTransform;
import java.awt.font.FontRenderContext;
import java.util.Hashtable;
import java.awt.Graphics;

public class mxUtils
{
    protected static transient Graphics fontGraphics;
    
    public static mxRectangle getLabelSize(final String s, final Hashtable hashtable, final boolean b) {
        final mxRectangle mxRectangle = new mxRectangle();
        mxRectangle mxRectangle2;
        if (b) {
            mxRectangle2 = getSizeForHtml(getBodyMarkup(s, true), hashtable);
        }
        else {
            mxRectangle2 = getSizeForString(s, getFloat(hashtable, mxConstants.STYLE_FONTSIZE, (float)mxConstants.DEFAULT_FONTSIZE), getString(hashtable, mxConstants.STYLE_FONTFAMILY, mxConstants.DEFAULT_FONTFAMILY), getInt(hashtable, mxConstants.STYLE_FONTSTYLE));
        }
        return mxRectangle2;
    }
    
    public static String getBodyMarkup(String s, final boolean b) {
        final String lowerCase = s.toLowerCase();
        int index = lowerCase.indexOf("<body>");
        if (index >= 0) {
            index += 7;
            final int lastIndex = lowerCase.lastIndexOf("</body>");
            if (lastIndex > index) {
                s = s.substring(index, lastIndex).trim();
            }
        }
        if (b) {
            s = s.replaceAll("\n", "<br>");
        }
        return s;
    }
    
    public static mxRectangle getScaledLabelBounds(double n, double n2, final mxRectangle mxRectangle, final double n3, final double n4, final Hashtable hashtable, final double n5) {
        final double n6 = mxConstants.LABEL_INSET * n5;
        double n7 = mxRectangle.getWidth() * n5 + 2.0 * n6;
        double n8 = mxRectangle.getHeight() * n5 + 2.0 * n6;
        final boolean true = isTrue(hashtable, mxConstants.STYLE_HORIZONTAL, true);
        final int n9 = (int)(getInt(hashtable, mxConstants.STYLE_SPACING) * n5);
        final String string = getString(hashtable, mxConstants.STYLE_ALIGN, "center");
        final String string2 = getString(hashtable, mxConstants.STYLE_VERTICAL_ALIGN, "middle");
        int n10 = (int)(getInt(hashtable, mxConstants.STYLE_SPACING_TOP) * n5);
        int n11 = (int)(getInt(hashtable, mxConstants.STYLE_SPACING_BOTTOM) * n5);
        int n12 = (int)(getInt(hashtable, mxConstants.STYLE_SPACING_LEFT) * n5);
        int n13 = (int)(getInt(hashtable, mxConstants.STYLE_SPACING_RIGHT) * n5);
        if (!true) {
            final int n14 = n10;
            n10 = n13;
            n13 = n11;
            n11 = n12;
            n12 = n14;
            final double n15 = n7;
            n7 = n8;
            n8 = n15;
        }
        if ((true && string.equals("center")) || (!true && string2.equals("middle"))) {
            n += (n3 - n7) / 2.0 + n12 - n13;
        }
        else if ((true && string.equals("right")) || (!true && string2.equals("bottom"))) {
            n += n3 - n7 - n9 - n13;
        }
        else {
            n += n9 + n12;
        }
        if ((!true && string.equals("center")) || (true && string2.equals("middle"))) {
            n2 += (n4 - n8) / 2.0 + n10 - n11;
        }
        else if ((!true && string.equals("left")) || (true && string2.equals("bottom"))) {
            n2 += n4 - n8 - n9 - n11;
        }
        else {
            n2 += n9 + n10;
        }
        return new mxRectangle(n, n2, n7, n8);
    }
    
    public static mxRectangle getSizeForString(final String s) {
        return getSizeForString(s, 0.0f);
    }
    
    public static mxRectangle getSizeForString(final String s, final float n) {
        return getSizeForString(s, n, null);
    }
    
    public static mxRectangle getSizeForString(final String s, final float n, final String s2) {
        return getSizeForString(s, n, s2, 0);
    }
    
    public static mxRectangle getSizeForString(final String s, float n, String default_FONTFAMILY, final int n2) {
        if (n == 0.0f) {
            n = (float)mxConstants.DEFAULT_FONTSIZE;
        }
        if (default_FONTFAMILY == null) {
            default_FONTFAMILY = mxConstants.DEFAULT_FONTFAMILY;
        }
        final int style = (((n2 & 0x1) == 0x1) ? 1 : 0) + (((n2 & 0x2) == 0x2) ? 2 : 0);
        final FontRenderContext frc = new FontRenderContext(null, false, false);
        final Font font = new Font(default_FONTFAMILY, style, (int)n);
        FontMetrics fontMetrics = null;
        if (mxUtils.fontGraphics != null) {
            fontMetrics = mxUtils.fontGraphics.getFontMetrics(font);
        }
        final double n3 = mxConstants.LINESPACING;
        double n4;
        if (fontMetrics != null) {
            n4 = n3 + fontMetrics.getHeight();
        }
        else {
            n4 = n3 + n * 1.27;
        }
        final String[] split = s.split("\n");
        Rectangle2D rectangle2D = null;
        for (int i = 0; i < split.length; ++i) {
            final Rectangle2D visualBounds = font.createGlyphVector(frc, split[i]).getVisualBounds();
            if (rectangle2D == null) {
                rectangle2D = visualBounds;
            }
            else {
                rectangle2D.setFrame(0.0, 0.0, Math.max(rectangle2D.getWidth(), visualBounds.getWidth()), rectangle2D.getHeight() + n4);
            }
        }
        return new mxRectangle(rectangle2D);
    }
    
    public static mxRectangle getSizeForHtml(final String text, final Hashtable hashtable) {
        final mxLightweightTextPane sharedInstance = mxLightweightTextPane.getSharedInstance();
        if (sharedInstance != null) {
            sharedInstance.setStyledDocument(createHtmlDocument(hashtable));
            sharedInstance.setText(text);
            final Dimension preferredSize = sharedInstance.getPreferredSize();
            return new mxRectangle(0.0, 0.0, preferredSize.width, preferredSize.height);
        }
        return getSizeForString(text);
    }
    
    public static mxRectangle getBoundingBox(final mxRectangle mxRectangle, final double angdeg) {
        mxRectangle mxRectangle2 = null;
        if (mxRectangle != null && angdeg != 0.0) {
            final double radians = Math.toRadians(angdeg);
            final double cos = Math.cos(radians);
            final double sin = Math.sin(radians);
            final mxPoint mxPoint = new mxPoint(mxRectangle.getX() + mxRectangle.getWidth() / 2.0, mxRectangle.getY() + mxRectangle.getHeight() / 2.0);
            final mxPoint mxPoint2 = new mxPoint(mxRectangle.getX(), mxRectangle.getY());
            final mxPoint mxPoint3 = new mxPoint(mxRectangle.getX() + mxRectangle.getWidth(), mxRectangle.getY());
            final mxPoint mxPoint4 = new mxPoint(mxPoint3.getX(), mxRectangle.getY() + mxRectangle.getHeight());
            final mxPoint mxPoint5 = new mxPoint(mxRectangle.getX(), mxPoint4.getY());
            final mxPoint rotatedPoint = getRotatedPoint(mxPoint2, cos, sin, mxPoint);
            final mxPoint rotatedPoint2 = getRotatedPoint(mxPoint3, cos, sin, mxPoint);
            final mxPoint rotatedPoint3 = getRotatedPoint(mxPoint4, cos, sin, mxPoint);
            final mxPoint rotatedPoint4 = getRotatedPoint(mxPoint5, cos, sin, mxPoint);
            final Rectangle rectangle = new Rectangle((int)rotatedPoint.getX(), (int)rotatedPoint.getY(), 0, 0);
            rectangle.add(rotatedPoint2.getPoint());
            rectangle.add(rotatedPoint3.getPoint());
            rectangle.add(rotatedPoint4.getPoint());
            mxRectangle2 = new mxRectangle(rectangle);
        }
        return mxRectangle2;
    }
    
    public static mxPoint getRotatedPoint(final mxPoint mxPoint, final double n, final double n2) {
        return getRotatedPoint(mxPoint, n, n2, new mxPoint());
    }
    
    public static mxPoint getRotatedPoint(final mxPoint mxPoint, final double n, final double n2, final mxPoint mxPoint2) {
        final double n3 = mxPoint.getX() - mxPoint2.getX();
        final double n4 = mxPoint.getY() - mxPoint2.getY();
        return new mxPoint(n3 * n - n4 * n2 + mxPoint2.getX(), n4 * n + n3 * n2 + mxPoint2.getY());
    }
    
    public static void drawImageClip(final Graphics graphics, final BufferedImage bufferedImage, final ImageObserver imageObserver) {
        final Rectangle clipBounds = graphics.getClipBounds();
        if (clipBounds != null) {
            final int width = bufferedImage.getWidth();
            final int height = bufferedImage.getHeight();
            final int max = Math.max(0, Math.min(clipBounds.x, width));
            final int max2 = Math.max(0, Math.min(clipBounds.y, height));
            final int min = Math.min(clipBounds.width, width - max);
            final int min2 = Math.min(clipBounds.height, height - max2);
            if (min > 0 && min2 > 0) {
                graphics.drawImage(bufferedImage.getSubimage(max, max2, min, min2), clipBounds.x, clipBounds.y, imageObserver);
            }
        }
        else {
            graphics.drawImage(bufferedImage, 0, 0, imageObserver);
        }
    }
    
    public static void fillClippedRect(final Graphics graphics, final int x, final int y, final int width, final int height) {
        Rectangle intersection = new Rectangle(x, y, width, height);
        try {
            if (graphics.getClipBounds() != null) {
                intersection = intersection.intersection(graphics.getClipBounds());
            }
        }
        catch (Exception ex) {}
        graphics.fillRect(intersection.x, intersection.y, intersection.width, intersection.height);
    }
    
    public static List translatePoints(final List list, final double n, final double n2) {
        List<mxPoint> list2 = null;
        if (list != null) {
            list2 = new ArrayList<mxPoint>(list.size());
            for (final mxPoint next : list) {
                if (next instanceof mxPoint) {
                    final mxPoint mxPoint = (mxPoint)next.clone();
                    mxPoint.setX(mxPoint.getX() + n);
                    mxPoint.setY(mxPoint.getY() + n2);
                    list2.add(mxPoint);
                }
                else {
                    list2.add(next);
                }
            }
        }
        return list2;
    }
    
    public static boolean contains(final mxRectangle mxRectangle, final double n, final double n2) {
        return mxRectangle.getX() <= n && mxRectangle.getX() + mxRectangle.getWidth() >= n && mxRectangle.getY() <= n2 && mxRectangle.getY() + mxRectangle.getHeight() >= n2;
    }
    
    public static mxPoint intersection(final double n, final double n2, final double n3, final double n4, final double n5, final double n6, final double n7, final double n8) {
        final double n9 = (n8 - n6) * (n3 - n) - (n7 - n5) * (n4 - n2);
        final double n10 = (n7 - n5) * (n2 - n6) - (n8 - n6) * (n - n5);
        final double n11 = (n3 - n) * (n2 - n6) - (n4 - n2) * (n - n5);
        final double n12 = n10 / n9;
        final double n13 = n11 / n9;
        if (n12 >= 0.0 && n12 <= 1.0 && n13 >= 0.0 && n13 <= 1.0) {
            return new mxPoint(n + n12 * (n3 - n), n2 + n12 * (n4 - n2));
        }
        return null;
    }
    
    public static String getStylename(final String s) {
        if (s != null) {
            final String s2 = s.split(";")[0];
            if (s2.indexOf("=") < 0) {
                return s2;
            }
        }
        return "";
    }
    
    public static String[] getStylenames(final String s) {
        final ArrayList<String> list = new ArrayList<String>();
        if (s != null) {
            final String[] split = s.split(";");
            for (int i = 0; i < split.length; ++i) {
                if (split[i].indexOf("=") < 0) {
                    list.add(split[i]);
                }
            }
        }
        return (String[])list.toArray();
    }
    
    public static int indexOfStylename(final String s, final String anObject) {
        if (s != null && anObject != null) {
            final String[] split = s.split(";");
            int n = 0;
            for (int i = 0; i < split.length; ++i) {
                if (split[i].equals(anObject)) {
                    return n;
                }
                n += split[i].length() + 1;
            }
        }
        return -1;
    }
    
    public String addStylename(String s, final String str) {
        if (indexOfStylename(s, str) < 0) {
            if (s == null) {
                s = "";
            }
            else if (s.length() > 0 && s.charAt(s.length() - 1) != ';') {
                s += ';';
            }
            s += str;
        }
        return s;
    }
    
    public String removeStylename(final String s, final String anObject) {
        final StringBuffer sb = new StringBuffer();
        if (s != null) {
            final String[] split = s.split(";");
            for (int i = 0; i < split.length; ++i) {
                if (!split[i].equals(anObject)) {
                    sb.append(split[i] + ";");
                }
            }
        }
        return (sb.length() > 1) ? sb.substring(0, sb.length() - 1) : sb.toString();
    }
    
    public static String removeAllStylenames(final String s) {
        final StringBuffer sb = new StringBuffer();
        if (s != null) {
            final String[] split = s.split(";");
            for (int i = 0; i < split.length; ++i) {
                if (split[i].indexOf(61) >= 0) {
                    sb.append(split[i] + ";");
                }
            }
        }
        return (sb.length() > 1) ? sb.substring(0, sb.length() - 1) : sb.toString();
    }
    
    public static void setCellStyles(final mxIGraphModel mxIGraphModel, final Object[] array, final String s, final String s2) {
        if (array != null && array.length > 0) {
            mxIGraphModel.beginUpdate();
            try {
                for (int i = 0; i < array.length; ++i) {
                    if (array[i] != null) {
                        mxIGraphModel.setStyle(array[i], setStyle(mxIGraphModel.getStyle(array[i]), s, s2));
                    }
                }
            }
            finally {
                mxIGraphModel.endUpdate();
            }
        }
    }
    
    public static String setStyle(String str, final String s, final String str2) {
        final boolean b = str2 != null && str2.length() > 0;
        if (str == null || str.length() == 0) {
            if (b) {
                str = s + "=" + str2;
            }
        }
        else {
            final int index = str.indexOf(s + "=");
            if (index < 0) {
                if (b) {
                    str = str + (str.endsWith(";") ? "" : ";") + s + '=' + str2;
                }
            }
            else {
                final String str3 = b ? (s + "=" + str2) : "";
                final int index2 = str.indexOf(";", index);
                str = str.substring(0, index) + str3 + ((index2 >= 0) ? str.substring(index2) : "");
            }
        }
        return str;
    }
    
    public static void setCellStyleFlags(final mxIGraphModel mxIGraphModel, final Object[] array, final String s, final int n, final Boolean b) {
        if (array != null && array.length > 0) {
            mxIGraphModel.beginUpdate();
            try {
                for (int i = 0; i < array.length; ++i) {
                    if (array[i] != null) {
                        mxIGraphModel.setStyle(array[i], setStyleFlag(mxIGraphModel.getStyle(array[i]), s, n, b));
                    }
                }
            }
            finally {
                mxIGraphModel.endUpdate();
            }
        }
    }
    
    public static String setStyleFlag(String s, final String s2, final int n, final Boolean b) {
        if (s == null || s.length() == 0) {
            if (b == null || b) {
                s = s2 + "=" + n;
            }
            else {
                s = s2 + "=0";
            }
        }
        else {
            final int index = s.indexOf(s2 + "=");
            if (index < 0) {
                final String s3 = s.endsWith(";") ? "" : ";";
                if (b == null || b) {
                    s = s + s3 + s2 + "=" + n;
                }
                else {
                    s = s + s3 + s2 + "=0";
                }
            }
            else {
                final int index2 = s.indexOf(";", index);
                String s4;
                if (index2 < 0) {
                    s4 = s.substring(index + s2.length() + 1);
                }
                else {
                    s4 = s.substring(index + s2.length() + 1, index2);
                }
                int i;
                if (b == null) {
                    i = (Integer.parseInt(s4) ^ n);
                }
                else if (b) {
                    i = (Integer.parseInt(s4) | n);
                }
                else {
                    i = (Integer.parseInt(s4) & ~n);
                }
                s = s.substring(0, index) + s2 + "=" + i + ((index2 >= 0) ? s.substring(index2) : "");
            }
        }
        return s;
    }
    
    public static boolean isTrue(final Hashtable hashtable, final String s) {
        return isTrue(hashtable, s, false);
    }
    
    public static boolean isTrue(final Hashtable hashtable, final String key, final boolean b) {
        final Object value = hashtable.get(key);
        if (value == null) {
            return b;
        }
        return !value.equals("0") && (value.equals("1") || Boolean.parseBoolean(value.toString()));
    }
    
    public static int getInt(final Hashtable hashtable, final String s) {
        return getInt(hashtable, s, 0);
    }
    
    public static int getInt(final Hashtable hashtable, final String key, final int n) {
        final Object value = hashtable.get(key);
        if (value == null) {
            return n;
        }
        return (int)Float.parseFloat(value.toString());
    }
    
    public static float getFloat(final Hashtable hashtable, final String s) {
        return getFloat(hashtable, s, 0.0f);
    }
    
    public static float getFloat(final Hashtable hashtable, final String key, final float n) {
        final Object value = hashtable.get(key);
        if (value == null) {
            return n;
        }
        return Float.parseFloat(value.toString());
    }
    
    public static double getDouble(final Hashtable hashtable, final String s) {
        return getDouble(hashtable, s, 0.0);
    }
    
    public static double getDouble(final Hashtable hashtable, final String key, final double n) {
        final Object value = hashtable.get(key);
        if (value == null) {
            return n;
        }
        return Double.parseDouble(value.toString());
    }
    
    public static String getString(final Hashtable hashtable, final String s) {
        return getString(hashtable, s, null);
    }
    
    public static String getString(final Hashtable hashtable, final String key, final String s) {
        final Object value = hashtable.get(key);
        if (value == null) {
            return s;
        }
        return value.toString();
    }
    
    public static Color getColor(final Hashtable hashtable, final String s) {
        return getColor(hashtable, s, null);
    }
    
    public static Color getColor(final Hashtable hashtable, final String key, final Color color) {
        final Object value = hashtable.get(key);
        if (value == null) {
            return color;
        }
        return parseColor(value.toString());
    }
    
    public static Font getFont(final Hashtable hashtable) {
        return getFont(hashtable, 1.0);
    }
    
    public static Font getFont(final Hashtable hashtable, final double n) {
        final String string = getString(hashtable, mxConstants.STYLE_FONTFAMILY, mxConstants.DEFAULT_FONTFAMILY);
        final int int1 = getInt(hashtable, mxConstants.STYLE_FONTSIZE, mxConstants.DEFAULT_FONTSIZE);
        final int int2 = getInt(hashtable, mxConstants.STYLE_FONTSTYLE);
        return new Font(string, (((int2 & 0x1) == 0x1) ? 1 : 0) + (((int2 & 0x2) == 0x2) ? 2 : 0), (int)Math.round(int1 * n));
    }
    
    public static String hexString(final Color color) {
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }
    
    public static Color parseColor(final String s) throws NumberFormatException {
        if (s.equalsIgnoreCase("white")) {
            return Color.white;
        }
        if (s.equalsIgnoreCase("black")) {
            return Color.black;
        }
        if (s.equalsIgnoreCase("red")) {
            return Color.red;
        }
        if (s.equalsIgnoreCase("green")) {
            return Color.green;
        }
        if (s.equalsIgnoreCase("blue")) {
            return Color.blue;
        }
        if (s.equalsIgnoreCase("orange")) {
            return Color.orange;
        }
        if (s.equalsIgnoreCase("yellow")) {
            return Color.yellow;
        }
        if (s.equalsIgnoreCase("pink")) {
            return Color.pink;
        }
        if (s.equalsIgnoreCase("turqoise")) {
            return new Color(0, 255, 255);
        }
        if (s.equalsIgnoreCase("gray")) {
            return Color.gray;
        }
        if (s.equalsIgnoreCase("none")) {
            return null;
        }
        int intValue;
        try {
            intValue = (int)Long.parseLong(s, 16);
        }
        catch (NumberFormatException ex) {
            intValue = Long.decode(s).intValue();
        }
        if (s.length() < 7 && !s.equals("0")) {
            return new Color(intValue);
        }
        return new Color(intValue);
    }
    
    public static String getHexColorString(final Color color) {
        return Integer.toHexString((color.getRGB() & 0xFFFFFF) | color.getAlpha() << 24);
    }
    
    public static String readFile(final String name) throws IOException {
        final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(name)));
        final StringBuffer sb = new StringBuffer();
        for (String str = bufferedReader.readLine(); str != null; str = bufferedReader.readLine()) {
            sb.append(str + "\n");
        }
        bufferedReader.close();
        return sb.toString();
    }
    
    public static void writeFile(final String str, final String fileName) throws IOException {
        final FileWriter fileWriter = new FileWriter(fileName);
        fileWriter.write(str);
        fileWriter.flush();
        fileWriter.close();
    }
    
    public static String getMd5Hash(final String s) {
        final StringBuffer a = new StringBuffer(32);
        try {
            final MessageDigest instance = MessageDigest.getInstance("MD5");
            instance.update(s.getBytes());
            final Formatter formatter = new Formatter(a);
            final byte[] digest = instance.digest();
            for (int i = 0; i < digest.length; ++i) {
                formatter.format("%02x", new Byte(digest[i]));
            }
        }
        catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }
        return a.toString();
    }
    
    public static boolean isNode(final Object o, final String s) {
        return isNode(o, s, null, null);
    }
    
    public static boolean isNode(final Object o, final String anotherString, final String s, final String anObject) {
        if (o instanceof Element) {
            final Element element = (Element)o;
            if (anotherString == null || element.getNodeName().equalsIgnoreCase(anotherString)) {
                final String s2 = (s != null) ? element.getAttribute(s) : null;
                return s == null || (s2 != null && s2.equals(anObject));
            }
        }
        return false;
    }
    
    public static Document createDocument() {
        try {
            return DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        }
        catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        }
    }
    
    public static HTMLDocument createHtmlDocument(final Hashtable hashtable) {
        return createHtmlDocument(hashtable, 1.0);
    }
    
    public static HTMLDocument createHtmlDocument(final Hashtable hashtable, final double n) {
        final HTMLDocument htmlDocument = new HTMLDocument();
        final StringBuffer sb = new StringBuffer("body {");
        sb.append(" font-family: " + getString(hashtable, mxConstants.STYLE_FONTFAMILY, mxConstants.DEFAULT_FONTFAMILIES) + " ; ");
        sb.append(" font-size: " + (int)(getInt(hashtable, mxConstants.STYLE_FONTSIZE, mxConstants.DEFAULT_FONTSIZE) * n) + " pt ;");
        final String string = getString(hashtable, mxConstants.STYLE_FONTCOLOR);
        if (string != null) {
            sb.append("color: " + string + " ; ");
        }
        final int int1 = getInt(hashtable, mxConstants.STYLE_FONTSTYLE);
        if ((int1 & 0x1) == 0x1) {
            sb.append(" font-weight: bold ; ");
        }
        if ((int1 & 0x2) == 0x2) {
            sb.append(" font-style: italic ; ");
        }
        if ((int1 & 0x4) == 0x4) {
            sb.append(" text-decoration: underline ; ");
        }
        final String string2 = getString(hashtable, mxConstants.STYLE_ALIGN, "left");
        if (string2.equals("center")) {
            sb.append(" text-align: center ; ");
        }
        else if (string2.equals("right")) {
            sb.append(" text-align: right ; ");
        }
        sb.append(" } ");
        htmlDocument.getStyleSheet().addRule(sb.toString());
        return htmlDocument;
    }
    
    public static Element createTable(final Document document, final String s, final int i, final int j, final int k, final int l, final double n, final Hashtable hashtable) {
        final Element element = document.createElement("table");
        if (s != null && s.length() > 0) {
            final Element element2 = document.createElement("tr");
            final Element element3 = document.createElement("td");
            element.setAttribute("cellspacing", "0");
            element.setAttribute("border", "0");
            element3.setAttribute("align", "center");
            String str = "position:absolute;left:" + String.valueOf(i) + "px;" + "top:" + String.valueOf(j) + "px;" + "width:" + String.valueOf(k) + "px;" + "height:" + String.valueOf(l) + "px;" + "font-size:" + String.valueOf((int)(getInt(hashtable, mxConstants.STYLE_FONTSIZE, mxConstants.DEFAULT_FONTSIZE) * n)) + "px;" + "font-family:" + getString(hashtable, mxConstants.STYLE_FONTFAMILY, mxConstants.DEFAULT_FONTFAMILIES) + ";" + "color:" + getString(hashtable, mxConstants.STYLE_FONTCOLOR, "black") + ";";
            final String string = getString(hashtable, mxConstants.STYLE_LABEL_BACKGROUNDCOLOR);
            if (string != null) {
                str = str + "background:" + string + ";";
            }
            final String string2 = getString(hashtable, mxConstants.STYLE_LABEL_BORDERCOLOR);
            if (string2 != null) {
                str = str + "border:" + string2 + " solid 1pt;";
            }
            final float float1 = getFloat(hashtable, mxConstants.STYLE_TEXT_OPACITY, 100.0f);
            if (float1 < 100.0f) {
                str = str + "filter:alpha(opacity=" + float1 + ");" + "opacity:" + float1 / 100.0f + ";";
            }
            element3.setAttribute("style", str);
            final String[] split = s.split("\n");
            for (int n2 = 0; n2 < split.length; ++n2) {
                element3.appendChild(document.createTextNode(split[n2]));
                element3.appendChild(document.createElement("br"));
            }
            element2.appendChild(element3);
            element.appendChild(element2);
        }
        return element;
    }
    
    public static Image loadImage(final String s) {
        Image read = null;
        URL resource;
        try {
            resource = new URL(s);
        }
        catch (Exception ex) {
            resource = mxUtils.class.getResource(s);
        }
        if (s != null) {
            try {
                read = ImageIO.read(resource);
            }
            catch (IOException ex2) {}
        }
        return read;
    }
    
    public static Document loadDocument(final String uri) {
        try {
            return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(uri);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static Document parse(final String s) {
        try {
            return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(s)));
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static Node selectSingleNode(final Document document, final String s) {
        try {
            return (Node)XPathFactory.newInstance().newXPath().evaluate(s, document, XPathConstants.NODE);
        }
        catch (XPathExpressionException ex) {
            return null;
        }
    }
    
    public static String htmlEntities(final String s) {
        return s.replaceAll("&", "&amp;").replaceAll("\"", "&quot;").replaceAll("'", "&prime;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
    }
    
    public static String getXml(final Node n) {
        try {
            final Transformer transformer = TransformerFactory.newInstance().newTransformer();
            final DOMSource domSource = new DOMSource(n);
            final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            transformer.transform(domSource, new StreamResult(outputStream));
            return outputStream.toString("UTF-8");
        }
        catch (Exception ex) {
            return "";
        }
    }
    
    public static String getPrettyXml(final Node node) {
        return getPrettyXml(node, "  ", "");
    }
    
    public static String getPrettyXml(final Node node, final String str, final String str2) {
        final StringBuffer sb = new StringBuffer();
        if (node != null) {
            if (node.getNodeType() == 3) {
                sb.append(node.getNodeValue());
            }
            else {
                sb.append(str2 + "<" + node.getNodeName());
                final NamedNodeMap attributes = node.getAttributes();
                if (attributes != null) {
                    for (int i = 0; i < attributes.getLength(); ++i) {
                        sb.append(" " + attributes.item(i).getNodeName() + "=\"" + attributes.item(i).getNodeValue() + "\"");
                    }
                }
                Node node2 = node.getFirstChild();
                if (node2 != null) {
                    sb.append(">\n");
                    while (node2 != null) {
                        sb.append(getPrettyXml(node2, str, str2 + str));
                        node2 = node2.getNextSibling();
                    }
                    sb.append(str2 + "</" + node.getNodeName() + ">\n");
                }
                else {
                    sb.append("/>\n");
                }
            }
        }
        return sb.toString();
    }
    
    static {
        try {
            mxUtils.fontGraphics = new BufferedImage(1, 1, 1).getGraphics();
        }
        catch (Exception ex) {}
    }
}
