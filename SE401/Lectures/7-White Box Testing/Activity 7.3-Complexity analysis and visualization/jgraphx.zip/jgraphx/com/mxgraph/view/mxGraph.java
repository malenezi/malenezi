// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.view;

import java.beans.PropertyChangeListener;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import com.mxgraph.canvas.mxICanvas;
import java.util.Set;
import java.awt.Rectangle;
import com.mxgraph.util.mxResources;
import java.util.TreeSet;
import com.mxgraph.model.mxCellPath;
import java.util.Comparator;
import com.mxgraph.layout.mxIGraphLayout;
import java.util.HashSet;
import java.awt.Point;
import com.mxgraph.util.mxConstants;
import java.util.Arrays;
import com.mxgraph.model.mxCell;
import com.mxgraph.util.mxPoint;
import java.util.LinkedHashSet;
import com.mxgraph.model.mxGeometry;
import com.mxgraph.util.mxUtils;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Collection;
import com.mxgraph.model.mxICell;
import java.util.ArrayList;
import com.mxgraph.model.mxGraphModel;
import java.util.List;
import com.mxgraph.util.mxImage;
import com.mxgraph.util.mxRectangle;
import com.mxgraph.model.mxIGraphModel;
import java.beans.PropertyChangeSupport;
import com.mxgraph.util.mxEventSource;

public class mxGraph extends mxEventSource
{
    public static final String VERSION = "0.13.0.2";
    public static String EVENT_BEFORE_SHOW;
    public static String EVENT_BEFORE_HIDE;
    public static String EVENT_BEFORE_REMOVE;
    public static String EVENT_SHOW;
    public static String EVENT_HIDE;
    public static String EVENT_REMOVE;
    public static String EVENT_AFTER_SHOW;
    public static String EVENT_AFTER_HIDE;
    public static String EVENT_AFTER_REMOVE;
    public static String EVENT_BEFORE_MOVE;
    public static String EVENT_MOVE;
    public static String EVENT_CLONE;
    public static String EVENT_AFTER_MOVE;
    public static String EVENT_BEFORE_ADD;
    public static String EVENT_ADD;
    public static String EVENT_AFTER_ADD;
    public static String EVENT_BEFORE_CONNECT;
    public static String EVENT_CONNECT;
    public static String EVENT_AFTER_CONNECT;
    public static String EVENT_BEFORE_DISCONNECT;
    public static String EVENT_DISCONNECT;
    public static String EVENT_AFTER_DISCONNECT;
    public static String EVENT_BEFORE_RESIZE;
    public static String EVENT_RESIZE;
    public static String EVENT_AFTER_RESIZE;
    public static String EVENT_BEFORE_COLLAPSE;
    public static String EVENT_COLLAPSE;
    public static String EVENT_AFTER_COLLAPSE;
    public static String EVENT_BEFORE_EXPAND;
    public static String EVENT_EXPAND;
    public static String EVENT_AFTER_EXPAND;
    public static String EVENT_BEFORE_LAYOUT;
    public static String EVENT_LAYOUT;
    public static String EVENT_AFTER_LAYOUT;
    public static String EVENT_BEFORE_UPDATESIZE;
    public static String EVENT_UPDATESIZE;
    public static String EVENT_AFTER_UPDATESIZE;
    public static String EVENT_FLIP;
    public static String EVENT_INDEX_CHANGED;
    public static String EVENT_REPAINT;
    protected PropertyChangeSupport changeSupport;
    protected mxIGraphModel model;
    protected mxGraphView view;
    protected mxStylesheet stylesheet;
    protected mxSelectionModel selection;
    protected int gridSize;
    protected boolean gridEnabled;
    protected int tolerance;
    protected double defaultOverlap;
    protected Object defaultParent;
    protected String alternateEdgeStyle;
    protected boolean enabled;
    protected boolean locked;
    protected boolean cloneable;
    protected boolean editable;
    protected boolean deletable;
    protected boolean movable;
    protected boolean edgeLabelsMovable;
    protected boolean vertexLabelsMovable;
    protected boolean dropEnabled;
    protected boolean sizable;
    protected boolean bendable;
    protected boolean disconnectable;
    protected boolean selectable;
    protected boolean autoSize;
    protected boolean autoLayout;
    protected boolean bubbleLayout;
    protected mxRectangle maximumGraphBounds;
    protected mxRectangle minimumContainerSize;
    protected mxRectangle maximumContainerSize;
    protected int border;
    protected boolean keepEdgesInForeground;
    protected boolean keepEdgesInBackground;
    protected boolean keepInsideParentOnMove;
    protected boolean extendParentOnResize;
    protected boolean shiftDownwards;
    protected boolean shiftRightwards;
    protected boolean collapseToPreferredSize;
    protected boolean resetEdgesOnResize;
    protected boolean resetEdgesOnMove;
    protected boolean allowLoops;
    protected mxMultiplicity[] multiplicities;
    protected mxEdgeStyle.mxEdgeStyleFunction defaultLoopStyle;
    protected boolean multigraph;
    protected boolean connectableEdges;
    protected boolean allowDanglingEdges;
    protected boolean cloneInvalidEdges;
    protected boolean disconnectOnMove;
    protected boolean labelsVisible;
    protected boolean htmlLabels;
    protected boolean swimlaneSelectionEnabled;
    protected boolean transparentSwimlaneContent;
    protected boolean swimlaneNesting;
    protected mxImage collapsedImage;
    protected mxImage expandedImage;
    protected mxImage warningImage;
    protected mxEventListener fullRepaintHandler;
    protected mxEventListener graphModelChangeHandler;
    
    public mxGraph() {
        this(null, null);
    }
    
    public mxGraph(final mxIGraphModel mxIGraphModel) {
        this(mxIGraphModel, null);
    }
    
    public mxGraph(final mxStylesheet mxStylesheet) {
        this(null, mxStylesheet);
    }
    
    public mxGraph(final mxIGraphModel mxIGraphModel, final mxStylesheet mxStylesheet) {
        this.changeSupport = new PropertyChangeSupport(this);
        this.selection = new mxSelectionModel(this);
        this.gridSize = 10;
        this.gridEnabled = true;
        this.tolerance = 4;
        this.defaultOverlap = 0.5;
        this.enabled = true;
        this.locked = false;
        this.cloneable = true;
        this.editable = true;
        this.deletable = true;
        this.movable = true;
        this.edgeLabelsMovable = true;
        this.vertexLabelsMovable = false;
        this.dropEnabled = true;
        this.sizable = true;
        this.bendable = true;
        this.disconnectable = true;
        this.selectable = true;
        this.autoSize = false;
        this.autoLayout = true;
        this.bubbleLayout = true;
        this.maximumGraphBounds = null;
        this.minimumContainerSize = null;
        this.maximumContainerSize = null;
        this.border = 0;
        this.keepEdgesInForeground = false;
        this.keepEdgesInBackground = false;
        this.keepInsideParentOnMove = true;
        this.extendParentOnResize = true;
        this.shiftDownwards = false;
        this.shiftRightwards = false;
        this.collapseToPreferredSize = true;
        this.resetEdgesOnResize = false;
        this.resetEdgesOnMove = false;
        this.allowLoops = false;
        this.defaultLoopStyle = mxEdgeStyle.Loop;
        this.multigraph = true;
        this.connectableEdges = false;
        this.allowDanglingEdges = true;
        this.cloneInvalidEdges = false;
        this.disconnectOnMove = true;
        this.labelsVisible = true;
        this.htmlLabels = false;
        this.swimlaneSelectionEnabled = true;
        this.transparentSwimlaneContent = true;
        this.swimlaneNesting = true;
        this.fullRepaintHandler = new mxEventListener() {
            public void invoke(final Object o, final Object[] array) {
                mxGraph.this.fireEvent(mxGraph.EVENT_REPAINT);
            }
        };
        this.graphModelChangeHandler = new mxEventListener() {
            public void invoke(final Object o, final Object[] array) {
                mxGraph.this.fireEvent(mxGraph.EVENT_REPAINT, new Object[] { mxGraph.this.graphModelChanged((mxIGraphModel)o, (List)array[0]) });
            }
        };
        this.setModel((mxIGraphModel != null) ? mxIGraphModel : new mxGraphModel());
        this.setStylesheet((mxStylesheet != null) ? mxStylesheet : new mxStylesheet());
        this.setView(new mxGraphView(this));
    }
    
    public mxIGraphModel getModel() {
        return this.model;
    }
    
    public void setModel(final mxIGraphModel mxIGraphModel) {
        if (this.model != null) {
            this.model.removeListener(this.graphModelChangeHandler);
        }
        final mxIGraphModel model = this.model;
        this.model = mxIGraphModel;
        if (this.view != null) {
            this.view.revalidate();
        }
        mxIGraphModel.addListener("change", this.graphModelChangeHandler);
        this.changeSupport.firePropertyChange("model", model, mxIGraphModel);
        this.fireEvent(mxGraph.EVENT_REPAINT);
    }
    
    public mxStylesheet getStylesheet() {
        return this.stylesheet;
    }
    
    public void setStylesheet(final mxStylesheet mxStylesheet) {
        final mxStylesheet stylesheet = this.stylesheet;
        this.stylesheet = mxStylesheet;
        this.changeSupport.firePropertyChange("stylesheet", stylesheet, mxStylesheet);
    }
    
    public mxGraphView getView() {
        return this.view;
    }
    
    public void setView(final mxGraphView mxGraphView) {
        if (this.view != null) {
            this.view.removeListener(this.fullRepaintHandler);
        }
        final mxGraphView view = this.view;
        this.view = mxGraphView;
        if (this.view != null) {
            this.view.revalidate();
        }
        mxGraphView.addListener(mxGraphView.EVENT_SCALE, this.fullRepaintHandler);
        mxGraphView.addListener(mxGraphView.EVENT_TRANSLATE, this.fullRepaintHandler);
        mxGraphView.addListener(mxGraphView.EVENT_SCALE_AND_TRANSLATE, this.fullRepaintHandler);
        mxGraphView.addListener(mxGraphView.EVENT_UP, this.fullRepaintHandler);
        mxGraphView.addListener(mxGraphView.EVENT_DOWN, this.fullRepaintHandler);
        this.changeSupport.firePropertyChange("view", view, mxGraphView);
    }
    
    public void selectCellsForChanges(final List list) {
        final ArrayList<mxICell> selectionCells = new ArrayList<mxICell>();
        for (final mxGraphModel.mxChildChange next : list) {
            if (next instanceof mxGraphModel.mxChildChange) {
                selectionCells.add(next.getChild());
            }
            else if (next instanceof mxGraphModel.mxTerminalChange) {
                selectionCells.add((mxICell)((mxGraphModel.mxTerminalChange)next).getCell());
            }
            else if (next instanceof mxGraphModel.mxValueChange) {
                selectionCells.add((mxICell)((mxGraphModel.mxValueChange)next).getCell());
            }
            else if (next instanceof mxGraphModel.mxStyleChange) {
                selectionCells.add((mxICell)((mxGraphModel.mxStyleChange)next).getCell());
            }
            else if (next instanceof mxGraphModel.mxGeometryChange) {
                selectionCells.add((mxICell)((mxGraphModel.mxGeometryChange)next).getCell());
            }
            else if (next instanceof mxGraphModel.mxCollapseChange) {
                selectionCells.add((mxICell)((mxGraphModel.mxCollapseChange)next).getCell());
            }
            else {
                if (!(next instanceof mxGraphModel.mxVisibleChange) || !((mxGraphModel.mxVisibleChange)next).isVisible()) {
                    continue;
                }
                selectionCells.add((mxICell)((mxGraphModel.mxVisibleChange)next).getCell());
            }
        }
        this.setSelectionCells(selectionCells);
    }
    
    public mxRectangle graphModelChanged(final mxIGraphModel mxIGraphModel, final List list) {
        mxRectangle processChanges = this.processChanges(list, true);
        this.view.validate();
        final mxRectangle processChanges2 = this.processChanges(list, false);
        if (processChanges2 != null) {
            if (processChanges == null) {
                processChanges = processChanges2;
            }
            else {
                processChanges.add(processChanges2);
            }
        }
        return processChanges;
    }
    
    public mxRectangle processChanges(final List list, final boolean b) {
        mxRectangle mxRectangle = null;
        final Iterator<Object> iterator = list.iterator();
        while (iterator.hasNext()) {
            final mxRectangle processChange = this.processChange(iterator.next(), b);
            if (mxRectangle == null) {
                mxRectangle = processChange;
            }
            else {
                mxRectangle.add(processChange);
            }
        }
        return mxRectangle;
    }
    
    public mxRectangle processChange(final Object o, final boolean b) {
        mxRectangle mxRectangle = null;
        if (o instanceof mxGraphModel.mxRootChange) {
            mxRectangle = this.getBounds();
            if (b) {
                this.clearSelection();
                this.cellRemoved(((mxGraphModel.mxRootChange)o).getPrevious(), false);
            }
        }
        else if (o instanceof mxGraphModel.mxChildChange) {
            final mxGraphModel.mxChildChange mxChildChange = (mxGraphModel.mxChildChange)o;
            if (mxChildChange.getParent() != mxChildChange.getPrevious()) {
                if (this.model.isVertex(mxChildChange.getParent()) || this.model.isEdge(mxChildChange.getParent())) {
                    mxRectangle = this.getBoundingBox(mxChildChange.getParent(), true, true);
                }
                if (this.model.isVertex(mxChildChange.getPrevious()) || this.model.isEdge(mxChildChange.getPrevious())) {
                    if (mxRectangle != null) {
                        mxRectangle.add(this.getBoundingBox(mxChildChange.getPrevious(), true, true));
                    }
                    else {
                        mxRectangle = this.getBoundingBox(mxChildChange.getPrevious(), true, true);
                    }
                }
            }
            if (mxRectangle == null) {
                mxRectangle = this.getBoundingBox(mxChildChange.getChild(), true, true);
            }
            if (b) {
                if (mxChildChange.getParent() != null) {
                    this.view.clear(mxChildChange.getChild(), false, true);
                }
                else {
                    this.cellRemoved(mxChildChange.getChild(), true);
                }
            }
        }
        else if (o instanceof mxGraphModel.mxTerminalChange) {
            final Object cell = ((mxGraphModel.mxTerminalChange)o).getCell();
            mxRectangle = this.getBoundingBox(cell, true);
            if (b) {
                this.view.invalidate(cell);
            }
        }
        else if (o instanceof mxGraphModel.mxValueChange) {
            final Object cell2 = ((mxGraphModel.mxValueChange)o).getCell();
            mxRectangle = this.getBoundingBox(cell2);
            if (b) {
                this.view.clear(cell2, false, false);
            }
        }
        else if (o instanceof mxGraphModel.mxStyleChange) {
            final Object cell3 = ((mxGraphModel.mxStyleChange)o).getCell();
            mxRectangle = this.getBoundingBox(cell3, true);
            if (b) {
                this.view.clear(cell3, false, false);
                this.view.invalidate(cell3);
            }
        }
        else if (o instanceof mxGraphModel.mxGeometryChange) {
            final Object cell4 = ((mxGraphModel.mxGeometryChange)o).getCell();
            mxRectangle = this.getBoundingBox(cell4, true, true);
            if (b) {
                this.view.invalidate(cell4);
            }
        }
        else if (o instanceof mxGraphModel.mxCollapseChange) {
            final Object cell5 = ((mxGraphModel.mxCollapseChange)o).getCell();
            mxRectangle = this.getBoundingBox(((mxGraphModel.mxCollapseChange)o).getCell(), true, true);
            if (b) {
                this.cellRemoved(cell5, false);
            }
        }
        else if (o instanceof mxGraphModel.mxVisibleChange) {
            final Object cell6 = ((mxGraphModel.mxVisibleChange)o).getCell();
            mxRectangle = this.getBoundingBox(((mxGraphModel.mxVisibleChange)o).getCell(), true, true);
            if (b) {
                this.cellRemoved(cell6, true);
            }
        }
        return mxRectangle;
    }
    
    protected void cellRemoved(final Object o, final boolean b) {
        if (b && this.isSelected(o)) {
            this.selection.removeCell(o);
        }
        for (int childCount = this.model.getChildCount(o), i = 0; i < childCount; ++i) {
            this.cellRemoved(this.model.getChildAt(o, i), b);
        }
        this.view.removeState(o);
    }
    
    public Hashtable getCellStyle(final Object o) {
        Hashtable hashtable = this.model.isEdge(o) ? this.stylesheet.getDefaultEdgeStyle() : this.stylesheet.getDefaultVertexStyle();
        final String style = this.model.getStyle(o);
        if (style != null) {
            hashtable = this.stylesheet.getCellStyle(style, hashtable);
        }
        if (hashtable == null) {
            hashtable = mxStylesheet.EMPTY_STYLE;
        }
        return hashtable;
    }
    
    public void setCellStyle(final String s) {
        this.setCellStyle(s, null);
    }
    
    public void setCellStyle(final String s, Object[] selectionCells) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        if (selectionCells != null) {
            this.model.beginUpdate();
            try {
                for (int i = 0; i < selectionCells.length; ++i) {
                    this.model.setStyle(selectionCells[i], s);
                }
            }
            finally {
                this.model.endUpdate();
            }
        }
    }
    
    public void toggleCellStyle(final String s, final boolean b, final Object o) {
        this.toggleCellStyles(s, b, new Object[] { o });
    }
    
    public void toggleCellStyles(final String s, final boolean b) {
        this.toggleCellStyles(s, b, null);
    }
    
    public void toggleCellStyles(final String s, final boolean b, Object[] selectionCells) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        if (selectionCells != null && selectionCells.length > 0) {
            final mxCellState state = this.view.getState(selectionCells[0]);
            final Hashtable hashtable = (state != null) ? state.getStyle() : this.getCellStyle(selectionCells[0]);
            if (hashtable != null) {
                this.setCellStyles(s, mxUtils.isTrue(hashtable, s, b) ? "0" : "1", selectionCells);
            }
        }
    }
    
    public void setCellStyles(final String s, final String s2) {
        this.setCellStyles(s, s2, null);
    }
    
    public void setCellStyles(final String s, final String s2, Object[] selectionCells) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        mxUtils.setCellStyles(this.model, selectionCells, s, s2);
    }
    
    public void toggleCellStyleFlags(final String s, final int n) {
        this.toggleCellStyleFlags(s, n, null);
    }
    
    public void toggleCellStyleFlags(final String s, final int n, final Object[] array) {
        this.setCellStyleFlags(s, n, null, array);
    }
    
    public void setCellStyleFlags(final String s, final int n, final boolean b) {
        this.setCellStyleFlags(s, n, b, null);
    }
    
    public void setCellStyleFlags(final String s, final int n, Boolean value, Object[] selectionCells) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        if (selectionCells != null && selectionCells.length > 0) {
            if (value == null) {
                final mxCellState state = this.view.getState(selectionCells[0]);
                final Hashtable hashtable = (state != null) ? state.getStyle() : this.getCellStyle(selectionCells[0]);
                if (hashtable != null) {
                    value = ((mxUtils.getInt(hashtable, s) & n) != n);
                }
            }
            mxUtils.setCellStyleFlags(this.model, selectionCells, s, n, value);
        }
    }
    
    public void alignCells(final String s) {
        this.alignCells(s, null);
    }
    
    public void alignCells(final String s, final Object[] array) {
        this.alignCells(s, array, null);
    }
    
    public void alignCells(final String s, Object[] selectionCells, Object o) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        if (selectionCells != null && selectionCells.length > 1) {
            if (o == null) {
                for (int i = 0; i < selectionCells.length; ++i) {
                    final mxGeometry cellGeometry = this.getCellGeometry(selectionCells[i]);
                    if (cellGeometry != null && !this.model.isEdge(selectionCells[i])) {
                        if (o == null) {
                            if (s == null || s.equals("left")) {
                                o = cellGeometry.getX();
                            }
                            else {
                                if (s.equals("center")) {
                                    o = cellGeometry.getX() + cellGeometry.getWidth() / 2.0;
                                    break;
                                }
                                if (s.equals("right")) {
                                    o = cellGeometry.getX() + cellGeometry.getWidth();
                                }
                                else if (s.equals("top")) {
                                    o = cellGeometry.getY();
                                }
                                else {
                                    if (s.equals("middle")) {
                                        o = cellGeometry.getY() + cellGeometry.getHeight() / 2.0;
                                        break;
                                    }
                                    if (s.equals("bottom")) {
                                        o = cellGeometry.getY() + cellGeometry.getHeight();
                                    }
                                }
                            }
                        }
                        else {
                            final double double1 = Double.parseDouble(String.valueOf(o));
                            if (s == null || s.equals("left")) {
                                o = Math.min(double1, cellGeometry.getX());
                            }
                            else if (s.equals("right")) {
                                o = Math.max(double1, cellGeometry.getX() + cellGeometry.getWidth());
                            }
                            else if (s.equals("top")) {
                                o = Math.min(double1, cellGeometry.getY());
                            }
                            else if (s.equals("bottom")) {
                                o = Math.max(double1, cellGeometry.getY() + cellGeometry.getHeight());
                            }
                        }
                    }
                }
            }
            this.model.beginUpdate();
            try {
                final double double2 = Double.parseDouble(String.valueOf(o));
                for (int j = 0; j < selectionCells.length; ++j) {
                    final mxGeometry cellGeometry2 = this.getCellGeometry(selectionCells[j]);
                    if (cellGeometry2 != null && !this.model.isEdge(selectionCells[j])) {
                        final mxGeometry mxGeometry = (mxGeometry)cellGeometry2.clone();
                        if (s == null || s.equals("left")) {
                            mxGeometry.setX(double2);
                        }
                        else if (s.equals("center")) {
                            mxGeometry.setX(double2 - mxGeometry.getWidth() / 2.0);
                        }
                        else if (s.equals("right")) {
                            mxGeometry.setX(double2 - mxGeometry.getWidth());
                        }
                        else if (s.equals("top")) {
                            mxGeometry.setY(double2);
                        }
                        else if (s.equals("middle")) {
                            mxGeometry.setY(double2 - mxGeometry.getHeight() / 2.0);
                        }
                        else if (s.equals("bottom")) {
                            mxGeometry.setY(double2 - mxGeometry.getHeight());
                        }
                        this.model.setGeometry(selectionCells[j], mxGeometry);
                    }
                }
            }
            finally {
                this.model.endUpdate();
            }
        }
    }
    
    public Object flip(final Object o) {
        if (o != null && this.alternateEdgeStyle != null) {
            this.model.beginUpdate();
            try {
                final String style = this.model.getStyle(o);
                if (style == null || style.length() == 0) {
                    this.model.setStyle(o, this.alternateEdgeStyle);
                }
                else {
                    this.model.setStyle(o, null);
                }
                final mxGeometry geometry = this.model.getGeometry(o);
                if (geometry != null) {
                    final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                    mxGeometry.setPoints(null);
                    this.model.setGeometry(o, mxGeometry);
                }
                this.fireEvent(mxGraph.EVENT_FLIP, new Object[] { o });
            }
            finally {
                this.model.endUpdate();
            }
        }
        return o;
    }
    
    public void toBack() {
        this.toBack(null);
    }
    
    public void toBack(final Object[] array) {
        this.setIndexForCells(array, 0);
    }
    
    public void toFront() {
        this.toFront(null);
    }
    
    public void toFront(final Object[] array) {
        this.setIndexForCells(array, null);
    }
    
    public void setIndexForCells(Object[] selectionCells, final Integer n) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        if (selectionCells != null) {
            this.model.beginUpdate();
            try {
                for (int i = 0; i < selectionCells.length; ++i) {
                    final Object parent = this.model.getParent(selectionCells[i]);
                    if (n == null) {
                        this.model.add(parent, selectionCells[i], this.model.getChildCount(parent) - 1);
                    }
                    else {
                        this.model.add(parent, selectionCells[i], n);
                    }
                }
                this.fireEvent(mxGraph.EVENT_INDEX_CHANGED, new Object[] { selectionCells, n });
            }
            finally {
                this.model.endUpdate();
            }
        }
    }
    
    public Object[] cloneCells(Object[] array) {
        Collection<Object> collection = null;
        if (array != null) {
            collection = new LinkedHashSet<Object>(array.length);
            for (int i = 0; i < array.length; ++i) {
                if (this.isCellCloneable(array[i])) {
                    collection.add(array[i]);
                }
            }
            if (!collection.isEmpty()) {
                final double scale = this.view.getScale();
                final mxPoint translate = this.view.getTranslate();
                array = collection.toArray();
                final Object[] cloneCells = this.model.cloneCells(array, true);
                for (int j = 0; j < array.length; ++j) {
                    final mxGeometry geometry = this.model.getGeometry(cloneCells[j]);
                    if (geometry != null) {
                        final mxCellState state = this.view.getState(array[j]);
                        final mxCellState state2 = this.view.getState(this.model.getParent(array[j]));
                        if (state != null && state2 != null) {
                            final double x = state2.getOrigin().getX();
                            final double y = state2.getOrigin().getY();
                            if (this.model.isEdge(cloneCells[j])) {
                                Object o;
                                for (o = this.model.getTerminal(array[j], true); o != null && !collection.contains(o); o = this.model.getParent(o)) {}
                                if (o == null) {
                                    final mxPoint absolutePoint = state.getAbsolutePoint(0);
                                    geometry.setTerminalPoint(new mxPoint(absolutePoint.getX() / scale - translate.getX(), absolutePoint.getY() / scale - translate.getY()), true);
                                }
                                Object o2;
                                for (o2 = this.model.getTerminal(array[j], false); o2 != null && !collection.contains(o2); o2 = this.model.getParent(o2)) {}
                                if (o2 == null) {
                                    final mxPoint absolutePoint2 = state.getAbsolutePoint(state.getAbsolutePointCount() - 1);
                                    geometry.setTerminalPoint(new mxPoint(absolutePoint2.getX() / scale - translate.getX(), absolutePoint2.getY() / scale - translate.getY()), false);
                                }
                                final List points = geometry.getPoints();
                                if (points != null) {
                                    for (final mxPoint mxPoint : points) {
                                        mxPoint.setX(mxPoint.getX() + x);
                                        mxPoint.setY(mxPoint.getY() + y);
                                    }
                                }
                            }
                            else {
                                geometry.setX(geometry.getX() + x);
                                geometry.setY(geometry.getY() + y);
                            }
                        }
                    }
                }
                return cloneCells;
            }
        }
        return (Object[])((collection != null) ? collection.toArray() : null);
    }
    
    public Object insertVertex(final Object o, final String s, final Object o2, final double n, final double n2, final double n3, final double n4) {
        return this.insertVertex(o, s, o2, n, n2, n3, n4, null);
    }
    
    public Object insertVertex(final Object o, final String s, final Object o2, final double n, final double n2, final double n3, final double n4, final String s2) {
        return this.addCell(this.createVertex(o, s, o2, n, n2, n3, n4, s2), o);
    }
    
    public Object createVertex(final Object o, final String id, final Object o2, final double n, final double n2, final double n3, final double n4, final String s) {
        final mxCell mxCell = new mxCell(o2, new mxGeometry(n, n2, n3, n4), s);
        mxCell.setId(id);
        mxCell.setVertex(true);
        mxCell.setConnectable(true);
        return mxCell;
    }
    
    public Object insertEdge(final Object o, final String s, final Object o2, final Object o3, final Object o4) {
        return this.insertEdge(o, s, o2, o3, o4, null);
    }
    
    public Object insertEdge(final Object o, final String s, final Object o2, final Object o3, final Object o4, final String s2) {
        return this.addEdge(this.createEdge(o, s, o2, o3, o4, s2), o, o3, o4, null);
    }
    
    public Object createEdge(final Object o, final String id, final Object o2, final Object o3, final Object o4, final String s) {
        final mxCell mxCell = new mxCell(o2, new mxGeometry(), s);
        mxCell.setId(id);
        mxCell.setEdge(true);
        mxCell.getGeometry().setRelative(true);
        return mxCell;
    }
    
    public Object addEdge(final Object o, final Object o2, final Object o3) {
        return this.addEdge(o, null, o2, o3, null);
    }
    
    public Object addEdge(final Object o, final Object o2, final Object o3, final Object o4, final Integer n) {
        return this.addCell(o, o2, n, o3, o4);
    }
    
    public Object addCell(final Object o) {
        return this.addCell(o, null);
    }
    
    public Object addCell(final Object o, final Object o2) {
        return this.addCell(o, o2, null, null, null);
    }
    
    public Object addCell(Object add, Object defaultParent, Integer value, final Object o, final Object o2) {
        if (defaultParent == null) {
            defaultParent = this.getDefaultParent();
        }
        if (value == null) {
            value = this.model.getChildCount(defaultParent);
        }
        this.fireEvent(mxGraph.EVENT_BEFORE_ADD, new Object[] { { add }, defaultParent, value, o, o2 });
        this.model.beginUpdate();
        try {
            add = this.model.add(defaultParent, add, value);
            if (add != null) {
                if (o != null) {
                    this.model.setTerminal(add, o, true);
                    this.fireEvent(mxGraph.EVENT_CONNECT, new Object[] { add, o, true });
                }
                if (o2 != null) {
                    this.model.setTerminal(add, o2, false);
                    this.fireEvent(mxGraph.EVENT_CONNECT, new Object[] { add, o2, false });
                }
                this.fireEvent(mxGraph.EVENT_ADD, new Object[] { { add } });
                this.layoutAfterAdd(defaultParent, new Object[] { add });
            }
        }
        finally {
            this.model.endUpdate();
        }
        if (add != null) {
            this.fireEvent(mxGraph.EVENT_AFTER_ADD, new Object[] { { add } });
        }
        return add;
    }
    
    public Object[] addCells(final Object[] array) {
        return this.addCells(array, null);
    }
    
    public Object[] addCells(final Object[] array, final Object o) {
        return this.addCells(array, o, null);
    }
    
    public Object[] addCells(final Object[] array, Object defaultParent, Integer value) {
        if (defaultParent == null) {
            defaultParent = this.getDefaultParent();
        }
        if (value == null) {
            value = this.model.getChildCount(defaultParent);
        }
        this.fireEvent(mxGraph.EVENT_BEFORE_ADD, new Object[] { array, defaultParent, value });
        this.model.beginUpdate();
        try {
            for (int i = 0; i < array.length; ++i) {
                this.model.add(defaultParent, array[i], value + i);
            }
            this.fireEvent(mxGraph.EVENT_ADD, new Object[] { array });
            this.layoutAfterAdd(defaultParent, array);
        }
        finally {
            this.model.endUpdate();
        }
        this.fireEvent(mxGraph.EVENT_AFTER_ADD, new Object[] { array });
        return array;
    }
    
    public Object[] layoutAfterAdd(final Object o, final Object[] array) {
        return this.layout(new Object[] { o });
    }
    
    public Object splitEdge(final Object o, final Object o2) {
        return this.splitEdge(o, o2, null);
    }
    
    public Object splitEdge(final Object o, final Object o2, Object o3) {
        if (o3 == null) {
            o3 = this.cloneCells(new Object[] { o })[0];
        }
        final Object parent = this.model.getParent(o);
        final Object terminal = this.model.getTerminal(o, true);
        final int childCount = this.model.getChildCount(parent);
        this.fireEvent(mxGraph.EVENT_BEFORE_ADD, new Object[] { { o3 }, parent, childCount, terminal, o2 });
        this.model.beginUpdate();
        try {
            this.model.add(parent, o3, childCount);
            this.model.setTerminal(o3, terminal, true);
            this.model.setTerminal(o3, o2, false);
            this.fireEvent(mxGraph.EVENT_CONNECT, new Object[] { { o3, terminal, true } });
            this.fireEvent(mxGraph.EVENT_CONNECT, new Object[] { { o3, o2, false } });
            this.model.setTerminal(o, o2, true);
            this.fireEvent(mxGraph.EVENT_CONNECT, new Object[] { { o, o2, true } });
            this.fireEvent(mxGraph.EVENT_ADD, new Object[] { { o3 } });
            this.layoutAfterSplit(parent, o, o2, o3);
        }
        finally {
            this.model.endUpdate();
        }
        this.fireEvent(mxGraph.EVENT_AFTER_ADD, new Object[] { { o3 } });
        return o3;
    }
    
    public Object[] layoutAfterSplit(final Object o, final Object o2, final Object o3, final Object o4) {
        return this.layout(new Object[] { o });
    }
    
    public Object[] remove() {
        return this.remove(null);
    }
    
    public Object[] remove(final Object[] array) {
        return this.remove(array, true, false, false);
    }
    
    public Object[] remove(final Object[] array, final boolean b) {
        return this.remove(array, b, false, false);
    }
    
    public Object[] hide() {
        return this.hide(null, true);
    }
    
    public Object[] hide(final Object[] array, final boolean b) {
        return this.remove(array, b, true, false);
    }
    
    public Object[] show() {
        return this.show(null, true);
    }
    
    public Object[] show(final Object[] array, final boolean b) {
        return this.remove(array, b, false, true);
    }
    
    public Object[] remove(Object[] selectionCells, final boolean b, final boolean b2, final boolean b3) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        List<Object> list = null;
        if (selectionCells != null && selectionCells.length > 0) {
            String s = mxGraph.EVENT_BEFORE_REMOVE;
            String s2 = mxGraph.EVENT_REMOVE;
            String s3 = mxGraph.EVENT_AFTER_REMOVE;
            if (b2) {
                s = mxGraph.EVENT_BEFORE_HIDE;
                s2 = mxGraph.EVENT_HIDE;
                s3 = mxGraph.EVENT_AFTER_HIDE;
            }
            else if (b3) {
                s = mxGraph.EVENT_BEFORE_SHOW;
                s2 = mxGraph.EVENT_SHOW;
                s3 = mxGraph.EVENT_AFTER_SHOW;
            }
            final double scale = this.view.getScale();
            final mxPoint translate = this.view.getTranslate();
            list = new ArrayList<Object>(selectionCells.length);
            this.fireEvent(s, new Object[] { selectionCells });
            this.model.beginUpdate();
            try {
                final Object[] parents = this.getParents(selectionCells);
                for (int i = 0; i < selectionCells.length; ++i) {
                    if (b2 || b3) {
                        if (b) {
                            this.removeEdges(selectionCells[i], true, b2, b3);
                        }
                        this.model.setVisible(selectionCells[i], b3);
                        list.add(selectionCells[i]);
                    }
                    else if (this.isDeletable(selectionCells[i])) {
                        if (b) {
                            list.addAll(Arrays.asList(this.removeEdges(selectionCells[i], true)));
                        }
                        else {
                            final List<Object> list2 = Arrays.asList(selectionCells);
                            final Object[] connections = this.getConnections(selectionCells[i]);
                            for (int j = 0; j < connections.length; ++j) {
                                if (!list2.contains(connections[j])) {
                                    final mxGeometry geometry = this.model.getGeometry(connections[j]);
                                    if (geometry != null) {
                                        final mxCellState state = this.view.getState(connections[j]);
                                        if (state != null) {
                                            final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                                            final boolean b4 = this.view.getVisibleTerminal(connections[j], true) == selectionCells[i];
                                            final mxPoint absolutePoint = state.getAbsolutePoint(b4 ? 0 : (state.getAbsolutePointCount() - 1));
                                            mxGeometry.setTerminalPoint(new mxPoint(absolutePoint.getX() / scale - translate.getX(), absolutePoint.getY() / scale - translate.getY()), b4);
                                            this.model.setTerminal(connections[j], null, b4);
                                            this.model.setGeometry(connections[j], mxGeometry);
                                        }
                                    }
                                }
                            }
                        }
                        list.add(this.model.remove(selectionCells[i]));
                    }
                }
                final Object[] array = list.toArray();
                this.fireEvent(s2, array, parents);
                this.layoutAfterRemove(parents, array, b2, b3);
            }
            finally {
                this.model.endUpdate();
            }
            this.fireEvent(s3, list.toArray());
        }
        return (Object[])((list != null) ? list.toArray() : null);
    }
    
    public Object[] layoutAfterRemove(final Object[] array, final Object[] array2, final boolean b, final boolean b2) {
        return this.layout(array);
    }
    
    public Object[] removeEdges(final Object o, final boolean b) {
        return this.removeEdges(o, b, false, false);
    }
    
    public Object[] hideEdges(final Object o, final boolean b) {
        return this.removeEdges(o, b, true, false);
    }
    
    public Object[] showEdges(final Object o, final boolean b) {
        return this.removeEdges(o, b, false, true);
    }
    
    public Object[] removeEdges(final Object o, final boolean b, final boolean b2, final boolean b3) {
        ArrayList list = null;
        if (o != null) {
            String s = mxGraph.EVENT_BEFORE_REMOVE;
            String s2 = mxGraph.EVENT_REMOVE;
            String s3 = mxGraph.EVENT_AFTER_REMOVE;
            if (b3) {
                s = mxGraph.EVENT_BEFORE_SHOW;
                s2 = mxGraph.EVENT_SHOW;
                s3 = mxGraph.EVENT_AFTER_SHOW;
            }
            else if (b2) {
                s = mxGraph.EVENT_BEFORE_HIDE;
                s2 = mxGraph.EVENT_HIDE;
                s3 = mxGraph.EVENT_AFTER_HIDE;
            }
            final int edgeCount = this.model.getEdgeCount(o);
            list = new ArrayList<Object>(edgeCount);
            this.model.beginUpdate();
            try {
                if (edgeCount > 0) {
                    this.fireEvent(s, new Object[] { list });
                    if (b3 || b2) {
                        for (int i = 0; i < edgeCount; ++i) {
                            final Object edge = this.model.getEdgeAt(o, i);
                            this.model.setVisible(edge, b3);
                            list.add(edge);
                        }
                    }
                    else {
                        for (int j = 0; j < edgeCount; ++j) {
                            final Object edge2 = this.model.getEdgeAt(o, 0);
                            if (this.isDeletable(edge2)) {
                                list.add(this.model.remove(edge2));
                            }
                        }
                    }
                    this.fireEvent(s2, new Object[] { list });
                }
                if (b) {
                    final Object[] children = mxGraphModel.getChildren(this.model, o);
                    for (int k = 0; k < children.length; ++k) {
                        this.removeEdges(children[k], true, b2, b3);
                    }
                }
            }
            finally {
                this.model.endUpdate();
            }
            if (!list.isEmpty()) {
                this.fireEvent(s3, new Object[] { list });
            }
        }
        return list.toArray();
    }
    
    public Object updateSize(final Object o) {
        if (o != null) {
            final mxRectangle preferredSizeForCell = this.getPreferredSizeForCell(o);
            final mxGeometry geometry = this.model.getGeometry(o);
            if (preferredSizeForCell != null && geometry != null) {
                this.fireEvent(mxGraph.EVENT_BEFORE_UPDATESIZE, new Object[] { o, preferredSizeForCell });
                this.model.beginUpdate();
                try {
                    mxGeometry updateSwimlaneSize = (mxGeometry)geometry.clone();
                    if (this.isSwimlane(o)) {
                        updateSwimlaneSize = this.updateSwimlaneSize(o, updateSwimlaneSize, preferredSizeForCell);
                    }
                    else {
                        updateSwimlaneSize.setWidth(preferredSizeForCell.getWidth());
                        updateSwimlaneSize.setHeight(preferredSizeForCell.getHeight());
                    }
                    if (geometry.getWidth() != updateSwimlaneSize.getWidth() || geometry.getHeight() != updateSwimlaneSize.getHeight()) {
                        this.resize(o, updateSwimlaneSize);
                    }
                    this.fireEvent(mxGraph.EVENT_UPDATESIZE, new Object[] { o, updateSwimlaneSize });
                }
                finally {
                    this.model.endUpdate();
                }
                this.fireEvent(mxGraph.EVENT_AFTER_UPDATESIZE, new Object[] { o });
            }
        }
        return o;
    }
    
    public mxGeometry updateSwimlaneSize(final Object o, final mxGeometry mxGeometry, final mxRectangle mxRectangle) {
        if (o != null && mxGeometry != null && mxRectangle != null) {
            this.model.beginUpdate();
            try {
                final boolean cellCollapsed = this.isCellCollapsed(o);
                final Hashtable cellStyle = this.getCellStyle(o);
                String style = this.model.getStyle(o);
                if (style == null) {
                    style = "";
                }
                String s;
                if (mxUtils.isTrue(cellStyle, mxConstants.STYLE_HORIZONTAL)) {
                    s = mxUtils.setStyle(style, mxConstants.STYLE_STARTSIZE, String.valueOf(mxRectangle.getWidth()));
                    if (cellCollapsed) {
                        mxGeometry.setWidth(mxRectangle.getWidth());
                    }
                    mxGeometry.setHeight(mxRectangle.getHeight());
                }
                else {
                    s = mxUtils.setStyle(style, mxConstants.STYLE_STARTSIZE, String.valueOf(mxRectangle.getHeight()));
                    if (cellCollapsed) {
                        mxGeometry.setHeight(mxRectangle.getHeight());
                    }
                    mxGeometry.setWidth(mxRectangle.getWidth());
                }
                this.model.setStyle(o, s);
                if (!cellCollapsed) {
                    final mxRectangle bounds = this.view.getBounds(mxGraphModel.getChildren(this.model, o));
                    if (bounds != null) {
                        final mxPoint translate = this.view.getTranslate();
                        final double scale = this.view.getScale();
                        final double b = (bounds.getX() + bounds.getWidth()) / scale - mxGeometry.getX() - translate.getX();
                        final double b2 = (bounds.getY() + bounds.getHeight()) / scale - mxGeometry.getY() - translate.getY();
                        mxGeometry.setWidth(Math.max(mxGeometry.getWidth(), b));
                        mxGeometry.setHeight(Math.max(mxGeometry.getHeight(), b2));
                    }
                }
            }
            finally {
                this.model.endUpdate();
            }
        }
        return mxGeometry;
    }
    
    public mxRectangle getPreferredSizeForCell(final Object o) {
        mxRectangle mxRectangle = null;
        if (o != null) {
            final mxCellState state = this.view.getState(o);
            final Hashtable hashtable = (state != null) ? state.style : this.getCellStyle(o);
            if (hashtable != null && !this.model.isEdge(o)) {
                double n = 0.0;
                double n2 = 0.0;
                if ((this.getImage(state) != null || mxUtils.getString(hashtable, mxConstants.STYLE_IMAGE) != null) && mxUtils.getString(hashtable, mxConstants.STYLE_SHAPE, "").equals("label")) {
                    if (mxUtils.getString(hashtable, mxConstants.STYLE_VERTICAL_ALIGN, "").equals("middle")) {
                        n += mxUtils.getDouble(hashtable, mxConstants.STYLE_IMAGE_WIDTH, mxConstants.DEFAULT_IMAGESIZE);
                    }
                    if (mxUtils.getString(hashtable, mxConstants.STYLE_ALIGN, "").equals("center")) {
                        n2 += mxUtils.getDouble(hashtable, mxConstants.STYLE_IMAGE_HEIGHT, mxConstants.DEFAULT_IMAGESIZE);
                    }
                }
                final double double1 = mxUtils.getDouble(hashtable, mxConstants.STYLE_SPACING);
                final double n3 = n + 2.0 * double1 + mxUtils.getDouble(hashtable, mxConstants.STYLE_SPACING_LEFT) + mxUtils.getDouble(hashtable, mxConstants.STYLE_SPACING_RIGHT);
                final double n4 = n2 + 2.0 * double1 + mxUtils.getDouble(hashtable, mxConstants.STYLE_SPACING_TOP) + mxUtils.getDouble(hashtable, mxConstants.STYLE_SPACING_BOTTOM);
                final String label = this.getLabel(o);
                if (label != null && label.length() > 0) {
                    final mxRectangle labelSize = mxUtils.getLabelSize(label, hashtable, this.isHtmlLabel(o));
                    double snap = labelSize.getWidth() + n3;
                    double snap2 = labelSize.getHeight() + n4;
                    if (!mxUtils.isTrue(hashtable, mxConstants.STYLE_HORIZONTAL, true)) {
                        final double n5 = snap2;
                        snap2 = snap;
                        snap = n5;
                    }
                    if (this.gridEnabled) {
                        snap = this.snap(snap + this.gridSize / 2);
                        snap2 = this.snap(snap2 + this.gridSize / 2);
                    }
                    mxRectangle = new mxRectangle(0.0, 0.0, snap, snap2);
                }
                else {
                    final double n6 = 4 * this.gridSize;
                    mxRectangle = new mxRectangle(0.0, 0.0, n6, n6);
                }
            }
        }
        return mxRectangle;
    }
    
    public void resize(final Object o, final mxRectangle mxRectangle) {
        this.resizeCells(new Object[] { o }, new mxRectangle[] { mxRectangle });
    }
    
    public void resizeCells(final Object[] array, final mxRectangle[] array2) {
        if (array != null && array2 != null) {
            this.fireEvent(mxGraph.EVENT_BEFORE_RESIZE, new Object[] { array, array2 });
            final ArrayList<Object> list = new ArrayList<Object>(array.length);
            final ArrayList<Object> list2 = new ArrayList<Object>(array.length);
            final ArrayList<mxRectangle> list3 = new ArrayList<mxRectangle>(array.length);
            final ArrayList<mxGeometry> list4 = new ArrayList<mxGeometry>(array.length);
            this.model.beginUpdate();
            try {
                for (int i = 0; i < array.length; ++i) {
                    final Object o = array[i];
                    final mxRectangle mxRectangle = array2[i];
                    final mxGeometry geometry = this.model.getGeometry(o);
                    if (geometry.getX() != mxRectangle.getX() || geometry.getY() != mxRectangle.getY() || geometry.getWidth() != mxRectangle.getWidth() || geometry.getHeight() != mxRectangle.getHeight()) {
                        list.add(o);
                        list3.add(mxRectangle);
                        list4.add(geometry);
                        final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                        if (mxGeometry.isRelative()) {
                            final mxPoint offset = mxGeometry.getOffset();
                            if (offset != null) {
                                offset.setX(offset.getX() + mxRectangle.getX() - mxGeometry.getX());
                                offset.setY(offset.getY() + mxRectangle.getY() - mxGeometry.getY());
                            }
                        }
                        else {
                            mxGeometry.setX(mxRectangle.getX());
                            mxGeometry.setY(mxRectangle.getY());
                        }
                        mxGeometry.setWidth(mxRectangle.getWidth());
                        mxGeometry.setHeight(mxRectangle.getHeight());
                        this.model.setGeometry(o, mxGeometry);
                        if (this.isExtendParentOnResize(o)) {
                            this.extendParent(o);
                        }
                        if (!this.isCellCollapsed(o)) {
                            list2.add(o);
                        }
                    }
                }
                if (!list.isEmpty()) {
                    final Object[] array3 = list.toArray();
                    this.fireEvent(mxGraph.EVENT_RESIZE, new Object[] { array3, list3, list4 });
                    if (this.resetEdgesOnResize) {
                        this.resetEdges(array3);
                    }
                    if (this.layoutAfterResize(this.getParents(array3), list2.toArray()).length == 0) {
                        this.cascadeResize(array3[0]);
                    }
                }
            }
            finally {
                this.model.endUpdate();
            }
            this.fireEvent(mxGraph.EVENT_AFTER_RESIZE, new Object[] { list });
        }
    }
    
    public Object[] layoutAfterResize(final Object[] array, final Object[] array2) {
        final int n = (array != null) ? array.length : 0;
        final int n2 = (array2 != null) ? array2.length : 0;
        final Object[] array3 = new Object[n + n2];
        System.arraycopy(array, 0, array3, 0, n);
        System.arraycopy(array2, 0, array3, n, n2);
        return this.layout(array3);
    }
    
    public void cascadeResize(final Object o) {
        if (o != null) {
            final mxCellState state = this.view.getState(o);
            final mxCellState state2 = this.view.getState(this.model.getParent(o));
            if (state != null && state2 != null) {
                final Object[] cellsToShift = this.getCellsToShift(state);
                if (cellsToShift != null) {
                    final double scale = this.view.getScale();
                    final mxPoint translate = this.view.getTranslate();
                    final double n = state.getX() - state2.getOrigin().getX() - translate.getX() * scale;
                    final double n2 = state.getY() - state2.getOrigin().getY() - translate.getY() * scale;
                    final double n3 = state.getX() + state.getWidth();
                    final double n4 = state.getY() + state.getHeight();
                    final mxGeometry geometry = this.model.getGeometry(o);
                    final double n5 = state.getWidth() - geometry.getWidth() * scale + n - geometry.getX() * scale;
                    final double n6 = state.getHeight() - geometry.getHeight() * scale + n2 - geometry.getY() * scale;
                    final double n7 = 1.0 - geometry.getWidth() * scale / state.getWidth();
                    final double n8 = 1.0 - geometry.getHeight() * scale / state.getHeight();
                    this.model.beginUpdate();
                    try {
                        for (int i = 0; i < cellsToShift.length; ++i) {
                            mxGeometry mxGeometry = this.model.getGeometry(cellsToShift[i]);
                            final mxCellState state3 = this.view.getState(cellsToShift[i]);
                            if (state3 != null && cellsToShift[i] != o && this.isShiftable(cellsToShift[i])) {
                                if (this.shiftRightwards) {
                                    if (state3.getX() >= n3) {
                                        mxGeometry = mxGeometry.translate(-n5, 0.0);
                                    }
                                    else {
                                        mxGeometry = mxGeometry.translate(-n7 * Math.max(0.0, state3.getX() - n), 0.0);
                                    }
                                }
                                if (this.shiftDownwards) {
                                    mxGeometry mxGeometry2;
                                    if (state3.getY() >= n4) {
                                        mxGeometry2 = mxGeometry.translate(0.0, -n6);
                                    }
                                    else {
                                        mxGeometry2 = mxGeometry.translate(0.0, -n8 * Math.max(0.0, state3.getY() - n2));
                                    }
                                    if (mxGeometry2 != this.model.getGeometry(cellsToShift[i])) {
                                        this.model.setGeometry(cellsToShift[i], mxGeometry2);
                                        if (this.isExtendParentOnResize(cellsToShift[i])) {
                                            this.extendParent(cellsToShift[i]);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    finally {
                        this.model.endUpdate();
                    }
                }
            }
        }
    }
    
    public void extendParent(final Object o) {
        if (o != null) {
            final Object parent = this.model.getParent(o);
            final mxGeometry geometry = this.model.getGeometry(parent);
            if (parent != null && geometry != null && !this.isCellCollapsed(parent)) {
                final mxGeometry geometry2 = this.model.getGeometry(o);
                if (geometry2 != null && (geometry.getWidth() < geometry2.getX() + geometry2.getWidth() || geometry.getHeight() < geometry2.getY() + geometry2.getHeight())) {
                    final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                    mxGeometry.setWidth(Math.max(mxGeometry.getWidth(), geometry2.getX() + geometry2.getWidth()));
                    mxGeometry.setHeight(Math.max(mxGeometry.getHeight(), geometry2.getY() + geometry2.getHeight()));
                    this.resize(parent, mxGeometry);
                }
            }
        }
    }
    
    public Object[] getCellsToShift(final mxCellState mxCellState) {
        return this.getCellsBeyond(mxCellState.getX() + (this.shiftDownwards ? 0.0 : mxCellState.getWidth()), mxCellState.getY() + ((this.shiftDownwards && this.shiftRightwards) ? 0.0 : mxCellState.getHeight()), this.model.getParent(mxCellState.getCell()), this.shiftRightwards, this.shiftDownwards);
    }
    
    public Object[] move(final Object[] array, final double n, final double n2) {
        return this.move(array, n, n2, false);
    }
    
    public Object[] move(final Object[] array, final double n, final double n2, final boolean b) {
        return this.move(array, n, n2, b, null, null);
    }
    
    public Object[] move(final Object[] array, final double n, final double n2, final boolean b, final Object o, final Point point) {
        Object[] cloneCells = array;
        if (cloneCells != null && (n != 0.0 || n2 != 0.0 || b || o != null)) {
            this.fireEvent(mxGraph.EVENT_BEFORE_MOVE, new Object[] { array, n, n2, b, o, point });
            this.model.beginUpdate();
            try {
                if (b) {
                    cloneCells = this.cloneCells(array);
                    for (int i = 0; i < cloneCells.length; ++i) {
                        if (this.cloneInvalidEdges || !this.model.isEdge(cloneCells[i]) || this.getEdgeValidationError(cloneCells[i], this.model.getTerminal(cloneCells[i], true), this.model.getTerminal(cloneCells[i], false)) == null) {
                            final Object defaultParent = this.getDefaultParent();
                            this.model.add(defaultParent, cloneCells[i], this.model.getChildCount(defaultParent));
                            final mxCellState state = this.view.getState(defaultParent);
                            final mxGeometry geometry = this.model.getGeometry(cloneCells[i]);
                            if (state != null && geometry != null) {
                                this.model.setGeometry(cloneCells[i], geometry.translate(-state.origin.getX(), -state.origin.getY()));
                            }
                        }
                        else {
                            cloneCells[i] = null;
                        }
                    }
                    this.fireEvent(mxGraph.EVENT_CLONE, new Object[] { cloneCells, array });
                }
                else if (this.disconnectOnMove && this.allowDanglingEdges) {
                    this.disconnect(array);
                }
                for (int j = 0; j < cloneCells.length; ++j) {
                    final mxGeometry geometry2 = this.model.getGeometry(cloneCells[j]);
                    if (geometry2 != null && this.isMovable(cloneCells[j])) {
                        final mxGeometry translate = geometry2.translate(n, n2);
                        if (translate.isRelative() && !this.model.isEdge(cloneCells[j])) {
                            if (translate.getOffset() == null) {
                                translate.setOffset(new mxPoint(n, n2));
                            }
                            else {
                                final mxPoint offset = translate.getOffset();
                                offset.setX(offset.getX() + n);
                                offset.setY(offset.getY() + n);
                            }
                        }
                        this.model.setGeometry(cloneCells[j], translate);
                    }
                }
                this.moveInto(cloneCells, o, point);
            }
            finally {
                this.model.endUpdate();
            }
            this.fireEvent(mxGraph.EVENT_AFTER_MOVE, new Object[] { array, cloneCells, n, n2, b, o, point });
        }
        return cloneCells;
    }
    
    public mxRectangle getContentArea(final Object o) {
        if (o != null && !this.model.isEdge(o)) {
            final Object parent = this.model.getParent(o);
            if (parent == this.getDefaultParent() || parent == this.getCurrentRoot()) {
                return this.getMaximumGraphBounds();
            }
            if (parent != null && parent != this.getDefaultParent()) {
                final mxGeometry geometry = this.model.getGeometry(parent);
                if (geometry != null) {
                    double width = 0.0;
                    double height = 0.0;
                    double width2 = geometry.getWidth();
                    double height2 = geometry.getHeight();
                    if (this.isSwimlane(parent)) {
                        final mxRectangle startSize = this.getStartSize(parent);
                        width = startSize.getWidth();
                        width2 -= startSize.getWidth();
                        height = startSize.getHeight();
                        height2 -= startSize.getHeight();
                    }
                    return new mxRectangle(width, height, width2, height2);
                }
            }
        }
        return null;
    }
    
    public mxRectangle getMaximumGraphBounds() {
        return this.maximumGraphBounds;
    }
    
    public void setMaximumGraphBounds(final mxRectangle mxRectangle) {
        final mxRectangle maximumGraphBounds = this.maximumGraphBounds;
        this.maximumGraphBounds = mxRectangle;
        this.changeSupport.firePropertyChange("maximumGraphBounds", maximumGraphBounds, mxRectangle);
    }
    
    public void removeFromParent() {
        this.removeFromParent(this.getSelectionCells());
    }
    
    public void removeFromParent(Object[] selectionCells) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        if (selectionCells != null) {
            final Object defaultParent = this.getDefaultParent();
            final ArrayList<Object> list = new ArrayList<Object>(selectionCells.length);
            for (int i = 0; i < selectionCells.length; ++i) {
                if (this.model.getParent(selectionCells[i]) != defaultParent) {
                    list.add(selectionCells[i]);
                }
            }
            if (!list.isEmpty()) {
                this.moveInto(list.toArray(), defaultParent);
            }
        }
    }
    
    public void moveInto(final Object[] array, final Object o) {
        this.moveInto(array, o, null);
    }
    
    public void moveInto(final Object[] array, final Object o, final Point point) {
        if (array != null && array.length > 0) {
            this.model.beginUpdate();
            try {
                Object list;
                if (o != null) {
                    list = new HashSet<Object>();
                    ((Collection<Object>)list).add(o);
                    final Object o2 = array[0];
                    if (this.model.isEdge(o) && this.model.isConnectable(o2)) {
                        if (this.getEdgeValidationError(o, this.model.getTerminal(o, true), o2) == null) {
                            this.splitEdge(o, o2);
                        }
                    }
                    else {
                        for (int i = 0; i < array.length; ++i) {
                            if (array[i] != o) {
                                int childCount = this.model.getChildCount(o);
                                final Object parent = this.model.getParent(array[i]);
                                ((Collection<Object>)list).add(parent);
                                if (o != parent) {
                                    final mxCellState state = this.view.getState(o);
                                    final mxCellState state2 = this.view.getState(parent);
                                    final mxGeometry geometry = this.model.getGeometry(array[i]);
                                    if (geometry != null && state != null && state2 != null) {
                                        this.model.setGeometry(array[i], geometry.translate(state2.getOrigin().getX() - state.getOrigin().getX(), state2.getOrigin().getY() - state.getOrigin().getY()));
                                    }
                                }
                                else {
                                    --childCount;
                                }
                                this.model.add(o, array[i], childCount);
                            }
                        }
                    }
                }
                else {
                    list = Arrays.asList(this.getParents(array));
                }
                this.cellsMoved(array, point);
                this.keepInside(array);
                if (this.resetEdgesOnMove) {
                    this.resetEdges(array);
                }
                this.fireEvent(mxGraph.EVENT_MOVE, new Object[] { array, list, o });
                this.layoutAfterMove(((Collection)list).toArray(), array, o);
            }
            finally {
                this.model.endUpdate();
            }
        }
    }
    
    public void cellsMoved(final Object[] array, final Point point) {
        if (array != null && point != null) {
            for (int i = 0; i < array.length; ++i) {
                final mxIGraphLayout layout = this.getLayout(this.model.getParent(array[i]));
                if (layout != null) {
                    layout.move(array[i], point.getX(), point.getY());
                }
            }
        }
    }
    
    public void keepInside(final Object[] array) {
        if (array != null) {
            this.model.beginUpdate();
            try {
                for (int i = 0; i < array.length; ++i) {
                    final Object o = array[i];
                    final mxRectangle mxRectangle = this.isKeepInsideParentOnMove(o) ? this.getContentArea(o) : this.getMaximumGraphBounds();
                    if (mxRectangle != null) {
                        final mxGeometry geometry = this.model.getGeometry(o);
                        if (!geometry.isRelative() && (geometry.getX() < mxRectangle.getX() || geometry.getY() < mxRectangle.getY() || mxRectangle.getWidth() < geometry.getX() + geometry.getWidth() || mxRectangle.getHeight() < geometry.getY() + geometry.getHeight())) {
                            final double overlap = this.getOverlap(o);
                            if (mxRectangle.getWidth() > 0.0) {
                                geometry.setX(Math.min(geometry.getX(), mxRectangle.getX() + mxRectangle.getWidth() - (1.0 - overlap) * geometry.getWidth()));
                            }
                            if (mxRectangle.getHeight() > 0.0) {
                                geometry.setY(Math.min(geometry.getY(), mxRectangle.getY() + mxRectangle.getHeight() - (1.0 - overlap) * geometry.getHeight()));
                            }
                            geometry.setX(Math.max(geometry.getX(), mxRectangle.getX() - geometry.getWidth() * overlap));
                            geometry.setY(Math.max(geometry.getY(), mxRectangle.getY() - geometry.getHeight() * overlap));
                        }
                    }
                }
            }
            finally {
                this.model.endUpdate();
            }
        }
    }
    
    public void resetEdges(final Object[] a) {
        if (a != null) {
            final HashSet set = new HashSet((Collection<? extends E>)Arrays.asList(a));
            this.model.beginUpdate();
            try {
                for (int i = 0; i < a.length; ++i) {
                    final Object[] edges = mxGraphModel.getEdges(this.model, a[i]);
                    if (edges != null) {
                        for (int j = 0; j < edges.length; ++j) {
                            final Object visibleTerminal = this.view.getVisibleTerminal(edges[j], true);
                            final Object visibleTerminal2 = this.view.getVisibleTerminal(edges[j], false);
                            if (!set.contains(visibleTerminal) || !set.contains(visibleTerminal2)) {
                                final mxGeometry geometry = this.model.getGeometry(edges[j]);
                                final List points = geometry.getPoints();
                                if (geometry != null && points != null && !points.isEmpty()) {
                                    final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                                    mxGeometry.setPoints(null);
                                    this.model.setGeometry(edges[j], mxGeometry);
                                }
                            }
                        }
                    }
                    this.resetEdges(mxGraphModel.getChildren(this.model, a[i]));
                }
            }
            finally {
                this.model.endUpdate();
            }
        }
    }
    
    public Object[] layoutAfterMove(final Object[] array, final Object[] array2, final Object o) {
        return this.layout(array);
    }
    
    public void connect(final Object o, final Object o2, final boolean b) {
        if (o != null) {
            this.fireEvent(mxGraph.EVENT_BEFORE_CONNECT, new Object[] { o, o2, b });
            this.model.beginUpdate();
            try {
                this.model.setTerminal(o, o2, b);
                final mxGeometry geometry = this.model.getGeometry(o);
                if (geometry != null && geometry.getPoints() != null) {
                    final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                    mxGeometry.setPoints(null);
                    this.model.setGeometry(o, mxGeometry);
                }
                this.fireEvent(mxGraph.EVENT_CONNECT, new Object[] { o, o2, b });
                this.layoutAfterConnect(o, o2, b);
            }
            finally {
                this.model.endUpdate();
            }
            this.fireEvent(mxGraph.EVENT_AFTER_CONNECT, new Object[] { o, o2, b });
        }
    }
    
    public Object[] layoutAfterConnect(final Object o, final Object o2, final boolean b) {
        final Object parent = this.model.getParent(o2);
        if (parent != null) {
            return this.layout(new Object[] { parent });
        }
        return null;
    }
    
    public void disconnect(final Object[] array) {
        if (array != null) {
            this.fireEvent(mxGraph.EVENT_BEFORE_DISCONNECT, new Object[] { array });
            this.model.beginUpdate();
            try {
                final double scale = this.view.getScale();
                final mxPoint translate = this.view.getTranslate();
                final HashSet<Object> set = new HashSet<Object>();
                for (int i = 0; i < array.length; ++i) {
                    set.add(array[i]);
                }
                for (int j = 0; j < array.length; ++j) {
                    if (this.model.isEdge(array[j])) {
                        final mxGeometry geometry = this.model.getGeometry(array[j]);
                        if (geometry != null) {
                            final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                            final mxCellState state = this.view.getState(array[j]);
                            final mxCellState state2 = this.view.getState(this.model.getParent(array[j]));
                            if (state != null && state2 != null) {
                                final double n = -state2.getOrigin().getX();
                                final double n2 = -state2.getOrigin().getY();
                                Object o = this.model.getTerminal(array[j], true);
                                if (o != null && this.isDisconnectable(array[j], o, true)) {
                                    while (o != null && !set.contains(o)) {
                                        o = this.model.getParent(o);
                                    }
                                    if (o == null) {
                                        final mxPoint absolutePoint = state.getAbsolutePoint(0);
                                        mxGeometry.setTerminalPoint(new mxPoint(absolutePoint.getX() / scale - translate.getX() + n, absolutePoint.getY() / scale - translate.getY() + n2), true);
                                        this.model.setTerminal(array[j], null, true);
                                    }
                                }
                                Object o2 = this.model.getTerminal(array[j], false);
                                if (o2 != null && this.isDisconnectable(array[j], o2, false)) {
                                    while (o2 != null && !set.contains(o2)) {
                                        o2 = this.model.getParent(o2);
                                    }
                                    if (o2 == null) {
                                        final mxPoint absolutePoint2 = state.getAbsolutePoint(state.getAbsolutePointCount() - 1);
                                        mxGeometry.setTerminalPoint(new mxPoint(absolutePoint2.getX() / scale - translate.getX() + n, absolutePoint2.getY() / scale - translate.getY() + n2), false);
                                        this.model.setTerminal(array[j], null, false);
                                    }
                                }
                            }
                            this.model.setGeometry(array[j], mxGeometry);
                        }
                    }
                }
                this.fireEvent(mxGraph.EVENT_DISCONNECT, new Object[] { array });
            }
            finally {
                this.model.endUpdate();
            }
            this.fireEvent(mxGraph.EVENT_AFTER_DISCONNECT, new Object[] { array });
        }
    }
    
    public mxRectangle getBounds() {
        return this.view.getBounds();
    }
    
    public mxRectangle getCellBounds(final Object o) {
        return this.getCellBounds(o, false);
    }
    
    public mxRectangle getCellBounds(final Object o, final boolean b) {
        return this.getCellBounds(o, b, false);
    }
    
    public mxRectangle getCellBounds(final Object o, final boolean b, final boolean b2) {
        return this.getCellBounds(o, b, b2, false);
    }
    
    public mxRectangle getBoundingBox(final Object o) {
        return this.getBoundingBox(o, false);
    }
    
    public mxRectangle getBoundingBox(final Object o, final boolean b) {
        return this.getBoundingBox(o, b, false);
    }
    
    public mxRectangle getBoundingBox(final Object o, final boolean b, final boolean b2) {
        return this.getCellBounds(o, b, b2, true);
    }
    
    public mxRectangle getPaintBounds(final Object[] array) {
        return this.getBoundsForCells(array, false, true, true);
    }
    
    public mxRectangle getBoundsForCells(final Object[] array, final boolean b, final boolean b2, final boolean b3) {
        mxRectangle mxRectangle = null;
        if (array != null && array.length > 0) {
            for (int i = 0; i < array.length; ++i) {
                final mxRectangle cellBounds = this.getCellBounds(array[i], b, b2, b3);
                if (cellBounds != null) {
                    if (mxRectangle == null) {
                        mxRectangle = new mxRectangle(cellBounds);
                    }
                    else {
                        mxRectangle.add(cellBounds);
                    }
                }
            }
        }
        return mxRectangle;
    }
    
    public mxRectangle getCellBounds(final Object o, final boolean b, final boolean b2, final boolean b3) {
        Object[] array;
        if (b) {
            final HashSet<Object> set = new HashSet<Object>();
            set.add(o);
            HashSet<Object> set3;
            for (HashSet<Object> set2 = new HashSet<Object>(Arrays.asList(this.getEdges(o))); !set2.isEmpty() && !set.containsAll(set2); set2 = set3) {
                set.addAll(set2);
                set3 = new HashSet<Object>();
                final Iterator<Object> iterator = set2.iterator();
                while (iterator.hasNext()) {
                    set3.addAll(Arrays.asList(this.getEdges(iterator.next())));
                }
            }
            array = set.toArray();
        }
        else {
            array = new Object[] { o };
        }
        mxRectangle mxRectangle;
        if (b3) {
            mxRectangle = this.view.getBoundingBox(array);
        }
        else {
            mxRectangle = this.view.getBounds(array);
        }
        if (b2) {
            for (int childCount = this.model.getChildCount(o), i = 0; i < childCount; ++i) {
                final mxRectangle cellBounds = this.getCellBounds(this.model.getChildAt(o, i), b, true, b3);
                if (mxRectangle != null) {
                    mxRectangle.add(cellBounds);
                }
                else {
                    mxRectangle = cellBounds;
                }
            }
        }
        return mxRectangle;
    }
    
    public void refresh() {
        this.view.revalidate();
        this.repaint();
    }
    
    public void repaint() {
        this.fireEvent(mxGraph.EVENT_REPAINT);
    }
    
    public double snap(double n) {
        if (this.gridEnabled) {
            n = (double)(Math.round(n / this.gridSize) * this.gridSize);
        }
        return n;
    }
    
    public boolean isCellVisible(final Object o) {
        return this.model.isVisible(o);
    }
    
    public boolean isCellCollapsed(final Object o) {
        return this.model.isCollapsed(o);
    }
    
    public boolean isOrthogonal(final mxCellState mxCellState, final mxCellState mxCellState2) {
        final mxEdgeStyle.mxEdgeStyleFunction value = mxCellState.style.get(mxConstants.STYLE_EDGE);
        return value != null && (value.equals("mxEdgeStyle.ElbowConnector") || value.equals("mxEdgeStyle.SideToSide") || value.equals("mxEdgeStyle.TopToBottom") || value.equals("mxEdgeStyle.EntityRelation") || value == mxEdgeStyle.ElbowConnector || value == mxEdgeStyle.SideToSide || value == mxEdgeStyle.TopToBottom || value == mxEdgeStyle.EntityRelation);
    }
    
    public boolean isLoop(final mxCellState mxCellState) {
        final Object visibleTerminal = this.view.getVisibleTerminal(mxCellState.getCell(), true);
        final Object visibleTerminal2 = this.view.getVisibleTerminal(mxCellState.getCell(), false);
        return visibleTerminal != null && visibleTerminal == visibleTerminal2;
    }
    
    public void collapse() {
        this.collapse(null);
    }
    
    public void collapse(final Object[] array) {
        this.collapse(array, false);
    }
    
    public void collapse(final Object[] array, final boolean b) {
        this.setCollapsedState(array, true, b);
    }
    
    public void expand() {
        this.expand(null);
    }
    
    public void expand(final Object[] array) {
        this.expand(array, false);
    }
    
    public void expand(final Object[] array, final boolean b) {
        this.setCollapsedState(array, false, b);
    }
    
    public void setCollapsedState(final boolean b) {
        this.setCollapsedState(null, b);
    }
    
    public void setCollapsedState(final Object[] array, final boolean b) {
        this.setCollapsedState(array, b, false);
    }
    
    public void setCollapsedState(Object[] selectionCells, final boolean b, final boolean b2) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        if (selectionCells != null && selectionCells.length > 0) {
            String s = mxGraph.EVENT_BEFORE_COLLAPSE;
            String s2 = mxGraph.EVENT_COLLAPSE;
            String s3 = mxGraph.EVENT_AFTER_COLLAPSE;
            if (b) {
                s = mxGraph.EVENT_BEFORE_EXPAND;
                s2 = mxGraph.EVENT_EXPAND;
                s3 = mxGraph.EVENT_AFTER_EXPAND;
            }
            this.fireEvent(s, new Object[] { selectionCells });
            this.model.beginUpdate();
            try {
                for (int i = 0; i < selectionCells.length; ++i) {
                    if ((b && this.isCollapsable(selectionCells[i]) && !this.isCellCollapsed(selectionCells[i])) || (!b && this.isExpandable(selectionCells[i]) && this.isCellCollapsed(selectionCells[i]))) {
                        this.model.setCollapsed(selectionCells[i], b);
                        this.swapBounds(selectionCells[i], b);
                        if (this.isExtendParentOnResize(selectionCells[i])) {
                            this.extendParent(selectionCells[i]);
                        }
                        this.cascadeResize(selectionCells[i]);
                        if (b2) {
                            this.setCollapsedState(mxGraphModel.getChildren(this.model, selectionCells[i]), b, true);
                        }
                    }
                }
                this.fireEvent(s2, new Object[] { selectionCells });
                this.layoutAfterCollapsedState(selectionCells, b);
            }
            finally {
                this.model.endUpdate();
            }
            this.fireEvent(s3, new Object[] { selectionCells });
        }
    }
    
    public Object[] layoutAfterCollapsedState(final Object[] array, final boolean b) {
        return this.layout(this.getParents(array));
    }
    
    public void swapBounds(final Object o, final boolean b) {
        if (o != null) {
            final mxGeometry geometry = this.model.getGeometry(o);
            if (geometry != null) {
                final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                this.updateAlternateBounds(o, mxGeometry, b);
                mxGeometry.swap();
                this.model.setGeometry(o, mxGeometry);
            }
        }
    }
    
    public void updateAlternateBounds(final Object o, final mxGeometry mxGeometry, final boolean b) {
        if (o != null && mxGeometry != null) {
            if (mxGeometry.getAlternateBounds() == null) {
                mxRectangle preferredSizeForCell = null;
                if (this.collapseToPreferredSize) {
                    preferredSizeForCell = this.getPreferredSizeForCell(o);
                    final mxCellState state = this.getView().getState(o);
                    final int int1 = mxUtils.getInt((state != null) ? state.getStyle() : this.getCellStyle(o), mxConstants.STYLE_STARTSIZE);
                    if (int1 > 0) {
                        preferredSizeForCell.setHeight(Math.max(preferredSizeForCell.getHeight(), int1));
                    }
                }
                if (preferredSizeForCell == null) {
                    preferredSizeForCell = mxGeometry;
                }
                mxGeometry.setAlternateBounds(new mxRectangle(mxGeometry.getX(), mxGeometry.getY(), preferredSizeForCell.getWidth(), preferredSizeForCell.getHeight()));
            }
            else {
                mxGeometry.getAlternateBounds().setX(mxGeometry.getX());
                mxGeometry.getAlternateBounds().setY(mxGeometry.getY());
            }
        }
    }
    
    public mxGeometry getCellGeometry(final Object o) {
        return this.model.getGeometry(o);
    }
    
    public Object getCurrentRoot() {
        return this.view.getCurrentRoot();
    }
    
    public mxPoint getTranslateForRoot(final Object o) {
        return null;
    }
    
    public mxPoint getChildOffsetForCell(final Object o) {
        return null;
    }
    
    public void enterGroup() {
        this.enterGroup(null);
    }
    
    public void enterGroup(Object selectionCell) {
        if (selectionCell == null) {
            selectionCell = this.getSelectionCell();
        }
        if (selectionCell != null && this.isValidRoot(selectionCell)) {
            this.view.setCurrentRoot(selectionCell);
            this.clearSelection();
        }
    }
    
    public void exitGroup() {
        final Object root = this.model.getRoot();
        final Object currentRoot = this.getCurrentRoot();
        if (currentRoot != null) {
            Object currentRoot2;
            for (currentRoot2 = this.model.getParent(currentRoot); currentRoot2 != root && !this.isValidRoot(currentRoot2) && this.model.getParent(currentRoot2) != root; currentRoot2 = this.model.getParent(currentRoot2)) {}
            if (currentRoot2 == root || this.model.getParent(currentRoot2) == root) {
                this.view.setCurrentRoot(null);
            }
            else {
                this.view.setCurrentRoot(currentRoot2);
            }
            if (this.view.getState(currentRoot) != null) {
                this.setSelectionCell(currentRoot);
            }
        }
    }
    
    public void home() {
        final Object currentRoot = this.getCurrentRoot();
        if (currentRoot != null) {
            this.view.setCurrentRoot(null);
            if (this.view.getState(currentRoot) != null) {
                this.setSelectionCell(currentRoot);
            }
        }
    }
    
    public boolean isValidRoot(final Object o) {
        return o != null;
    }
    
    public Object group() {
        return this.group(null);
    }
    
    public Object group(final Object o) {
        return this.group(o, 0.0);
    }
    
    public Object group(final Object o, final double n) {
        return this.group(o, n, null);
    }
    
    public Object group(Object selectionCell, final double n, Object[] selectionCells) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        if (selectionCells != null && selectionCells.length > 1) {
            final Object parent = this.model.getParent(selectionCells[0]);
            final ArrayList<Object> list = new ArrayList<Object>(selectionCells.length);
            list.add(selectionCells[0]);
            for (int i = 1; i < selectionCells.length; ++i) {
                if (this.model.getParent(selectionCells[i]) == parent) {
                    list.add(selectionCells[i]);
                }
            }
            final Object[] array = list.toArray();
            if (array.length > 1) {
                if (selectionCell == null) {
                    selectionCell = this.createGroupCell(array);
                }
                selectionCell = this.addGroup(selectionCell, array, n);
                if (selectionCell != null) {
                    this.setSelectionCell(selectionCell);
                }
            }
        }
        return selectionCell;
    }
    
    public Object createGroupCell(final Object[] array) {
        final mxCell mxCell = new mxCell("");
        mxCell.setVertex(true);
        mxCell.setConnectable(false);
        return mxCell;
    }
    
    public void ungroup() {
        this.ungroup(null);
    }
    
    public void ungroup(Object[] selectionCells) {
        if (selectionCells == null) {
            selectionCells = this.getSelectionCells();
        }
        if (selectionCells != null) {
            this.clearSelection();
            this.model.beginUpdate();
            try {
                for (int i = 0; i < selectionCells.length; ++i) {
                    final Object[] children = mxGraphModel.getChildren(this.model, selectionCells[i]);
                    if (children != null && children.length > 0) {
                        this.moveInto(children, this.model.getParent(selectionCells[i]));
                        this.selection.addCells(children);
                        this.remove(new Object[] { selectionCells[i] });
                    }
                }
            }
            finally {
                this.model.endUpdate();
            }
        }
    }
    
    public Object addGroup(final Object o, final Object[] array) {
        return this.addGroup(o, array, 0.0);
    }
    
    public Object addGroup(Object groupCells, final Object[] array, final double n) {
        final Object parent = this.model.getParent(array[0]);
        final mxCellState state = this.view.getState(parent);
        final mxRectangle bounds = this.view.getBounds(array);
        if (bounds != null) {
            final double scale = this.view.getScale();
            final mxPoint translate = this.view.getTranslate();
            double n2 = bounds.getX() - state.getOrigin().getX() * scale;
            double n3 = bounds.getY() - state.getOrigin().getY() * scale;
            double width = bounds.getWidth();
            double height = bounds.getHeight();
            if (this.isSwimlane(groupCells)) {
                final mxRectangle startSize = this.getStartSize(groupCells);
                n2 -= startSize.getWidth();
                width += startSize.getWidth();
                n3 -= startSize.getHeight();
                height += startSize.getHeight();
            }
            final mxGeometry mxGeometry = new mxGeometry(n2 / scale - n - translate.getX(), n3 / scale - n - translate.getY(), width / scale + 2.0 * n, height / scale + 2.0 * n);
            this.model.beginUpdate();
            try {
                groupCells = this.groupCells(parent, groupCells, array, -mxGeometry.getX(), -mxGeometry.getY());
                if (groupCells != null) {
                    this.model.setGeometry(groupCells, mxGeometry);
                }
            }
            finally {
                this.model.endUpdate();
            }
            return groupCells;
        }
        return null;
    }
    
    public Object groupCells(final Object o, Object add, final Object[] array, final double n, final double n2) {
        this.model.beginUpdate();
        try {
            add = this.model.add(o, add, this.model.getChildCount(o));
            if (add != null) {
                for (int i = 0; i < array.length; ++i) {
                    if (this.model.getParent(array[i]) != add) {
                        this.model.add(add, array[i], this.model.getChildCount(add));
                    }
                    final mxGeometry geometry = this.model.getGeometry(array[i]);
                    if (geometry != null) {
                        this.model.setGeometry(array[i], geometry.translate(n, n2));
                    }
                }
            }
        }
        finally {
            this.model.endUpdate();
        }
        return add;
    }
    
    public mxIGraphLayout getLayout(final Object o) {
        return null;
    }
    
    public boolean isBubbleLayout() {
        return this.bubbleLayout;
    }
    
    public void setBubbleLayout(final boolean b) {
        final boolean bubbleLayout = this.bubbleLayout;
        this.bubbleLayout = b;
        this.changeSupport.firePropertyChange("bubbleLayout", bubbleLayout, b);
    }
    
    public boolean isAutoLayout(final Object o) {
        return this.autoLayout;
    }
    
    public void setAutoLayout(final boolean b) {
        final boolean autoLayout = this.autoLayout;
        this.autoLayout = b;
        this.changeSupport.firePropertyChange("autoLayout", autoLayout, b);
    }
    
    public Object[] getParents(final Object[] array) {
        final HashSet<Object> set = new HashSet<Object>();
        if (array != null) {
            for (int i = 0; i < array.length; ++i) {
                if (this.model.getParent(array[i]) != null) {
                    set.add(this.model.getParent(array[i]));
                }
            }
        }
        return set.toArray();
    }
    
    public Object[] layout(Object[] array) {
        final ArrayList<Object> list = new ArrayList<Object>((array != null) ? array.length : 0);
        if (array != null && array.length > 0) {
            this.fireEvent(mxGraph.EVENT_BEFORE_LAYOUT, new Object[] { array });
            final TreeSet set = new TreeSet(new Comparator() {
                public int compare(final Object o, final Object o2) {
                    final int compareTo = mxCellPath.create((mxICell)o).compareTo(mxCellPath.create((mxICell)o2));
                    return (compareTo == 0) ? compareTo : ((compareTo < 0) ? 1 : -1);
                }
            });
            set.addAll(Arrays.asList(array));
            if (this.isBubbleLayout()) {
                for (Object list2 = set; !((Collection)list2).isEmpty(); list2 = Arrays.asList(this.getParents(((Collection)list2).toArray()))) {
                    set.addAll((Collection)list2);
                }
            }
            array = set.toArray();
            Object o = null;
            this.model.beginUpdate();
            try {
                for (int i = 0; i < array.length; ++i) {
                    final Object o2 = array[i];
                    if (o2 != null && o2 != o && this.isAutoLayout(o2)) {
                        final mxIGraphLayout layout = this.getLayout(o2);
                        if (layout != null) {
                            layout.execute(o2);
                            list.add(o2);
                        }
                    }
                    o = o2;
                }
                this.fireEvent(mxGraph.EVENT_LAYOUT, new Object[] { list });
            }
            finally {
                this.model.endUpdate();
            }
            this.fireEvent(mxGraph.EVENT_AFTER_LAYOUT, new Object[] { list });
        }
        return list.toArray();
    }
    
    public void setMultiplicities(final mxMultiplicity[] array) {
        final mxMultiplicity[] multiplicities = this.multiplicities;
        this.multiplicities = array;
        this.changeSupport.firePropertyChange("multiplicities", multiplicities, array);
    }
    
    public mxMultiplicity[] getMultiplicities() {
        return this.multiplicities;
    }
    
    public boolean isEdgeValid(final Object o, final Object o2, final Object o3) {
        return this.getEdgeValidationError(o, o2, o3) == null;
    }
    
    public String getEdgeValidationError(final Object o, final Object o2, final Object o3) {
        if (o != null && this.model.getTerminal(o, true) == null && this.model.getTerminal(o, false) == null) {
            return null;
        }
        if (!this.allowLoops && o2 == o3 && o2 != null) {
            return "";
        }
        if (!this.isValidConnection(o2, o3)) {
            return "";
        }
        if (o2 != null && o3 != null) {
            final StringBuffer sb = new StringBuffer();
            if (!this.multigraph) {
                final Object[] edgesBetween = mxGraphModel.getEdgesBetween(this.model, o2, o3, true);
                if (edgesBetween.length > 1 || (edgesBetween.length == 1 && edgesBetween[0] != o)) {
                    sb.append(mxResources.get("alreadyConnected", "Already Connected") + "\n");
                }
            }
            final int directedEdgeCount = mxGraphModel.getDirectedEdgeCount(this.model, o2, true, o);
            final int directedEdgeCount2 = mxGraphModel.getDirectedEdgeCount(this.model, o3, false, o);
            if (this.multiplicities != null) {
                for (int i = 0; i < this.multiplicities.length; ++i) {
                    final String check = this.multiplicities[i].check(this, o, o2, o3, directedEdgeCount, directedEdgeCount2);
                    if (check != null) {
                        sb.append(check);
                    }
                }
            }
            final String validateEdge = this.validateEdge(o, o2, o3);
            if (validateEdge != null) {
                sb.append(validateEdge);
            }
            return (sb.length() > 0) ? sb.toString() : null;
        }
        return this.allowDanglingEdges ? null : "";
    }
    
    public String validateEdge(final Object o, final Object o2, final Object o3) {
        return null;
    }
    
    public String validate() {
        return this.validate(this.model.getRoot(), new Hashtable());
    }
    
    public String validate(final Object o, final Hashtable hashtable) {
        boolean b = true;
        for (int childCount = this.model.getChildCount(o), i = 0; i < childCount; ++i) {
            final Object child = this.model.getChildAt(o, i);
            Hashtable hashtable2 = hashtable;
            if (this.isValidRoot(child)) {
                hashtable2 = new Hashtable();
            }
            final String validate = this.validate(child, hashtable2);
            if (validate != null) {
                validate.replaceAll("\n", "<br>").length();
            }
            b = (b && validate == null);
        }
        final StringBuffer sb = new StringBuffer();
        if (this.isCellCollapsed(o) && !b) {
            sb.append(mxResources.get("containsValidationErrors", "Contains Validation Errors") + "\n");
        }
        if (this.model.isEdge(o)) {
            final String edgeValidationError = this.getEdgeValidationError(o, this.model.getTerminal(o, true), this.model.getTerminal(o, false));
            if (edgeValidationError != null) {
                sb.append(edgeValidationError);
            }
        }
        else {
            final String cellValidationError = this.getCellValidationError(o);
            if (cellValidationError != null) {
                sb.append(cellValidationError);
            }
        }
        final String validateCell = this.validateCell(o, hashtable);
        if (validateCell != null) {
            sb.append(validateCell);
        }
        if (this.model.getParent(o) == null) {
            this.view.validate();
        }
        return (sb.length() > 0 || !b) ? sb.toString() : null;
    }
    
    public String getCellValidationError(final Object o) {
        final int directedEdgeCount = mxGraphModel.getDirectedEdgeCount(this.model, o, true);
        final int directedEdgeCount2 = mxGraphModel.getDirectedEdgeCount(this.model, o, false);
        final StringBuffer sb = new StringBuffer();
        final Object value = this.model.getValue(o);
        for (int i = 0; i < this.multiplicities.length; ++i) {
            final mxMultiplicity mxMultiplicity = this.multiplicities[i];
            final int maxValue = mxMultiplicity.getMaxValue();
            if (mxMultiplicity.source && mxUtils.isNode(value, mxMultiplicity.type, mxMultiplicity.attr, mxMultiplicity.value) && ((maxValue == 0 && directedEdgeCount > 0) || (mxMultiplicity.min == 1 && directedEdgeCount == 0) || (maxValue == 1 && directedEdgeCount > 1))) {
                sb.append(mxMultiplicity.countError + '\n');
            }
            else if (!mxMultiplicity.source && mxUtils.isNode(value, mxMultiplicity.type, mxMultiplicity.attr, mxMultiplicity.value) && ((maxValue == 0 && directedEdgeCount2 > 0) || (mxMultiplicity.min == 1 && directedEdgeCount2 == 0) || (maxValue == 1 && directedEdgeCount2 > 1))) {
                sb.append(mxMultiplicity.countError + '\n');
            }
        }
        return (sb.length() > 0) ? sb.toString() : null;
    }
    
    public String validateCell(final Object o, final Hashtable hashtable) {
        return null;
    }
    
    public boolean isLabelsVisible() {
        return this.labelsVisible;
    }
    
    public void setLabelsVisible(final boolean b) {
        final boolean labelsVisible = this.labelsVisible;
        this.labelsVisible = b;
        this.changeSupport.firePropertyChange("labelsVisible", labelsVisible, b);
    }
    
    public void setHtmlLabels(final boolean b) {
        final boolean htmlLabels = this.htmlLabels;
        this.htmlLabels = b;
        this.changeSupport.firePropertyChange("htmlLabels", htmlLabels, b);
    }
    
    public boolean isHtmlLabels() {
        return this.htmlLabels;
    }
    
    public String convertValueToString(final Object o) {
        final Object value = this.model.getValue(o);
        return (value != null) ? value.toString() : "";
    }
    
    public String getLabel(final Object o) {
        String convertValueToString = "";
        final Hashtable cellStyle = this.getCellStyle(o);
        if (o != null && this.labelsVisible && !mxUtils.isTrue(cellStyle, mxConstants.STYLE_NOLABEL, false)) {
            convertValueToString = this.convertValueToString(o);
        }
        return convertValueToString;
    }
    
    public boolean isHtmlLabel(final Object o) {
        return this.htmlLabels;
    }
    
    public String getToolTipForCell(final Object o) {
        return this.convertValueToString(o);
    }
    
    public mxRectangle getStartSize(final Object o) {
        final mxRectangle mxRectangle = new mxRectangle();
        final Hashtable cellStyle = this.getCellStyle(o);
        if (cellStyle != null) {
            final double double1 = mxUtils.getDouble(cellStyle, mxConstants.STYLE_STARTSIZE);
            if (mxUtils.isTrue(cellStyle, mxConstants.STYLE_HORIZONTAL, true)) {
                mxRectangle.setHeight(double1);
            }
            else {
                mxRectangle.setWidth(double1);
            }
        }
        return mxRectangle;
    }
    
    public String getImage(final mxCellState mxCellState) {
        return (mxCellState != null && mxCellState.getStyle() != null) ? mxUtils.getString(mxCellState.getStyle(), mxConstants.STYLE_IMAGE) : null;
    }
    
    public int getBorder() {
        return this.border;
    }
    
    public void setBorder(final int border) {
        this.border = border;
    }
    
    public mxEdgeStyle.mxEdgeStyleFunction getDefaultLoopStyle() {
        return this.defaultLoopStyle;
    }
    
    public void setDefaultLoopStyle(final mxEdgeStyle.mxEdgeStyleFunction defaultLoopStyle) {
        final mxEdgeStyle.mxEdgeStyleFunction defaultLoopStyle2 = this.defaultLoopStyle;
        this.defaultLoopStyle = defaultLoopStyle;
        this.changeSupport.firePropertyChange("defaultLoopStyle", defaultLoopStyle2, this.defaultLoopStyle);
    }
    
    public boolean isSwimlane(final Object o) {
        if (o != null && this.model.getParent(o) != this.model.getRoot()) {
            final mxCellState state = this.view.getState(o);
            final Hashtable hashtable = (state != null) ? state.getStyle() : this.getCellStyle(o);
            if (hashtable != null && !this.model.isEdge(o)) {
                return mxUtils.getString(hashtable, mxConstants.STYLE_SHAPE, "").equals("swimlane");
            }
        }
        return false;
    }
    
    public boolean isEnabled() {
        return this.enabled;
    }
    
    public void setEnabled(final boolean b) {
        final boolean enabled = this.enabled;
        this.enabled = b;
        this.changeSupport.firePropertyChange("enabled", enabled, b);
    }
    
    public boolean isLocked(final Object o) {
        final mxGeometry geometry = this.model.getGeometry(o);
        return this.locked || (geometry != null && this.model.isVertex(o) && geometry.isRelative());
    }
    
    public void setLocked(final boolean b) {
        final boolean locked = this.locked;
        this.locked = b;
        this.changeSupport.firePropertyChange("locked", locked, b);
    }
    
    public boolean isCellCloneable(final Object o) {
        return true;
    }
    
    public boolean isCloneable() {
        return this.cloneable;
    }
    
    public void setCloneable(final boolean b) {
        final boolean cloneable = this.cloneable;
        this.cloneable = b;
        this.changeSupport.firePropertyChange("cloneable", cloneable, b);
    }
    
    public void setSwimlaneNesting(final boolean b) {
        final boolean swimlaneNesting = this.swimlaneNesting;
        this.swimlaneNesting = b;
        this.changeSupport.firePropertyChange("swimlaneNesting", swimlaneNesting, b);
    }
    
    public boolean isSwimlaneNesting() {
        return this.swimlaneNesting;
    }
    
    public void setSwimlaneSelectionEnabled(final boolean b) {
        final boolean swimlaneSelectionEnabled = this.swimlaneSelectionEnabled;
        this.swimlaneSelectionEnabled = b;
        this.changeSupport.firePropertyChange("swimlaneSelectionEnabled", swimlaneSelectionEnabled, b);
    }
    
    public boolean isSwimlaneSelectionEnabled() {
        return this.swimlaneSelectionEnabled;
    }
    
    public boolean isMultigraph() {
        return this.multigraph;
    }
    
    public void setMultigraph(final boolean b) {
        final boolean multigraph = this.multigraph;
        this.multigraph = b;
        this.changeSupport.firePropertyChange("multigraph", multigraph, b);
    }
    
    public boolean isAllowDanglingEdges() {
        return this.allowDanglingEdges;
    }
    
    public void setAllowDanglingEdges(final boolean b) {
        final boolean allowDanglingEdges = this.allowDanglingEdges;
        this.allowDanglingEdges = b;
        this.changeSupport.firePropertyChange("allowDanglingEdges", allowDanglingEdges, b);
    }
    
    public boolean isCloneInvalidEdges() {
        return this.cloneInvalidEdges;
    }
    
    public void setCloneInvalidEdges(final boolean b) {
        final boolean cloneInvalidEdges = this.cloneInvalidEdges;
        this.cloneInvalidEdges = b;
        this.changeSupport.firePropertyChange("cloneInvalidEdges", cloneInvalidEdges, b);
    }
    
    public boolean isDisconnectOnMove() {
        return this.disconnectOnMove;
    }
    
    public void setDisconnectOnMove(final boolean b) {
        final boolean disconnectOnMove = this.disconnectOnMove;
        this.disconnectOnMove = b;
        this.changeSupport.firePropertyChange("disconnectOnMove", disconnectOnMove, b);
    }
    
    public boolean isAllowLoops() {
        return this.allowLoops;
    }
    
    public void setAllowLoops(final boolean b) {
        final boolean allowLoops = this.allowLoops;
        this.allowLoops = b;
        this.changeSupport.firePropertyChange("allowLoops", allowLoops, b);
    }
    
    public boolean isConnectableEdges() {
        return this.connectableEdges;
    }
    
    public void setConnectableEdges(final boolean b) {
        final boolean connectableEdges = this.connectableEdges;
        this.connectableEdges = b;
        this.changeSupport.firePropertyChange("connectableEdges", connectableEdges, b);
    }
    
    public boolean isResetEdgesOnMove() {
        return this.resetEdgesOnMove;
    }
    
    public void setResetEdgesOnMove(final boolean b) {
        final boolean resetEdgesOnMove = this.resetEdgesOnMove;
        this.resetEdgesOnMove = b;
        this.changeSupport.firePropertyChange("resetEdgesOnMove", resetEdgesOnMove, b);
    }
    
    public boolean isResetEdgesOnResize() {
        return this.resetEdgesOnResize;
    }
    
    public void setResetEdgesOnResize(final boolean b) {
        final boolean resetEdgesOnResize = this.resetEdgesOnResize;
        this.resetEdgesOnResize = b;
        this.changeSupport.firePropertyChange("resetEdgesOnResize", resetEdgesOnResize, b);
    }
    
    public boolean isShiftDownwards() {
        return this.shiftDownwards;
    }
    
    public void setShiftDownwards(final boolean b) {
        final boolean shiftDownwards = this.shiftDownwards;
        this.shiftDownwards = b;
        this.changeSupport.firePropertyChange("shiftDownwards", shiftDownwards, b);
    }
    
    public boolean isShiftRightwards() {
        return this.shiftRightwards;
    }
    
    public void setShiftRightwards(final boolean b) {
        final boolean shiftRightwards = this.shiftRightwards;
        this.shiftRightwards = b;
        this.changeSupport.firePropertyChange("shiftRightwards", shiftRightwards, b);
    }
    
    public boolean isSelectable(final Object o) {
        return o != null && this.selectable;
    }
    
    public void setSelectable(final boolean b) {
        final boolean selectable = this.selectable;
        this.selectable = b;
        this.changeSupport.firePropertyChange("selectable", selectable, b);
    }
    
    public boolean isDeletable(final Object o) {
        return this.deletable;
    }
    
    public void setDeletable(final boolean b) {
        final boolean deletable = this.deletable;
        this.deletable = b;
        this.changeSupport.firePropertyChange("deletable", deletable, b);
    }
    
    public boolean isLabelMovable(final Object o) {
        return !this.isLocked(o) && ((this.model.isEdge(o) && this.edgeLabelsMovable) || (this.model.isVertex(o) && this.vertexLabelsMovable));
    }
    
    public void setVertexLabelsMovable(final boolean vertexLabelsMovable) {
        final boolean vertexLabelsMovable2 = this.vertexLabelsMovable;
        this.vertexLabelsMovable = vertexLabelsMovable;
        this.changeSupport.firePropertyChange("vertexLabelsMovable", vertexLabelsMovable2, this.vertexLabelsMovable);
    }
    
    public boolean isVertexLabelsMovable() {
        return this.vertexLabelsMovable;
    }
    
    public void setEdgeLabelsMovable(final boolean edgeLabelsMovable) {
        final boolean edgeLabelsMovable2 = this.edgeLabelsMovable;
        this.edgeLabelsMovable = edgeLabelsMovable;
        this.changeSupport.firePropertyChange("edgeLabelsMovable", edgeLabelsMovable2, this.edgeLabelsMovable);
    }
    
    public boolean isEdgeLabelsMovable() {
        return this.edgeLabelsMovable;
    }
    
    public boolean isMovable(final Object o) {
        return this.movable && !this.isLocked(o);
    }
    
    public void setMovable(final boolean b) {
        final boolean movable = this.movable;
        this.movable = b;
        this.changeSupport.firePropertyChange("movable", movable, b);
    }
    
    public boolean isDropEnabled() {
        return this.dropEnabled;
    }
    
    public void setDropEnabled(final boolean b) {
        final boolean dropEnabled = this.dropEnabled;
        this.dropEnabled = b;
        this.changeSupport.firePropertyChange("dropEnabled", dropEnabled, b);
    }
    
    public boolean isSizable(final Object o) {
        return this.sizable;
    }
    
    public void setSizable(final boolean b) {
        final boolean sizable = this.sizable;
        this.sizable = b;
        this.changeSupport.firePropertyChange("sizable", sizable, b);
    }
    
    public boolean isEditable(final Object o) {
        return this.editable;
    }
    
    public boolean isEditable() {
        return this.editable;
    }
    
    public void setEditable(final boolean b) {
        final boolean editable = this.editable;
        this.editable = b;
        this.changeSupport.firePropertyChange("editable", editable, b);
    }
    
    public boolean isValidSource(final Object o) {
        return (o == null && this.allowDanglingEdges) || (o != null && (!this.model.isEdge(o) || this.connectableEdges) && this.model.isConnectable(o));
    }
    
    public boolean isValidTarget(final Object o) {
        return this.isValidSource(o);
    }
    
    public boolean isValidConnection(final Object o, final Object o2) {
        return this.isValidSource(o) && this.isValidTarget(o2) && (this.allowLoops || o != o2);
    }
    
    public boolean isBendable(final Object o) {
        return this.bendable && !this.isLocked(o);
    }
    
    public void setBendable(final boolean b) {
        final boolean bendable = this.bendable;
        this.bendable = b;
        this.changeSupport.firePropertyChange("bendable", bendable, b);
    }
    
    public boolean isDisconnectable(final Object o, final Object o2, final boolean b) {
        return this.disconnectable && !this.isLocked(o);
    }
    
    public void setDisconnectable(final boolean b) {
        final boolean disconnectable = this.disconnectable;
        this.disconnectable = b;
        this.changeSupport.firePropertyChange("disconnectable", disconnectable, b);
    }
    
    public void setUpdateSize(final boolean autoSize) {
        final boolean autoSize2 = this.autoSize;
        this.autoSize = autoSize;
        this.changeSupport.firePropertyChange("autoSize", autoSize2, this.autoSize);
    }
    
    public boolean isUpdateSize(final Object o) {
        return this.autoSize;
    }
    
    public boolean isExtendParentOnResize(final Object o) {
        return this.extendParentOnResize;
    }
    
    public void setExtendParentOnResize(final boolean b) {
        final boolean extendParentOnResize = this.extendParentOnResize;
        this.extendParentOnResize = b;
        this.changeSupport.firePropertyChange("extendParentOnResize", extendParentOnResize, b);
    }
    
    public boolean isKeepInsideParentOnMove(final Object o) {
        return this.keepInsideParentOnMove;
    }
    
    public void setKeepInsideParentOnMove(final boolean keepInsideParentOnMove) {
        final boolean keepInsideParentOnMove2 = this.keepInsideParentOnMove;
        this.keepInsideParentOnMove = keepInsideParentOnMove;
        this.changeSupport.firePropertyChange("keepInsideParentOnMove", keepInsideParentOnMove2, this.gridSize);
    }
    
    public boolean isKeepEdgesInForeground() {
        return this.keepEdgesInForeground;
    }
    
    public void setKeepEdgesInForeground(final boolean b) {
        final boolean keepEdgesInForeground = this.keepEdgesInForeground;
        this.keepEdgesInForeground = b;
        this.changeSupport.firePropertyChange("keepEdgesInForeground", keepEdgesInForeground, b);
    }
    
    public boolean isKeepEdgesInBackground() {
        return this.keepEdgesInBackground;
    }
    
    public void setKeepEdgesInBackground(final boolean b) {
        final boolean keepEdgesInBackground = this.keepEdgesInBackground;
        this.keepEdgesInBackground = b;
        this.changeSupport.firePropertyChange("keepEdgesInBackground", keepEdgesInBackground, b);
    }
    
    public mxRectangle getMinimumContainerSize() {
        return this.minimumContainerSize;
    }
    
    public void setMinimumContainerSize(final mxRectangle mxRectangle) {
        final mxRectangle minimumContainerSize = this.minimumContainerSize;
        this.minimumContainerSize = mxRectangle;
        this.changeSupport.firePropertyChange("minimumContainerSize", minimumContainerSize, mxRectangle);
    }
    
    public mxRectangle getMaximumContainerSize() {
        return this.maximumContainerSize;
    }
    
    public void setMaximumContainerSize(final mxRectangle mxRectangle) {
        final mxRectangle maximumContainerSize = this.maximumContainerSize;
        this.maximumContainerSize = mxRectangle;
        this.changeSupport.firePropertyChange("maximumContainerSize", maximumContainerSize, mxRectangle);
    }
    
    public double getOverlap(final Object o) {
        return this.isAllowOverlapParent(o) ? this.defaultOverlap : 0.0;
    }
    
    public boolean isAllowOverlapParent(final Object o) {
        return false;
    }
    
    public boolean isShiftable(final Object o) {
        return !this.model.isEdge(o);
    }
    
    public boolean isExpandable(final Object o) {
        return this.model.getChildCount(o) > 0;
    }
    
    public boolean isCollapsable(final Object o) {
        return this.isExpandable(o);
    }
    
    public boolean isGridEnabled() {
        return this.gridEnabled;
    }
    
    public void setGridEnabled(final boolean gridEnabled) {
        final boolean gridEnabled2 = this.gridEnabled;
        this.gridEnabled = gridEnabled;
        this.changeSupport.firePropertyChange("gridEnabled", gridEnabled2, this.gridSize);
    }
    
    public int getGridSize() {
        return this.gridSize;
    }
    
    public void setGridSize(final int n) {
        final int gridSize = this.gridSize;
        this.gridSize = n;
        this.changeSupport.firePropertyChange("gridSize", gridSize, n);
    }
    
    public int getTolerance() {
        return this.tolerance;
    }
    
    public void setTolerance(final int n) {
        final int tolerance = this.tolerance;
        this.tolerance = n;
        this.changeSupport.firePropertyChange("tolerance", tolerance, n);
    }
    
    public String getAlternateEdgeStyle() {
        return this.alternateEdgeStyle;
    }
    
    public void setAlternateEdgeStyle(final String s) {
        final String alternateEdgeStyle = this.alternateEdgeStyle;
        this.alternateEdgeStyle = s;
        this.changeSupport.firePropertyChange("alternateEdgeStyle", alternateEdgeStyle, s);
    }
    
    public boolean isValidDropTarget(final Object o, final Object[] array) {
        if (this.model.isEdge(o)) {
            return array != null && array.length == 1 && this.isSplitDropTarget(o, array[0]);
        }
        return this.isParentDropTarget(o, array);
    }
    
    public boolean isSplitDropTarget(final Object o, final Object o2) {
        if (o != null) {
            final Object terminal = this.model.getTerminal(o, true);
            final Object terminal2 = this.model.getTerminal(o, false);
            return !this.model.isAncestor(o2, terminal) && !this.model.isAncestor(o2, terminal2);
        }
        return false;
    }
    
    public boolean isParentDropTarget(final Object o, final Object[] array) {
        return o != null && (this.isSwimlane(o) || (this.model.getChildCount(o) > 0 && !this.isCellCollapsed(o)));
    }
    
    public Object getDropTarget(final Object[] array, final Point point, Object parent) {
        if (!this.swimlaneNesting) {
            for (int i = 0; i < array.length; ++i) {
                if (this.isSwimlane(array[i])) {
                    return null;
                }
            }
        }
        final Object o = null;
        if (parent == null) {
            parent = o;
        }
        else if (o != null) {
            Object o2;
            for (o2 = this.model.getParent(o); o2 != null && this.isSwimlane(o2) && o2 != parent; o2 = this.model.getParent(o2)) {}
            if (o2 == parent) {
                parent = o;
            }
        }
        while (parent != null && !this.isValidDropTarget(parent, array) && this.model.getParent(parent) != this.model.getRoot()) {
            parent = this.model.getParent(parent);
        }
        return (this.model.getParent(parent) != this.model.getRoot()) ? parent : null;
    }
    
    public Object getDefaultParent() {
        Object o = null;
        if (o == null) {
            o = this.view.getCurrentRoot();
            if (o == null) {
                o = this.model.getChildAt(this.model.getRoot(), 0);
            }
        }
        return o;
    }
    
    public Object getCellAt(final int n, final int n2) {
        return this.getCellAt(n, n2, true);
    }
    
    public Object getCellAt(final int n, final int n2, final boolean b) {
        return this.getCellAt(n, n2, b, null);
    }
    
    public Object getCellAt(final int x, final int y, final boolean b, Object defaultParent) {
        if (defaultParent == null) {
            defaultParent = this.getDefaultParent();
        }
        if (defaultParent != null) {
            final Rectangle rectangle = new Rectangle(x, y, 1, 1);
            for (int i = this.model.getChildCount(defaultParent) - 1; i >= 0; --i) {
                final Object child = this.model.getChildAt(defaultParent, i);
                final Object cell = this.getCellAt(x, y, b, child);
                if (cell != null) {
                    return cell;
                }
                if (this.isCellVisible(child) && this.intersects(this.view.getState(child), rectangle) && (!this.isSwimlane(child) || b || !this.hitsSwimlaneContent(child, x, y))) {
                    return child;
                }
            }
        }
        return null;
    }
    
    public boolean intersects(final mxCellState mxCellState, Rectangle rectangle) {
        if (mxCellState != null) {
            if (mxCellState.getLabelBounds() != null && mxCellState.getLabelBounds().getRectangle().intersects(rectangle)) {
                return true;
            }
            final int absolutePointCount = mxCellState.getAbsolutePointCount();
            if (absolutePointCount <= 0) {
                return mxCellState.getRectangle().intersects(rectangle);
            }
            rectangle = (Rectangle)rectangle.clone();
            rectangle.grow(this.tolerance, this.tolerance);
            mxPoint absolutePoint = mxCellState.getAbsolutePoint(0);
            for (int i = 0; i < absolutePointCount; ++i) {
                final mxPoint absolutePoint2 = mxCellState.getAbsolutePoint(i);
                if (rectangle.intersectsLine(absolutePoint.getX(), absolutePoint.getY(), absolutePoint2.getX(), absolutePoint2.getY())) {
                    return true;
                }
                absolutePoint = absolutePoint2;
            }
        }
        return false;
    }
    
    public boolean hitsSwimlaneContent(final Object o, final int x, final int y) {
        if (this.transparentSwimlaneContent) {
            final mxCellState state = this.view.getState(o);
            if (state != null) {
                final double b = mxUtils.getInt(state.getStyle(), mxConstants.STYLE_STARTSIZE) * this.view.getScale();
                if (b > 0.0) {
                    final double max = Math.max(2.0, b);
                    final Rectangle rectangle = state.getRectangle();
                    if (mxUtils.isTrue(state.getStyle(), mxConstants.STYLE_HORIZONTAL, true)) {
                        final Rectangle rectangle2 = rectangle;
                        rectangle2.y += (int)max;
                        final Rectangle rectangle3 = rectangle;
                        rectangle3.height -= (int)max;
                    }
                    else {
                        final Rectangle rectangle4 = rectangle;
                        rectangle4.x += (int)max;
                        final Rectangle rectangle5 = rectangle;
                        rectangle5.width -= (int)max;
                    }
                    return rectangle.contains(x, y);
                }
            }
        }
        return false;
    }
    
    public Object[] getChildVertices(final Object o) {
        return this.getChildCells(o, true, false);
    }
    
    public Object[] getChildEdges(final Object o) {
        return this.getChildCells(o, false, true);
    }
    
    public Object[] getChildCells(final Object o) {
        return this.getChildCells(o, false, false);
    }
    
    public Object[] getChildCells(final Object o, final boolean b, final boolean b2) {
        final Object[] childCells = mxGraphModel.getChildCells(this.model, o, b, b2);
        final ArrayList list = new ArrayList<Object>(childCells.length);
        for (int i = 0; i < childCells.length; ++i) {
            if (this.isCellVisible(childCells[i])) {
                list.add(childCells[i]);
            }
        }
        return list.toArray();
    }
    
    public Object[] getConnections(final Object o) {
        return this.getConnections(o, null);
    }
    
    public Object[] getConnections(final Object o, final Object o2) {
        return this.getEdges(o, o2, true, true, false);
    }
    
    public Object[] getIncomingEdges(final Object o) {
        return this.getIncomingEdges(o, null);
    }
    
    public Object[] getIncomingEdges(final Object o, final Object o2) {
        return this.getEdges(o, o2, true, false, false);
    }
    
    public Object[] getOutgoingEdges(final Object o) {
        return this.getOutgoingEdges(o, null);
    }
    
    public Object[] getOutgoingEdges(final Object o, final Object o2) {
        return this.getEdges(o, o2, false, true, false);
    }
    
    public Object[] getEdges(final Object o) {
        return this.getEdges(o, null);
    }
    
    public Object[] getEdges(final Object o, final Object o2) {
        return this.getEdges(o, o2, true, true, true);
    }
    
    public Object[] getEdges(final Object o, final Object o2, final boolean b, final boolean b2, final boolean b3) {
        final boolean cellCollapsed = this.isCellCollapsed(o);
        final ArrayList<Object> list = new ArrayList<Object>();
        for (int childCount = this.model.getChildCount(o), i = 0; i < childCount; ++i) {
            final Object child = this.model.getChildAt(o, i);
            if (cellCollapsed || !this.isCellVisible(child)) {
                list.addAll(Arrays.asList(mxGraphModel.getEdges(this.model, child, b, b2, b3)));
            }
        }
        list.addAll(Arrays.asList(mxGraphModel.getEdges(this.model, o, b, b2, b3)));
        final ArrayList list2 = new ArrayList<Object>(list.size());
        for (final Object next : list) {
            final Object visibleTerminal = this.view.getVisibleTerminal(next, true);
            final Object visibleTerminal2 = this.view.getVisibleTerminal(next, false);
            if (b3 || (visibleTerminal != visibleTerminal2 && ((b && visibleTerminal2 == o && (o2 == null || this.model.getParent(visibleTerminal) == o2)) || (b2 && visibleTerminal == o && (o2 == null || this.model.getParent(visibleTerminal2) == o2))))) {
                list2.add(next);
            }
        }
        return list2.toArray();
    }
    
    public Object[] getOpposites(final Object[] array, final Object o) {
        return this.getOpposites(array, o, true, true);
    }
    
    public Object[] getOpposites(final Object[] array, final Object o, final boolean b, final boolean b2) {
        final LinkedHashSet<Object> set = new LinkedHashSet<Object>();
        if (array != null) {
            for (int i = 0; i < array.length; ++i) {
                final Object visibleTerminal = this.view.getVisibleTerminal(array[i], true);
                final Object visibleTerminal2 = this.view.getVisibleTerminal(array[i], false);
                if (b2 && visibleTerminal == o && visibleTerminal2 != null && visibleTerminal2 != o) {
                    set.add(visibleTerminal2);
                }
                else if (b && visibleTerminal2 == o && visibleTerminal != null && visibleTerminal != o) {
                    set.add(visibleTerminal);
                }
            }
        }
        return set.toArray();
    }
    
    public Object[] getEdgesBetween(final Object o, final Object o2) {
        return this.getEdgesBetween(o, o2, false);
    }
    
    public Object[] getEdgesBetween(final Object o, final Object o2, final boolean b) {
        final Object[] edges = this.getEdges(o);
        final ArrayList list = new ArrayList<Object>(edges.length);
        for (int i = 0; i < edges.length; ++i) {
            if (this.view.getVisibleTerminal(edges[i], false) == o2 || (!b && this.view.getVisibleTerminal(edges[i], true) == o2)) {
                list.add(edges[i]);
            }
        }
        return list.toArray();
    }
    
    public Object[] getCells(final int n, final int n2, final int n3, final int n4) {
        return this.getCells(n, n2, n3, n4, null);
    }
    
    public Object[] getCells(final int n, final int n2, final int n3, final int n4, Object defaultParent) {
        final ArrayList<Object> list = new ArrayList<Object>();
        if (n3 > 0 || n4 > 0) {
            final int n5 = n + n3;
            final int n6 = n2 + n4;
            if (defaultParent == null) {
                defaultParent = this.getDefaultParent();
            }
            if (defaultParent != null) {
                for (int childCount = this.model.getChildCount(defaultParent), i = 0; i < childCount; ++i) {
                    final Object child = this.model.getChildAt(defaultParent, i);
                    final mxCellState state = this.view.getState(child);
                    if (this.isCellVisible(child) && state != null) {
                        if (state.getX() >= n && state.getY() >= n2 && state.getX() + state.getWidth() <= n5 && state.getY() + state.getHeight() <= n6) {
                            list.add(child);
                        }
                        else {
                            list.addAll(Arrays.asList(this.getCells(n, n2, n3, n4, child)));
                        }
                    }
                }
            }
        }
        return list.toArray();
    }
    
    public Object[] getCellsBeyond(final double n, final double n2, Object defaultParent, final boolean b, final boolean b2) {
        if (defaultParent == null) {
            defaultParent = this.getDefaultParent();
        }
        final int childCount = this.model.getChildCount(defaultParent);
        final ArrayList list = new ArrayList<Object>(childCount);
        if ((b || b2) && defaultParent != null) {
            for (int i = 0; i < childCount; ++i) {
                final Object child = this.model.getChildAt(defaultParent, i);
                final mxCellState state = this.view.getState(child);
                if (this.isCellVisible(child) && state != null && (!b || state.getX() >= n) && (!b2 || state.getY() >= n2)) {
                    list.add(child);
                }
            }
        }
        return list.toArray();
    }
    
    public Object[] findTreeRoots(final Object o) {
        return this.findTreeRoots(o, false);
    }
    
    public Object[] findTreeRoots(final Object o, final boolean b) {
        return this.findTreeRoots(o, b, false);
    }
    
    public Object[] findTreeRoots(final Object o, final boolean b, final boolean b2) {
        final ArrayList<Object> list = new ArrayList<Object>();
        if (o != null) {
            final int childCount = this.model.getChildCount(o);
            Object o2 = null;
            int n = 0;
            for (int i = 0; i < childCount; ++i) {
                final Object child = this.model.getChildAt(o, i);
                if (this.model.isVertex(child) && this.isCellVisible(child)) {
                    final Object[] connections = this.getConnections(child, b ? o : null);
                    int n2 = 0;
                    int n3 = 0;
                    for (int j = 0; j < connections.length; ++j) {
                        if (this.view.getVisibleTerminal(connections[j], true) == child) {
                            ++n2;
                        }
                        else {
                            ++n3;
                        }
                    }
                    if ((b2 && n2 == 0 && n3 > 0) || (!b2 && n3 == 0 && n2 > 0)) {
                        list.add(child);
                    }
                    final int n4 = b2 ? (n3 - n2) : (n2 - n3);
                    if (n4 > n) {
                        n = n4;
                        o2 = child;
                    }
                }
            }
            if (list.isEmpty() && o2 != null) {
                list.add(o2);
            }
        }
        return list.toArray();
    }
    
    public void traverse(final Object o, final boolean b, final mxICellVisitor mxICellVisitor) {
        this.traverse(o, b, mxICellVisitor, null, null);
    }
    
    public void traverse(final Object o, final boolean b, final mxICellVisitor mxICellVisitor, final Object o2, Set set) {
        if (o != null && mxICellVisitor != null) {
            if (set == null) {
                set = new HashSet<Object>();
            }
            if (!set.contains(o)) {
                set.add(o);
                if (mxICellVisitor.visit(o, o2)) {
                    final int edgeCount = this.model.getEdgeCount(o);
                    if (edgeCount > 0) {
                        for (int i = 0; i < edgeCount; ++i) {
                            final Object edge = this.model.getEdgeAt(o, i);
                            final boolean b2 = this.model.getTerminal(edge, true) == o;
                            if (!b || b2) {
                                this.traverse(this.model.getTerminal(edge, !b2), b, mxICellVisitor, edge, set);
                            }
                        }
                    }
                }
            }
        }
    }
    
    public mxSelectionModel getSelection() {
        return this.selection;
    }
    
    public int getSelectionCount() {
        return this.selection.size();
    }
    
    public boolean isSelected(final Object o) {
        return this.selection.isSelected(o);
    }
    
    public boolean isSelectionEmpty() {
        return this.selection.isEmpty();
    }
    
    public void clearSelection() {
        this.selection.clear();
    }
    
    public Object getSelectionCell() {
        return this.selection.getCell();
    }
    
    public void setSelectionCell(final Object cell) {
        this.selection.setCell(cell);
    }
    
    public Object[] getSelectionCells() {
        return this.selection.getCells();
    }
    
    public void setSelectionCells(final Object[] cells) {
        this.selection.setCells(cells);
    }
    
    public void setSelectionCells(final Collection collection) {
        if (collection != null) {
            this.setSelectionCells(collection.toArray());
        }
    }
    
    public void selectNext() {
        this.select(true, false, false);
    }
    
    public void selectPrevious() {
        this.select(false, false, false);
    }
    
    public void selectParent() {
        this.select(false, true, false);
    }
    
    public void selectChild() {
        this.select(false, false, true);
    }
    
    public void select(final boolean b, final boolean b2, final boolean b3) {
        final Object selectionCell = this.getSelectionCell();
        if (this.getSelectionCount() > 1) {
            this.clearSelection();
        }
        final Object selectionCell2 = (selectionCell != null) ? this.model.getParent(selectionCell) : this.getDefaultParent();
        final int childCount = this.model.getChildCount(selectionCell2);
        if (selectionCell == null && childCount > 0) {
            this.setSelectionCell(this.model.getChildAt(selectionCell2, 0));
        }
        else if ((selectionCell == null || b2) && this.view.getState(selectionCell2) != null && this.model.getGeometry(selectionCell2) != null) {
            if (this.getCurrentRoot() != selectionCell2) {
                this.setSelectionCell(selectionCell2);
            }
        }
        else if (selectionCell != null && b3) {
            if (this.model.getChildCount(selectionCell) > 0) {
                this.setSelectionCell(this.model.getChildAt(selectionCell, 0));
            }
        }
        else if (childCount > 0) {
            int index = ((mxICell)selectionCell2).getIndex((mxICell)selectionCell);
            if (b) {
                ++index;
                this.setSelectionCell(this.model.getChildAt(selectionCell2, index % childCount));
            }
            else {
                this.setSelectionCell(this.model.getChildAt(selectionCell2, (--index < 0) ? (childCount - 1) : index));
            }
        }
    }
    
    public void selectVertices() {
        this.selectVertices(null);
    }
    
    public void selectVertices(final Object o) {
        this.selectCells(true, false, o);
    }
    
    public void selectEdges() {
        this.selectEdges(null);
    }
    
    public void selectEdges(final Object o) {
        this.selectCells(false, true, o);
    }
    
    public void selectCells(final boolean b, final boolean b2) {
        this.selectCells(b, b2, null);
    }
    
    public void selectCells(final boolean b, final boolean b2, Object defaultParent) {
        if (defaultParent == null) {
            defaultParent = this.getDefaultParent();
        }
        this.setSelectionCells(mxGraphModel.filter(this.getModel(), new mxGraphModel.Filter() {
            public boolean filter(final Object o) {
                return mxGraph.this.view.getState(o) != null && mxGraph.this.model.getChildCount(o) == 0 && ((mxGraph.this.model.isVertex(o) && b) || (mxGraph.this.model.isEdge(o) && b2));
            }
        }));
    }
    
    public void selectAll() {
        this.selectAll(null);
    }
    
    public void selectAll(Object defaultParent) {
        if (defaultParent == null) {
            defaultParent = this.getDefaultParent();
        }
        final Object[] children = mxGraphModel.getChildren(this.model, defaultParent);
        if (children != null) {
            this.setSelectionCells(children);
        }
    }
    
    public void draw(final mxICanvas mxICanvas) {
        this.drawCell(mxICanvas, this.getModel().getRoot());
    }
    
    public void drawCell(final mxICanvas mxICanvas, final Object o) {
        this.drawCellWithLabel(mxICanvas, o, this.getLabel(o));
        for (int childCount = this.model.getChildCount(o), i = 0; i < childCount; ++i) {
            this.drawCell(mxICanvas, this.model.getChildAt(o, i));
        }
    }
    
    public mxCellState drawCellWithLabel(final mxICanvas mxICanvas, final Object o, final String s) {
        mxCellState state = null;
        if (o != this.view.getCurrentRoot() && o != this.model.getRoot()) {
            state = this.getView().getState(o);
            if (state != null) {
                Object o2 = null;
                Object drawLabel = null;
                final int n = (int)Math.round(state.getX());
                final int n2 = (int)Math.round(state.getY());
                final int n3 = (int)Math.round(state.getWidth() - n + state.getX());
                final int n4 = (int)Math.round(state.getHeight() - n2 + state.getY());
                if (this.model.isVertex(o)) {
                    o2 = mxICanvas.drawVertex(n, n2, n3, n4, state.getStyle());
                }
                else if (this.model.isEdge(o)) {
                    o2 = mxICanvas.drawEdge(state.getAbsolutePoints(), state.getStyle());
                }
                final mxRectangle labelBounds = state.getLabelBounds();
                if (s != null && labelBounds != null) {
                    final int n5 = (int)Math.round(labelBounds.getX());
                    final int n6 = (int)Math.round(labelBounds.getY());
                    drawLabel = mxICanvas.drawLabel(s, n5, n6, (int)Math.round(labelBounds.getWidth() - n5 + labelBounds.getX()), (int)Math.round(labelBounds.getHeight() - n6 + labelBounds.getY()), state.getStyle(), this.isHtmlLabel(o));
                }
                if (o2 != null) {
                    this.cellDrawn(o, o2, drawLabel);
                }
            }
        }
        return state;
    }
    
    protected void cellDrawn(final Object o, final Object o2, final Object o3) {
        if (o2 instanceof Element) {
            final String linkForCell = this.getLinkForCell(o);
            if (linkForCell != null) {
                final String toolTipForCell = this.getToolTipForCell(o);
                Element element = (Element)o2;
                if (element.getNodeName().startsWith("v:")) {
                    element.setAttribute("href", linkForCell.toString());
                    if (toolTipForCell != null) {
                        element.setAttribute("title", toolTipForCell);
                    }
                }
                else if (element.getOwnerDocument().getElementsByTagName("svg").getLength() > 0) {
                    final Element element2 = element.getOwnerDocument().createElement("a");
                    element2.setAttribute("xlink:href", linkForCell.toString());
                    element.getParentNode().replaceChild(element2, element);
                    element2.appendChild(element);
                    if (toolTipForCell != null) {
                        element2.setAttribute("xlink:title", toolTipForCell);
                    }
                    element = element2;
                }
                else {
                    final Element element3 = element.getOwnerDocument().createElement("a");
                    element3.setAttribute("href", linkForCell.toString());
                    element3.setAttribute("style", "text-decoration:none;");
                    element.getParentNode().replaceChild(element3, element);
                    element3.appendChild(element);
                    if (toolTipForCell != null) {
                        element3.setAttribute("title", toolTipForCell);
                    }
                    element = element3;
                }
                final String targetForCell = this.getTargetForCell(o);
                if (targetForCell != null) {
                    element.setAttribute("target", targetForCell);
                }
            }
        }
    }
    
    protected String getLinkForCell(final Object o) {
        return null;
    }
    
    protected String getTargetForCell(final Object o) {
        return null;
    }
    
    public void addPropertyChangeListener(final PropertyChangeListener listener) {
        this.changeSupport.addPropertyChangeListener(listener);
    }
    
    public void addPropertyChangeListener(final String propertyName, final PropertyChangeListener listener) {
        this.changeSupport.addPropertyChangeListener(propertyName, listener);
    }
    
    public void removePropertyChangeListener(final PropertyChangeListener listener) {
        this.changeSupport.removePropertyChangeListener(listener);
    }
    
    public void removePropertyChangeListener(final String propertyName, final PropertyChangeListener listener) {
        this.changeSupport.removePropertyChangeListener(propertyName, listener);
    }
    
    public static void main(final String[] array) {
        System.out.println("mxGraph version \"0.13.0.2\"");
    }
    
    static {
        mxResources.add("com.mxgraph.resources.graph");
        mxGraph.EVENT_BEFORE_SHOW = "beforeShow";
        mxGraph.EVENT_BEFORE_HIDE = "beforeHide";
        mxGraph.EVENT_BEFORE_REMOVE = "beforeRemove";
        mxGraph.EVENT_SHOW = "show";
        mxGraph.EVENT_HIDE = "hide";
        mxGraph.EVENT_REMOVE = "remove";
        mxGraph.EVENT_AFTER_SHOW = "afterShow";
        mxGraph.EVENT_AFTER_HIDE = "afterHide";
        mxGraph.EVENT_AFTER_REMOVE = "afterRemove";
        mxGraph.EVENT_BEFORE_MOVE = "beforeMove";
        mxGraph.EVENT_MOVE = "move";
        mxGraph.EVENT_CLONE = "clone";
        mxGraph.EVENT_AFTER_MOVE = "afterMove";
        mxGraph.EVENT_BEFORE_ADD = "beforeAdd";
        mxGraph.EVENT_ADD = "add";
        mxGraph.EVENT_AFTER_ADD = "afterAdd";
        mxGraph.EVENT_BEFORE_CONNECT = "beforeConnect";
        mxGraph.EVENT_CONNECT = "connect";
        mxGraph.EVENT_AFTER_CONNECT = "afterConnect";
        mxGraph.EVENT_BEFORE_DISCONNECT = "beforeDisconnect";
        mxGraph.EVENT_DISCONNECT = "disconnect";
        mxGraph.EVENT_AFTER_DISCONNECT = "afterDisconnect";
        mxGraph.EVENT_BEFORE_RESIZE = "beforeResize";
        mxGraph.EVENT_RESIZE = "resize";
        mxGraph.EVENT_AFTER_RESIZE = "afterResize";
        mxGraph.EVENT_BEFORE_COLLAPSE = "beforeCollapse";
        mxGraph.EVENT_COLLAPSE = "collapse";
        mxGraph.EVENT_AFTER_COLLAPSE = "afterCollapse";
        mxGraph.EVENT_BEFORE_EXPAND = "beforeExpand";
        mxGraph.EVENT_EXPAND = "expand";
        mxGraph.EVENT_AFTER_EXPAND = "afterExpand";
        mxGraph.EVENT_BEFORE_LAYOUT = "beforeLayout";
        mxGraph.EVENT_LAYOUT = "layout";
        mxGraph.EVENT_AFTER_LAYOUT = "afterLayout";
        mxGraph.EVENT_BEFORE_UPDATESIZE = "beforeUpdateSize";
        mxGraph.EVENT_UPDATESIZE = "updateSize";
        mxGraph.EVENT_AFTER_UPDATESIZE = "afterUpdateSize";
        mxGraph.EVENT_FLIP = "flip";
        mxGraph.EVENT_INDEX_CHANGED = "indexChanged";
        mxGraph.EVENT_REPAINT = "repaint";
    }
    
    public interface mxICellVisitor
    {
        boolean visit(final Object p0, final Object p1);
    }
}
