// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.util;

import java.util.ArrayList;
import java.util.List;

public class mxEventSource
{
    protected static final Object[] EMPTY_ARRAY;
    protected transient List eventListeners;
    protected Object source;
    protected boolean eventsEnabled;
    
    public mxEventSource() {
        this(null);
    }
    
    public mxEventSource(Object source) {
        this.eventListeners = null;
        this.eventsEnabled = true;
        if (source == null) {
            source = this;
        }
        this.source = source;
    }
    
    public boolean isEventsEnabled() {
        return this.eventsEnabled;
    }
    
    public void setEventsEnabled(final boolean eventsEnabled) {
        this.eventsEnabled = eventsEnabled;
    }
    
    public void addListener(final String s, final mxEventListener mxEventListener) {
        if (this.eventListeners == null) {
            this.eventListeners = new ArrayList();
        }
        this.eventListeners.add(s);
        this.eventListeners.add(mxEventListener);
    }
    
    public void removeListener(final mxEventListener mxEventListener) {
        this.removeListener(null, mxEventListener);
    }
    
    public void removeListener(final String anObject, final mxEventListener mxEventListener) {
        if (this.eventListeners != null) {
            for (int i = this.eventListeners.size() - 2; i > 1; i -= 2) {
                if (this.eventListeners.get(i + 1) == mxEventListener && (anObject == null || String.valueOf(this.eventListeners.get(i)).equals(anObject))) {
                    this.eventListeners.remove(i + 1);
                    this.eventListeners.remove(i);
                }
            }
        }
    }
    
    public void fireEvent(final String s) {
        this.fireEvent(s, this.source, null);
    }
    
    public void fireEvent(final String s, final Object[] array) {
        this.fireEvent(s, this.source, array);
    }
    
    public void fireEvent(final String anObject, final Object o, Object[] empty_ARRAY) {
        if (this.eventListeners != null && !this.eventListeners.isEmpty() && this.eventsEnabled) {
            if (empty_ARRAY == null) {
                empty_ARRAY = mxEventSource.EMPTY_ARRAY;
            }
            for (int i = 0; i < this.eventListeners.size(); i += 2) {
                final String s = this.eventListeners.get(i);
                if (s == null || s.equals(anObject)) {
                    ((mxEventListener)this.eventListeners.get(i + 1)).invoke(o, empty_ARRAY);
                }
            }
        }
    }
    
    static {
        EMPTY_ARRAY = new Object[0];
    }
    
    public interface mxEventListener
    {
        void invoke(final Object p0, final Object[] p1);
    }
    
    public interface mxIEventSource
    {
        void addListener(final String p0, final mxEventListener p1);
        
        void removeListener(final mxEventListener p0);
        
        void removeListener(final String p0, final mxEventListener p1);
    }
}
