// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import java.awt.event.MouseEvent;
import java.awt.Color;
import com.mxgraph.swing.mxGraphComponent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;

public class mxHighlight extends mxCellMarker implements MouseListener, MouseMotionListener
{
    public mxHighlight(final mxGraphComponent mxGraphComponent, final Color color) {
        super(mxGraphComponent, color);
        mxGraphComponent.getControl().addMouseListener(this);
        mxGraphComponent.getControl().addMouseMotionListener(this);
    }
    
    public void destroy() {
        this.graphComponent.getControl().removeMouseListener(this);
        this.graphComponent.getControl().removeMouseMotionListener(this);
    }
    
    public void mouseClicked(final MouseEvent mouseEvent) {
    }
    
    public void mouseEntered(final MouseEvent mouseEvent) {
    }
    
    public void mouseExited(final MouseEvent mouseEvent) {
    }
    
    public void mousePressed(final MouseEvent mouseEvent) {
    }
    
    public void mouseReleased(final MouseEvent mouseEvent) {
        this.reset();
    }
    
    public void mouseDragged(final MouseEvent mouseEvent) {
    }
    
    public void mouseMoved(final MouseEvent mouseEvent) {
        this.process(mouseEvent);
    }
}
