// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import javax.swing.TransferHandler;
import com.mxgraph.swing.util.mxGraphActions;
import javax.swing.ActionMap;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import com.mxgraph.swing.mxGraphComponent;

public class mxKeyboardHandler
{
    public mxKeyboardHandler(final mxGraphComponent mxGraphComponent) {
        this.installKeyboardActions(mxGraphComponent);
    }
    
    protected void installKeyboardActions(final mxGraphComponent component) {
        SwingUtilities.replaceUIInputMap(component, 1, this.getInputMap(1));
        SwingUtilities.replaceUIInputMap(component, 0, this.getInputMap(0));
        SwingUtilities.replaceUIActionMap(component, this.createActionMap());
    }
    
    protected InputMap getInputMap(final int n) {
        InputMap inputMap = null;
        if (n == 1) {
            inputMap = (InputMap)UIManager.get("ScrollPane.ancestorInputMap");
        }
        else if (n == 0) {
            inputMap = new InputMap();
            inputMap.put(KeyStroke.getKeyStroke("F2"), "edit");
            inputMap.put(KeyStroke.getKeyStroke("DELETE"), "delete");
            inputMap.put(KeyStroke.getKeyStroke("UP"), "selectParent");
            inputMap.put(KeyStroke.getKeyStroke("DOWN"), "selectChild");
            inputMap.put(KeyStroke.getKeyStroke("RIGHT"), "selectNext");
            inputMap.put(KeyStroke.getKeyStroke("LEFT"), "selectPrevious");
            inputMap.put(KeyStroke.getKeyStroke("PAGE_DOWN"), "drillDown");
            inputMap.put(KeyStroke.getKeyStroke("PAGE_UP"), "drillUp");
            inputMap.put(KeyStroke.getKeyStroke("HOME"), "drillHome");
            inputMap.put(KeyStroke.getKeyStroke("ENTER"), "expand");
            inputMap.put(KeyStroke.getKeyStroke("BACK_SPACE"), "collapse");
            inputMap.put(KeyStroke.getKeyStroke("control A"), "selectAll");
            inputMap.put(KeyStroke.getKeyStroke("control D"), "selectNone");
            inputMap.put(KeyStroke.getKeyStroke("control X"), "cut");
            inputMap.put(KeyStroke.getKeyStroke("control C"), "copy");
            inputMap.put(KeyStroke.getKeyStroke("control V"), "paste");
            inputMap.put(KeyStroke.getKeyStroke("control G"), "group");
            inputMap.put(KeyStroke.getKeyStroke("control U"), "ungroup");
            inputMap.put(KeyStroke.getKeyStroke("ADD"), "zoomIn");
            inputMap.put(KeyStroke.getKeyStroke("SUBTRACT"), "zoomOut");
        }
        return inputMap;
    }
    
    protected ActionMap createActionMap() {
        final ActionMap actionMap = (ActionMap)UIManager.get("ScrollPane.actionMap");
        actionMap.put("edit", mxGraphActions.getEditAction());
        actionMap.put("delete", mxGraphActions.getDeleteAction());
        actionMap.put("drillHome", mxGraphActions.getHomeAction());
        actionMap.put("drillDown", mxGraphActions.getEnterGroupAction());
        actionMap.put("drillUp", mxGraphActions.getExitGroupAction());
        actionMap.put("collapse", mxGraphActions.getCollapseAction());
        actionMap.put("expand", mxGraphActions.getExpandAction());
        actionMap.put("toBack", mxGraphActions.getToBackAction());
        actionMap.put("toFront", mxGraphActions.getToFrontAction());
        actionMap.put("selectNone", mxGraphActions.getSelectNoneAction());
        actionMap.put("selectAll", mxGraphActions.getSelectAllAction());
        actionMap.put("selectNext", mxGraphActions.getSelectNextAction());
        actionMap.put("selectPrevious", mxGraphActions.getSelectPreviousAction());
        actionMap.put("selectParent", mxGraphActions.getSelectParentAction());
        actionMap.put("selectChild", mxGraphActions.getSelectChildAction());
        actionMap.put("cut", TransferHandler.getCutAction());
        actionMap.put("copy", TransferHandler.getCopyAction());
        actionMap.put("paste", TransferHandler.getPasteAction());
        actionMap.put("group", mxGraphActions.getGroupAction());
        actionMap.put("ungroup", mxGraphActions.getUngroupAction());
        return actionMap;
    }
}
