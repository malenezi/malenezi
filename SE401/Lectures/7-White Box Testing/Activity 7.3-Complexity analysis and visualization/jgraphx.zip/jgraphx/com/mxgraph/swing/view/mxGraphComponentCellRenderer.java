// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.view;

import com.mxgraph.util.mxRectangle;
import java.awt.image.BufferedImage;
import com.mxgraph.canvas.mxGraphics2DCanvas;
import com.mxgraph.canvas.mxICanvas;
import java.awt.Color;
import com.mxgraph.swing.mxGraphComponent;

public class mxGraphComponentCellRenderer extends mxGraphCellRenderer
{
    protected mxGraphComponent graphComponent;
    
    public mxGraphComponentCellRenderer(final mxGraphComponent graphComponent) {
        this.graphComponent = graphComponent;
    }
    
    @Override
    protected mxICanvas createCanvas(final int n, final int n2, final int n3, final int n4, final double n5, final Color color) {
        final mxGraphics2DCanvas graphicsCanvas = this.graphComponent.createGraphicsCanvas(n, n2, n3 + 1, n4 + 1, n5, color);
        if (graphicsCanvas.getGraphics() != null) {
            graphicsCanvas.setTextAntiAlias(true);
            graphicsCanvas.setAntiAlias(this.graphComponent.isAntiAlias());
            return graphicsCanvas;
        }
        return null;
    }
    
    public static BufferedImage render(final mxGraphComponent mxGraphComponent, final double n, final Color color, final Object[] array) {
        if (array != null) {
            final mxGraphComponentCellRenderer mxGraphComponentCellRenderer = new mxGraphComponentCellRenderer(mxGraphComponent);
            return mxGraphComponentCellRenderer.getImage(mxGraphComponentCellRenderer.drawCells(mxGraphComponent.getGraph(), array, n, color, null));
        }
        return null;
    }
    
    public static BufferedImage render(final mxGraphComponent mxGraphComponent, final double n, final Color color) {
        return render(mxGraphComponent, n, color, new Object[] { mxGraphComponent.getGraph().getModel().getRoot() });
    }
}
