// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.util;

import java.util.EventObject;
import javax.swing.AbstractAction;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.view.mxGraph;
import java.awt.event.ActionEvent;
import javax.swing.Action;

public class mxGraphActions
{
    static final Action deleteAction;
    static final Action editAction;
    static final Action groupAction;
    static final Action ungroupAction;
    static final Action removeFromParentAction;
    static final Action selectAllAction;
    static final Action selectVerticesAction;
    static final Action selectEdgesAction;
    static final Action selectNoneAction;
    static final Action selectNextAction;
    static final Action selectPreviousAction;
    static final Action selectParentAction;
    static final Action selectChildAction;
    static final Action collapseAction;
    static final Action expandAction;
    static final Action enterGroupAction;
    static final Action exitGroupAction;
    static final Action homeAction;
    static final Action zoomActualAction;
    static final Action zoomInAction;
    static final Action zoomOutAction;
    static final Action toBackAction;
    static final Action toFrontAction;
    
    public static Action getDeleteAction() {
        return mxGraphActions.deleteAction;
    }
    
    public static Action getEditAction() {
        return mxGraphActions.editAction;
    }
    
    public static Action getGroupAction() {
        return mxGraphActions.groupAction;
    }
    
    public static Action getUngroupAction() {
        return mxGraphActions.ungroupAction;
    }
    
    public static Action getRemoveFromParentAction() {
        return mxGraphActions.removeFromParentAction;
    }
    
    public static Action getSelectAllAction() {
        return mxGraphActions.selectAllAction;
    }
    
    public static Action getSelectVerticesAction() {
        return mxGraphActions.selectVerticesAction;
    }
    
    public static Action getSelectEdgesAction() {
        return mxGraphActions.selectEdgesAction;
    }
    
    public static Action getSelectNoneAction() {
        return mxGraphActions.selectNoneAction;
    }
    
    public static Action getSelectNextAction() {
        return mxGraphActions.selectNextAction;
    }
    
    public static Action getSelectPreviousAction() {
        return mxGraphActions.selectPreviousAction;
    }
    
    public static Action getSelectParentAction() {
        return mxGraphActions.selectParentAction;
    }
    
    public static Action getSelectChildAction() {
        return mxGraphActions.selectChildAction;
    }
    
    public static Action getEnterGroupAction() {
        return mxGraphActions.enterGroupAction;
    }
    
    public static Action getExitGroupAction() {
        return mxGraphActions.exitGroupAction;
    }
    
    public static Action getHomeAction() {
        return mxGraphActions.homeAction;
    }
    
    public static Action getCollapseAction() {
        return mxGraphActions.collapseAction;
    }
    
    public static Action getExpandAction() {
        return mxGraphActions.expandAction;
    }
    
    public static Action getZoomActualAction() {
        return mxGraphActions.zoomActualAction;
    }
    
    public static Action getZoomInAction() {
        return mxGraphActions.zoomInAction;
    }
    
    public static Action getZoomOutAction() {
        return mxGraphActions.zoomOutAction;
    }
    
    public static Action getToBackAction() {
        return mxGraphActions.toBackAction;
    }
    
    public static Action getToFrontAction() {
        return mxGraphActions.toFrontAction;
    }
    
    public static final mxGraph getGraph(final ActionEvent actionEvent) {
        final Object source = actionEvent.getSource();
        if (source instanceof mxGraphComponent) {
            return ((mxGraphComponent)source).getGraph();
        }
        return null;
    }
    
    static {
        deleteAction = new DeleteAction("delete");
        editAction = new EditAction("edit");
        groupAction = new GroupAction("group");
        ungroupAction = new UngroupAction("ungroup");
        removeFromParentAction = new RemoveFromParentAction("removeFromParent");
        selectAllAction = new SelectAction("selectAll");
        selectVerticesAction = new SelectAction("vertices");
        selectEdgesAction = new SelectAction("edges");
        selectNoneAction = new SelectAction("selectNone");
        selectNextAction = new SelectAction("selectNext");
        selectPreviousAction = new SelectAction("selectPrevious");
        selectParentAction = new SelectAction("selectParent");
        selectChildAction = new SelectAction("selectChild");
        collapseAction = new FoldAction("collapse");
        expandAction = new FoldAction("expand");
        enterGroupAction = new DrillAction("enterGroup");
        exitGroupAction = new DrillAction("exitGroup");
        homeAction = new DrillAction("home");
        zoomActualAction = new ZoomAction("actual");
        zoomInAction = new ZoomAction("zoomIn");
        zoomOutAction = new ZoomAction("zoomOut");
        toBackAction = new LayerAction("toBack");
        toFrontAction = new LayerAction("toFront");
    }
    
    public static class SelectAction extends AbstractAction
    {
        public SelectAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final mxGraph graph = mxGraphActions.getGraph(actionEvent);
            if (graph != null) {
                final String string = this.getValue("Name").toString();
                if (string.equalsIgnoreCase("selectAll")) {
                    graph.selectAll();
                }
                else if (string.equalsIgnoreCase("selectNone")) {
                    graph.clearSelection();
                }
                else if (string.equalsIgnoreCase("selectNext")) {
                    graph.selectNext();
                }
                else if (string.equalsIgnoreCase("selectPrevious")) {
                    graph.selectPrevious();
                }
                else if (string.equalsIgnoreCase("selectParent")) {
                    graph.selectParent();
                }
                else if (string.equalsIgnoreCase("vertices")) {
                    graph.selectVertices();
                }
                else if (string.equalsIgnoreCase("edges")) {
                    graph.selectEdges();
                }
                else {
                    graph.selectChild();
                }
            }
        }
    }
    
    public static class ZoomAction extends AbstractAction
    {
        public ZoomAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final Object source = actionEvent.getSource();
            if (source instanceof mxGraphComponent) {
                final mxGraphComponent mxGraphComponent = (mxGraphComponent)source;
                if (this.getValue("Name").toString().equalsIgnoreCase("zoomIn")) {
                    mxGraphComponent.zoomIn();
                }
                else if (this.getValue("Name").toString().equalsIgnoreCase("zoomOut")) {
                    mxGraphComponent.zoomOut();
                }
                else {
                    mxGraphComponent.zoomActual();
                }
            }
        }
    }
    
    public static class DrillAction extends AbstractAction
    {
        public DrillAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final mxGraph graph = mxGraphActions.getGraph(actionEvent);
            if (graph != null) {
                final String string = this.getValue("Name").toString();
                if (string.equalsIgnoreCase("enterGroup")) {
                    graph.enterGroup();
                }
                else if (string.equalsIgnoreCase("exitGroup")) {
                    graph.exitGroup();
                }
                else {
                    graph.home();
                }
            }
        }
    }
    
    public static class FoldAction extends AbstractAction
    {
        public FoldAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final mxGraph graph = mxGraphActions.getGraph(actionEvent);
            if (graph != null) {
                if (this.getValue("Name").toString().equalsIgnoreCase("collapse")) {
                    graph.collapse();
                }
                else {
                    graph.expand();
                }
            }
        }
    }
    
    public static class LayerAction extends AbstractAction
    {
        public LayerAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final mxGraph graph = mxGraphActions.getGraph(actionEvent);
            if (graph != null) {
                if (this.getValue("Name").toString().equalsIgnoreCase("toBack")) {
                    graph.toBack();
                }
                else {
                    graph.toFront();
                }
            }
        }
    }
    
    public static class RemoveFromParentAction extends AbstractAction
    {
        public RemoveFromParentAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final mxGraph graph = mxGraphActions.getGraph(actionEvent);
            if (graph != null) {
                graph.removeFromParent();
            }
        }
    }
    
    public static class UngroupAction extends AbstractAction
    {
        public UngroupAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final mxGraph graph = mxGraphActions.getGraph(actionEvent);
            if (graph != null) {
                graph.ungroup();
            }
        }
    }
    
    public static class GroupAction extends AbstractAction
    {
        public GroupAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final mxGraph graph = mxGraphActions.getGraph(actionEvent);
            if (graph != null) {
                graph.group(null, 2 * graph.getGridSize());
            }
        }
    }
    
    public static class DeleteAction extends AbstractAction
    {
        public DeleteAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            final mxGraph graph = mxGraphActions.getGraph(actionEvent);
            if (graph != null) {
                graph.remove();
            }
        }
    }
    
    public static class EditAction extends AbstractAction
    {
        public EditAction(final String name) {
            super(name);
        }
        
        public void actionPerformed(final ActionEvent actionEvent) {
            if (actionEvent.getSource() instanceof mxGraphComponent) {
                ((mxGraphComponent)actionEvent.getSource()).edit(actionEvent);
            }
        }
    }
}
