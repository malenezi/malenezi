// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing;

import com.mxgraph.view.mxGraphView;
import javax.swing.JScrollBar;
import java.awt.AWTEvent;
import javax.swing.SwingUtilities;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import java.awt.image.ImageObserver;
import java.awt.Shape;
import com.mxgraph.util.mxUtils;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Graphics2D;
import com.mxgraph.canvas.mxGraphics2DCanvas;
import com.mxgraph.util.mxPoint;
import java.awt.print.PageFormat;
import com.mxgraph.canvas.mxICanvas;
import java.awt.image.BufferedImage;
import java.awt.Dimension;
import com.mxgraph.view.mxGraph;
import java.awt.Cursor;
import java.awt.Component;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentAdapter;
import com.mxgraph.util.mxRectangle;
import java.awt.event.AdjustmentListener;
import java.awt.event.ComponentListener;
import com.mxgraph.util.mxEventSource;
import java.awt.Point;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.border.Border;
import javax.swing.JComponent;

public class mxGraphOutline extends JComponent
{
    public static Border DEFAULT_FINDER_BORDER;
    public static Border DEFAULT_ZOOMHANDLE_BORDER;
    public static Color DEFAULT_ZOOMHANDLE_FILL;
    protected mxGraphComponent graphComponent;
    protected ImageIcon buffer;
    protected JPanel finder;
    protected JPanel zoomHandle;
    protected boolean useScaledInstance;
    protected boolean wholePage;
    protected int pageBorder;
    protected MouseTracker tracker;
    private double scale;
    private Point translate;
    protected mxEventSource.mxEventListener repaintHandler;
    protected ComponentListener componentHandler;
    protected AdjustmentListener adjustmentHandler;
    
    public mxGraphOutline(final mxGraphComponent graphComponent) {
        this.finder = new JPanel();
        this.zoomHandle = new JPanel();
        this.useScaledInstance = true;
        this.wholePage = false;
        this.pageBorder = 50;
        this.tracker = new MouseTracker();
        this.scale = 0.0;
        this.translate = new Point();
        this.repaintHandler = new mxEventSource.mxEventListener() {
            public void invoke(final Object o, final Object[] array) {
                final mxRectangle mxRectangle = (array.length > 0) ? ((mxRectangle)array[0]) : null;
                mxGraphOutline.this.refresh((mxRectangle != null) ? mxRectangle : null);
            }
        };
        this.componentHandler = new ComponentAdapter() {
            @Override
            public void componentResized(final ComponentEvent componentEvent) {
                mxGraphOutline.this.refresh(null);
            }
        };
        this.adjustmentHandler = new AdjustmentListener() {
            public void adjustmentValueChanged(final AdjustmentEvent adjustmentEvent) {
                mxGraphOutline.this.updateFinder();
            }
        };
        this.setGraphComponent(graphComponent);
        this.setEnabled(true);
        this.setOpaque(true);
        this.finder.setBorder(mxGraphOutline.DEFAULT_FINDER_BORDER);
        this.finder.addMouseMotionListener(this.tracker);
        this.finder.addMouseListener(this.tracker);
        this.finder.setOpaque(false);
        this.add(this.finder);
        this.zoomHandle.setBorder(mxGraphOutline.DEFAULT_ZOOMHANDLE_BORDER);
        this.zoomHandle.addMouseMotionListener(this.tracker);
        this.zoomHandle.addMouseListener(this.tracker);
        this.zoomHandle.setBackground(mxGraphOutline.DEFAULT_ZOOMHANDLE_FILL);
        this.zoomHandle.setOpaque(true);
        this.add(this.zoomHandle, 0);
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(final ComponentEvent componentEvent) {
                mxGraphOutline.this.refresh(null);
            }
        });
    }
    
    @Override
    public void setEnabled(final boolean enabled) {
        super.setEnabled(enabled);
        this.finder.setCursor(new Cursor(enabled ? 13 : 0));
        this.zoomHandle.setCursor(new Cursor(enabled ? 12 : 0));
    }
    
    @Override
    public void setVisible(final boolean visible) {
        super.setVisible(visible);
        if (!visible) {
            this.buffer = null;
        }
        else {
            this.refresh(null);
        }
    }
    
    public void setFinderVisible(final boolean visible) {
        this.finder.setVisible(visible);
    }
    
    public void setFinderEnabled(final boolean enabled) {
        this.finder.setEnabled(enabled);
    }
    
    public void setZoomHandleVisible(final boolean visible) {
        this.zoomHandle.setVisible(visible);
    }
    
    public void setZoomHandleEnabled(final boolean enabled) {
        this.zoomHandle.setEnabled(enabled);
    }
    
    public void setWholePage(final boolean wholePage) {
        this.wholePage = wholePage;
    }
    
    public boolean isWholePage() {
        return this.wholePage;
    }
    
    public void setPageBorder(final int pageBorder) {
        this.pageBorder = pageBorder;
    }
    
    public int getPageBorder() {
        return this.pageBorder;
    }
    
    public void setFinderBorder(final Border border) {
        this.finder.setBorder(border);
    }
    
    public mxGraphComponent getGraphComponent() {
        return this.graphComponent;
    }
    
    public void setGraphComponent(final mxGraphComponent graphComponent) {
        if (this.graphComponent != null) {
            this.graphComponent.getGraph().removeListener(this.repaintHandler);
            this.graphComponent.removeComponentListener(this.componentHandler);
            this.graphComponent.getHorizontalScrollBar().removeAdjustmentListener(this.adjustmentHandler);
            this.graphComponent.getVerticalScrollBar().removeAdjustmentListener(this.adjustmentHandler);
        }
        this.graphComponent = graphComponent;
        this.buffer = null;
        if (this.graphComponent != null) {
            this.graphComponent.getGraph().addListener(mxGraph.EVENT_REPAINT, this.repaintHandler);
            this.graphComponent.addComponentListener(this.componentHandler);
            this.graphComponent.getHorizontalScrollBar().addAdjustmentListener(this.adjustmentHandler);
            this.graphComponent.getVerticalScrollBar().addAdjustmentListener(this.adjustmentHandler);
            this.refresh(null);
        }
    }
    
    public void refresh(final mxRectangle mxRectangle) {
        final double scale = this.graphComponent.getGraph().getView().getScale();
        if (this.graphComponent.isPageVisible() && this.wholePage) {
            final PageFormat pageFormat = this.graphComponent.getPageFormat();
            final double pageScale = this.graphComponent.getPageScale();
            final int n = 0;
            final Dimension dimension = new Dimension((int)Math.round(pageFormat.getWidth() * pageScale * scale) + n, (int)Math.round(pageFormat.getHeight() * pageScale * scale) + n);
            this.scale = Math.min(this.getWidth() / dimension.getWidth(), this.getHeight() / dimension.getHeight());
            final int n2 = 0;
            final mxPoint translate = this.graphComponent.getGraph().getView().getTranslate();
            (this.translate = new Point((int)Math.round(translate.getX() * scale) - n2, (int)Math.round(translate.getY() * scale) - n2)).translate(-(int)Math.round((this.getWidth() - dimension.getWidth() * this.scale) / 2.0 / this.scale), -(int)Math.round((this.getHeight() - dimension.getHeight() * this.scale) / 2.0 / this.scale));
        }
        else {
            final Dimension preferredSize = this.graphComponent.getControl().getPreferredSize();
            this.scale = Math.min(this.getWidth() / Math.max(this.graphComponent.getWidth(), preferredSize.getWidth()), this.getHeight() / Math.max(this.graphComponent.getHeight(), preferredSize.getHeight()));
            this.translate = new Point();
        }
        final mxGraphics2DCanvas canvas = this.graphComponent.getControl().getCanvas(true);
        if (this.buffer != null && canvas != null) {
            if (this.buffer.getImage() instanceof BufferedImage) {
                final Graphics2D graphics = canvas.getGraphics();
                final Graphics2D graphics2 = ((BufferedImage)this.buffer.getImage()).createGraphics();
                Rectangle rectangle = null;
                if (mxRectangle != null) {
                    rectangle = new mxRectangle(mxRectangle.getX() * this.scale, mxRectangle.getY() * this.scale, mxRectangle.getWidth() * this.scale, mxRectangle.getHeight() * this.scale).getRectangle();
                    rectangle.grow(2, 2);
                }
                try {
                    final int n3 = (int)Math.round(this.translate.x * this.scale);
                    final int n4 = (int)Math.round(this.translate.y * this.scale);
                    canvas.setGraphics(graphics2);
                    if (rectangle != null) {
                        rectangle.translate(-n3, -n4);
                        canvas.setClip(rectangle);
                        canvas.clear(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
                    }
                    else {
                        canvas.clear(0, 0, this.buffer.getIconWidth(), this.buffer.getIconHeight());
                    }
                    graphics2.translate(-n3, -n4);
                    graphics2.scale(this.scale, this.scale);
                    this.graphComponent.getGraph().draw(canvas);
                    graphics2.translate(n3, n4);
                }
                finally {
                    canvas.clearClip();
                    canvas.setGraphics(graphics);
                    graphics2.dispose();
                }
                if (rectangle != null) {
                    this.repaint(rectangle);
                }
                else {
                    this.repaint();
                }
            }
            else {
                this.buffer = null;
                this.repaint();
            }
        }
        this.updateFinder();
    }
    
    public void updateFinder() {
        final Rectangle viewRect = this.graphComponent.getViewport().getViewRect();
        final int x = (int)Math.round(viewRect.x * this.scale);
        final int y = (int)Math.round(viewRect.y * this.scale);
        this.updateFinder(new Rectangle(x, y, (int)Math.round((viewRect.x + viewRect.width) * this.scale) - x + 1, (int)Math.round((viewRect.y + viewRect.height) * this.scale) - y + 1));
    }
    
    public void updateFinder(final Rectangle bounds) {
        bounds.translate((int)(-Math.round(this.translate.x * this.scale)), (int)(-Math.round(this.translate.y * this.scale)));
        this.finder.setBounds(bounds);
        this.zoomHandle.setBounds(bounds.x + bounds.width - 6, bounds.y + bounds.height - 6, 8, 8);
    }
    
    public void createBuffer() {
        if (this.graphComponent != null && this.getWidth() > 0 && this.getHeight() > 0 && this.scale > 0.0) {
            final mxGraphics2DCanvas canvas = this.graphComponent.getControl().getCanvas();
            if (this.useScaledInstance && this.buffer != null && this.buffer.getImage() instanceof BufferedImage && canvas != null && canvas.getImage() != null) {
                this.buffer = null;
            }
            if (this.buffer == null || (!this.useScaledInstance && (this.buffer.getIconWidth() != this.getWidth() || this.buffer.getIconHeight() != this.getHeight()))) {
                if (canvas != null && canvas.getImage() != null && this.useScaledInstance) {
                    final mxRectangle bounds = this.graphComponent.getGraph().getBounds();
                    if (bounds.getWidth() > 0.0 || bounds.getHeight() > 0.0) {
                        this.buffer = new ImageIcon(this.graphComponent.getControl().getCanvas().getImage().getScaledInstance((int)(bounds.getWidth() * this.scale), (int)(bounds.getHeight() * this.scale), 4));
                    }
                }
                else {
                    this.buffer = new ImageIcon(new BufferedImage(this.getWidth(), this.getHeight(), 2));
                    this.refresh(null);
                }
            }
        }
        else {
            this.buffer = null;
        }
    }
    
    protected void paintBackground(final Graphics graphics) {
        if (this.graphComponent != null) {
            graphics.setColor(this.getBackground());
            mxUtils.fillClippedRect(graphics, 0, 0, this.getWidth(), this.getHeight());
            graphics.setColor(this.graphComponent.getBackground());
            final Dimension viewSize = this.graphComponent.getViewport().getViewSize();
            mxUtils.fillClippedRect(graphics, 0, 0, (int)(viewSize.width * this.scale), (int)(viewSize.height * this.scale));
        }
    }
    
    public void paintComponent(final Graphics graphics) {
        super.paintComponent(graphics);
        final int n = (int)Math.round(this.translate.x * this.scale);
        final int n2 = (int)Math.round(this.translate.y * this.scale);
        graphics.translate(-n, -n2);
        if (this.isVisible()) {
            if (this.isOpaque()) {
                if (this.graphComponent == null || !this.graphComponent.isPageVisible()) {
                    this.paintBackground(graphics);
                }
                if (this.graphComponent != null) {
                    final Rectangle clipBounds = graphics.getClipBounds();
                    final Rectangle paintBackgroundPage = this.graphComponent.paintBackgroundPage(graphics, this.scale);
                    if (this.graphComponent.isPageVisible()) {
                        graphics.clipRect(paintBackgroundPage.x + 1, paintBackgroundPage.y + 1, paintBackgroundPage.width - 1, paintBackgroundPage.height - 1);
                    }
                    this.graphComponent.paintBackgroundImage(graphics, this.scale);
                    graphics.setClip(clipBounds);
                }
            }
            this.createBuffer();
            if (this.buffer != null && this.buffer.getImage() instanceof BufferedImage) {
                graphics.translate(n, n2);
                mxUtils.drawImageClip(graphics, (BufferedImage)this.buffer.getImage(), this);
                graphics.translate(-n, -n2);
            }
            else if (this.buffer != null) {
                this.buffer.paintIcon(this, graphics, -this.translate.x, -this.translate.y);
            }
        }
        graphics.translate(n, n2);
    }
    
    static {
        mxGraphOutline.DEFAULT_FINDER_BORDER = BorderFactory.createLineBorder(Color.blue, 2);
        mxGraphOutline.DEFAULT_ZOOMHANDLE_BORDER = BorderFactory.createLineBorder(Color.black, 1);
        mxGraphOutline.DEFAULT_ZOOMHANDLE_FILL = new Color(0, 255, 255);
    }
    
    public class MouseTracker implements MouseListener, MouseMotionListener
    {
        protected Point start;
        
        public MouseTracker() {
            this.start = null;
        }
        
        public void mousePressed(MouseEvent convertMouseEvent) {
            if (mxGraphOutline.this.graphComponent != null) {
                if (convertMouseEvent.getSource() == mxGraphOutline.this.zoomHandle) {
                    convertMouseEvent = SwingUtilities.convertMouseEvent(convertMouseEvent.getComponent(), convertMouseEvent, mxGraphOutline.this);
                }
                this.start = convertMouseEvent.getPoint();
            }
        }
        
        public void mouseDragged(MouseEvent convertMouseEvent) {
            if (mxGraphOutline.this.isEnabled() && this.start != null) {
                if (convertMouseEvent.getSource() == mxGraphOutline.this.zoomHandle) {
                    convertMouseEvent = SwingUtilities.convertMouseEvent(convertMouseEvent.getComponent(), convertMouseEvent, mxGraphOutline.this);
                    final Rectangle viewRect = mxGraphOutline.this.graphComponent.getViewport().getViewRect();
                    final double n = viewRect.getWidth() / viewRect.getHeight();
                    final Rectangle bounds = mxGraphOutline.this.finder.getBounds();
                    bounds.width = (int)Math.max(0.0, convertMouseEvent.getX() - bounds.getX());
                    bounds.height = (int)Math.max(0.0, bounds.getWidth() / n);
                    mxGraphOutline.this.updateFinder(bounds);
                }
                else {
                    final int n2 = (int)((convertMouseEvent.getX() - this.start.getX()) / mxGraphOutline.this.scale);
                    final int n3 = (int)((convertMouseEvent.getY() - this.start.getY()) / mxGraphOutline.this.scale);
                    mxGraphOutline.this.graphComponent.getHorizontalScrollBar().setValue(mxGraphOutline.this.graphComponent.getHorizontalScrollBar().getValue() + n2);
                    mxGraphOutline.this.graphComponent.getVerticalScrollBar().setValue(mxGraphOutline.this.graphComponent.getVerticalScrollBar().getValue() + n3);
                }
            }
            else {
                mxGraphOutline.this.dispatchEvent(SwingUtilities.convertMouseEvent(convertMouseEvent.getComponent(), convertMouseEvent, mxGraphOutline.this));
            }
        }
        
        public void mouseMoved(final MouseEvent mouseEvent) {
        }
        
        public void mouseClicked(final MouseEvent mouseEvent) {
        }
        
        public void mouseEntered(final MouseEvent mouseEvent) {
        }
        
        public void mouseExited(final MouseEvent mouseEvent) {
        }
        
        public void mouseReleased(MouseEvent convertMouseEvent) {
            if (this.start != null && convertMouseEvent.getSource() == mxGraphOutline.this.zoomHandle) {
                convertMouseEvent = SwingUtilities.convertMouseEvent(convertMouseEvent.getComponent(), convertMouseEvent, mxGraphOutline.this);
                final double n = convertMouseEvent.getX() - this.start.getX();
                final double n2 = mxGraphOutline.this.finder.getWidth();
                final JScrollBar horizontalScrollBar = mxGraphOutline.this.graphComponent.getHorizontalScrollBar();
                double n3;
                if (horizontalScrollBar != null) {
                    n3 = horizontalScrollBar.getValue() / (double)horizontalScrollBar.getMaximum();
                }
                else {
                    n3 = 0.0;
                }
                final JScrollBar verticalScrollBar = mxGraphOutline.this.graphComponent.getVerticalScrollBar();
                double n4;
                if (verticalScrollBar != null) {
                    n4 = verticalScrollBar.getValue() / (double)verticalScrollBar.getMaximum();
                }
                else {
                    n4 = 0.0;
                }
                final mxGraphView view = mxGraphOutline.this.graphComponent.getGraph().getView();
                final double scale = view.getScale();
                final double scale2 = scale - n * scale / n2;
                final double n5 = scale2 / scale;
                view.setScale(scale2);
                if (horizontalScrollBar != null) {
                    horizontalScrollBar.setValue((int)(n3 * horizontalScrollBar.getMaximum() * n5));
                }
                if (verticalScrollBar != null) {
                    verticalScrollBar.setValue((int)(n4 * verticalScrollBar.getMaximum() * n5));
                }
            }
            else {
                mxGraphOutline.this.dispatchEvent(SwingUtilities.convertMouseEvent(convertMouseEvent.getComponent(), convertMouseEvent, mxGraphOutline.this));
            }
            this.start = null;
        }
    }
}
