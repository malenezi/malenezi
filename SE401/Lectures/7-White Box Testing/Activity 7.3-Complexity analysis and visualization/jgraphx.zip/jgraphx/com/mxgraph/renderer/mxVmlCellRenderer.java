// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.renderer;

import com.mxgraph.util.mxRectangle;
import com.mxgraph.view.mxGraph;
import org.w3c.dom.Document;
import com.mxgraph.canvas.mxVmlCanvas;
import com.mxgraph.canvas.mxICanvas;
import java.awt.Color;

public class mxVmlCellRenderer extends mxAbstractCellRenderer
{
    @Override
    protected mxICanvas createCanvas(final int n, final int n2, final int n3, final int n4, final double n5, final Color color) {
        return new mxVmlCanvas(n, n2, n3, n4, n5, color);
    }
    
    public Document getDocument(final mxICanvas mxICanvas) {
        if (mxICanvas instanceof mxVmlCanvas) {
            return ((mxVmlCanvas)mxICanvas).getDocument();
        }
        return null;
    }
    
    public static Document render(final mxGraph mxGraph, final double n, final Color color, final Object[] array) {
        if (array != null) {
            final mxVmlCellRenderer mxVmlCellRenderer = new mxVmlCellRenderer();
            return mxVmlCellRenderer.getDocument(mxVmlCellRenderer.drawCells(mxGraph, array, n, color, null));
        }
        return null;
    }
    
    public static Document render(final mxGraph mxGraph, final double n, final Color color) {
        return render(mxGraph, n, color, new Object[] { mxGraph.getModel().getRoot() });
    }
}
