// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.reader;

import org.xml.sax.XMLReader;
import org.xml.sax.ContentHandler;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import org.xml.sax.SAXException;
import javax.xml.parsers.ParserConfigurationException;
import java.io.InputStream;
import org.xml.sax.InputSource;
import java.io.FileInputStream;
import java.awt.image.BufferedImage;
import com.mxgraph.canvas.mxGraphics2DCanvas;
import com.mxgraph.util.mxUtils;
import com.mxgraph.canvas.mxICanvas;
import java.util.Hashtable;
import java.awt.Color;

public class mxGraphViewGraphics2DReader extends mxGraphViewReader
{
    protected Color background;
    protected int border;
    
    public mxGraphViewGraphics2DReader() {
        this(null);
    }
    
    public mxGraphViewGraphics2DReader(final Color color) {
        this(color, 0);
    }
    
    public mxGraphViewGraphics2DReader(final Color background, final int border) {
        this.border = 0;
        this.background = background;
        this.border = border;
    }
    
    @Override
    public mxICanvas createCanvas(final Hashtable hashtable) {
        return new mxGraphics2DCanvas(0, 0, (int)(Math.round(mxUtils.getDouble(hashtable, "x")) + Math.round(mxUtils.getDouble(hashtable, "width"))) + this.border + 1, (int)(Math.round(mxUtils.getDouble(hashtable, "y")) + Math.round(mxUtils.getDouble(hashtable, "height"))) + this.border + 1, this.scale, this.background);
    }
    
    public static BufferedImage convert(final String name) throws ParserConfigurationException, SAXException, IOException {
        return convert(new InputSource(new FileInputStream(name)));
    }
    
    public static BufferedImage convert(final InputSource inputSource) throws ParserConfigurationException, SAXException, IOException {
        BufferedImage image = null;
        final XMLReader xmlReader = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
        final mxGraphViewGraphics2DReader contentHandler = new mxGraphViewGraphics2DReader();
        xmlReader.setContentHandler(contentHandler);
        xmlReader.parse(inputSource);
        if (contentHandler.getCanvas() != null) {
            final mxGraphics2DCanvas mxGraphics2DCanvas = (mxGraphics2DCanvas)contentHandler.getCanvas();
            image = mxGraphics2DCanvas.getImage();
            mxGraphics2DCanvas.destroy();
        }
        return image;
    }
}
