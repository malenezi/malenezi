// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import java.awt.Component;
import javax.swing.BorderFactory;
import com.mxgraph.util.mxConstants;
import java.awt.Point;
import com.mxgraph.swing.mxGraphComponent;
import java.awt.Color;
import com.mxgraph.swing.util.mxMouseControl;

public class mxRubberband extends mxMouseControl
{
    protected Color borderColor;
    protected Color fillColor;
    protected mxGraphComponent graphComponent;
    protected transient Point start;
    
    public mxRubberband(final mxGraphComponent graphComponent) {
        this.borderColor = mxConstants.RUBBERBAND_BORDERCOLOR;
        this.fillColor = mxConstants.RUBBERBAND_FILLCOLOR;
        this.graphComponent = graphComponent;
        this.setBorder(BorderFactory.createLineBorder(this.borderColor));
        this.setVisible(false);
        graphComponent.getControl().add(this, 0);
        graphComponent.getControl().addMouseListener(this);
        graphComponent.getControl().addMouseMotionListener(this);
        graphComponent.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(final KeyEvent keyEvent) {
                if (keyEvent.getKeyCode() == 27 && graphComponent.isEscapeEnabled()) {
                    mxRubberband.this.reset();
                }
            }
        });
    }
    
    @Override
    public void mousePressed(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && !mouseEvent.isPopupTrigger()) {
            this.start = mouseEvent.getPoint();
            this.getParent().setComponentZOrder(this, 0);
            this.setBounds(new Rectangle(this.start));
            mouseEvent.consume();
        }
    }
    
    @Override
    public void mouseDragged(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.start != null) {
            final Rectangle bounds = new Rectangle(this.start);
            bounds.add(mouseEvent.getPoint());
            this.setBounds(bounds);
            if (!this.isVisible() && this.graphComponent.isSignificant(this.getWidth(), this.getHeight())) {
                this.setVisible(true);
                if (!this.graphComponent.isToggleEvent(mouseEvent)) {
                    this.graphComponent.getGraph().clearSelection();
                }
            }
            mouseEvent.consume();
        }
    }
    
    @Override
    public void mouseReleased(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.isVisible() && this.start != null) {
            this.reset();
            this.select(this.getBounds(), mouseEvent);
            mouseEvent.consume();
        }
    }
    
    public void reset() {
        this.setVisible(false);
        this.start = null;
    }
    
    public Object[] select(final Rectangle rectangle, final MouseEvent mouseEvent) {
        return this.graphComponent.selectRegion(rectangle, mouseEvent);
    }
    
    public void paintComponent(final Graphics g) {
        super.paintComponent(g);
        g.setColor(this.fillColor);
        g.fillRect(0, 0, this.getWidth() - 1, this.getHeight() - 1);
    }
}
