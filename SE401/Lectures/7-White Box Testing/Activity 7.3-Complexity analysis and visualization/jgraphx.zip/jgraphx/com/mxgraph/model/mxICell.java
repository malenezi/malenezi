// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.model;

public interface mxICell
{
    String getId();
    
    void setId(final String p0);
    
    Object getValue();
    
    void setValue(final Object p0);
    
    mxGeometry getGeometry();
    
    void setGeometry(final mxGeometry p0);
    
    String getStyle();
    
    void setStyle(final String p0);
    
    boolean isVertex();
    
    boolean isEdge();
    
    boolean isConnectable();
    
    boolean isVisible();
    
    void setVisible(final boolean p0);
    
    boolean isCollapsed();
    
    void setCollapsed(final boolean p0);
    
    mxICell getParent();
    
    void setParent(final mxICell p0);
    
    mxICell getTerminal(final boolean p0);
    
    mxICell setTerminal(final mxICell p0, final boolean p1);
    
    int getChildCount();
    
    int getIndex(final mxICell p0);
    
    mxICell getChildAt(final int p0);
    
    mxICell insert(final mxICell p0);
    
    mxICell insert(final mxICell p0, final int p1);
    
    mxICell remove(final int p0);
    
    mxICell remove(final mxICell p0);
    
    void removeFromParent();
    
    int getEdgeCount();
    
    int getEdgeIndex(final mxICell p0);
    
    mxICell getEdgeAt(final int p0);
    
    mxICell insertEdge(final mxICell p0, final boolean p1);
    
    mxICell removeEdge(final mxICell p0, final boolean p1);
    
    void removeFromTerminal(final boolean p0);
    
    Object clone();
}
