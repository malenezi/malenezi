// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.model;

import java.util.ArrayList;
import java.util.List;
import com.mxgraph.util.mxPoint;
import com.mxgraph.util.mxRectangle;

public class mxGeometry extends mxRectangle
{
    protected mxRectangle alternateBounds;
    protected mxPoint sourcePoint;
    protected mxPoint targetPoint;
    protected List points;
    protected mxPoint offset;
    protected boolean relative;
    
    public mxGeometry() {
        this(0.0, 0.0, 0.0, 0.0);
    }
    
    public mxGeometry(final double n, final double n2, final double n3, final double n4) {
        super(n, n2, n3, n4);
        this.relative = false;
    }
    
    public mxGeometry(final mxGeometry mxGeometry) {
        this(mxGeometry.getX(), mxGeometry.getY(), mxGeometry.getWidth(), mxGeometry.getHeight());
        if (mxGeometry.points != null) {
            this.points = new ArrayList();
            for (int i = 0; i < mxGeometry.points.size(); ++i) {
                this.points.add(((mxPoint)mxGeometry.points.get(i)).clone());
            }
        }
        if (mxGeometry.targetPoint != null) {
            this.targetPoint = (mxPoint)mxGeometry.targetPoint.clone();
        }
        if (mxGeometry.sourcePoint != null) {
            this.sourcePoint = (mxPoint)mxGeometry.sourcePoint.clone();
        }
        if (mxGeometry.offset != null) {
            this.offset = (mxPoint)mxGeometry.offset.clone();
        }
        if (mxGeometry.alternateBounds != null) {
            this.alternateBounds = (mxRectangle)mxGeometry.alternateBounds.clone();
        }
        this.relative = mxGeometry.relative;
    }
    
    public mxRectangle getAlternateBounds() {
        return this.alternateBounds;
    }
    
    public void setAlternateBounds(final mxRectangle alternateBounds) {
        this.alternateBounds = alternateBounds;
    }
    
    public List getPoints() {
        return this.points;
    }
    
    public void setPoints(final List points) {
        this.points = points;
    }
    
    public mxPoint getOffset() {
        return this.offset;
    }
    
    public void setOffset(final mxPoint offset) {
        this.offset = offset;
    }
    
    public boolean isRelative() {
        return this.relative;
    }
    
    public void setRelative(final boolean relative) {
        this.relative = relative;
    }
    
    public void swap() {
        if (this.alternateBounds != null) {
            final mxRectangle alternateBounds = new mxRectangle(this);
            this.x = this.alternateBounds.getX();
            this.y = this.alternateBounds.getY();
            this.width = this.alternateBounds.getWidth();
            this.height = this.alternateBounds.getHeight();
            this.alternateBounds = alternateBounds;
        }
    }
    
    public mxPoint getTerminalPoint(final boolean b) {
        return b ? this.sourcePoint : this.targetPoint;
    }
    
    public mxPoint setTerminalPoint(final mxPoint mxPoint, final boolean b) {
        if (b) {
            this.sourcePoint = mxPoint;
        }
        else {
            this.targetPoint = mxPoint;
        }
        return mxPoint;
    }
    
    public mxGeometry translate(final double n, final double n2) {
        final mxGeometry mxGeometry = (mxGeometry)this.clone();
        if (!mxGeometry.isRelative()) {
            final mxGeometry mxGeometry2 = mxGeometry;
            mxGeometry2.x += n;
            final mxGeometry mxGeometry3 = mxGeometry;
            mxGeometry3.y += n2;
        }
        if (mxGeometry.sourcePoint != null) {
            mxGeometry.sourcePoint.setX(mxGeometry.sourcePoint.getX() + n);
            mxGeometry.sourcePoint.setY(mxGeometry.sourcePoint.getY() + n2);
        }
        if (mxGeometry.targetPoint != null) {
            mxGeometry.targetPoint.setX(mxGeometry.targetPoint.getX() + n);
            mxGeometry.targetPoint.setY(mxGeometry.targetPoint.getY() + n2);
        }
        if (mxGeometry.points != null) {
            for (int size = mxGeometry.points.size(), i = 0; i < size; ++i) {
                final mxPoint mxPoint = mxGeometry.points.get(i);
                mxPoint.setX(mxPoint.getX() + n);
                mxPoint.setY(mxPoint.getY() + n2);
            }
        }
        return mxGeometry;
    }
    
    @Override
    public Object clone() {
        return new mxGeometry(this);
    }
}
