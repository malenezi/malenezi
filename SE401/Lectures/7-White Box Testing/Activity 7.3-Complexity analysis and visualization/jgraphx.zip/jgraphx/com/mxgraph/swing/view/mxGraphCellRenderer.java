// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.view;

import com.mxgraph.util.mxRectangle;
import com.mxgraph.view.mxGraph;
import java.awt.image.BufferedImage;
import com.mxgraph.canvas.mxGraphics2DCanvas;
import com.mxgraph.canvas.mxICanvas;
import java.awt.Color;
import com.mxgraph.renderer.mxAbstractCellRenderer;

public class mxGraphCellRenderer extends mxAbstractCellRenderer
{
    public static boolean ANTI_ALIAS;
    public static boolean TEXT_ANTI_ALIAS;
    
    @Override
    protected mxICanvas createCanvas(final int n, final int n2, final int n3, final int n4, final double n5, final Color color) {
        final mxGraphics2DCanvas mxGraphics2DCanvas = new mxGraphics2DCanvas(n, n2, n3, n4, n5, color);
        if (mxGraphics2DCanvas.getGraphics() != null) {
            mxGraphics2DCanvas.setTextAntiAlias(mxGraphCellRenderer.TEXT_ANTI_ALIAS);
            mxGraphics2DCanvas.setAntiAlias(mxGraphCellRenderer.ANTI_ALIAS);
            return mxGraphics2DCanvas;
        }
        return null;
    }
    
    public BufferedImage getImage(final mxICanvas mxICanvas) {
        BufferedImage image = null;
        if (mxICanvas instanceof mxGraphics2DCanvas) {
            final mxGraphics2DCanvas mxGraphics2DCanvas = (mxGraphics2DCanvas)mxICanvas;
            image = mxGraphics2DCanvas.getImage();
            mxGraphics2DCanvas.destroy();
        }
        return image;
    }
    
    public static BufferedImage render(final mxGraph mxGraph, final double n, final Color color, final Object[] array) {
        if (array != null) {
            final mxGraphCellRenderer mxGraphCellRenderer = new mxGraphCellRenderer();
            return mxGraphCellRenderer.getImage(mxGraphCellRenderer.drawCells(mxGraph, array, n, color, null));
        }
        return null;
    }
    
    public static BufferedImage render(final mxGraph mxGraph, final double n, final Color color) {
        return render(mxGraph, n, color, new Object[] { mxGraph.getModel().getRoot() });
    }
    
    static {
        mxGraphCellRenderer.ANTI_ALIAS = true;
        mxGraphCellRenderer.TEXT_ANTI_ALIAS = true;
    }
}
