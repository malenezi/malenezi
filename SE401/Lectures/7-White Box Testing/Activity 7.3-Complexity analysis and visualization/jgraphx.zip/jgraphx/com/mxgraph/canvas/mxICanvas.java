// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.canvas;

import java.util.List;
import java.util.Hashtable;

public interface mxICanvas
{
    Object drawVertex(final int p0, final int p1, final int p2, final int p3, final Hashtable p4);
    
    Object drawEdge(final List p0, final Hashtable p1);
    
    Object drawLabel(final String p0, final int p1, final int p2, final int p3, final int p4, final Hashtable p5, final boolean p6);
}
