// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.io;

import java.util.Iterator;
import org.w3c.dom.Element;
import java.util.Hashtable;
import org.w3c.dom.Node;
import java.util.Map;
import com.mxgraph.view.mxStylesheet;

public class mxStylesheetCodec extends mxObjectCodec
{
    public mxStylesheetCodec() {
        this(new mxStylesheet());
    }
    
    public mxStylesheetCodec(final Object o) {
        this(o, null, null, null);
    }
    
    public mxStylesheetCodec(final Object o, final String[] array, final String[] array2, final Map map) {
        super(o, array, array2, map);
    }
    
    @Override
    public Node encode(final mxCodec mxCodec, final Object o) {
        final Element element = mxCodec.document.createElement(mxCodecRegistry.getName(o.getClass()));
        if (o instanceof mxStylesheet) {
            for (final Map.Entry<Object, V> entry : ((mxStylesheet)o).getStyles().entrySet()) {
                final Element element2 = mxCodec.document.createElement("add");
                element2.setAttribute("as", String.valueOf(entry.getKey()));
                for (final Map.Entry<Object, V> entry2 : ((Hashtable)entry.getValue()).entrySet()) {
                    final Element element3 = mxCodec.document.createElement("add");
                    element3.setAttribute("as", String.valueOf(entry2.getKey()));
                    element3.setAttribute("value", String.valueOf(entry2.getValue()));
                    element2.appendChild(element3);
                }
                if (element2.getChildNodes().getLength() > 0) {
                    element.appendChild(element2);
                }
            }
        }
        return element;
    }
    
    @Override
    public Object decode(final mxCodec mxCodec, Node node, final Object o) {
        Object o2 = null;
        if (node instanceof Element) {
            final String attribute = ((Element)node).getAttribute("id");
            o2 = mxCodec.objects.get(attribute);
            if (o2 == null) {
                o2 = o;
                if (o2 == null) {
                    o2 = this.cloneTemplate(node);
                }
                if (attribute != null && attribute.length() > 0) {
                    mxCodec.putObject(attribute, o2);
                }
            }
            String attribute2;
            String attribute3;
            Hashtable<? extends String, ? extends String> t;
            Hashtable<String, String> hashtable;
            Node node2;
            Element element;
            String attribute4;
            String textContent;
            for (node = node.getFirstChild(); node != null; node = node.getNextSibling()) {
                if (!this.processInclude(mxCodec, node, o2) && node.getNodeName().equals("add") && node instanceof Element) {
                    attribute2 = ((Element)node).getAttribute("as");
                    if (attribute2 != null && attribute2.length() > 0) {
                        attribute3 = ((Element)node).getAttribute("extend");
                        t = ((attribute3 != null) ? ((mxStylesheet)o2).getStyles().get(attribute3) : null);
                        if (t == null) {
                            hashtable = new Hashtable<String, String>();
                        }
                        else {
                            hashtable = new Hashtable<String, String>(t);
                        }
                        for (node2 = node.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
                            if (node2 instanceof Element) {
                                element = (Element)node2;
                                attribute4 = element.getAttribute("as");
                                if (node2.getNodeName().equals("add")) {
                                    textContent = node2.getTextContent();
                                    if (textContent != null && textContent.length() > 0) {
                                        hashtable.put(attribute4, textContent);
                                    }
                                    else {
                                        hashtable.put(attribute4, element.getAttribute("value"));
                                    }
                                }
                                else if (node2.getNodeName().equals("remove")) {
                                    hashtable.remove(attribute4);
                                }
                            }
                        }
                        ((mxStylesheet)o2).putCellStyle(attribute2, hashtable);
                    }
                }
            }
        }
        return o2;
    }
}
