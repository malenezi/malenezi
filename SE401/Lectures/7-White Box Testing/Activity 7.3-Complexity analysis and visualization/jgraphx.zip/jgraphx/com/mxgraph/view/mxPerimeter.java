// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.view;

import com.mxgraph.util.mxConstants;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxPoint;
import com.mxgraph.util.mxRectangle;

public class mxPerimeter
{
    public static mxPerimeterFunction RectanglePerimeter;
    public static mxPerimeterFunction EllipsePerimeter;
    public static mxPerimeterFunction RhombusPerimeter;
    public static mxPerimeterFunction TrianglePerimeter;
    
    static {
        mxPerimeter.RectanglePerimeter = new mxPerimeterFunction() {
            public mxPoint apply(final mxRectangle mxRectangle, final mxCellState mxCellState, final mxCellState mxCellState2, final boolean b, final mxPoint mxPoint) {
                final double n = mxRectangle.getX() + mxRectangle.getWidth() / 2.0;
                final double n2 = mxRectangle.getY() + mxRectangle.getHeight() / 2.0;
                final double atan2 = Math.atan2(mxPoint.getY() - n2, mxPoint.getX() - n);
                final mxPoint mxPoint2 = new mxPoint();
                final double n3 = 3.141592653589793;
                final double n4 = 1.5707963267948966 - atan2;
                final double atan3 = Math.atan2(mxRectangle.getHeight(), mxRectangle.getWidth());
                if (atan2 < -n3 + atan3 || atan2 > n3 - atan3) {
                    mxPoint2.setX(mxRectangle.getX());
                    mxPoint2.setY(n2 - mxRectangle.getWidth() * Math.tan(atan2) / 2.0);
                }
                else if (atan2 < -atan3) {
                    mxPoint2.setY(mxRectangle.getY());
                    mxPoint2.setX(n - mxRectangle.getHeight() * Math.tan(n4) / 2.0);
                }
                else if (atan2 < atan3) {
                    mxPoint2.setX(mxRectangle.getX() + mxRectangle.getWidth());
                    mxPoint2.setY(n2 + mxRectangle.getWidth() * Math.tan(atan2) / 2.0);
                }
                else {
                    mxPoint2.setY(mxRectangle.getY() + mxRectangle.getHeight());
                    mxPoint2.setX(n + mxRectangle.getHeight() * Math.tan(n4) / 2.0);
                }
                if (mxCellState != null && mxCellState.view.graph.isOrthogonal(mxCellState, mxCellState2)) {
                    if (mxPoint.getX() >= mxRectangle.getX() && mxPoint.getX() <= mxRectangle.getX() + mxRectangle.getWidth()) {
                        mxPoint2.setX(mxPoint.getX());
                    }
                    else if (mxPoint.getY() >= mxRectangle.getY() && mxPoint.getY() <= mxRectangle.getY() + mxRectangle.getHeight()) {
                        mxPoint2.setY(mxPoint.getY());
                    }
                    if (mxPoint.getX() < mxRectangle.getX()) {
                        mxPoint2.setX(mxRectangle.getX());
                    }
                    else if (mxPoint.getX() > mxRectangle.getX() + mxRectangle.getWidth()) {
                        mxPoint2.setX(mxRectangle.getX() + mxRectangle.getWidth());
                    }
                    if (mxPoint.getY() < mxRectangle.getY()) {
                        mxPoint2.setY(mxRectangle.getY());
                    }
                    else if (mxPoint.getY() > mxRectangle.getY() + mxRectangle.getHeight()) {
                        mxPoint2.setY(mxRectangle.getY() + mxRectangle.getHeight());
                    }
                }
                return mxPoint2;
            }
        };
        mxPerimeter.EllipsePerimeter = new mxPerimeterFunction() {
            public mxPoint apply(final mxRectangle mxRectangle, final mxCellState mxCellState, final mxCellState mxCellState2, final boolean b, final mxPoint mxPoint) {
                final double x = mxRectangle.getX();
                final double y = mxRectangle.getY();
                final double n = mxRectangle.getWidth() / 2.0;
                final double n2 = mxRectangle.getHeight() / 2.0;
                final double n3 = x + n;
                final double n4 = y + n2;
                final double x2 = mxPoint.getX();
                final double y2 = mxPoint.getY();
                final double n5 = x2 - n3;
                final double a = y2 - n4;
                if (n5 == 0.0) {
                    return new mxPoint(n3, n4 + n2 * a / Math.abs(a));
                }
                if (mxCellState != null && mxCellState.view.graph.isOrthogonal(mxCellState, mxCellState2)) {
                    if (y2 >= y && y2 <= y + mxRectangle.getHeight()) {
                        final double n6 = y2 - n4;
                        double sqrt = Math.sqrt(n * n * (1.0 - n6 * n6 / (n2 * n2)));
                        if (Double.isNaN(sqrt)) {
                            sqrt = 0.0;
                        }
                        if (x2 <= x) {
                            sqrt = -sqrt;
                        }
                        return new mxPoint(n3 + sqrt, y2);
                    }
                    if (x2 >= x && x2 <= x + mxRectangle.getWidth()) {
                        final double n7 = x2 - n3;
                        double sqrt2 = Math.sqrt(n2 * n2 * (1.0 - n7 * n7 / (n * n)));
                        if (Double.isNaN(sqrt2)) {
                            sqrt2 = 0.0;
                        }
                        if (y2 <= y) {
                            sqrt2 = -sqrt2;
                        }
                        return new mxPoint(x2, n4 + sqrt2);
                    }
                }
                final double n8 = a / n5;
                final double n9 = n4 - n8 * n3;
                final double n10 = n * n * n8 * n8 + n2 * n2;
                final double n11 = -2.0 * n3 * n10;
                final double sqrt3 = Math.sqrt(n11 * n11 - 4.0 * n10 * (n * n * n8 * n8 * n3 * n3 + n2 * n2 * n3 * n3 - n * n * n2 * n2));
                final double n12 = (-n11 + sqrt3) / (2.0 * n10);
                final double n13 = (-n11 - sqrt3) / (2.0 * n10);
                final double n14 = n8 * n12 + n9;
                final double n15 = n8 * n13 + n9;
                double n16;
                double n17;
                if (Math.sqrt(Math.pow(n12 - x2, 2.0) + Math.pow(n14 - y2, 2.0)) < Math.sqrt(Math.pow(n13 - x2, 2.0) + Math.pow(n15 - y2, 2.0))) {
                    n16 = n12;
                    n17 = n14;
                }
                else {
                    n16 = n13;
                    n17 = n15;
                }
                return new mxPoint(n16, n17);
            }
        };
        mxPerimeter.RhombusPerimeter = new mxPerimeterFunction() {
            public mxPoint apply(final mxRectangle mxRectangle, final mxCellState mxCellState, final mxCellState mxCellState2, final boolean b, final mxPoint mxPoint) {
                final double x = mxRectangle.getX();
                final double y = mxRectangle.getY();
                final double width = mxRectangle.getWidth();
                final double height = mxRectangle.getHeight();
                final double n = x + width / 2.0;
                final double n2 = y + height / 2.0;
                final double x2 = mxPoint.getX();
                final double y2 = mxPoint.getY();
                if (n == x2) {
                    if (n2 > y2) {
                        return new mxPoint(n, y);
                    }
                    return new mxPoint(n, y + height);
                }
                else if (n2 == y2) {
                    if (n > x2) {
                        return new mxPoint(x, n2);
                    }
                    return new mxPoint(x + width, n2);
                }
                else {
                    double n3 = n;
                    double n4 = n2;
                    if (mxCellState != null && mxCellState.view.graph.isOrthogonal(mxCellState, mxCellState2)) {
                        if (x2 >= x && x2 <= x + width) {
                            n3 = x2;
                        }
                        else if (y2 >= y && y2 <= y + height) {
                            n4 = y2;
                        }
                    }
                    if (x2 < n) {
                        if (y2 < n2) {
                            return mxUtils.intersection(x2, y2, n3, n4, n, y, x, n2);
                        }
                        return mxUtils.intersection(x2, y2, n3, n4, n, y + height, x, n2);
                    }
                    else {
                        if (y2 < n2) {
                            return mxUtils.intersection(x2, y2, n3, n4, n, y, x + width, n2);
                        }
                        return mxUtils.intersection(x2, y2, n3, n4, n, y + height, x + width, n2);
                    }
                }
            }
        };
        mxPerimeter.TrianglePerimeter = new mxPerimeterFunction() {
            public mxPoint apply(final mxRectangle mxRectangle, final mxCellState mxCellState, final mxCellState mxCellState2, final boolean b, final mxPoint mxPoint) {
                final boolean b2 = mxCellState != null && mxCellState.view.graph.isOrthogonal(mxCellState, mxCellState2);
                final String s = (mxCellState2 != null) ? mxUtils.getString(mxCellState2.style, mxConstants.STYLE_DIRECTION, "east") : "east";
                final boolean b3 = s.equals("north") || s.equals("south");
                final double x = mxRectangle.getX();
                final double y = mxRectangle.getY();
                final double width = mxRectangle.getWidth();
                final double height = mxRectangle.getHeight();
                double x2 = x + width / 2.0;
                double y2 = y + height / 2.0;
                mxPoint mxPoint2 = new mxPoint(x, y);
                mxPoint mxPoint3 = new mxPoint(x + width, y2);
                mxPoint mxPoint4 = new mxPoint(x, y + height);
                if (s.equals("north")) {
                    mxPoint2 = mxPoint4;
                    mxPoint3 = new mxPoint(x2, y);
                    mxPoint4 = new mxPoint(x + width, y + height);
                }
                else if (s.equals("south")) {
                    mxPoint3 = new mxPoint(x2, y + height);
                    mxPoint4 = new mxPoint(x + width, y);
                }
                else if (s.equals("west")) {
                    mxPoint2 = new mxPoint(x + width, y);
                    mxPoint3 = new mxPoint(x, y2);
                    mxPoint4 = new mxPoint(x + width, y + height);
                }
                final double n = mxPoint.getX() - x2;
                final double n2 = mxPoint.getY() - y2;
                final double n3 = b3 ? Math.atan2(n, n2) : Math.atan2(n2, n);
                final double n4 = b3 ? Math.atan2(width, height) : Math.atan2(height, width);
                boolean b4;
                if (s.equals("north") || s.equals("west")) {
                    b4 = (n3 > -n4 && n3 < n4);
                }
                else {
                    b4 = (n3 < -3.141592653589793 + n4 || n3 > 3.141592653589793 - n4);
                }
                mxPoint mxPoint5 = null;
                if (b4) {
                    if (b2 && ((b3 && mxPoint.getX() >= mxPoint2.getX() && mxPoint.getX() <= mxPoint4.getX()) || (!b3 && mxPoint.getY() >= mxPoint2.getY() && mxPoint.getY() <= mxPoint4.getY()))) {
                        if (b3) {
                            mxPoint5 = new mxPoint(mxPoint.getX(), mxPoint2.getY());
                        }
                        else {
                            mxPoint5 = new mxPoint(mxPoint2.getX(), mxPoint.getY());
                        }
                    }
                    else if (s.equals("east")) {
                        mxPoint5 = new mxPoint(x, y + height / 2.0 - width * Math.tan(n3) / 2.0);
                    }
                    else if (s.equals("north")) {
                        mxPoint5 = new mxPoint(x + width / 2.0 + height * Math.tan(n3) / 2.0, y + height);
                    }
                    else if (s.equals("south")) {
                        mxPoint5 = new mxPoint(x + width / 2.0 - height * Math.tan(n3) / 2.0, y);
                    }
                    else if (s.equals("west")) {
                        mxPoint5 = new mxPoint(x + width, y + height / 2.0 + width * Math.tan(n3) / 2.0);
                    }
                }
                else {
                    if (b2) {
                        final mxPoint mxPoint6 = new mxPoint(x2, y2);
                        if (mxPoint.getY() >= y && mxPoint.getY() <= y + height) {
                            mxPoint6.setX(b3 ? x2 : (s.equals("west") ? (x + width) : x));
                            mxPoint6.setY(mxPoint.getY());
                        }
                        else if (mxPoint.getX() >= x && mxPoint.getX() <= x + width) {
                            mxPoint6.setX(mxPoint.getX());
                            mxPoint6.setY(b3 ? (s.equals("north") ? (y + height) : y) : y2);
                        }
                        final double n5 = mxPoint.getX() - mxPoint6.getX();
                        final double n6 = mxPoint.getY() - mxPoint6.getY();
                        x2 = mxPoint6.getX();
                        y2 = mxPoint6.getY();
                    }
                    if ((b3 && mxPoint.getX() <= x + width / 2.0) || (!b3 && mxPoint.getY() <= y + height / 2.0)) {
                        mxPoint5 = mxUtils.intersection(mxPoint.getX(), mxPoint.getY(), x2, y2, mxPoint2.getX(), mxPoint2.getY(), mxPoint3.getX(), mxPoint3.getY());
                    }
                    else {
                        mxPoint5 = mxUtils.intersection(mxPoint.getX(), mxPoint.getY(), x2, y2, mxPoint3.getX(), mxPoint3.getY(), mxPoint4.getX(), mxPoint4.getY());
                    }
                }
                if (mxPoint5 == null) {
                    mxPoint5 = new mxPoint(x2, y2);
                }
                return mxPoint5;
            }
        };
    }
    
    public interface mxPerimeterFunction
    {
        mxPoint apply(final mxRectangle p0, final mxCellState p1, final mxCellState p2, final boolean p3, final mxPoint p4);
    }
}
