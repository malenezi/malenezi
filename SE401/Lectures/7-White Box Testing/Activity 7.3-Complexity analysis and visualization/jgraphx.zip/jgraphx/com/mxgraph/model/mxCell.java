// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.model;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class mxCell implements mxICell, Cloneable, Serializable
{
    protected String id;
    protected Object value;
    protected mxGeometry geometry;
    protected String style;
    protected boolean vertex;
    protected boolean edge;
    protected boolean connectable;
    protected boolean visible;
    protected boolean collapsed;
    protected mxICell parent;
    protected mxICell source;
    protected mxICell target;
    protected transient List children;
    protected transient List edges;
    
    public mxCell() {
        this(null);
    }
    
    public mxCell(final Object o) {
        this(o, null, null);
    }
    
    public mxCell(final Object value, final mxGeometry geometry, final String style) {
        this.vertex = false;
        this.edge = false;
        this.connectable = true;
        this.visible = true;
        this.collapsed = false;
        this.setValue(value);
        this.setGeometry(geometry);
        this.setStyle(style);
    }
    
    public String getId() {
        return this.id;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public Object getValue() {
        return this.value;
    }
    
    public void setValue(final Object value) {
        this.value = value;
    }
    
    public mxGeometry getGeometry() {
        return this.geometry;
    }
    
    public void setGeometry(final mxGeometry geometry) {
        this.geometry = geometry;
    }
    
    public String getStyle() {
        return this.style;
    }
    
    public void setStyle(final String style) {
        this.style = style;
    }
    
    public boolean isVertex() {
        return this.vertex;
    }
    
    public void setVertex(final boolean vertex) {
        this.vertex = vertex;
    }
    
    public boolean isEdge() {
        return this.edge;
    }
    
    public void setEdge(final boolean edge) {
        this.edge = edge;
    }
    
    public boolean isConnectable() {
        return this.connectable;
    }
    
    public void setConnectable(final boolean connectable) {
        this.connectable = connectable;
    }
    
    public boolean isVisible() {
        return this.visible;
    }
    
    public void setVisible(final boolean visible) {
        this.visible = visible;
    }
    
    public boolean isCollapsed() {
        return this.collapsed;
    }
    
    public void setCollapsed(final boolean collapsed) {
        this.collapsed = collapsed;
    }
    
    public mxICell getParent() {
        return this.parent;
    }
    
    public void setParent(final mxICell parent) {
        this.parent = parent;
    }
    
    public mxICell getSource() {
        return this.source;
    }
    
    public void setSource(final mxICell source) {
        this.source = source;
    }
    
    public mxICell getTarget() {
        return this.target;
    }
    
    public void setTarget(final mxICell target) {
        this.target = target;
    }
    
    public mxICell getTerminal(final boolean b) {
        return b ? this.source : this.target;
    }
    
    public mxICell setTerminal(final mxICell mxICell, final boolean b) {
        if (b) {
            this.source = mxICell;
        }
        else {
            this.target = mxICell;
        }
        return mxICell;
    }
    
    public int getChildCount() {
        return (this.children != null) ? this.children.size() : 0;
    }
    
    public int getIndex(final mxICell mxICell) {
        return (this.children != null) ? this.children.indexOf(mxICell) : -1;
    }
    
    public mxICell getChildAt(final int n) {
        return (this.children != null) ? this.children.get(n) : null;
    }
    
    public mxICell insert(final mxICell mxICell) {
        return this.insert(mxICell, this.getChildCount());
    }
    
    public mxICell insert(final mxICell mxICell, final int n) {
        if (mxICell != null) {
            mxICell.removeFromParent();
            mxICell.setParent(this);
            if (this.children == null) {
                (this.children = new ArrayList()).add(mxICell);
            }
            else {
                this.children.add(n, mxICell);
            }
        }
        return mxICell;
    }
    
    public mxICell remove(final int n) {
        mxICell child = null;
        if (this.children != null && n >= 0) {
            child = this.getChildAt(n);
            this.remove(child);
        }
        return child;
    }
    
    public mxICell remove(final mxICell mxICell) {
        if (mxICell != null && this.children != null) {
            this.children.remove(mxICell);
            mxICell.setParent(null);
        }
        return mxICell;
    }
    
    public void removeFromParent() {
        if (this.parent != null) {
            this.parent.remove(this);
        }
    }
    
    public int getEdgeCount() {
        return (this.edges != null) ? this.edges.size() : 0;
    }
    
    public int getEdgeIndex(final mxICell mxICell) {
        return (this.edges != null) ? this.edges.indexOf(mxICell) : -1;
    }
    
    public mxICell getEdgeAt(final int n) {
        return (this.edges != null) ? this.edges.get(n) : null;
    }
    
    public mxICell insertEdge(final mxICell mxICell, final boolean b) {
        if (mxICell != null) {
            mxICell.removeFromTerminal(b);
            mxICell.setTerminal(this, b);
            if (this.edges == null || mxICell.getTerminal(!b) != this || !this.edges.contains(mxICell)) {
                if (this.edges == null) {
                    this.edges = new ArrayList();
                }
                this.edges.add(mxICell);
            }
        }
        return mxICell;
    }
    
    public mxICell removeEdge(final mxICell mxICell, final boolean b) {
        if (mxICell != null && mxICell.getTerminal(!b) != this && this.edges != null) {
            this.edges.remove(mxICell);
            mxICell.setTerminal(null, b);
        }
        return mxICell;
    }
    
    public void removeFromTerminal(final boolean b) {
        final mxICell terminal = this.getTerminal(b);
        if (terminal != null) {
            terminal.removeEdge(this, b);
        }
    }
    
    public String getAttribute(final String s) {
        return this.getAttribute(s, null);
    }
    
    public String getAttribute(final String s, final String s2) {
        final Object value = this.getValue();
        String attribute = null;
        if (value instanceof Element) {
            attribute = ((Element)value).getAttribute(s);
        }
        if (attribute == null) {
            attribute = s2;
        }
        return attribute;
    }
    
    public void setAttribute(final String s, final String s2) {
        final Object value = this.getValue();
        if (value instanceof Element) {
            ((Element)value).setAttribute(s, s2);
        }
    }
    
    public Object clone() {
        final mxCell mxCell = new mxCell(this.cloneValue(), null, this.getStyle());
        mxCell.setCollapsed(this.isCollapsed());
        mxCell.setConnectable(this.isConnectable());
        mxCell.setEdge(this.isEdge());
        mxCell.setVertex(this.isVertex());
        mxCell.setVisible(this.isVisible());
        final mxGeometry geometry = this.getGeometry();
        if (geometry != null) {
            mxCell.setGeometry((mxGeometry)geometry.clone());
        }
        return mxCell;
    }
    
    protected Object cloneValue() {
        Object o = this.getValue();
        if (o instanceof Node) {
            o = ((Node)o).cloneNode(true);
        }
        return o;
    }
}
