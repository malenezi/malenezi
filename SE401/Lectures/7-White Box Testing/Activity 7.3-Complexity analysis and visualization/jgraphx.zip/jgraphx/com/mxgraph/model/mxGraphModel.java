// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.model;

import java.util.Collection;
import java.util.ArrayList;
import com.mxgraph.util.mxPoint;
import java.util.Map;
import com.mxgraph.util.mxUndoableEdit;
import java.util.Hashtable;
import com.mxgraph.util.mxEventSource;

public class mxGraphModel extends mxEventSource implements mxIGraphModel
{
    protected mxICell root;
    protected Hashtable cells;
    protected boolean maintainEdgeParent;
    protected boolean createIds;
    protected int nextId;
    protected transient mxUndoableEdit currentEdit;
    protected transient int updateLevel;
    
    public mxGraphModel() {
        this(null);
    }
    
    public mxGraphModel(Object root) {
        this.maintainEdgeParent = true;
        this.createIds = true;
        this.nextId = 0;
        this.updateLevel = 0;
        this.currentEdit = this.createUndoableEdit();
        if (root == null) {
            root = this.createRoot();
        }
        this.setRoot(root);
    }
    
    public Object createRoot() {
        final mxCell mxCell = new mxCell();
        mxCell.insert(new mxCell());
        return mxCell;
    }
    
    public Object getCell(final String key) {
        Object value = null;
        if (this.cells != null) {
            value = this.cells.get(key);
        }
        return value;
    }
    
    public boolean isMaintainEdgeParent() {
        return this.maintainEdgeParent;
    }
    
    public void setMaintainEdgeParent(final boolean maintainEdgeParent) {
        this.maintainEdgeParent = maintainEdgeParent;
    }
    
    public boolean isCreateIds() {
        return this.createIds;
    }
    
    public void setCreateIds(final boolean createIds) {
        this.createIds = createIds;
    }
    
    public Object getRoot() {
        return this.root;
    }
    
    public Object setRoot(final Object o) {
        this.execute(new mxRootChange(this, o));
        return o;
    }
    
    protected Object rootChanged(final Object o) {
        final mxICell root = this.root;
        this.root = (mxICell)o;
        this.nextId = 0;
        this.cells = null;
        this.cellAdded(o);
        return root;
    }
    
    protected mxUndoableEdit createUndoableEdit() {
        return new mxUndoableEdit(this) {
            @Override
            public void dispatch() {
                ((mxGraphModel)this.source).fireEvent("change", new Object[] { this.changes });
            }
        };
    }
    
    public Object[] cloneCells(final Object[] array, final boolean b) {
        final Hashtable hashtable = new Hashtable();
        final Object[] array2 = new Object[array.length];
        for (int i = 0; i < array.length; ++i) {
            array2[i] = this.cloneCell(array[i], hashtable, b);
        }
        for (int j = 0; j < array.length; ++j) {
            this.restoreClone(array2[j], array[j], hashtable);
        }
        return array2;
    }
    
    protected Object cloneCell(final Object o, final Map map, final boolean b) {
        if (o instanceof mxICell) {
            final mxICell mxICell = (mxICell)((mxICell)o).clone();
            map.put(o, mxICell);
            if (b) {
                for (int childCount = this.getChildCount(o), i = 0; i < childCount; ++i) {
                    mxICell.insert((mxICell)this.cloneCell(this.getChildAt(o, i), map, true));
                }
            }
            return mxICell;
        }
        return null;
    }
    
    protected void restoreClone(final Object o, final Object o2, final Map map) {
        if (o instanceof mxICell) {
            final mxICell mxICell = (mxICell)o;
            final Object terminal = this.getTerminal(o2, true);
            if (terminal instanceof mxICell) {
                final mxICell mxICell2 = map.get(terminal);
                if (mxICell2 != null) {
                    mxICell2.insertEdge(mxICell, true);
                }
            }
            final Object terminal2 = this.getTerminal(o2, false);
            if (terminal2 instanceof mxICell) {
                final mxICell mxICell3 = map.get(terminal2);
                if (mxICell3 != null) {
                    mxICell3.insertEdge(mxICell, false);
                }
            }
        }
        for (int childCount = this.getChildCount(o), i = 0; i < childCount; ++i) {
            this.restoreClone(this.getChildAt(o, i), this.getChildAt(o2, i), map);
        }
    }
    
    public boolean isAncestor(final Object o, Object parent) {
        while (parent != null && parent != o) {
            parent = this.getParent(parent);
        }
        return parent == o;
    }
    
    public boolean contains(final Object o) {
        return this.isAncestor(this.getRoot(), o);
    }
    
    public Object getParent(final Object o) {
        return (o instanceof mxICell) ? ((mxICell)o).getParent() : null;
    }
    
    public Object add(final Object o, final Object o2, final int n) {
        if (o != null && o2 != null) {
            final boolean b = o != this.getParent(o2);
            this.execute(new mxChildChange(this, (mxICell)o, (mxICell)o2, n));
            if (this.maintainEdgeParent && b) {
                this.updateEdgeParents(o2);
            }
        }
        return o2;
    }
    
    protected void cellAdded(final Object value) {
        if (value instanceof mxICell) {
            final mxICell mxICell = (mxICell)value;
            if (mxICell.getId() == null && this.isCreateIds()) {
                mxICell.setId(this.createId(value));
            }
            if (mxICell.getId() != null) {
                Object o = this.getCell(mxICell.getId());
                if (o != value) {
                    while (o != null) {
                        mxICell.setId(this.createId(value));
                        o = this.getCell(mxICell.getId());
                    }
                    if (this.cells == null) {
                        this.cells = new Hashtable();
                    }
                    this.cells.put(mxICell.getId(), value);
                }
            }
            try {
                this.nextId = Math.max(this.nextId, Integer.parseInt(mxICell.getId()) + 1);
            }
            catch (NumberFormatException ex) {}
            for (int childCount = mxICell.getChildCount(), i = 0; i < childCount; ++i) {
                this.cellAdded(mxICell.getChildAt(i));
            }
        }
    }
    
    public String createId(final Object o) {
        final String value = String.valueOf(this.nextId);
        ++this.nextId;
        return value;
    }
    
    public Object remove(final Object o) {
        if (o == this.root) {
            this.setRoot(null);
        }
        else if (this.getParent(o) != null) {
            this.execute(new mxChildChange(this, null, (mxICell)o));
        }
        return o;
    }
    
    protected void cellRemoved(final Object o) {
        if (o instanceof mxICell) {
            final mxICell mxICell = (mxICell)o;
            for (int childCount = mxICell.getChildCount(), i = 0; i < childCount; ++i) {
                this.cellRemoved(mxICell.getChildAt(i));
            }
            if (this.cells != null && mxICell.getId() != null) {
                this.cells.remove(mxICell.getId());
            }
        }
    }
    
    protected Object parentForCellChanged(final Object o, final Object o2, final int n) {
        final mxICell mxICell = (mxICell)o;
        final mxICell mxICell2 = (mxICell)this.getParent(o);
        if (o2 != null) {
            if (o2 != mxICell2 || mxICell2.getIndex(mxICell) != n) {
                ((mxICell)o2).insert(mxICell, n);
            }
        }
        else if (mxICell2 != null) {
            mxICell2.remove(mxICell2.getIndex(mxICell));
        }
        if (!this.contains(mxICell2) && o2 != null) {
            this.cellAdded(o);
        }
        else if (o2 == null) {
            this.cellRemoved(o);
        }
        return mxICell2;
    }
    
    public int getChildCount(final Object o) {
        return (o instanceof mxICell) ? ((mxICell)o).getChildCount() : 0;
    }
    
    public Object getChildAt(final Object o, final int n) {
        return (o instanceof mxICell) ? ((mxICell)o).getChildAt(n) : null;
    }
    
    public Object getTerminal(final Object o, final boolean b) {
        return (o instanceof mxICell) ? ((mxICell)o).getTerminal(b) : null;
    }
    
    public Object setTerminal(final Object o, final Object o2, final boolean b) {
        if (o2 != this.getTerminal(o, b)) {
            this.execute(new mxTerminalChange(this, o, o2, b));
            if (this.maintainEdgeParent) {
                this.updateEdgeParent(o);
            }
        }
        return o2;
    }
    
    protected Object terminalForCellChanged(final Object o, final Object o2, final boolean b) {
        final mxICell mxICell = (mxICell)this.getTerminal(o, b);
        if (o2 != null) {
            ((mxICell)o2).insertEdge((mxICell)o, b);
        }
        else if (mxICell != null) {
            mxICell.removeEdge((mxICell)o, b);
        }
        return mxICell;
    }
    
    public void updateEdgeParents(final Object o) {
        this.updateEdgeParents(o, this.getRoot());
    }
    
    public void updateEdgeParents(final Object o, final Object o2) {
        for (int childCount = this.getChildCount(o), i = 0; i < childCount; ++i) {
            this.updateEdgeParents(this.getChildAt(o, i), o2);
        }
        for (int edgeCount = this.getEdgeCount(o), j = 0; j < edgeCount; ++j) {
            final Object edge = this.getEdgeAt(o, j);
            if (this.isAncestor(o2, edge)) {
                this.updateEdgeParent(edge);
            }
        }
        if (this.isEdge(o)) {
            this.updateEdgeParent(o);
        }
    }
    
    public void updateEdgeParent(final Object o) {
        final Object terminal = this.getTerminal(o, true);
        final Object terminal2 = this.getTerminal(o, false);
        Object o2;
        if (terminal == terminal2) {
            o2 = this.getParent(terminal);
        }
        else {
            o2 = this.getNearestCommonAncestor(terminal, terminal2);
        }
        if (o2 != null && this.getParent(o2) != this.root && this.getParent(o) != o2) {
            final mxGeometry geometry = this.getGeometry(o);
            if (geometry != null) {
                final mxPoint origin = this.getOrigin(this.getParent(o));
                final mxPoint origin2 = this.getOrigin(o2);
                this.setGeometry(o, geometry.translate(-(origin2.getX() - origin.getX()), -(origin2.getY() - origin.getY())));
            }
            this.add(o2, o, this.getChildCount(o2));
        }
    }
    
    public mxPoint getOrigin(final Object o) {
        mxPoint origin;
        if (o != null) {
            origin = this.getOrigin(this.getParent(o));
            if (!this.isEdge(o)) {
                final mxGeometry geometry = this.getGeometry(o);
                if (geometry != null) {
                    origin.setX(origin.getX() + geometry.getX());
                    origin.setY(origin.getY() + geometry.getY());
                }
            }
        }
        else {
            origin = new mxPoint();
        }
        return origin;
    }
    
    public Object getNearestCommonAncestor(final Object o, final Object o2) {
        if (o != null && o2 != null) {
            final String create = mxCellPath.create((mxICell)o2);
            if (create != null && create.length() > 0) {
                Object o3 = o;
                String str = mxCellPath.create((mxICell)o3) + mxCellPath.PATH_SEPARATOR;
                while (o3 != null) {
                    final Object parent = this.getParent(o3);
                    if (create.indexOf(str) == 0 && parent != null) {
                        return o3;
                    }
                    str = mxCellPath.getParentPath(str) + mxCellPath.PATH_SEPARATOR;
                    o3 = parent;
                }
            }
        }
        return null;
    }
    
    public int getEdgeCount(final Object o) {
        return (o instanceof mxICell) ? ((mxICell)o).getEdgeCount() : 0;
    }
    
    public Object getEdgeAt(final Object o, final int n) {
        return (o instanceof mxICell) ? ((mxICell)o).getEdgeAt(n) : null;
    }
    
    public boolean isVertex(final Object o) {
        return o != null && ((mxICell)o).isVertex();
    }
    
    public boolean isEdge(final Object o) {
        return o != null && ((mxICell)o).isEdge();
    }
    
    public boolean isConnectable(final Object o) {
        return !(o instanceof mxICell) || ((mxICell)o).isConnectable();
    }
    
    public Object getValue(final Object o) {
        return (o instanceof mxICell) ? ((mxICell)o).getValue() : null;
    }
    
    public Object setValue(final Object o, final Object o2) {
        this.execute(new mxValueChange(this, o, o2));
        return o2;
    }
    
    protected Object valueForCellChanged(final Object o, final Object value) {
        final Object value2 = ((mxICell)o).getValue();
        ((mxICell)o).setValue(value);
        return value2;
    }
    
    public mxGeometry getGeometry(final Object o) {
        return (o instanceof mxICell) ? ((mxICell)o).getGeometry() : null;
    }
    
    public mxGeometry setGeometry(final Object o, final mxGeometry mxGeometry) {
        if (mxGeometry != this.getGeometry(o)) {
            this.execute(new mxGeometryChange(this, o, mxGeometry));
        }
        return mxGeometry;
    }
    
    protected mxGeometry geometryForCellChanged(final Object o, final mxGeometry geometry) {
        final mxGeometry geometry2 = this.getGeometry(o);
        ((mxICell)o).setGeometry(geometry);
        return geometry2;
    }
    
    public String getStyle(final Object o) {
        return (o instanceof mxICell) ? ((mxICell)o).getStyle() : null;
    }
    
    public String setStyle(final Object o, final String s) {
        if (s != this.getStyle(o)) {
            this.execute(new mxStyleChange(this, o, s));
        }
        return s;
    }
    
    protected String styleForCellChanged(final Object o, final String style) {
        final String style2 = this.getStyle(o);
        ((mxICell)o).setStyle(style);
        return style2;
    }
    
    public boolean isCollapsed(final Object o) {
        return o instanceof mxICell && ((mxICell)o).isCollapsed();
    }
    
    public boolean setCollapsed(final Object o, final boolean b) {
        if (b != this.isCollapsed(o)) {
            this.execute(new mxCollapseChange(this, o, b));
        }
        return b;
    }
    
    protected boolean collapsedStateForCellChanged(final Object o, final boolean collapsed) {
        final boolean collapsed2 = this.isCollapsed(o);
        ((mxICell)o).setCollapsed(collapsed);
        return collapsed2;
    }
    
    public boolean isVisible(final Object o) {
        return o instanceof mxICell && ((mxICell)o).isVisible();
    }
    
    public boolean setVisible(final Object o, final boolean b) {
        if (b != this.isVisible(o)) {
            this.execute(new mxVisibleChange(this, o, b));
        }
        return b;
    }
    
    protected boolean visibleStateForCellChanged(final Object o, final boolean visible) {
        final boolean visible2 = this.isVisible(o);
        ((mxICell)o).setVisible(visible);
        return visible2;
    }
    
    public void execute(final mxAtomicGraphModelChange mxAtomicGraphModelChange) {
        this.fireEvent("beforeExecute", new Object[] { mxAtomicGraphModelChange });
        mxAtomicGraphModelChange.execute();
        this.fireEvent("execute", new Object[] { mxAtomicGraphModelChange });
        this.beginUpdate();
        this.currentEdit.add(mxAtomicGraphModelChange);
        this.endUpdate();
        this.fireEvent("afterExecute", new Object[] { mxAtomicGraphModelChange });
    }
    
    public void beginUpdate() {
        ++this.updateLevel;
        this.fireEvent("beginUpdate");
    }
    
    public void endUpdate() {
        --this.updateLevel;
        this.fireEvent("endUpdate");
        if (this.updateLevel == 0 && !this.currentEdit.isEmpty()) {
            final mxUndoableEdit currentEdit = this.currentEdit;
            this.fireEvent("beforeUndo", new Object[] { currentEdit });
            this.currentEdit = this.createUndoableEdit();
            currentEdit.dispatch();
            this.fireEvent("undo", new Object[] { currentEdit });
        }
    }
    
    public static int getDirectedEdgeCount(final mxIGraphModel mxIGraphModel, final Object o, final boolean b) {
        return getDirectedEdgeCount(mxIGraphModel, o, b, null);
    }
    
    public static int getDirectedEdgeCount(final mxIGraphModel mxIGraphModel, final Object o, final boolean b, final Object o2) {
        int n = 0;
        for (int edgeCount = mxIGraphModel.getEdgeCount(o), i = 0; i < edgeCount; ++i) {
            final Object edge = mxIGraphModel.getEdgeAt(o, i);
            if (edge != o2 && mxIGraphModel.getTerminal(edge, b) == o) {
                ++n;
            }
        }
        return n;
    }
    
    public static Object[] getEdges(final mxIGraphModel mxIGraphModel, final Object o) {
        return getEdges(mxIGraphModel, o, true, true, true);
    }
    
    public static Object[] getConnections(final mxIGraphModel mxIGraphModel, final Object o) {
        return getEdges(mxIGraphModel, o, true, true, false);
    }
    
    public static Object[] getIncomingEdges(final mxIGraphModel mxIGraphModel, final Object o) {
        return getEdges(mxIGraphModel, o, true, false, false);
    }
    
    public static Object[] getOutgoingEdges(final mxIGraphModel mxIGraphModel, final Object o) {
        return getEdges(mxIGraphModel, o, false, true, false);
    }
    
    public static Object[] getEdges(final mxIGraphModel mxIGraphModel, final Object o, final boolean b, final boolean b2, final boolean b3) {
        final int edgeCount = mxIGraphModel.getEdgeCount(o);
        final ArrayList list = new ArrayList<Object>(edgeCount);
        for (int i = 0; i < edgeCount; ++i) {
            final Object edge = mxIGraphModel.getEdgeAt(o, i);
            final Object terminal = mxIGraphModel.getTerminal(edge, true);
            final Object terminal2 = mxIGraphModel.getTerminal(edge, false);
            if (b3 || (terminal != terminal2 && ((b && terminal2 == o) || (b2 && terminal == o)))) {
                list.add(edge);
            }
        }
        return list.toArray();
    }
    
    public static Object[] getEdgesBetween(final mxIGraphModel mxIGraphModel, final Object o, final Object o2) {
        return getEdgesBetween(mxIGraphModel, o, o2, false);
    }
    
    public static Object[] getEdgesBetween(final mxIGraphModel mxIGraphModel, final Object o, final Object o2, final boolean b) {
        final int edgeCount = mxIGraphModel.getEdgeCount(o);
        final int edgeCount2 = mxIGraphModel.getEdgeCount(o2);
        Object o3 = o;
        int initialCapacity = edgeCount;
        if (edgeCount2 < edgeCount) {
            initialCapacity = edgeCount2;
            o3 = o2;
        }
        final ArrayList list = new ArrayList<Object>(initialCapacity);
        for (int i = 0; i < initialCapacity; ++i) {
            final Object edge = mxIGraphModel.getEdgeAt(o3, i);
            final Object terminal = mxIGraphModel.getTerminal(edge, true);
            final Object terminal2 = mxIGraphModel.getTerminal(edge, false);
            final boolean b2 = terminal == o;
            if ((b2 && terminal2 == o2) || (!b && mxIGraphModel.getTerminal(edge, !b2) == o2)) {
                list.add(edge);
            }
        }
        return list.toArray();
    }
    
    public static Object[] getOpposites(final mxIGraphModel mxIGraphModel, final Object[] array, final Object o) {
        return getOpposites(mxIGraphModel, array, o, true, true);
    }
    
    public static Object[] getOpposites(final mxIGraphModel mxIGraphModel, final Object[] array, final Object o, final boolean b, final boolean b2) {
        final ArrayList<Object> list = new ArrayList<Object>();
        if (array != null) {
            for (int i = 0; i < array.length; ++i) {
                final Object terminal = mxIGraphModel.getTerminal(array[i], true);
                final Object terminal2 = mxIGraphModel.getTerminal(array[i], false);
                if (b2 && terminal == o && terminal2 != null && terminal2 != o) {
                    list.add(terminal2);
                }
                else if (b && terminal2 == o && terminal != null && terminal != o) {
                    list.add(terminal);
                }
            }
        }
        return list.toArray();
    }
    
    public static void setTerminals(final mxIGraphModel mxIGraphModel, final Object o, final Object o2, final Object o3) {
        mxIGraphModel.beginUpdate();
        try {
            mxIGraphModel.setTerminal(o, o2, true);
            mxIGraphModel.setTerminal(o, o3, false);
        }
        finally {
            mxIGraphModel.endUpdate();
        }
    }
    
    public static Object[] getChildren(final mxIGraphModel mxIGraphModel, final Object o) {
        return getChildCells(mxIGraphModel, o, false, false);
    }
    
    public static Object[] getChildVertices(final mxIGraphModel mxIGraphModel, final Object o) {
        return getChildCells(mxIGraphModel, o, true, false);
    }
    
    public static Object[] getChildEdges(final mxIGraphModel mxIGraphModel, final Object o) {
        return getChildCells(mxIGraphModel, o, false, true);
    }
    
    public static Object[] getChildCells(final mxIGraphModel mxIGraphModel, final Object o, final boolean b, final boolean b2) {
        final int childCount = mxIGraphModel.getChildCount(o);
        final ArrayList list = new ArrayList<Object>(childCount);
        for (int i = 0; i < childCount; ++i) {
            final Object child = mxIGraphModel.getChildAt(o, i);
            if ((!b2 && !b) || (b2 && mxIGraphModel.isEdge(child)) || (b && mxIGraphModel.isVertex(child))) {
                list.add(child);
            }
        }
        return list.toArray();
    }
    
    public static Collection filter(final mxIGraphModel mxIGraphModel, final Filter filter) {
        return filter(mxIGraphModel, mxIGraphModel.getRoot(), filter);
    }
    
    public static Collection filter(final mxIGraphModel mxIGraphModel, final Object o, final Filter filter) {
        final ArrayList<Object> list = new ArrayList<Object>();
        if (filter.filter(o)) {
            list.add(o);
        }
        for (int childCount = mxIGraphModel.getChildCount(o), i = 0; i < childCount; ++i) {
            list.addAll(filter(mxIGraphModel, mxIGraphModel.getChildAt(o, i), filter));
        }
        return list;
    }
    
    public static class mxVisibleChange extends mxAtomicGraphModelChange
    {
        protected Object cell;
        protected boolean visible;
        protected boolean previous;
        
        public mxVisibleChange(final mxGraphModel mxGraphModel, final Object cell, final boolean visible) {
            super(mxGraphModel);
            this.cell = cell;
            this.visible = visible;
            this.previous = this.visible;
        }
        
        public Object getCell() {
            return this.cell;
        }
        
        public boolean isVisible() {
            return this.visible;
        }
        
        public boolean getPrevious() {
            return this.visible;
        }
        
        @Override
        public void execute() {
            this.visible = this.previous;
            this.previous = ((mxGraphModel)this.model).visibleStateForCellChanged(this.cell, this.previous);
        }
    }
    
    public static class mxCollapseChange extends mxAtomicGraphModelChange
    {
        protected Object cell;
        protected boolean collapsed;
        protected boolean previous;
        
        public mxCollapseChange(final mxGraphModel mxGraphModel, final Object cell, final boolean collapsed) {
            super(mxGraphModel);
            this.cell = cell;
            this.collapsed = collapsed;
            this.previous = this.collapsed;
        }
        
        public Object getCell() {
            return this.cell;
        }
        
        public boolean isCollapsed() {
            return this.collapsed;
        }
        
        public boolean getPrevious() {
            return this.previous;
        }
        
        @Override
        public void execute() {
            this.collapsed = this.previous;
            this.previous = ((mxGraphModel)this.model).collapsedStateForCellChanged(this.cell, this.previous);
        }
    }
    
    public static class mxGeometryChange extends mxAtomicGraphModelChange
    {
        protected Object cell;
        protected mxGeometry geometry;
        protected mxGeometry previous;
        
        public mxGeometryChange(final mxGraphModel mxGraphModel, final Object cell, final mxGeometry geometry) {
            super(mxGraphModel);
            this.cell = cell;
            this.geometry = geometry;
            this.previous = this.geometry;
        }
        
        public Object getCell() {
            return this.cell;
        }
        
        public mxGeometry getGeometry() {
            return this.geometry;
        }
        
        public mxGeometry getPrevious() {
            return this.previous;
        }
        
        @Override
        public void execute() {
            this.geometry = this.previous;
            this.previous = ((mxGraphModel)this.model).geometryForCellChanged(this.cell, this.previous);
        }
    }
    
    public static class mxStyleChange extends mxAtomicGraphModelChange
    {
        protected Object cell;
        protected String style;
        protected String previous;
        
        public mxStyleChange(final mxGraphModel mxGraphModel, final Object cell, final String style) {
            super(mxGraphModel);
            this.cell = cell;
            this.style = style;
            this.previous = this.style;
        }
        
        public Object getCell() {
            return this.cell;
        }
        
        public String getStyle() {
            return this.style;
        }
        
        public String getPrevious() {
            return this.previous;
        }
        
        @Override
        public void execute() {
            this.style = this.previous;
            this.previous = ((mxGraphModel)this.model).styleForCellChanged(this.cell, this.previous);
        }
    }
    
    public static class mxValueChange extends mxAtomicGraphModelChange
    {
        protected Object cell;
        protected Object value;
        protected Object previous;
        
        public mxValueChange(final mxGraphModel mxGraphModel, final Object cell, final Object value) {
            super(mxGraphModel);
            this.cell = cell;
            this.value = value;
            this.previous = this.value;
        }
        
        public Object getCell() {
            return this.cell;
        }
        
        public Object getValue() {
            return this.value;
        }
        
        public Object getPrevious() {
            return this.previous;
        }
        
        @Override
        public void execute() {
            this.value = this.previous;
            this.previous = ((mxGraphModel)this.model).valueForCellChanged(this.cell, this.previous);
        }
    }
    
    public static class mxTerminalChange extends mxAtomicGraphModelChange
    {
        protected Object cell;
        protected Object terminal;
        protected Object previous;
        protected boolean isSource;
        
        public mxTerminalChange(final mxGraphModel mxGraphModel, final Object cell, final Object terminal, final boolean isSource) {
            super(mxGraphModel);
            this.cell = cell;
            this.terminal = terminal;
            this.previous = this.terminal;
            this.isSource = isSource;
        }
        
        public Object getCell() {
            return this.cell;
        }
        
        public Object getTerminal() {
            return this.terminal;
        }
        
        public Object getPrevious() {
            return this.previous;
        }
        
        public boolean isSource() {
            return this.isSource;
        }
        
        @Override
        public void execute() {
            this.terminal = this.previous;
            this.previous = ((mxGraphModel)this.model).terminalForCellChanged(this.cell, this.previous, this.isSource);
        }
    }
    
    public static class mxChildChange extends mxAtomicGraphModelChange
    {
        protected mxICell parent;
        protected mxICell previous;
        protected mxICell child;
        protected int index;
        protected int previousIndex;
        protected boolean isAdded;
        
        public mxChildChange(final mxGraphModel mxGraphModel, final mxICell mxICell, final mxICell mxICell2) {
            this(mxGraphModel, mxICell, mxICell2, 0);
        }
        
        public mxChildChange(final mxGraphModel mxGraphModel, final mxICell parent, final mxICell child, final int n) {
            super(mxGraphModel);
            this.parent = parent;
            this.previous = this.parent;
            this.child = child;
            this.index = n;
            this.previousIndex = n;
            this.isAdded = (parent == null);
        }
        
        public mxICell getParent() {
            return this.parent;
        }
        
        public mxICell getPrevious() {
            return this.previous;
        }
        
        public mxICell getChild() {
            return this.child;
        }
        
        public int getIndex() {
            return this.index;
        }
        
        public int getPreviousIndex() {
            return this.previousIndex;
        }
        
        public boolean isAdded() {
            return this.isAdded;
        }
        
        protected void connect(final mxICell mxICell, final boolean b) {
            final mxICell terminal = mxICell.getTerminal(true);
            final mxICell terminal2 = mxICell.getTerminal(false);
            if (terminal != null) {
                if (b) {
                    ((mxGraphModel)this.model).terminalForCellChanged(mxICell, terminal, true);
                }
                else {
                    ((mxGraphModel)this.model).terminalForCellChanged(mxICell, null, true);
                }
            }
            if (terminal2 != null) {
                if (b) {
                    ((mxGraphModel)this.model).terminalForCellChanged(mxICell, terminal2, false);
                }
                else {
                    ((mxGraphModel)this.model).terminalForCellChanged(mxICell, null, false);
                }
            }
            mxICell.setTerminal(terminal, true);
            mxICell.setTerminal(terminal2, false);
            for (int childCount = this.model.getChildCount(mxICell), i = 0; i < childCount; ++i) {
                this.connect((mxICell)this.model.getChildAt(mxICell, i), b);
            }
        }
        
        @Override
        public void execute() {
            final mxICell mxICell = (mxICell)this.model.getParent(this.child);
            final int previousIndex = (mxICell != null) ? mxICell.getIndex(this.child) : 0;
            if (this.previous == null) {
                this.connect(this.child, false);
            }
            final mxICell previous = (mxICell)((mxGraphModel)this.model).parentForCellChanged(this.child, this.previous, this.previousIndex);
            if (this.previous != null) {
                this.connect(this.child, true);
            }
            this.parent = this.previous;
            this.previous = previous;
            this.index = this.previousIndex;
            this.previousIndex = previousIndex;
            this.isAdded = !this.isAdded;
        }
    }
    
    public static class mxRootChange extends mxAtomicGraphModelChange
    {
        protected Object root;
        protected Object previous;
        
        public mxRootChange(final mxGraphModel mxGraphModel, final Object o) {
            super(mxGraphModel);
            this.root = o;
            this.previous = o;
        }
        
        public Object getRoot() {
            return this.root;
        }
        
        public Object getPrevious() {
            return this.previous;
        }
        
        @Override
        public void execute() {
            this.root = this.previous;
            this.previous = ((mxGraphModel)this.model).rootChanged(this.previous);
        }
    }
    
    public interface Filter
    {
        boolean filter(final Object p0);
    }
}
