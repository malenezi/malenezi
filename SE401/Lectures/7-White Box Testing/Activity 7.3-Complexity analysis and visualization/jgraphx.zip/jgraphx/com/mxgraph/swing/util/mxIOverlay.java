// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.util;

import com.mxgraph.util.mxRectangle;
import com.mxgraph.view.mxCellState;

public interface mxIOverlay
{
    mxRectangle getBounds(final mxCellState p0);
}
