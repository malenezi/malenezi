// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.io;

import com.mxgraph.util.mxUtils;
import org.w3c.dom.NamedNodeMap;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import org.w3c.dom.Element;
import java.util.Collection;
import org.w3c.dom.Node;
import java.util.Iterator;
import java.util.Hashtable;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class mxObjectCodec
{
    private static Set EMPTY_SET;
    Object template;
    Set exclude;
    Set idrefs;
    Map mapping;
    Map reverse;
    
    public mxObjectCodec(final Object o) {
        this(o, null, null, null);
    }
    
    public mxObjectCodec(final Object template, final String[] array, final String[] array2, Map mapping) {
        this.template = template;
        if (array != null) {
            this.exclude = new HashSet();
            for (int i = 0; i < array.length; ++i) {
                this.exclude.add(array[i]);
            }
        }
        else {
            this.exclude = mxObjectCodec.EMPTY_SET;
        }
        if (array2 != null) {
            this.idrefs = new HashSet();
            for (int j = 0; j < array2.length; ++j) {
                this.idrefs.add(array2[j]);
            }
        }
        else {
            this.idrefs = mxObjectCodec.EMPTY_SET;
        }
        if (mapping == null) {
            mapping = new Hashtable<Object, Object>();
        }
        this.mapping = mapping;
        this.reverse = new Hashtable();
        for (final Map.Entry<K, Object> entry : mapping.entrySet()) {
            this.reverse.put(entry.getValue().toString(), entry.getKey().toString());
        }
    }
    
    public Object getTemplate() {
        return this.template;
    }
    
    protected Object cloneTemplate(Node firstChild) {
        Object instance = null;
        try {
            instance = this.template.getClass().newInstance();
            if (instance instanceof Collection) {
                firstChild = firstChild.getFirstChild();
                if (firstChild != null && firstChild.hasAttributes() && firstChild.getAttributes().getNamedItem("as") != null) {
                    instance = new Hashtable();
                }
            }
        }
        catch (InstantiationException ex) {
            ex.printStackTrace();
        }
        catch (IllegalAccessException ex2) {
            ex2.printStackTrace();
        }
        return instance;
    }
    
    public boolean isExcluded(final Object o, final String s, final Object o2, final boolean b) {
        return this.exclude.contains(s);
    }
    
    public boolean isReference(final Object o, final String s, final Object o2, final boolean b) {
        return this.idrefs.contains(s);
    }
    
    public Node encode(final mxCodec mxCodec, Object beforeEncode) {
        final Element element = mxCodec.document.createElement(mxCodecRegistry.getName(beforeEncode.getClass()));
        beforeEncode = this.beforeEncode(mxCodec, beforeEncode, element);
        this.encodeObject(mxCodec, beforeEncode, element);
        return this.afterEncode(mxCodec, beforeEncode, element);
    }
    
    protected void encodeObject(final mxCodec mxCodec, final Object o, final Node node) {
        mxCodec.setAttribute(node, "id", mxCodec.getId(o));
        this.encodeFields(mxCodec, o, node);
        this.encodeElements(mxCodec, o, node);
    }
    
    protected void encodeFields(final mxCodec mxCodec, final Object o, final Node node) {
        for (Class<?> clazz = o.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            final Field[] declaredFields = clazz.getDeclaredFields();
            for (int i = 0; i < declaredFields.length; ++i) {
                final Field field = declaredFields[i];
                if ((field.getModifiers() & 0x80) != 0x80) {
                    final String name = field.getName();
                    this.encodeValue(mxCodec, o, name, this.getFieldValue(o, name), node);
                }
            }
        }
    }
    
    protected void encodeElements(final mxCodec mxCodec, final Object o, final Node node) {
        if (o.getClass().isArray()) {
            final Object[] array = (Object[])o;
            for (int i = 0; i < array.length; ++i) {
                this.encodeValue(mxCodec, o, null, array[i], node);
            }
        }
        else if (o instanceof Map) {
            for (final Map.Entry<Object, V> entry : ((Map)o).entrySet()) {
                this.encodeValue(mxCodec, o, String.valueOf(entry.getKey()), entry.getValue(), node);
            }
        }
        else if (o instanceof Collection) {
            final Iterator<Object> iterator2 = ((Collection)o).iterator();
            while (iterator2.hasNext()) {
                this.encodeValue(mxCodec, o, null, iterator2.next(), node);
            }
        }
    }
    
    protected void encodeValue(final mxCodec mxCodec, final Object o, final String str, Object o2, final Node node) {
        if (o2 != null && !this.isExcluded(o, str, o2, true)) {
            if (this.isReference(o, str, o2, true)) {
                final String id = mxCodec.getId(o2);
                if (id == null) {
                    System.err.println("mxObjectCodec.encode: No ID for " + mxCodecRegistry.getName(o.getClass()) + "." + str + "=" + o2);
                    return;
                }
                o2 = id;
            }
            final Object fieldValue = this.getFieldValue(this.template, str);
            if (str == null || mxCodec.isEncodeDefaults() || fieldValue == null || !fieldValue.equals(o2)) {
                this.writeAttribute(mxCodec, o, this.getAttributeName(str), o2, node);
            }
        }
    }
    
    protected boolean isPrimitiveValue(final Object o) {
        return o instanceof String || o instanceof Boolean || o instanceof Character || o instanceof Byte || o instanceof Short || o instanceof Integer || o instanceof Long || o instanceof Float || o instanceof Double || o.getClass().isPrimitive();
    }
    
    protected void writeAttribute(final mxCodec mxCodec, final Object o, final String s, Object convertValueToXml, final Node node) {
        convertValueToXml = this.convertValueToXml(convertValueToXml);
        if (this.isPrimitiveValue(convertValueToXml)) {
            this.writePrimitiveAttribute(mxCodec, o, s, convertValueToXml, node);
        }
        else {
            this.writeComplexAttribute(mxCodec, o, s, convertValueToXml, node);
        }
    }
    
    protected void writePrimitiveAttribute(final mxCodec mxCodec, final Object o, final String s, final Object o2, final Node node) {
        if (s == null || o instanceof Map) {
            final Element element = mxCodec.document.createElement("add");
            if (s != null) {
                mxCodec.setAttribute(element, "as", s);
            }
            mxCodec.setAttribute(element, "value", o2);
            node.appendChild(element);
        }
        else {
            mxCodec.setAttribute(node, s, o2);
        }
    }
    
    protected void writeComplexAttribute(final mxCodec mxCodec, final Object o, final String str, final Object obj, final Node node) {
        final Node encode = mxCodec.encode(obj);
        if (encode != null) {
            if (str != null) {
                mxCodec.setAttribute(encode, "as", str);
            }
            node.appendChild(encode);
        }
        else {
            System.err.println("mxObjectCodec.encode: No node for " + mxCodecRegistry.getName(o.getClass()) + "." + str + ": " + obj);
        }
    }
    
    protected Object convertValueToXml(Object o) {
        if (o instanceof Boolean) {
            o = (o ? "1" : "0");
        }
        return o;
    }
    
    protected Object convertValueFromXml(final Class clazz, Object o) {
        if (o instanceof String && clazz.isPrimitive()) {
            String s = (String)o;
            if (clazz.equals(Boolean.TYPE)) {
                if (s.equals("1") || s.equals("0")) {
                    s = (s.equals("1") ? "true" : "false");
                }
                o = new Boolean(s);
            }
            else if (clazz.equals(Character.TYPE)) {
                o = new Character(s.charAt(0));
            }
            else if (clazz.equals(Byte.TYPE)) {
                o = new Byte(s);
            }
            else if (clazz.equals(Short.TYPE)) {
                o = new Short(s);
            }
            else if (clazz.equals(Integer.TYPE)) {
                o = new Integer(s);
            }
            else if (clazz.equals(Long.TYPE)) {
                o = new Long(s);
            }
            else if (clazz.equals(Float.TYPE)) {
                o = new Float(s);
            }
            else if (clazz.equals(Double.TYPE)) {
                o = new Double(s);
            }
        }
        return o;
    }
    
    protected String getAttributeName(String string) {
        if (string != null) {
            final Object value = this.mapping.get(string);
            if (value != null) {
                string = value.toString();
            }
        }
        return string;
    }
    
    protected String getFieldName(String string) {
        if (string != null) {
            final Object value = this.reverse.get(string);
            if (value != null) {
                string = value.toString();
            }
        }
        return string;
    }
    
    protected Field getField(final Object o, final String name) {
        for (Class<?> clazz = o.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            try {
                final Field declaredField = clazz.getDeclaredField(name);
                if (declaredField != null) {
                    return declaredField;
                }
            }
            catch (Exception ex) {}
        }
        return null;
    }
    
    protected Method getAccessor(final Object o, final Field field, final boolean b) {
        final String name = field.getName();
        final String string = name.substring(0, 1).toUpperCase() + name.substring(1);
        String s;
        if (!b) {
            s = "set" + string;
        }
        else if (Boolean.TYPE.isAssignableFrom(field.getType())) {
            s = "is" + string;
        }
        else {
            s = "get" + string;
        }
        try {
            if (b) {
                return this.getMethod(o, s, null);
            }
            return this.getMethod(o, s, new Class[] { field.getType() });
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    protected Method getMethod(final Object o, final String name, final Class[] parameterTypes) {
        for (Class<?> clazz = o.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            try {
                final Method declaredMethod = clazz.getDeclaredMethod(name, (Class<?>[])parameterTypes);
                if (declaredMethod != null) {
                    return declaredMethod;
                }
            }
            catch (Exception ex) {}
        }
        return null;
    }
    
    protected Object getFieldValue(final Object o, final String s) {
        Object o2 = null;
        if (o != null && s != null) {
            final Field field = this.getField(o, s);
            try {
                if (field != null) {
                    o2 = field.get(o);
                }
            }
            catch (IllegalAccessException ex) {
                if (field != null) {
                    try {
                        o2 = this.getAccessor(o, field, true).invoke(o, (Object[])null);
                    }
                    catch (Exception ex2) {}
                }
            }
            catch (Exception ex3) {}
        }
        return o2;
    }
    
    protected void setFieldValue(final Object o, final String str, Object convertValueFromXml) {
        Field field = null;
        try {
            field = this.getField(o, str);
            if (field.getType() == Boolean.class) {
                convertValueFromXml = new Boolean(convertValueFromXml.equals("1") || String.valueOf(convertValueFromXml).equalsIgnoreCase("true"));
            }
            field.set(o, convertValueFromXml);
        }
        catch (IllegalAccessException ex) {
            if (field != null) {
                try {
                    final Method accessor = this.getAccessor(o, field, false);
                    convertValueFromXml = this.convertValueFromXml(accessor.getParameterTypes()[0], convertValueFromXml);
                    accessor.invoke(o, convertValueFromXml);
                }
                catch (Exception obj) {
                    System.err.println("setFieldValue: " + obj + " on " + o.getClass().getSimpleName() + "." + str + " (" + field.getType().getSimpleName() + ") = " + convertValueFromXml + " (" + convertValueFromXml.getClass().getSimpleName() + ")");
                }
            }
        }
        catch (Exception ex2) {}
    }
    
    public Object beforeEncode(final mxCodec mxCodec, final Object o, final Node node) {
        return o;
    }
    
    public Node afterEncode(final mxCodec mxCodec, final Object o, final Node node) {
        return node;
    }
    
    public Object decode(final mxCodec mxCodec, final Node node) {
        return this.decode(mxCodec, node, null);
    }
    
    public Object decode(final mxCodec mxCodec, Node beforeDecode, final Object o) {
        Object afterDecode = null;
        if (beforeDecode instanceof Element) {
            final String attribute = ((Element)beforeDecode).getAttribute("id");
            Object o2 = mxCodec.objects.get(attribute);
            if (o2 == null) {
                o2 = o;
                if (o2 == null) {
                    o2 = this.cloneTemplate(beforeDecode);
                }
                if (attribute != null && attribute.length() > 0) {
                    mxCodec.putObject(attribute, o2);
                }
            }
            beforeDecode = this.beforeDecode(mxCodec, beforeDecode, o2);
            this.decodeNode(mxCodec, beforeDecode, o2);
            afterDecode = this.afterDecode(mxCodec, beforeDecode, o2);
        }
        return afterDecode;
    }
    
    protected void decodeNode(final mxCodec mxCodec, final Node node, final Object o) {
        if (node != null) {
            this.decodeAttributes(mxCodec, node, o);
            this.decodeChildren(mxCodec, node, o);
        }
    }
    
    protected void decodeAttributes(final mxCodec mxCodec, final Node node, final Object o) {
        final NamedNodeMap attributes = node.getAttributes();
        if (attributes != null) {
            for (int i = 0; i < attributes.getLength(); ++i) {
                this.decodeAttribute(mxCodec, attributes.item(i), o);
            }
        }
    }
    
    protected void decodeAttribute(final mxCodec mxCodec, final Node node, final Object o) {
        final String nodeName = node.getNodeName();
        if (!nodeName.equalsIgnoreCase("as") && !nodeName.equalsIgnoreCase("id")) {
            String nodeValue = node.getNodeValue();
            final String fieldName = this.getFieldName(nodeName);
            if (this.isReference(o, fieldName, nodeValue, false)) {
                final Object object = mxCodec.getObject(String.valueOf(nodeValue));
                if (object == null) {
                    System.err.println("mxObjectCodec.decode: No object for " + mxCodecRegistry.getName(o.getClass()) + "." + fieldName + "=" + (Object)nodeValue);
                    return;
                }
                nodeValue = (String)object;
            }
            if (!this.isExcluded(o, fieldName, nodeValue, false)) {
                this.setFieldValue(o, fieldName, nodeValue);
            }
        }
    }
    
    protected void decodeChildren(final mxCodec mxCodec, final Node node, final Object o) {
        for (Node node2 = node.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
            if (node2.getNodeType() == 1 && !this.processInclude(mxCodec, node2, o)) {
                this.decodeChild(mxCodec, node2, o);
            }
        }
    }
    
    protected void decodeChild(final mxCodec mxCodec, final Node node, final Object o) {
        final String fieldName = this.getFieldName(((Element)node).getAttribute("as"));
        if (fieldName == null || !this.isExcluded(o, fieldName, node, false)) {
            final Object fieldValue = this.getFieldValue(o, fieldName);
            Object o2;
            if (node.getNodeName().equals("add")) {
                o2 = ((Element)node).getAttribute("value");
                if (o2 == null) {
                    o2 = node.getTextContent();
                }
            }
            else {
                o2 = mxCodec.decode(node, fieldValue);
            }
            if (o2 != null && !o2.equals(fieldValue)) {
                if (fieldName != null && o instanceof Map) {
                    ((Map)o).put(fieldName, o2);
                }
                else if (fieldName != null && fieldName.length() > 0) {
                    this.setFieldValue(o, fieldName, o2);
                }
                else if (o instanceof Collection) {
                    ((Collection)o).add(o2);
                }
                else if (o.getClass().isArray()) {}
            }
        }
    }
    
    public boolean processInclude(final mxCodec mxCodec, final Node node, final Object o) {
        if (node.getNodeType() == 1 && node.getNodeName().equalsIgnoreCase("include")) {
            final String attribute = ((Element)node).getAttribute("name");
            if (attribute != null) {
                try {
                    final Element documentElement = mxUtils.loadDocument(mxObjectCodec.class.getResource(attribute).toString()).getDocumentElement();
                    if (documentElement != null) {
                        mxCodec.decode(documentElement, o);
                    }
                }
                catch (Exception ex) {
                    System.err.println("Cannot process include: " + attribute);
                }
            }
            return true;
        }
        return false;
    }
    
    public Node beforeDecode(final mxCodec mxCodec, final Node node, final Object o) {
        return node;
    }
    
    public Object afterDecode(final mxCodec mxCodec, final Node node, final Object o) {
        return o;
    }
    
    static {
        mxObjectCodec.EMPTY_SET = new HashSet();
    }
}
