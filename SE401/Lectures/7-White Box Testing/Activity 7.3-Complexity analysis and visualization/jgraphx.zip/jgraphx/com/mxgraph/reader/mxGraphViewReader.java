// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.reader;

import com.mxgraph.util.mxPoint;
import java.util.ArrayList;
import java.util.List;
import com.mxgraph.util.mxUtils;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;
import java.util.Hashtable;
import com.mxgraph.canvas.mxICanvas;
import org.xml.sax.helpers.DefaultHandler;

public abstract class mxGraphViewReader extends DefaultHandler
{
    protected mxICanvas canvas;
    protected double scale;
    
    public mxGraphViewReader() {
        this.scale = 1.0;
    }
    
    public abstract mxICanvas createCanvas(final Hashtable p0);
    
    public mxICanvas getCanvas() {
        return this.canvas;
    }
    
    @Override
    public void startElement(final String s, final String s2, final String s3, final Attributes attributes) throws SAXException {
        final String upperCase = s3.toUpperCase();
        final Hashtable<String, String> hashtable = new Hashtable<String, String>();
        for (int i = 0; i < attributes.getLength(); ++i) {
            String key = attributes.getLocalName(i);
            if (key == null) {
                key = attributes.getQName(i);
            }
            hashtable.put(key, attributes.getValue(i));
        }
        this.parseElement(upperCase, hashtable);
    }
    
    public void parseElement(final String s, final Hashtable hashtable) {
        if (this.canvas == null && s.equalsIgnoreCase("GRAPH")) {
            this.scale = mxUtils.getDouble(hashtable, "scale", 1.0);
            this.canvas = this.createCanvas(hashtable);
        }
        else if (this.canvas != null) {
            if (s.equalsIgnoreCase("VERTEX") || s.equalsIgnoreCase("GROUP")) {
                this.drawVertex(hashtable);
            }
            else if (s.equalsIgnoreCase("EDGE")) {
                this.drawEdge(hashtable);
            }
            this.drawLabel(s.equalsIgnoreCase("EDGE"), hashtable);
        }
    }
    
    public void drawVertex(final Hashtable hashtable) {
        final int int1 = mxUtils.getInt(hashtable, "width");
        final int int2 = mxUtils.getInt(hashtable, "height");
        if (int1 > 0 && int2 > 0) {
            this.canvas.drawVertex((int)Math.round(mxUtils.getDouble(hashtable, "x")), (int)Math.round(mxUtils.getDouble(hashtable, "y")), int1, int2, hashtable);
        }
    }
    
    public void drawEdge(final Hashtable hashtable) {
        final List points = parsePoints(mxUtils.getString(hashtable, "points"));
        if (points.size() > 0) {
            this.canvas.drawEdge(points, hashtable);
        }
    }
    
    public void drawLabel(final boolean b, final Hashtable hashtable) {
        final String string = mxUtils.getString(hashtable, "label");
        if (string != null && string.length() > 0) {
            int n = (int)Math.round(mxUtils.getDouble(hashtable, "offsetX"));
            int n2 = (int)Math.round(mxUtils.getDouble(hashtable, "offsetY"));
            int int1 = 0;
            int int2 = 0;
            if (!b) {
                n += (int)Math.round(mxUtils.getDouble(hashtable, "x"));
                n2 += (int)Math.round(mxUtils.getDouble(hashtable, "y"));
                int1 = mxUtils.getInt(hashtable, "width");
                int2 = mxUtils.getInt(hashtable, "height");
            }
            mxUtils.getScaledLabelBounds(n, n2, mxUtils.getLabelSize(string, hashtable, false), int1, int2, hashtable, this.scale);
            this.canvas.drawLabel(string, n, n2, int1, int2, hashtable, false);
        }
    }
    
    public static List parsePoints(final String s) {
        final ArrayList<mxPoint> list = new ArrayList<mxPoint>();
        if (s != null) {
            final int length = s.length();
            String string = "";
            String s2 = null;
            for (int i = 0; i < length; ++i) {
                final char char1 = s.charAt(i);
                if (char1 == ',' || char1 == ' ') {
                    if (s2 == null) {
                        s2 = string;
                    }
                    else {
                        list.add(new mxPoint(Double.parseDouble(s2), Double.parseDouble(string)));
                        s2 = null;
                    }
                    string = "";
                }
                else {
                    string += char1;
                }
            }
            list.add(new mxPoint(Double.parseDouble(s2), Double.parseDouble(string)));
        }
        return list;
    }
}
