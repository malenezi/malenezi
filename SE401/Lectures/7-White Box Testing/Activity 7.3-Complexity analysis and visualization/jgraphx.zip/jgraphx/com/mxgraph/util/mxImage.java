// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.util;

import java.io.Serializable;

public class mxImage implements Serializable, Cloneable
{
    protected String src;
    protected int width;
    protected int height;
    
    public mxImage(final String src, final int width, final int height) {
        this.src = src;
        this.width = width;
        this.height = height;
    }
    
    public String getSrc() {
        return this.src;
    }
    
    public void setSrc(final String src) {
        this.src = src;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public void setWidth(final int width) {
        this.width = width;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public void setHeight(final int height) {
        this.height = height;
    }
}
