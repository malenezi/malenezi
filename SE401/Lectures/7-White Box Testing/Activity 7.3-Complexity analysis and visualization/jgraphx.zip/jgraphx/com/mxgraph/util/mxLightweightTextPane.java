// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.util;

import java.awt.Rectangle;
import javax.swing.border.Border;
import javax.swing.JTextPane;

public class mxLightweightTextPane extends JTextPane
{
    private static final long serialVersionUID = -6771477489533614010L;
    protected static mxLightweightTextPane sharedInstance;
    
    public static mxLightweightTextPane getSharedInstance() {
        return mxLightweightTextPane.sharedInstance;
    }
    
    public mxLightweightTextPane() {
        this.setContentType("text/html");
        this.setOpaque(false);
        this.setBorder(null);
    }
    
    @Override
    public void validate() {
    }
    
    @Override
    public void revalidate() {
    }
    
    @Override
    public void repaint(final long n, final int n2, final int n3, final int n4, final int n5) {
    }
    
    @Override
    public void repaint(final Rectangle rectangle) {
    }
    
    @Override
    protected void firePropertyChange(final String propertyName, final Object oldValue, final Object newValue) {
        if (propertyName == "document") {
            super.firePropertyChange(propertyName, oldValue, newValue);
        }
    }
    
    @Override
    public void firePropertyChange(final String s, final byte b, final byte b2) {
    }
    
    @Override
    public void firePropertyChange(final String s, final char c, final char c2) {
    }
    
    @Override
    public void firePropertyChange(final String s, final short n, final short n2) {
    }
    
    @Override
    public void firePropertyChange(final String s, final int n, final int n2) {
    }
    
    @Override
    public void firePropertyChange(final String s, final long n, final long n2) {
    }
    
    @Override
    public void firePropertyChange(final String s, final float n, final float n2) {
    }
    
    @Override
    public void firePropertyChange(final String s, final double n, final double n2) {
    }
    
    @Override
    public void firePropertyChange(final String s, final boolean b, final boolean b2) {
    }
    
    static {
        try {
            mxLightweightTextPane.sharedInstance = new mxLightweightTextPane();
        }
        catch (Exception ex) {}
    }
}
