// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing;

import java.awt.RenderingHints;
import com.mxgraph.util.mxResources;
import java.awt.Stroke;
import java.awt.BasicStroke;
import com.mxgraph.util.mxUtils;
import java.awt.image.ImageObserver;
import java.awt.Shape;
import java.awt.Cursor;
import com.mxgraph.swing.util.mxOverlay;
import java.util.List;
import java.util.Arrays;
import com.mxgraph.swing.util.mxIOverlay;
import java.util.Iterator;
import java.util.Map;
import com.mxgraph.swing.handler.mxEdgeHandler;
import com.mxgraph.swing.handler.mxElbowEdgeHandler;
import com.mxgraph.view.mxEdgeStyle;
import com.mxgraph.util.mxConstants;
import com.mxgraph.swing.handler.mxVertexHandler;
import com.mxgraph.swing.handler.mxCellHandler;
import com.mxgraph.canvas.mxGraphics2DCanvas;
import java.awt.geom.AffineTransform;
import com.mxgraph.canvas.mxICanvas;
import javax.swing.RepaintManager;
import java.awt.Graphics2D;
import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.ToolTipManager;
import com.mxgraph.view.mxCellState;
import javax.swing.BoundedRangeModel;
import javax.swing.JScrollBar;
import javax.swing.SwingUtilities;
import java.awt.Dimension;
import com.mxgraph.model.mxIGraphModel;
import com.mxgraph.util.mxPoint;
import java.awt.Point;
import java.awt.geom.Rectangle2D;
import java.awt.Rectangle;
import java.awt.event.ComponentListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.util.EventObject;
import javax.swing.TransferHandler;
import com.mxgraph.swing.handler.mxGraphTransferHandler;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import com.mxgraph.model.mxGraphModel;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import com.mxgraph.view.mxGraphView;
import java.awt.Component;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import com.mxgraph.util.mxRectangle;
import com.mxgraph.swing.view.mxCellEditor;
import java.util.Hashtable;
import java.awt.Color;
import java.awt.print.PageFormat;
import com.mxgraph.swing.handler.mxGraphHandler;
import com.mxgraph.swing.handler.mxPanningHandler;
import com.mxgraph.swing.handler.mxConnectionHandler;
import com.mxgraph.swing.view.mxICellEditor;
import com.mxgraph.util.mxEventSource;
import com.mxgraph.view.mxGraph;
import javax.swing.ImageIcon;
import java.awt.print.Printable;
import javax.swing.JScrollPane;

public class mxGraphComponent extends JScrollPane implements Printable
{
    public static final String EVENT_BEFORE_LABELCHANGED = "beforelabelchanged";
    public static final String EVENT_LABELCHANGED = "labelchanged";
    public static final String EVENT_AFTER_LABELCHANGED = "afterlabelchanged";
    public static final String EVENT_ADDOVERLAY = "addoverlay";
    public static final String EVENT_REMOVEOVERLAY = "removeoverlay";
    public static final int GRID_STYLE_DOT = 0;
    public static final int GRID_STYLE_CROSS = 1;
    public static final int GRID_STYLE_LINE = 2;
    public static final int GRID_STYLE_DASHED = 3;
    public static final int ZOOM_POLICY_NONE = 0;
    public static final int ZOOM_POLICY_PAGE = 1;
    public static final int ZOOM_POLICY_WIDTH = 2;
    public static ImageIcon DEFAULT_EXPANDED_ICON;
    public static ImageIcon DEFAULT_COLLAPSED_ICON;
    public static ImageIcon DEFAULT_WARNING_ICON;
    public static final double DEFAULT_PAGESCALE = 1.4;
    protected mxGraph graph;
    protected mxGraphControl control;
    protected mxEventSource eventSource;
    protected mxICellEditor cellEditor;
    protected mxConnectionHandler connectionHandler;
    protected mxPanningHandler panningHandler;
    protected mxGraphHandler graphHandler;
    protected ImageIcon backgroundImage;
    protected PageFormat pageFormat;
    protected double pageScale;
    protected boolean pageVisible;
    protected boolean preferPageSize;
    protected boolean pageBreakVisible;
    protected boolean centerPage;
    protected Color pageBackgroundColor;
    protected Color pageShadowColor;
    protected boolean gridVisible;
    protected Color gridColor;
    protected boolean dragEnabled;
    protected boolean dropEnabled;
    protected boolean foldingEnabled;
    protected int gridStyle;
    protected ImageIcon expandedIcon;
    protected ImageIcon collapsedIcon;
    protected ImageIcon warningIcon;
    protected boolean antiAlias;
    protected boolean textAntiAlias;
    protected boolean escapeEnabled;
    protected boolean invokesStopCellEditing;
    protected int zoomPolicy;
    private boolean zooming;
    protected double zoomFactor;
    protected boolean keepSelectionVisibleOnZoom;
    protected boolean centerZoom;
    protected boolean tripleBuffered;
    public boolean showDirtyRectangle;
    protected Hashtable components;
    protected Hashtable overlays;
    private boolean centerOnResize;
    protected mxEventSource.mxEventListener updateHandler;
    
    public mxGraphComponent(final mxGraph graph) {
        this.eventSource = new mxEventSource(this);
        this.cellEditor = new mxCellEditor(this);
        this.pageFormat = new PageFormat();
        this.pageScale = 1.4;
        this.pageVisible = false;
        this.preferPageSize = false;
        this.pageBreakVisible = false;
        this.centerPage = true;
        this.pageBackgroundColor = new Color(144, 153, 174);
        this.pageShadowColor = new Color(110, 120, 140);
        this.gridVisible = false;
        this.gridColor = new Color(192, 192, 192);
        this.dragEnabled = true;
        this.dropEnabled = true;
        this.foldingEnabled = true;
        this.gridStyle = 3;
        this.expandedIcon = mxGraphComponent.DEFAULT_EXPANDED_ICON;
        this.collapsedIcon = mxGraphComponent.DEFAULT_COLLAPSED_ICON;
        this.warningIcon = mxGraphComponent.DEFAULT_WARNING_ICON;
        this.antiAlias = true;
        this.textAntiAlias = true;
        this.escapeEnabled = true;
        this.invokesStopCellEditing = true;
        this.zoomPolicy = 1;
        this.zooming = false;
        this.zoomFactor = 1.2;
        this.keepSelectionVisibleOnZoom = false;
        this.centerZoom = true;
        this.tripleBuffered = false;
        this.showDirtyRectangle = false;
        this.components = new Hashtable();
        this.overlays = new Hashtable();
        this.centerOnResize = true;
        this.updateHandler = new mxEventSource.mxEventListener() {
            public void invoke(final Object o, final Object[] array) {
                mxGraphComponent.this.update();
            }
        };
        (this.graph = graph).addListener(mxGraph.EVENT_REPAINT, new mxEventSource.mxEventListener() {
            public void invoke(final Object o, final Object[] array) {
                final mxRectangle mxRectangle = (array.length > 0) ? ((mxRectangle)array[0]) : null;
                mxGraphComponent.this.control.refresh(mxRectangle);
                JPanel comp = (JPanel)mxGraphComponent.this.getClientProperty("dirty");
                if (mxGraphComponent.this.showDirtyRectangle) {
                    if (comp == null) {
                        comp = new JPanel();
                        comp.setOpaque(false);
                        comp.setBorder(BorderFactory.createLineBorder(Color.RED));
                        mxGraphComponent.this.putClientProperty("dirty", comp);
                        mxGraphComponent.this.control.add(comp);
                    }
                    if (mxRectangle != null) {
                        comp.setBounds(mxRectangle.getRectangle());
                    }
                    comp.setVisible(mxRectangle != null);
                }
                else if (comp != null && comp.getParent() != null) {
                    comp.getParent().remove(comp);
                    mxGraphComponent.this.putClientProperty("dirty", null);
                    mxGraphComponent.this.repaint();
                }
            }
        });
        graph.getModel().addListener("change", this.updateHandler);
        final mxGraphView view = graph.getView();
        view.addListener(mxGraphView.EVENT_SCALE, this.updateHandler);
        view.addListener(mxGraphView.EVENT_TRANSLATE, this.updateHandler);
        view.addListener(mxGraphView.EVENT_SCALE_AND_TRANSLATE, this.updateHandler);
        view.addListener(mxGraphView.EVENT_UP, this.updateHandler);
        view.addListener(mxGraphView.EVENT_DOWN, this.updateHandler);
        graph.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(final PropertyChangeEvent propertyChangeEvent) {
                if (propertyChangeEvent.getPropertyName().equals("view")) {
                    final mxGraphView mxGraphView = (mxGraphView)propertyChangeEvent.getOldValue();
                    final mxGraphView mxGraphView2 = (mxGraphView)propertyChangeEvent.getNewValue();
                    if (mxGraphView != null) {
                        mxGraphView.removeListener(mxGraphComponent.this.updateHandler);
                    }
                    if (mxGraphView2 != null) {
                        mxGraphView2.addListener(com.mxgraph.view.mxGraphView.EVENT_SCALE, mxGraphComponent.this.updateHandler);
                        mxGraphView2.addListener(com.mxgraph.view.mxGraphView.EVENT_TRANSLATE, mxGraphComponent.this.updateHandler);
                        mxGraphView2.addListener(com.mxgraph.view.mxGraphView.EVENT_SCALE_AND_TRANSLATE, mxGraphComponent.this.updateHandler);
                        mxGraphView2.addListener(com.mxgraph.view.mxGraphView.EVENT_UP, mxGraphComponent.this.updateHandler);
                        mxGraphView2.addListener(com.mxgraph.view.mxGraphView.EVENT_DOWN, mxGraphComponent.this.updateHandler);
                    }
                }
                else if (propertyChangeEvent.getPropertyName().equals("model")) {
                    final mxGraphModel mxGraphModel = (mxGraphModel)propertyChangeEvent.getOldValue();
                    final mxGraphModel mxGraphModel2 = (mxGraphModel)propertyChangeEvent.getNewValue();
                    if (mxGraphModel != null) {
                        mxGraphModel.removeListener(mxGraphComponent.this.updateHandler);
                    }
                    if (mxGraphModel2 != null) {
                        mxGraphModel2.addListener("change", mxGraphComponent.this.updateHandler);
                    }
                }
            }
        });
        (this.control = this.createControl()).addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(final MouseEvent mouseEvent) {
                if (!mxGraphComponent.this.hasFocus()) {
                    mxGraphComponent.this.requestFocus();
                }
            }
        });
        this.setTransferHandler(new mxGraphTransferHandler());
        this.setViewportView(this.control);
        this.createHandlers();
        this.control.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(final MouseEvent mouseEvent) {
                if (!mouseEvent.isConsumed() && mxGraphComponent.this.isEditEvent(mouseEvent)) {
                    final Object cell = graph.getCellAt(mouseEvent.getX(), mouseEvent.getY(), false);
                    if (cell != null) {
                        mxGraphComponent.this.edit(cell, mouseEvent);
                    }
                }
                else {
                    mxGraphComponent.this.stopEditing(!mxGraphComponent.this.invokesStopCellEditing);
                }
            }
        });
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(final KeyEvent keyEvent) {
                if (keyEvent.getKeyCode() == 27) {
                    mxGraphComponent.this.escape(keyEvent);
                }
            }
        });
        final mxEventSource.mxEventListener mxEventListener = new mxEventSource.mxEventListener() {
            public void invoke(final Object o, final Object[] array) {
                if (!mxGraphComponent.this.zooming) {
                    mxGraphComponent.this.zoomPolicy = 0;
                }
            }
        };
        graph.getView().addListener(mxGraphView.EVENT_SCALE, mxEventListener);
        graph.getView().addListener(mxGraphView.EVENT_SCALE_AND_TRANSLATE, mxEventListener);
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(final ComponentEvent componentEvent) {
                mxGraphComponent.this.zoomAndCenter();
            }
        });
    }
    
    public mxGraph getGraph() {
        return this.graph;
    }
    
    protected mxGraphControl createControl() {
        return new mxGraphControl();
    }
    
    public mxGraphControl getControl() {
        return this.control;
    }
    
    protected void createHandlers() {
        this.connectionHandler = this.createConnectionHandler();
        this.panningHandler = this.createPanningHandler();
        this.graphHandler = this.createGraphHandler();
    }
    
    protected mxGraphHandler createGraphHandler() {
        return new mxGraphHandler(this);
    }
    
    public mxGraphHandler getGraphHandler() {
        return this.graphHandler;
    }
    
    protected mxConnectionHandler createConnectionHandler() {
        return new mxConnectionHandler(this);
    }
    
    public mxConnectionHandler getConnectionHandler() {
        return this.connectionHandler;
    }
    
    protected mxPanningHandler createPanningHandler() {
        return new mxPanningHandler(this);
    }
    
    public mxPanningHandler getPanningHandler() {
        return this.panningHandler;
    }
    
    public mxICellEditor getCellEditor() {
        return this.cellEditor;
    }
    
    public void setCellEditor(final mxICellEditor cellEditor) {
        this.firePropertyChange("cellEditor", this.cellEditor, this.cellEditor = cellEditor);
    }
    
    public PageFormat getPageFormat() {
        return this.pageFormat;
    }
    
    public void setPageFormat(final PageFormat pageFormat) {
        this.firePropertyChange("pageFormat", this.pageFormat, this.pageFormat = pageFormat);
    }
    
    public double getPageScale() {
        return this.pageScale;
    }
    
    public void setPageScale(final double pageScale) {
        this.firePropertyChange("pageScale", this.pageScale, this.pageScale = pageScale);
    }
    
    public mxRectangle getLayoutAreaSize() {
        if (this.pageVisible) {
            return new mxRectangle(0.0, 0.0, this.pageFormat.getWidth() * this.pageScale, this.pageFormat.getHeight() * this.pageScale);
        }
        return new mxRectangle(new Rectangle(this.control.getSize()));
    }
    
    public ImageIcon getBackgroundImage() {
        return this.backgroundImage;
    }
    
    public void setBackgroundImage(final ImageIcon backgroundImage) {
        this.firePropertyChange("backgroundImage", this.backgroundImage, this.backgroundImage = backgroundImage);
    }
    
    public boolean isPageVisible() {
        return this.pageVisible;
    }
    
    public void setPageVisible(final boolean pageVisible) {
        this.firePropertyChange("pageVisible", this.pageVisible, this.pageVisible = pageVisible);
    }
    
    public boolean isPreferPageSize() {
        return this.preferPageSize;
    }
    
    public void setPreferPageSize(final boolean preferPageSize) {
        this.firePropertyChange("preferPageSize", this.preferPageSize, this.preferPageSize = preferPageSize);
    }
    
    public boolean isPageBreakVisible() {
        return this.pageBreakVisible;
    }
    
    public void setPageBreakVisible(final boolean pageBreakVisible) {
        final boolean pageBreakVisible2 = this.pageBreakVisible;
        this.pageBreakVisible = pageBreakVisible;
        this.firePropertyChange("pageBreakVisible", pageBreakVisible2, this.pageVisible);
    }
    
    public boolean isCenterPage() {
        return this.centerPage;
    }
    
    public void setCenterPage(final boolean centerPage) {
        this.firePropertyChange("centerPage", this.centerPage, this.centerPage = centerPage);
    }
    
    public Color getPageBackgroundColor() {
        return this.pageBackgroundColor;
    }
    
    public void setPageBackgroundColor(final Color pageBackgroundColor) {
        this.firePropertyChange("pageBackgroundColor", this.pageBackgroundColor, this.pageBackgroundColor = pageBackgroundColor);
    }
    
    public Color getPageShadowColor() {
        return this.pageShadowColor;
    }
    
    public void setPageShadowColor(final Color pageShadowColor) {
        this.firePropertyChange("pageShadowColor", this.pageShadowColor, this.pageShadowColor = pageShadowColor);
    }
    
    public boolean isKeepSelectionVisibleOnZoom() {
        return this.keepSelectionVisibleOnZoom;
    }
    
    public void setKeepSelectionVisibleOnZoom(final boolean keepSelectionVisibleOnZoom) {
        this.firePropertyChange("keepSelectionVisibleOnZoom", this.keepSelectionVisibleOnZoom, this.keepSelectionVisibleOnZoom = keepSelectionVisibleOnZoom);
    }
    
    public double getZoomFactor() {
        return this.zoomFactor;
    }
    
    public void setZoomFactor(final double zoomFactor) {
        this.firePropertyChange("zoomFactor", this.zoomFactor, this.zoomFactor = zoomFactor);
    }
    
    public boolean isCenterZoom() {
        return this.centerZoom;
    }
    
    public void setCenterZoom(final boolean centerZoom) {
        this.firePropertyChange("centerZoom", this.centerZoom, this.centerZoom = centerZoom);
    }
    
    public void setZoomPolicy(final int n) {
        final int zoomPolicy = this.zoomPolicy;
        this.zoomPolicy = n;
        if (n != 0) {
            this.zoom(n == 1, true);
        }
        this.firePropertyChange("zoomPolicy", zoomPolicy, n);
    }
    
    public int getZoomPolicy() {
        return this.zoomPolicy;
    }
    
    public void escape(final KeyEvent keyEvent) {
        if (this.escapeEnabled) {
            this.cellEditor.stopEditing(true);
            this.graphHandler.reset();
            this.connectionHandler.reset();
        }
    }
    
    public Object[] importCells(final Object[] array, final double n, final double n2, final Object o, final Point point) {
        return this.graph.move(array, n, n2, true, o, point);
    }
    
    public void refresh() {
        this.graph.refresh();
        this.graphHandler.refresh();
    }
    
    public mxPoint getPointForEvent(final MouseEvent mouseEvent) {
        final double scale = this.graph.getView().getScale();
        final mxPoint translate = this.graph.getView().getTranslate();
        return new mxPoint(this.graph.snap(mouseEvent.getX() / scale - translate.getX() - this.graph.getGridSize() / 2), this.graph.snap(mouseEvent.getY() / scale - translate.getY() - this.graph.getGridSize() / 2));
    }
    
    public void edit() {
        this.edit(null);
    }
    
    public void edit(final EventObject eventObject) {
        this.edit(null, eventObject);
    }
    
    public void edit(Object selectionCell, final EventObject eventObject) {
        if (selectionCell == null) {
            selectionCell = this.graph.getSelectionCell();
        }
        if (selectionCell != null && this.graph.isEditable(selectionCell)) {
            this.startEditingAtCell(selectionCell, eventObject);
        }
    }
    
    public void startEditingAtCell(final Object o, final EventObject eventObject) {
        this.cellEditor.startEditing(o, eventObject);
    }
    
    public String getEditingValue(final Object o, final EventObject eventObject) {
        return this.graph.convertValueToString(o);
    }
    
    public void stopEditing(final boolean b) {
        this.cellEditor.stopEditing(b);
    }
    
    public void labelChanged(final Object o, final Object o2, final EventObject eventObject) {
        final mxIGraphModel model = this.graph.getModel();
        final Object value = model.getValue(o);
        this.eventSource.fireEvent("beforelabelchanged", new Object[] { o, value, o2, eventObject });
        model.beginUpdate();
        try {
            model.setValue(o, o2);
            if (this.graph.isUpdateSize(o)) {
                this.graph.updateSize(o);
            }
            this.eventSource.fireEvent("labelchanged", new Object[] { o, value, o2, eventObject });
        }
        finally {
            model.endUpdate();
        }
        this.eventSource.fireEvent("afterlabelchanged", new Object[] { o, value, o2, eventObject });
    }
    
    protected Dimension getPreferredSizeForPage() {
        return new Dimension((int)Math.round(3.0 * this.pageFormat.getWidth() * this.pageScale), (int)Math.round(2.0 * this.pageFormat.getHeight() * this.pageScale));
    }
    
    protected Dimension getScaledPreferredSizeForGraph() {
        final mxRectangle bounds = this.graph.getBounds();
        final int border = this.graph.getBorder();
        return new Dimension((int)Math.round(bounds.getWidth()) + border + 1, (int)Math.round(bounds.getHeight()) + border + 1);
    }
    
    protected mxPoint getPageTranslate(final double n) {
        final Dimension preferredSizeForPage = this.getPreferredSizeForPage();
        return new mxPoint(Math.max(0.0, (Math.max(preferredSizeForPage.width, (this.getViewport().getWidth() - 8) / n) - this.pageFormat.getWidth() * this.pageScale) / 2.0), Math.max(0.0, (Math.max(preferredSizeForPage.height, (this.getViewport().getHeight() - 8) / n) - this.pageFormat.getHeight() * this.pageScale) / 2.0));
    }
    
    public void zoomAndCenter() {
        if (this.zoomPolicy != 0) {
            this.zoom(this.zoomPolicy == 1, this.centerOnResize || this.zoomPolicy == 1);
            this.centerOnResize = false;
        }
        else if (this.pageVisible && this.centerPage) {
            this.graph.getView().setTranslate(this.getPageTranslate(this.graph.getView().getScale()));
        }
    }
    
    public void zoomIn() {
        final mxGraphView view = this.graph.getView();
        double n = (int)(view.getScale() * 100.0 * this.zoomFactor) / 100.0;
        if (n == view.getScale()) {
            n += 0.01;
        }
        if (n > 0.0) {
            final mxPoint mxPoint = (this.pageVisible && this.centerPage) ? this.getPageTranslate(n) : new mxPoint();
            this.graph.getView().scaleAndTranslate(n, mxPoint.getX(), mxPoint.getY());
            if (this.keepSelectionVisibleOnZoom && !this.graph.isSelectionEmpty()) {
                this.getControl().scrollRectToVisible(view.getBoundingBox(this.graph.getSelectionCells()).getRectangle());
            }
            else {
                this.maintainScrollBar(true, this.zoomFactor, this.centerZoom);
                this.maintainScrollBar(false, this.zoomFactor, this.centerZoom);
            }
        }
    }
    
    public void zoomOut() {
        final mxGraphView view = this.graph.getView();
        final double n = (int)(view.getScale() * 100.0 / this.zoomFactor) / 100.0;
        if (n >= 0.01) {
            final mxPoint mxPoint = (this.pageVisible && this.centerPage) ? this.getPageTranslate(n) : new mxPoint();
            this.graph.getView().scaleAndTranslate(n, mxPoint.getX(), mxPoint.getY());
            if (this.keepSelectionVisibleOnZoom && !this.graph.isSelectionEmpty()) {
                this.getControl().scrollRectToVisible(view.getBoundingBox(this.graph.getSelectionCells()).getRectangle());
            }
            else {
                this.maintainScrollBar(true, 1.0 / this.zoomFactor, this.centerZoom);
                this.maintainScrollBar(false, 1.0 / this.zoomFactor, this.centerZoom);
            }
        }
    }
    
    public void zoomTo(final double n, final boolean b) {
        final double scale = this.graph.getView().getScale();
        final mxPoint mxPoint = (this.pageVisible && this.centerPage) ? this.getPageTranslate(n) : new mxPoint();
        this.graph.getView().scaleAndTranslate(n, mxPoint.getX(), mxPoint.getY());
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                mxGraphComponent.this.maintainScrollBar(true, n / scale, b);
                mxGraphComponent.this.maintainScrollBar(false, n / scale, b);
            }
        });
    }
    
    public void zoomActual() {
        final mxPoint mxPoint = (this.pageVisible && this.centerPage) ? this.getPageTranslate(1.0) : new mxPoint();
        this.graph.getView().scaleAndTranslate(1.0, mxPoint.getX(), mxPoint.getY());
        if (this.isPageVisible()) {
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    if (mxGraphComponent.this.getViewport().getWidth() > mxGraphComponent.this.pageFormat.getWidth() * mxGraphComponent.this.pageScale) {
                        mxGraphComponent.this.scrollToCenter(true);
                    }
                    else {
                        final JScrollBar horizontalScrollBar = mxGraphComponent.this.getHorizontalScrollBar();
                        if (horizontalScrollBar != null) {
                            horizontalScrollBar.setValue(horizontalScrollBar.getMaximum() / 3 - 4);
                        }
                    }
                    if (mxGraphComponent.this.getViewport().getHeight() > mxGraphComponent.this.pageFormat.getHeight() * mxGraphComponent.this.pageScale) {
                        mxGraphComponent.this.scrollToCenter(false);
                    }
                    else {
                        final JScrollBar verticalScrollBar = mxGraphComponent.this.getVerticalScrollBar();
                        if (verticalScrollBar != null) {
                            verticalScrollBar.setValue(verticalScrollBar.getMaximum() / 4 - 4);
                        }
                    }
                }
            });
        }
    }
    
    public void zoom(final boolean b, final boolean b2) {
        if (this.pageVisible && !this.zooming) {
            this.zooming = true;
            try {
                final double n = this.getViewport().getWidth() - 8;
                final double n2 = this.getViewport().getHeight() - 8;
                final double n3 = this.pageFormat.getWidth() * this.pageScale;
                final double n4 = this.pageFormat.getHeight() * this.pageScale;
                final double a = n / n3;
                final double n5 = (int)(Math.min(a, b ? (n2 / n4) : a) * 20.0) / 20.0;
                if (n5 > 0.0) {
                    final mxGraphView view = this.graph.getView();
                    final double scale = view.getScale();
                    final mxPoint mxPoint = this.centerPage ? this.getPageTranslate(n5) : new mxPoint();
                    view.scaleAndTranslate(n5, mxPoint.getX(), mxPoint.getY());
                    SwingUtilities.invokeLater(new Runnable() {
                        final /* synthetic */ double val$factor = n5 / scale;
                        
                        public void run() {
                            if (b2) {
                                if (b) {
                                    mxGraphComponent.this.scrollToCenter(true);
                                    mxGraphComponent.this.scrollToCenter(false);
                                }
                                else {
                                    mxGraphComponent.this.scrollToCenter(true);
                                    mxGraphComponent.this.maintainScrollBar(false, this.val$factor, false);
                                }
                            }
                            else if (this.val$factor != 1.0) {
                                mxGraphComponent.this.maintainScrollBar(true, this.val$factor, false);
                                mxGraphComponent.this.maintainScrollBar(false, this.val$factor, false);
                            }
                        }
                    });
                }
            }
            finally {
                this.zooming = false;
            }
        }
    }
    
    protected void maintainScrollBar(final boolean b, final double n, final boolean b2) {
        final JScrollBar scrollBar = b ? this.getHorizontalScrollBar() : this.getVerticalScrollBar();
        if (scrollBar != null) {
            final BoundedRangeModel model = scrollBar.getModel();
            model.setValue((int)Math.round(model.getValue() * n) + (int)Math.round(b2 ? (model.getExtent() * (n - 1.0) / 2.0) : 0.0));
        }
    }
    
    public void scrollToCenter(final boolean b) {
        final JScrollBar scrollBar = b ? this.getHorizontalScrollBar() : this.getVerticalScrollBar();
        if (scrollBar != null) {
            final BoundedRangeModel model = scrollBar.getModel();
            model.setValue(model.getMaximum() / 2 - model.getExtent() / 2);
        }
    }
    
    public void scrollCellToVisible(final Object o) {
        final mxCellState state = this.graph.getView().getState(o);
        if (state != null) {
            this.scrollRectToVisible(state.getRectangle());
        }
    }
    
    public Object[] selectRegion(final Rectangle rectangle, final MouseEvent mouseEvent) {
        final Object[] cells = this.graph.getCells(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
        if (cells.length > 0) {
            this.selectCellsForEvent(cells, mouseEvent);
        }
        else if (!this.graph.isSelectionEmpty() && !mouseEvent.isConsumed()) {
            this.graph.clearSelection();
        }
        return cells;
    }
    
    public void selectCellsForEvent(final Object[] cells, final MouseEvent mouseEvent) {
        if (this.isToggleEvent(mouseEvent)) {
            this.graph.getSelection().addCells(cells);
        }
        else {
            this.graph.getSelection().setCells(cells);
        }
    }
    
    public void selectCellForEvent(final Object selectionCell, final MouseEvent mouseEvent) {
        final boolean selected = this.graph.isSelected(selectionCell);
        if (this.isToggleEvent(mouseEvent)) {
            if (selected) {
                this.graph.getSelection().removeCell(selectionCell);
            }
            else {
                this.graph.getSelection().addCell(selectionCell);
            }
        }
        else if (!selected || this.graph.getSelectionCount() != 1) {
            this.graph.setSelectionCell(selectionCell);
        }
    }
    
    public boolean isSignificant(final double a, final double a2) {
        final int tolerance = this.graph.getTolerance();
        return Math.abs(a) > tolerance || Math.abs(a2) > tolerance;
    }
    
    public ImageIcon getFoldingIcon(final mxCellState mxCellState) {
        if (mxCellState != null) {
            final Object cell = mxCellState.getCell();
            final boolean cellCollapsed = this.graph.isCellCollapsed(cell);
            if ((cellCollapsed && this.graph.isExpandable(cell)) || (!cellCollapsed && this.graph.isCollapsable(cell))) {
                return cellCollapsed ? this.collapsedIcon : this.expandedIcon;
            }
        }
        return null;
    }
    
    public Rectangle getFoldingIconBounds(final mxCellState mxCellState, final ImageIcon imageIcon) {
        final boolean edge = this.graph.getModel().isEdge(mxCellState.getCell());
        final double scale = this.getGraph().getView().getScale();
        int x = (int)Math.round(mxCellState.getX() + 4.0 * scale);
        int y = (int)Math.round(mxCellState.getY() + 4.0 * scale);
        final int width = (int)Math.max(8.0, imageIcon.getIconWidth() * scale);
        final int height = (int)Math.max(8.0, imageIcon.getIconHeight() * scale);
        if (edge) {
            final mxPoint point = this.graph.getView().getPoint(mxCellState);
            x = (int)point.getX() - width / 2;
            y = (int)point.getY() - height / 2;
        }
        return new Rectangle(x, y, width, height);
    }
    
    public boolean hitsFoldingIcon(final Object o, final int x, final int y) {
        if (o != null) {
            final mxIGraphModel model = this.graph.getModel();
            final boolean edge = model.isEdge(o);
            if (this.foldingEnabled && (model.isVertex(o) || edge)) {
                final mxCellState state = this.graph.getView().getState(o);
                if (state != null) {
                    final ImageIcon foldingIcon = this.getFoldingIcon(state);
                    if (foldingIcon != null) {
                        return this.getFoldingIconBounds(state, foldingIcon).contains(x, y);
                    }
                }
            }
        }
        return false;
    }
    
    public void setToolTips(final boolean b) {
        if (b) {
            ToolTipManager.sharedInstance().registerComponent(this.control);
            ToolTipManager.sharedInstance().registerComponent(this.graphHandler);
        }
        else {
            ToolTipManager.sharedInstance().unregisterComponent(this.control);
            ToolTipManager.sharedInstance().unregisterComponent(this.graphHandler);
        }
    }
    
    public boolean isConnectable() {
        return this.connectionHandler.isEnabled();
    }
    
    public void setConnectable(final boolean enabled) {
        this.connectionHandler.setEnabled(enabled);
    }
    
    public boolean isPanning() {
        return this.panningHandler.isPanningEnabled();
    }
    
    public void setPanning(final boolean panningEnabled) {
        this.panningHandler.setPanningEnabled(panningEnabled);
    }
    
    public boolean isEscapeEnabled() {
        return this.escapeEnabled;
    }
    
    public void setEscapeEnabled(final boolean escapeEnabled) {
        this.firePropertyChange("escapeEnabled", this.escapeEnabled, this.escapeEnabled = escapeEnabled);
    }
    
    public boolean isInvokesStopCellEditing() {
        return this.invokesStopCellEditing;
    }
    
    public void setInvokesStopCellEditing(final boolean invokesStopCellEditing) {
        this.firePropertyChange("invokesStopCellEditing", this.invokesStopCellEditing, this.invokesStopCellEditing = invokesStopCellEditing);
    }
    
    public boolean isDragEnabled() {
        return this.dragEnabled;
    }
    
    public void setDragEnabled(final boolean dragEnabled) {
        this.firePropertyChange("dragEnabled", this.dragEnabled, this.dragEnabled = dragEnabled);
    }
    
    public boolean isGridVisible() {
        return this.gridVisible;
    }
    
    public void setGridVisible(final boolean gridVisible) {
        this.firePropertyChange("gridVisible", this.gridVisible, this.gridVisible = gridVisible);
    }
    
    public boolean isAntiAlias() {
        return this.antiAlias;
    }
    
    public void setAntiAlias(final boolean antiAlias) {
        this.firePropertyChange("antiAlias", this.antiAlias, this.antiAlias = antiAlias);
    }
    
    public boolean isTextAntiAlias() {
        return this.antiAlias;
    }
    
    public void setTextAntiAlias(final boolean textAntiAlias) {
        this.firePropertyChange("textAntiAlias", this.textAntiAlias, this.textAntiAlias = textAntiAlias);
    }
    
    public boolean isTripleBuffered() {
        return this.tripleBuffered;
    }
    
    public boolean isForceTripleBuffered() {
        return false;
    }
    
    public void setTripleBuffered(final boolean tripleBuffered) {
        this.firePropertyChange("tripleBuffered", this.tripleBuffered, this.tripleBuffered = tripleBuffered);
    }
    
    public Color getGridColor() {
        return this.gridColor;
    }
    
    public void setGridColor(final Color gridColor) {
        this.firePropertyChange("gridColor", this.gridColor, this.gridColor = gridColor);
    }
    
    public int getGridStyle() {
        return this.gridStyle;
    }
    
    public void setGridStyle(final int gridStyle) {
        this.firePropertyChange("gridStyle", this.gridStyle, this.gridStyle = gridStyle);
    }
    
    public boolean isDropEnabled() {
        return this.dropEnabled;
    }
    
    public void setDropEnabled(final boolean dropEnabled) {
        this.firePropertyChange("dropEnabled", this.dropEnabled, this.dropEnabled = dropEnabled);
    }
    
    public boolean isFoldingEnabled() {
        return this.foldingEnabled;
    }
    
    public void setFoldingEnabled(final boolean foldingEnabled) {
        this.firePropertyChange("foldingEnabled", this.foldingEnabled, this.foldingEnabled = foldingEnabled);
    }
    
    public boolean isEditEvent(final MouseEvent mouseEvent) {
        return mouseEvent != null && mouseEvent.getClickCount() == 2;
    }
    
    public boolean isToggleEvent(final MouseEvent mouseEvent) {
        return mouseEvent != null && mouseEvent.isControlDown();
    }
    
    public boolean isGridEnabledEvent(final MouseEvent mouseEvent) {
        return mouseEvent != null && !mouseEvent.isAltDown();
    }
    
    public boolean isPanningEvent(final MouseEvent mouseEvent) {
        return mouseEvent != null && mouseEvent.isAltDown();
    }
    
    public boolean isConstrainedEvent(final MouseEvent mouseEvent) {
        return mouseEvent != null && mouseEvent.isShiftDown();
    }
    
    public mxPoint snapScaledPoint(final mxPoint mxPoint) {
        return this.snapScaledPoint(mxPoint, 0.0, 0.0);
    }
    
    public mxPoint snapScaledPoint(final mxPoint mxPoint, final double n, final double n2) {
        if (mxPoint != null) {
            final double scale = this.graph.getView().getScale();
            final mxPoint translate = this.graph.getView().getTranslate();
            mxPoint.setX((this.graph.snap(mxPoint.getX() / scale - translate.getX() + n / scale) + translate.getX()) * scale - n);
            mxPoint.setY((this.graph.snap(mxPoint.getY() / scale - translate.getY() + n2 / scale) + translate.getY()) * scale - n2);
        }
        return mxPoint;
    }
    
    public int print(final Graphics graphics, final PageFormat pageFormat, final int n) {
        final double n2 = 1.0;
        final Dimension size = this.graph.getBounds().getRectangle().getSize();
        final int n3 = (int)(pageFormat.getWidth() * n2);
        final int n4 = (int)(pageFormat.getHeight() * n2);
        final int n5 = (int)Math.max(Math.ceil((size.width - 5) / (double)n3), 1.0);
        final int n6 = (int)Math.max(Math.ceil((size.height - 5) / (double)n4), 1.0);
        if (n < n5 * n6) {
            final AffineTransform transform = ((Graphics2D)graphics).getTransform();
            final RepaintManager currentManager = RepaintManager.currentManager(this);
            currentManager.setDoubleBufferingEnabled(false);
            int n7 = (int)(n % n5 * pageFormat.getWidth());
            int n8 = (int)(n % n6 * pageFormat.getHeight());
            if (this.pageVisible) {
                final mxPoint translate = this.graph.getView().getTranslate();
                final double scale = this.graph.getView().getScale();
                n7 += (int)Math.round(translate.getX() * scale);
                n8 += (int)Math.round(translate.getY() * scale);
            }
            graphics.translate(-n7, -n8);
            graphics.setClip(n7, n8, (int)(n7 + pageFormat.getWidth()), (int)(n8 + pageFormat.getHeight()));
            final mxGraphics2DCanvas graphicsCanvas = this.createGraphicsCanvas(0, 0, 0, 0, 1.0, null);
            graphicsCanvas.setGraphics((Graphics2D)graphics);
            this.graph.draw(graphicsCanvas);
            ((Graphics2D)graphics).setTransform(transform);
            currentManager.setDoubleBufferingEnabled(true);
            return 0;
        }
        return 1;
    }
    
    public mxGraphics2DCanvas createGraphicsCanvas(final int n, final int n2, final int n3, final int n4, final double n5, final Color color) {
        return new mxGraphics2DCanvas(n, n2, n3, n4, n5, color);
    }
    
    public mxCellHandler createHandler(final mxCellState mxCellState) {
        if (this.graph.getModel().isVertex(mxCellState.getCell())) {
            return new mxVertexHandler(this, mxCellState);
        }
        if (!this.graph.getModel().isEdge(mxCellState.getCell())) {
            return new mxCellHandler(this, mxCellState);
        }
        final mxEdgeStyle.mxEdgeStyleFunction value = mxCellState.getStyle().get(mxConstants.STYLE_EDGE);
        if (this.graph.isLoop(mxCellState) || (value != null && (value.equals("mxEdgeStyle.ElbowConnector") || value.equals("mxEdgeStyle.SideToSide") || value.equals("mxEdgeStyle.TopToBottom") || value == mxEdgeStyle.ElbowConnector || value == mxEdgeStyle.SideToSide || value == mxEdgeStyle.TopToBottom))) {
            return new mxElbowEdgeHandler(this, mxCellState);
        }
        return new mxEdgeHandler(this, mxCellState);
    }
    
    public Component[] createComponents(final mxCellState mxCellState) {
        return null;
    }
    
    public void insertComponent(final mxCellState mxCellState, final Component comp) {
        this.getControl().add(comp, 0);
    }
    
    public void removeComponent(final Component comp, final Object o) {
        if (comp.getParent() != null) {
            comp.getParent().remove(comp);
        }
    }
    
    public void updateComponent(final mxCellState mxCellState, final Component component) {
        component.setBounds((int)mxCellState.getX(), (int)mxCellState.getY(), (int)mxCellState.getWidth(), (int)mxCellState.getHeight());
    }
    
    public void update() {
        final Object root = this.graph.getModel().getRoot();
        final Hashtable updateComponents = this.updateComponents(root);
        this.removeAllComponents(this.components);
        this.components = updateComponents;
        if (!this.overlays.isEmpty()) {
            final Hashtable updateOverlays = this.updateOverlays(root);
            this.removeAllOverlays(this.overlays);
            this.overlays = updateOverlays;
        }
    }
    
    public void removeAllComponents(final Hashtable hashtable) {
        for (final Map.Entry<K, Component[]> entry : hashtable.entrySet()) {
            final Component[] array = entry.getValue();
            for (int i = 0; i < array.length; ++i) {
                this.removeComponent(array[i], entry.getKey());
            }
        }
    }
    
    public void removeAllOverlays(final Hashtable hashtable) {
        for (final Map.Entry<K, mxIOverlay[]> entry : hashtable.entrySet()) {
            final mxIOverlay[] array = entry.getValue();
            for (int i = 0; i < array.length; ++i) {
                this.removeOverlayComponent(array[i], entry.getKey());
            }
        }
    }
    
    public Hashtable updateComponents(final Object o) {
        final Hashtable<Object, Component[]> hashtable = new Hashtable<Object, Component[]>();
        Component[] components = this.components.remove(o);
        final mxCellState state = this.getGraph().getView().getState(o);
        if (state != null) {
            if (components == null) {
                components = this.createComponents(state);
                if (components != null) {
                    for (int i = 0; i < components.length; ++i) {
                        this.insertComponent(state, components[i]);
                    }
                }
            }
            if (components != null) {
                hashtable.put(o, components);
                for (int j = 0; j < components.length; ++j) {
                    this.updateComponent(state, components[j]);
                }
            }
        }
        for (int childCount = this.getGraph().getModel().getChildCount(o), k = 0; k < childCount; ++k) {
            hashtable.putAll(this.updateComponents(this.getGraph().getModel().getChildAt(o, k)));
        }
        return hashtable;
    }
    
    public mxIOverlay addOverlay(final Object key, final mxIOverlay mxIOverlay) {
        final mxIOverlay[] overlays = this.getOverlays(key);
        mxIOverlay[] value;
        if (overlays == null) {
            value = new mxIOverlay[] { mxIOverlay };
        }
        else {
            final List<mxIOverlay> list = Arrays.asList(overlays);
            list.add(mxIOverlay);
            value = (mxIOverlay[])list.toArray();
        }
        this.overlays.put(key, value);
        final mxCellState state = this.graph.getView().getState(key);
        if (state != null) {
            this.updateOverlayComponent(state, mxIOverlay);
        }
        this.eventSource.fireEvent("addoverlay", new Object[] { key, mxIOverlay });
        return mxIOverlay;
    }
    
    public mxIOverlay[] getOverlays(final Object key) {
        return this.overlays.get(key);
    }
    
    public mxIOverlay removeOverlay(final Object key, final mxIOverlay mxIOverlay) {
        if (mxIOverlay == null) {
            this.removeOverlays(key);
        }
        else {
            final mxIOverlay[] overlays = this.getOverlays(key);
            if (overlays != null) {
                final List<mxIOverlay> list = Arrays.asList(overlays);
                if (list.remove(mxIOverlay)) {
                    this.removeOverlayComponent(mxIOverlay, key);
                }
                this.overlays.put(key, list.toArray());
            }
        }
        return mxIOverlay;
    }
    
    public mxIOverlay[] removeOverlays(final Object key) {
        final mxIOverlay[] array = this.overlays.remove(key);
        if (array != null) {
            for (int i = 0; i < array.length; ++i) {
                this.removeOverlayComponent(array[i], key);
            }
        }
        return array;
    }
    
    protected void removeOverlayComponent(final mxIOverlay mxIOverlay, final Object o) {
        if (mxIOverlay instanceof Component) {
            final Component comp = (Component)mxIOverlay;
            if (comp.getParent() != null) {
                comp.getParent().remove(comp);
                this.eventSource.fireEvent("removeoverlay", new Object[] { o, mxIOverlay });
            }
        }
    }
    
    protected void updateOverlayComponent(final mxCellState mxCellState, final mxIOverlay mxIOverlay) {
        if (mxIOverlay instanceof Component) {
            final Component comp = (Component)mxIOverlay;
            if (comp.getParent() == null) {
                this.getControl().add(comp, 0);
            }
            final mxRectangle bounds = mxIOverlay.getBounds(mxCellState);
            if (bounds != null) {
                comp.setBounds(bounds.getRectangle());
                comp.setVisible(true);
            }
            else {
                comp.setVisible(false);
            }
        }
    }
    
    public void clearOverlays() {
        this.clearOverlays(null);
    }
    
    public void clearOverlays(Object root) {
        final mxIGraphModel model = this.graph.getModel();
        if (root == null) {
            root = model.getRoot();
        }
        this.removeOverlays(root);
        for (int childCount = model.getChildCount(root), i = 0; i < childCount; ++i) {
            this.clearOverlays(model.getChildAt(root, i));
        }
    }
    
    public mxIOverlay setWarning(final Object o, final String s) {
        return this.setWarning(o, s, null, false);
    }
    
    public mxIOverlay setWarning(final Object o, final String s, final ImageIcon imageIcon) {
        return this.setWarning(o, s, imageIcon, false);
    }
    
    public mxIOverlay setWarning(final Object o, final String s, ImageIcon imageIcon, final boolean b) {
        if (s != null && s.length() > 0) {
            imageIcon = ((imageIcon != null) ? imageIcon : this.warningIcon);
            final mxOverlay mxOverlay = new mxOverlay(imageIcon, s);
            if (b) {
                mxOverlay.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mousePressed(final MouseEvent mouseEvent) {
                        mxGraphComponent.this.getGraph().setSelectionCell(o);
                    }
                });
                mxOverlay.setCursor(new Cursor(12));
            }
            return this.addOverlay(o, mxOverlay);
        }
        this.removeOverlays(o);
        return null;
    }
    
    public Hashtable updateOverlays(final Object o) {
        final Hashtable<Object, mxIOverlay[]> hashtable = new Hashtable<Object, mxIOverlay[]>();
        final mxIOverlay[] value = this.overlays.remove(o);
        final mxCellState state = this.getGraph().getView().getState(o);
        if (value != null) {
            if (state != null) {
                for (int i = 0; i < value.length; ++i) {
                    this.updateOverlayComponent(state, value[i]);
                }
            }
            else {
                for (int j = 0; j < value.length; ++j) {
                    this.removeOverlayComponent(value[j], o);
                }
            }
            hashtable.put(o, value);
        }
        for (int childCount = this.getGraph().getModel().getChildCount(o), k = 0; k < childCount; ++k) {
            hashtable.putAll(this.updateOverlays(this.getGraph().getModel().getChildAt(o, k)));
        }
        return hashtable;
    }
    
    protected void paintBackground(final Graphics graphics) {
        final Rectangle clipBounds = graphics.getClipBounds();
        final Rectangle paintBackgroundPage = this.paintBackgroundPage(graphics, 1.0);
        if (this.isPageVisible()) {
            graphics.clipRect(paintBackgroundPage.x + 1, paintBackgroundPage.y + 1, paintBackgroundPage.width - 1, paintBackgroundPage.height - 1);
        }
        this.paintBackgroundImage(graphics, 1.0);
        this.paintGrid(graphics);
        graphics.setClip(clipBounds);
    }
    
    protected void paintBackgroundImage(final Graphics graphics, final double n) {
        if (this.backgroundImage != null) {
            final mxPoint translate = this.graph.getView().getTranslate();
            final double n2 = this.graph.getView().getScale() * n;
            graphics.drawImage(this.backgroundImage.getImage(), (int)(translate.getX() * n2), (int)(translate.getY() * n2), (int)(this.backgroundImage.getIconWidth() * n2), (int)(this.backgroundImage.getIconHeight() * n2), this);
        }
    }
    
    protected Rectangle paintBackgroundPage(final Graphics graphics, final double n) {
        final mxPoint translate = this.graph.getView().getTranslate();
        final double n2 = this.graph.getView().getScale() * n;
        final int n3 = (int)Math.round(translate.getX() * n2) - 1;
        final int n4 = (int)Math.round(translate.getY() * n2) - 1;
        final int n5 = (int)Math.round(this.pageFormat.getWidth() * this.pageScale * n2) + 2;
        final int n6 = (int)Math.round(this.pageFormat.getHeight() * this.pageScale * n2) + 2;
        final int n7 = 1;
        final int n8 = 1;
        if (this.isPageVisible()) {
            graphics.setColor(this.pageBackgroundColor);
            mxUtils.fillClippedRect(graphics, 0, 0, this.getControl().getWidth(), this.getControl().getHeight());
            graphics.setColor(this.pageShadowColor);
            mxUtils.fillClippedRect(graphics, n3 + n7 * n5, n4 + 6, 6, n8 * n6);
            mxUtils.fillClippedRect(graphics, n3 + 8, n4 + n8 * n6, n7 * n5 - 2, 6);
            graphics.setColor(this.getBackground());
            mxUtils.fillClippedRect(graphics, n3 + 1, n4 + 1, n7 * n5, n8 * n6);
            graphics.setColor(Color.black);
            graphics.drawRect(n3, n4, n7 * n5, n8 * n6);
        }
        if (this.isPageBreakVisible() && (n7 > 1 || n8 > 1)) {
            final Graphics2D graphics2D = (Graphics2D)graphics;
            final Stroke stroke = graphics2D.getStroke();
            graphics2D.setStroke(new BasicStroke(1.0f, 0, 0, 10.0f, new float[] { 1.0f, 2.0f }, 0.0f));
            graphics2D.setColor(Color.darkGray);
            for (int i = 1; i <= n7; ++i) {
                graphics2D.drawLine(n3 + i * n5, n4 + 1, n3 + i * n5, n4 + n8 * n6);
            }
            for (int j = 1; j <= n8; ++j) {
                graphics2D.drawLine(n3 + 1, n4 + j * n6, n3 + n7 * n5, n4 + j * n6);
            }
            graphics2D.setStroke(stroke);
        }
        return new Rectangle(n3, n4, n7 * n5, n8 * n6);
    }
    
    protected void paintGrid(final Graphics graphics) {
        if (this.isGridVisible()) {
            graphics.setColor(this.getGridColor());
            Rectangle rectangle = graphics.getClipBounds();
            if (rectangle == null) {
                rectangle = this.getControl().getBounds();
            }
            final double x = rectangle.getX();
            final double y = rectangle.getY();
            final double n = x + rectangle.getWidth();
            final double n2 = y + rectangle.getHeight();
            final int gridStyle = this.getGridStyle();
            int gridSize;
            final int n3 = gridSize = this.graph.getGridSize();
            if (gridStyle == 1 || gridStyle == 0) {
                gridSize /= 2;
            }
            final mxPoint translate = this.graph.getView().getTranslate();
            final double scale = this.graph.getView().getScale();
            final double n4 = translate.getX() * scale;
            final double n5 = translate.getY() * scale;
            double n6 = n3 * scale;
            if (n6 < gridSize) {
                n6 *= (int)Math.round(Math.ceil(gridSize / n6) / 2.0) * 2;
            }
            final double n7 = Math.floor((x - n4) / n6) * n6 + n4;
            final double n8 = Math.ceil(n / n6) * n6;
            final double n9 = Math.floor((y - n5) / n6) * n6 + n5;
            final double n10 = Math.ceil(n2 / n6) * n6;
            switch (gridStyle) {
                case 1: {
                    final int n11 = (n6 > 16.0) ? 2 : 1;
                    for (double a = n7; a <= n8; a += n6) {
                        double a2;
                        for (double n12 = n9; n12 <= n10; n12 = a2 + n6) {
                            a = Math.round((a - n4) / n6) * n6 + n4;
                            a2 = Math.round((n12 - n5) / n6) * n6 + n5;
                            final int n13 = (int)Math.round(a);
                            final int n14 = (int)Math.round(a2);
                            graphics.drawLine(n13 - n11, n14, n13 + n11, n14);
                            graphics.drawLine(n13, n14 - n11, n13, n14 + n11);
                        }
                    }
                    break;
                }
                case 2: {
                    final double a3 = n8 + (int)Math.ceil(n6);
                    final double a4 = n10 + (int)Math.ceil(n6);
                    final int n15 = (int)Math.round(n7);
                    final int n16 = (int)Math.round(a3);
                    final int n17 = (int)Math.round(n9);
                    final int n18 = (int)Math.round(a4);
                    double a5;
                    for (double n19 = n7; n19 <= a3; n19 = a5 + n6) {
                        a5 = Math.round((n19 - n4) / n6) * n6 + n4;
                        final int n20 = (int)Math.round(a5);
                        graphics.drawLine(n20, n17, n20, n18);
                    }
                    double a6;
                    for (double n21 = n9; n21 <= a4; n21 = a6 + n6) {
                        a6 = Math.round((n21 - n5) / n6) * n6 + n5;
                        final int n22 = (int)Math.round(a6);
                        graphics.drawLine(n15, n22, n16, n22);
                    }
                    break;
                }
                case 3: {
                    final Graphics2D graphics2D = (Graphics2D)graphics;
                    final Stroke stroke = graphics2D.getStroke();
                    final double a7 = n8 + (int)Math.ceil(n6);
                    final double a8 = n10 + (int)Math.ceil(n6);
                    final int n23 = (int)Math.round(n7);
                    final int n24 = (int)Math.round(a7);
                    final int n25 = (int)Math.round(n9);
                    final int n26 = (int)Math.round(a8);
                    final Stroke[] array = { new BasicStroke(1.0f, 0, 0, 1.0f, new float[] { 3.0f, 1.0f }, (float)(n25 % 4)), new BasicStroke(1.0f, 0, 0, 1.0f, new float[] { 2.0f, 2.0f }, (float)(n25 % 4)), new BasicStroke(1.0f, 0, 0, 1.0f, new float[] { 1.0f, 1.0f }, 0.0f), new BasicStroke(1.0f, 0, 0, 1.0f, new float[] { 2.0f, 2.0f }, (float)(n25 % 4)) };
                    for (double n27 = n7; n27 <= a7; n27 += n6) {
                        graphics2D.setStroke(array[(int)(n27 / n6) % array.length]);
                        final int n28 = (int)Math.round(Math.round((n27 - n4) / n6) * n6 + n4);
                        graphics.drawLine(n28, n25, n28, n26);
                    }
                    final Stroke[] array2 = { new BasicStroke(1.0f, 0, 0, 1.0f, new float[] { 3.0f, 1.0f }, (float)(n23 % 4)), new BasicStroke(1.0f, 0, 0, 1.0f, new float[] { 2.0f, 2.0f }, (float)(n23 % 4)), new BasicStroke(1.0f, 0, 0, 1.0f, new float[] { 1.0f, 1.0f }, 0.0f), new BasicStroke(1.0f, 0, 0, 1.0f, new float[] { 2.0f, 2.0f }, (float)(n23 % 4)) };
                    double a9;
                    for (double n29 = n9; n29 <= a8; n29 = a9 + n6) {
                        graphics2D.setStroke(array2[(int)(n29 / n6) % array2.length]);
                        a9 = Math.round((n29 - n5) / n6) * n6 + n5;
                        final int n30 = (int)Math.round(a9);
                        graphics.drawLine(n23, n30, n24, n30);
                    }
                    graphics2D.setStroke(stroke);
                    break;
                }
                default: {
                    for (double a10 = n7; a10 <= n8; a10 += n6) {
                        double a11;
                        for (double n31 = n9; n31 <= n10; n31 = a11 + n6) {
                            a10 = Math.round((a10 - n4) / n6) * n6 + n4;
                            a11 = Math.round((n31 - n5) / n6) * n6 + n5;
                            final int n32 = (int)Math.round(a10);
                            final int n33 = (int)Math.round(a11);
                            graphics.drawLine(n32, n33, n32, n33);
                        }
                    }
                    break;
                }
            }
        }
    }
    
    public boolean isEventsEnabled() {
        return this.eventSource.isEventsEnabled();
    }
    
    public void setEventsEnabled(final boolean eventsEnabled) {
        this.eventSource.setEventsEnabled(eventsEnabled);
    }
    
    public void addListener(final String s, final mxEventSource.mxEventListener mxEventListener) {
        this.eventSource.addListener(s, mxEventListener);
    }
    
    public void removeListener(final mxEventSource.mxEventListener mxEventListener) {
        this.eventSource.removeListener(mxEventListener);
    }
    
    public void removeListener(final String s, final mxEventSource.mxEventListener mxEventListener) {
        this.eventSource.removeListener(s, mxEventListener);
    }
    
    static {
        mxGraphComponent.DEFAULT_EXPANDED_ICON = null;
        mxGraphComponent.DEFAULT_COLLAPSED_ICON = null;
        mxGraphComponent.DEFAULT_WARNING_ICON = null;
        mxGraphComponent.DEFAULT_EXPANDED_ICON = new ImageIcon(mxGraphComponent.class.getResource("/com/mxgraph/swing/images/expanded.gif"));
        mxGraphComponent.DEFAULT_COLLAPSED_ICON = new ImageIcon(mxGraphComponent.class.getResource("/com/mxgraph/swing/images/collapsed.gif"));
        mxGraphComponent.DEFAULT_WARNING_ICON = new ImageIcon(mxGraphComponent.class.getResource("/com/mxgraph/swing/images/warning.gif"));
    }
    
    public class mxGraphControl extends JComponent
    {
        protected transient mxGraphics2DCanvas canvas;
        
        public mxGraphControl() {
            this.refresh();
        }
        
        public mxGraphComponent getGraphContainer() {
            return mxGraphComponent.this;
        }
        
        public mxGraphics2DCanvas getCanvas() {
            return this.canvas;
        }
        
        public mxGraphics2DCanvas getCanvas(final boolean b) {
            if (this.canvas == null) {
                this.canvas = this.createCanvas();
                if (this.canvas.getImage() != null) {
                    this.draw(this.canvas);
                }
            }
            return this.canvas;
        }
        
        @Override
        public String getToolTipText(final MouseEvent event) {
            String s = mxGraphComponent.this.graphHandler.getHandleToolTipText(event);
            if (s == null) {
                final Object cell = mxGraphComponent.this.graph.getCellAt(event.getX(), event.getY());
                if (cell != null) {
                    if (mxGraphComponent.this.hitsFoldingIcon(cell, event.getX(), event.getY())) {
                        s = mxResources.get("collapse-expand");
                    }
                    else {
                        s = mxGraphComponent.this.graph.getToolTipForCell(cell);
                    }
                }
            }
            if (s != null && s.length() > 0) {
                return s;
            }
            return super.getToolTipText(event);
        }
        
        protected mxGraphics2DCanvas createCanvas() {
            final mxRectangle bounds = mxGraphComponent.this.graph.getBounds();
            int n = 0;
            int n2 = 0;
            if (mxGraphComponent.this.tripleBuffered || mxGraphComponent.this.isForceTripleBuffered()) {
                final Rectangle rectangle = bounds.getRectangle();
                n = rectangle.x + rectangle.width + 1;
                n2 = rectangle.y + rectangle.height + 1;
            }
            final mxGraphics2DCanvas graphicsCanvas = mxGraphComponent.this.createGraphicsCanvas(0, 0, n, n2, mxGraphComponent.this.graph.getView().getScale(), null);
            if (graphicsCanvas.getGraphics() != null) {
                graphicsCanvas.setAntiAlias(mxGraphComponent.this.antiAlias);
                graphicsCanvas.setTextAntiAlias(mxGraphComponent.this.textAntiAlias);
            }
            return graphicsCanvas;
        }
        
        public void refresh() {
            this.refresh(null);
        }
        
        public void refresh(final mxRectangle mxRectangle) {
            if (this.canvas != null) {
                if ((!mxGraphComponent.this.tripleBuffered && this.canvas.getImage() != null) || mxRectangle == null || this.canvas.getImage() == null || this.canvas.getWidth() < mxRectangle.getX() + mxRectangle.getWidth() || this.canvas.getHeight() < mxRectangle.getY() + mxRectangle.getHeight()) {
                    this.canvas.destroy();
                    this.canvas = null;
                    this.repaint(mxGraphComponent.this.getViewport().getViewRect());
                }
                else {
                    final Rectangle rectangle2;
                    final Rectangle rectangle = rectangle2 = mxRectangle.getRectangle();
                    ++rectangle2.width;
                    final Rectangle rectangle3 = rectangle;
                    ++rectangle3.height;
                    this.canvas.clear(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
                    this.canvas.setClip(rectangle);
                    this.draw(this.canvas);
                    this.canvas.clearClip();
                    this.repaint(rectangle);
                }
            }
            this.updatePreferredSize();
        }
        
        protected void updatePreferredSize() {
            final double scale = mxGraphComponent.this.graph.getView().getScale();
            Dimension scaledPreferredSizeForGraph;
            if (mxGraphComponent.this.preferPageSize || mxGraphComponent.this.pageVisible) {
                final Dimension preferredSizeForPage = mxGraphComponent.this.getPreferredSizeForPage();
                scaledPreferredSizeForGraph = new Dimension((int)(preferredSizeForPage.width * scale), (int)(preferredSizeForPage.height * scale));
            }
            else {
                scaledPreferredSizeForGraph = mxGraphComponent.this.getScaledPreferredSizeForGraph();
            }
            final mxRectangle minimumContainerSize = mxGraphComponent.this.graph.getMinimumContainerSize();
            if (minimumContainerSize != null) {
                scaledPreferredSizeForGraph.width = (int)Math.max(scaledPreferredSizeForGraph.width, Math.round(minimumContainerSize.getWidth() * scale));
                scaledPreferredSizeForGraph.height = (int)Math.max(scaledPreferredSizeForGraph.height, Math.round(minimumContainerSize.getHeight() * scale));
            }
            final mxRectangle maximumContainerSize = mxGraphComponent.this.graph.getMaximumContainerSize();
            if (maximumContainerSize != null) {
                scaledPreferredSizeForGraph.width = (int)Math.min(scaledPreferredSizeForGraph.width, Math.round(maximumContainerSize.getWidth() * scale));
                scaledPreferredSizeForGraph.height = (int)Math.min(scaledPreferredSizeForGraph.height, Math.round(maximumContainerSize.getHeight() * scale));
            }
            if (!this.getPreferredSize().equals(scaledPreferredSizeForGraph)) {
                this.setPreferredSize(scaledPreferredSizeForGraph);
                this.setMinimumSize(scaledPreferredSizeForGraph);
                this.revalidate();
            }
        }
        
        public void paintComponent(final Graphics g) {
            super.paintComponent(g);
            mxGraphComponent.this.paintBackground(g);
            this.canvas = this.getCanvas(true);
            if (this.canvas.getImage() != null) {
                mxUtils.drawImageClip(g, this.canvas.getImage(), this);
            }
            else {
                final Graphics2D graphics = (Graphics2D)g;
                final RenderingHints renderingHints = graphics.getRenderingHints();
                try {
                    this.canvas.setGraphics(graphics);
                    this.canvas.setAntiAlias(mxGraphComponent.this.antiAlias);
                    this.canvas.setTextAntiAlias(mxGraphComponent.this.textAntiAlias);
                    this.canvas.setClip(g.getClipBounds());
                    this.draw(this.canvas);
                }
                finally {
                    this.canvas.clearClip();
                    graphics.setRenderingHints(renderingHints);
                    this.canvas.setGraphics(null);
                }
            }
        }
        
        public void draw(final mxICanvas mxICanvas) {
            this.drawCell(mxICanvas, mxGraphComponent.this.graph.getModel().getRoot());
        }
        
        protected String getDisplayLabelForCell(final Object o) {
            return (o != mxGraphComponent.this.cellEditor.getEditingCell()) ? mxGraphComponent.this.graph.getLabel(o) : null;
        }
        
        protected boolean isCellDisplayable(final Object o) {
            return o != mxGraphComponent.this.graph.getView().getCurrentRoot() && o != mxGraphComponent.this.graph.getModel().getRoot();
        }
        
        public void drawCell(final mxICanvas mxICanvas, final Object o) {
            mxCellState drawCellWithLabel = null;
            if (this.isCellDisplayable(o)) {
                drawCellWithLabel = mxGraphComponent.this.graph.drawCellWithLabel(mxICanvas, o, this.getDisplayLabelForCell(o));
            }
            final boolean keepEdgesInBackground = mxGraphComponent.this.graph.isKeepEdgesInBackground();
            final boolean keepEdgesInForeground = mxGraphComponent.this.graph.isKeepEdgesInForeground();
            if (keepEdgesInBackground) {
                this.drawChildren(o, true, false);
            }
            this.drawChildren(o, !keepEdgesInBackground && !keepEdgesInForeground, true);
            if (keepEdgesInForeground) {
                this.drawChildren(o, true, false);
            }
            if (drawCellWithLabel != null) {
                this.cellDrawn(mxICanvas, drawCellWithLabel);
            }
        }
        
        protected void drawChildren(final Object o, final boolean b, final boolean b2) {
            final mxIGraphModel model = mxGraphComponent.this.graph.getModel();
            for (int childCount = model.getChildCount(o), i = 0; i < childCount; ++i) {
                final boolean edge = model.isEdge(model.getChildAt(o, i));
                if ((b2 && !edge) || (b && edge)) {
                    this.drawCell(this.canvas, model.getChildAt(o, i));
                }
            }
        }
        
        protected void cellDrawn(final mxICanvas mxICanvas, final mxCellState mxCellState) {
            if (mxICanvas instanceof mxGraphics2DCanvas) {
                final mxIGraphModel model = mxGraphComponent.this.graph.getModel();
                final Graphics2D graphics = ((mxGraphics2DCanvas)mxICanvas).getGraphics();
                final boolean edge = model.isEdge(mxCellState.getCell());
                if ((model.isVertex(mxCellState.getCell()) || edge) && mxGraphComponent.this.foldingEnabled) {
                    final ImageIcon foldingIcon = mxGraphComponent.this.getFoldingIcon(mxCellState);
                    if (foldingIcon != null) {
                        final Rectangle foldingIconBounds = mxGraphComponent.this.getFoldingIconBounds(mxCellState, foldingIcon);
                        graphics.drawImage(foldingIcon.getImage(), foldingIconBounds.x, foldingIconBounds.y, foldingIconBounds.width, foldingIconBounds.height, this);
                    }
                }
            }
        }
    }
}
