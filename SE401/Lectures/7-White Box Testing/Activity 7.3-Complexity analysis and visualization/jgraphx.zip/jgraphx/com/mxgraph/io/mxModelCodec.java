// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.io;

import org.w3c.dom.Element;
import com.mxgraph.model.mxICell;
import org.w3c.dom.Node;
import java.util.Map;
import com.mxgraph.model.mxGraphModel;

public class mxModelCodec extends mxObjectCodec
{
    public mxModelCodec() {
        this(new mxGraphModel());
    }
    
    public mxModelCodec(final Object o) {
        this(o, null, null, null);
    }
    
    public mxModelCodec(final Object o, final String[] array, final String[] array2, final Map map) {
        super(o, array, array2, map);
    }
    
    @Override
    public Node encode(final mxCodec mxCodec, final Object o) {
        Node element = null;
        if (o instanceof mxGraphModel) {
            final mxGraphModel mxGraphModel = (mxGraphModel)o;
            element = mxCodec.document.createElement(mxCodecRegistry.getName(o.getClass()));
            final Element element2 = mxCodec.document.createElement("root");
            mxCodec.encodeCell((mxICell)mxGraphModel.getRoot(), element2, true);
            element.appendChild(element2);
        }
        return element;
    }
    
    @Override
    public Node beforeDecode(final mxCodec mxCodec, final Node node, final Object o) {
        if (node instanceof Element) {
            final Element element = (Element)node;
            mxGraphModel mxGraphModel;
            if (o instanceof mxGraphModel) {
                mxGraphModel = (mxGraphModel)o;
            }
            else {
                mxGraphModel = new mxGraphModel();
            }
            final Node item = element.getElementsByTagName("root").item(0);
            Object root = null;
            if (item != null) {
                for (Node node2 = item.getFirstChild(); node2 != null; node2 = node2.getNextSibling()) {
                    final mxICell decodeCell = mxCodec.decodeCell(node2, true);
                    if (decodeCell != null && decodeCell.getParent() == null) {
                        root = decodeCell;
                    }
                }
                item.getParentNode().removeChild(item);
            }
            if (root != null) {
                mxGraphModel.setRoot(root);
            }
        }
        return node;
    }
}
