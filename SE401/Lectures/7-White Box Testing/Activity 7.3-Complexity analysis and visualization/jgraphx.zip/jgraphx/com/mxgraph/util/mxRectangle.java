// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.util;

import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

public class mxRectangle extends mxPoint
{
    protected double width;
    protected double height;
    
    public mxRectangle() {
        this(0.0, 0.0, 0.0, 0.0);
    }
    
    public mxRectangle(final mxRectangle mxRectangle) {
        this(mxRectangle.getX(), mxRectangle.getY(), mxRectangle.getWidth(), mxRectangle.getHeight());
    }
    
    public mxRectangle(final Rectangle2D rectangle2D) {
        this(rectangle2D.getX(), rectangle2D.getY(), rectangle2D.getWidth(), rectangle2D.getHeight());
    }
    
    public mxRectangle(final double n, final double n2, final double width, final double height) {
        super(n, n2);
        this.setWidth(width);
        this.setHeight(height);
    }
    
    public double getWidth() {
        return this.width;
    }
    
    public void setWidth(final double width) {
        this.width = width;
    }
    
    public double getHeight() {
        return this.height;
    }
    
    public void setHeight(final double height) {
        this.height = height;
    }
    
    public void add(final mxRectangle mxRectangle) {
        if (mxRectangle != null) {
            final double min = Math.min(this.x, mxRectangle.x);
            final double min2 = Math.min(this.y, mxRectangle.y);
            final double max = Math.max(this.x + this.width, mxRectangle.x + mxRectangle.width);
            final double max2 = Math.max(this.y + this.height, mxRectangle.y + mxRectangle.height);
            this.x = min;
            this.y = min2;
            this.width = max - min;
            this.height = max2 - min2;
        }
    }
    
    public void grow(final double n) {
        this.x -= n;
        this.y -= n;
        this.width += 2.0 * n;
        this.height += 2.0 * n;
    }
    
    public Rectangle getRectangle() {
        final int x = (int)Math.round(this.x);
        final int y = (int)Math.round(this.y);
        return new Rectangle(x, y, (int)Math.round(this.width - x + this.x), (int)Math.round(this.height - y + this.y));
    }
    
    @Override
    public Object clone() {
        return new mxRectangle(this);
    }
}
