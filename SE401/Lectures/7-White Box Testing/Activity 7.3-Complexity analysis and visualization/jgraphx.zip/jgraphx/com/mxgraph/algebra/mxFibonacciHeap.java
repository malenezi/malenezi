// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.algebra;

import java.util.Hashtable;
import java.util.Map;

public class mxFibonacciHeap
{
    protected Map nodes;
    protected Node min;
    protected int size;
    
    public mxFibonacciHeap() {
        this.nodes = new Hashtable();
    }
    
    public Node getNode(final Object o, final boolean b) {
        Node node = this.nodes.get(o);
        if (node == null && b) {
            node = new Node(o, Double.MAX_VALUE);
            this.nodes.put(o, node);
            this.insert(node, node.getKey());
        }
        return node;
    }
    
    public boolean isEmpty() {
        return this.min == null;
    }
    
    public void decreaseKey(final Node min, final double key) {
        if (key > min.key) {
            throw new IllegalArgumentException("decreaseKey() got larger key value");
        }
        min.key = key;
        final Node parent = min.parent;
        if (parent != null && min.key < parent.key) {
            this.cut(min, parent);
            this.cascadingCut(parent);
        }
        if (this.min == null || min.key < this.min.key) {
            this.min = min;
        }
    }
    
    public void delete(final Node node) {
        this.decreaseKey(node, Double.NEGATIVE_INFINITY);
        this.removeMin();
    }
    
    public void insert(final Node node, final double key) {
        node.key = key;
        if (this.min != null) {
            node.left = this.min;
            node.right = this.min.right;
            this.min.right = node;
            node.right.left = node;
            if (key < this.min.key) {
                this.min = node;
            }
        }
        else {
            this.min = node;
        }
        ++this.size;
    }
    
    public Node min() {
        return this.min;
    }
    
    public Node removeMin() {
        final Node min = this.min;
        if (min != null) {
            int i = min.degree;
            Node child = min.child;
            while (i > 0) {
                final Node right = child.right;
                child.left.right = child.right;
                child.right.left = child.left;
                child.left = this.min;
                child.right = this.min.right;
                this.min.right = child;
                child.right.left = child;
                child.parent = null;
                child = right;
                --i;
            }
            min.left.right = min.right;
            min.right.left = min.left;
            if (min == min.right) {
                this.min = null;
            }
            else {
                this.min = min.right;
                this.consolidate();
            }
            --this.size;
        }
        return min;
    }
    
    public int size() {
        return this.size;
    }
    
    public static mxFibonacciHeap union(final mxFibonacciHeap mxFibonacciHeap, final mxFibonacciHeap mxFibonacciHeap2) {
        final mxFibonacciHeap mxFibonacciHeap3 = new mxFibonacciHeap();
        if (mxFibonacciHeap != null && mxFibonacciHeap2 != null) {
            mxFibonacciHeap3.min = mxFibonacciHeap.min;
            if (mxFibonacciHeap3.min != null) {
                if (mxFibonacciHeap2.min != null) {
                    mxFibonacciHeap3.min.right.left = mxFibonacciHeap2.min.left;
                    mxFibonacciHeap2.min.left.right = mxFibonacciHeap3.min.right;
                    mxFibonacciHeap3.min.right = mxFibonacciHeap2.min;
                    mxFibonacciHeap2.min.left = mxFibonacciHeap3.min;
                    if (mxFibonacciHeap2.min.key < mxFibonacciHeap.min.key) {
                        mxFibonacciHeap3.min = mxFibonacciHeap2.min;
                    }
                }
            }
            else {
                mxFibonacciHeap3.min = mxFibonacciHeap2.min;
            }
            mxFibonacciHeap3.size = mxFibonacciHeap.size + mxFibonacciHeap2.size;
        }
        return mxFibonacciHeap3;
    }
    
    protected void cascadingCut(final Node node) {
        final Node parent = node.parent;
        if (parent != null) {
            if (!node.mark) {
                node.mark = true;
            }
            else {
                this.cut(node, parent);
                this.cascadingCut(parent);
            }
        }
    }
    
    protected void consolidate() {
        final int n = this.size + 1;
        final Node[] array = new Node[n];
        for (int i = 0; i < n; ++i) {
            array[i] = null;
        }
        int j = 0;
        Node node = this.min;
        if (node != null) {
            ++j;
            for (node = node.right; node != this.min; node = node.right) {
                ++j;
            }
        }
        while (j > 0) {
            int degree = node.degree;
            final Node right = node.right;
            while (array[degree] != null) {
                Node node2 = array[degree];
                if (node.key > node2.key) {
                    final Node node3 = node2;
                    node2 = node;
                    node = node3;
                }
                this.link(node2, node);
                array[degree] = null;
                ++degree;
            }
            array[degree] = node;
            node = right;
            --j;
        }
        this.min = null;
        for (int k = 0; k < n; ++k) {
            if (array[k] != null) {
                if (this.min != null) {
                    array[k].left.right = array[k].right;
                    array[k].right.left = array[k].left;
                    array[k].left = this.min;
                    array[k].right = this.min.right;
                    this.min.right = array[k];
                    array[k].right.left = array[k];
                    if (array[k].key < this.min.key) {
                        this.min = array[k];
                    }
                }
                else {
                    this.min = array[k];
                }
            }
        }
    }
    
    protected void cut(final Node node, final Node node2) {
        node.left.right = node.right;
        node.right.left = node.left;
        --node2.degree;
        if (node2.child == node) {
            node2.child = node.right;
        }
        if (node2.degree == 0) {
            node2.child = null;
        }
        node.left = this.min;
        node.right = this.min.right;
        this.min.right = node;
        node.right.left = node;
        node.parent = null;
        node.mark = false;
    }
    
    protected void link(final Node left, final Node parent) {
        left.left.right = left.right;
        left.right.left = left.left;
        left.parent = parent;
        if (parent.child == null) {
            parent.child = left;
            left.right = left;
            left.left = left;
        }
        else {
            left.left = parent.child;
            left.right = parent.child.right;
            parent.child.right = left;
            left.right.left = left;
        }
        ++parent.degree;
        left.mark = false;
    }
    
    public static class Node
    {
        Object userObject;
        Node child;
        Node left;
        Node parent;
        Node right;
        boolean mark;
        double key;
        int degree;
        
        public Node(final Object userObject, final double key) {
            this.userObject = userObject;
            this.right = this;
            this.left = this;
            this.key = key;
        }
        
        public final double getKey() {
            return this.key;
        }
        
        public Object getUserObject() {
            return this.userObject;
        }
        
        public void setUserObject(final Object userObject) {
            this.userObject = userObject;
        }
    }
}
