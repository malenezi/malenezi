// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.view;

import javax.swing.text.JTextComponent;
import java.awt.Color;
import com.mxgraph.util.mxConstants;
import java.awt.LayoutManager;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.text.Document;
import com.mxgraph.util.mxUtils;
import com.mxgraph.model.mxGeometry;
import com.mxgraph.model.mxIGraphModel;
import java.awt.Rectangle;
import com.mxgraph.view.mxCellState;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.util.EventObject;
import com.mxgraph.swing.mxGraphComponent;

public class mxCellEditor implements mxICellEditor
{
    public static int DEFAULT_MIN_WIDTH;
    public static int DEFAULT_MIN_HEIGHT;
    public static double DEFAULT_MINIMUM_EDITOR_SCALE;
    protected mxGraphComponent graphComponent;
    protected boolean returnEnabled;
    protected double minimumEditorScale;
    protected int minimumWidth;
    protected int minimumHeight;
    protected transient Object editingCell;
    protected transient EventObject trigger;
    protected transient JScrollPane scrollPane;
    protected transient JTextArea textArea;
    protected transient JEditorPane editorPane;
    protected transient KeyAdapter keyListener;
    
    public mxCellEditor(final mxGraphComponent graphComponent) {
        this.returnEnabled = false;
        this.minimumEditorScale = mxCellEditor.DEFAULT_MINIMUM_EDITOR_SCALE;
        this.minimumWidth = mxCellEditor.DEFAULT_MIN_WIDTH;
        this.minimumHeight = mxCellEditor.DEFAULT_MIN_HEIGHT;
        this.keyListener = new KeyAdapter() {
            protected transient boolean ignoreEnter = false;
            
            @Override
            public void keyPressed(final KeyEvent keyEvent) {
                if (mxCellEditor.this.returnEnabled && keyEvent.getKeyCode() == 10) {
                    if (keyEvent.isShiftDown() || keyEvent.isControlDown() || keyEvent.isAltDown()) {
                        if (!this.ignoreEnter) {
                            this.ignoreEnter = true;
                            try {
                                ((Component)keyEvent.getSource()).dispatchEvent(new KeyEvent((Component)keyEvent.getSource(), keyEvent.getID(), keyEvent.getWhen(), 0, keyEvent.getKeyCode(), keyEvent.getKeyChar()));
                            }
                            finally {
                                this.ignoreEnter = false;
                            }
                        }
                    }
                    else if (!this.ignoreEnter) {
                        mxCellEditor.this.stopEditing(false);
                    }
                }
            }
        };
        this.graphComponent = graphComponent;
        (this.textArea = new JTextArea()).setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        this.textArea.setOpaque(false);
        this.textArea.addKeyListener(this.keyListener);
        (this.editorPane = new JEditorPane()).setOpaque(false);
        this.editorPane.setContentType("text/html");
        this.editorPane.addKeyListener(this.keyListener);
        (this.scrollPane = new JScrollPane()).setBorder(BorderFactory.createEmptyBorder());
        this.scrollPane.getViewport().setOpaque(false);
        this.scrollPane.setVisible(false);
        this.scrollPane.setOpaque(false);
    }
    
    public void setReturnEnabled(final boolean returnEnabled) {
        this.returnEnabled = returnEnabled;
    }
    
    public boolean isReturnEnabled() {
        return this.returnEnabled;
    }
    
    public Component getEditor() {
        if (this.textArea.getParent() != null) {
            return this.textArea;
        }
        if (this.editingCell != null) {
            return this.editorPane;
        }
        return null;
    }
    
    public Rectangle getEditorBounds(final mxCellState mxCellState) {
        final mxIGraphModel model = mxCellState.getView().getGraph().getModel();
        final mxGeometry geometry = model.getGeometry(mxCellState.getCell());
        Rectangle rectangle;
        if ((geometry != null && geometry.getOffset() != null && (geometry.getOffset().getX() != 0.0 || geometry.getOffset().getY() != 0.0)) || model.isEdge(mxCellState.getCell())) {
            final Rectangle rectangle2;
            rectangle = (rectangle2 = mxCellState.getLabelBounds().getRectangle());
            rectangle2.height += 10;
        }
        else {
            rectangle = mxCellState.getRectangle();
        }
        return rectangle;
    }
    
    public String getInitialValue(final mxCellState mxCellState) {
        return this.graphComponent.getEditingValue(mxCellState.getCell(), this.trigger);
    }
    
    public String getCurrentValue() {
        if (this.textArea.getParent() != null) {
            return this.textArea.getText();
        }
        return this.editorPane.getText();
    }
    
    public void startEditing(final Object editingCell, final EventObject trigger) {
        if (this.editingCell != null) {
            this.stopEditing(true);
        }
        final mxCellState state = this.graphComponent.getGraph().getView().getState(editingCell);
        if (state != null) {
            final double max = Math.max(this.minimumEditorScale, this.graphComponent.getGraph().getView().getScale());
            this.trigger = trigger;
            this.editingCell = editingCell;
            this.scrollPane.setBounds(this.getEditorBounds(state));
            this.scrollPane.setSize(Math.max(this.scrollPane.getWidth(), (int)Math.round(this.minimumWidth * max)), Math.max(this.scrollPane.getHeight(), (int)Math.round(this.minimumHeight * max)));
            this.scrollPane.setVisible(true);
            JTextComponent textComponent;
            if (this.graphComponent.getGraph().isHtmlLabel(editingCell)) {
                this.editorPane.setDocument(mxUtils.createHtmlDocument(state.getStyle(), max));
                this.editorPane.setText(mxUtils.getBodyMarkup(this.getInitialValue(state), true));
                final JPanel viewportView = new JPanel(new BorderLayout());
                viewportView.setOpaque(false);
                viewportView.add(this.editorPane, "Center");
                this.scrollPane.setViewportView(viewportView);
                textComponent = this.editorPane;
            }
            else {
                this.textArea.setFont(mxUtils.getFont(state.getStyle(), max));
                this.textArea.setForeground(mxUtils.getColor(state.getStyle(), mxConstants.STYLE_FONTCOLOR, Color.black));
                this.textArea.setText(this.getInitialValue(state));
                this.scrollPane.setViewportView(this.textArea);
                textComponent = this.textArea;
            }
            this.graphComponent.getControl().add(this.scrollPane, 0);
            this.graphComponent.getControl().refresh(state.getBoundingBox());
            textComponent.revalidate();
            textComponent.requestFocusInWindow();
            textComponent.selectAll();
        }
    }
    
    public void stopEditing(final boolean b) {
        if (this.editingCell != null) {
            this.scrollPane.transferFocusUpCycle();
            final Object editingCell = this.editingCell;
            this.editingCell = null;
            if (!b) {
                final EventObject trigger = this.trigger;
                this.trigger = null;
                this.graphComponent.labelChanged(editingCell, this.getCurrentValue(), trigger);
            }
            else {
                this.graphComponent.getControl().refresh(this.graphComponent.getGraph().getView().getState(editingCell).getBoundingBox());
            }
            if (this.scrollPane.getParent() != null) {
                this.scrollPane.setVisible(false);
                this.scrollPane.getParent().remove(this.scrollPane);
            }
            this.graphComponent.requestFocusInWindow();
        }
    }
    
    public Object getEditingCell() {
        return this.editingCell;
    }
    
    public double getMinimumEditorScale() {
        return this.minimumEditorScale;
    }
    
    public void setMinimumEditorScale(final double minimumEditorScale) {
        this.minimumEditorScale = minimumEditorScale;
    }
    
    public int getMinimumWidth() {
        return this.minimumWidth;
    }
    
    public void setMinimumWidth(final int minimumWidth) {
        this.minimumWidth = minimumWidth;
    }
    
    public int getMinimumHeight() {
        return this.minimumHeight;
    }
    
    public void setMinimumHeight(final int minimumHeight) {
        this.minimumHeight = minimumHeight;
    }
    
    static {
        mxCellEditor.DEFAULT_MIN_WIDTH = 100;
        mxCellEditor.DEFAULT_MIN_HEIGHT = 60;
        mxCellEditor.DEFAULT_MINIMUM_EDITOR_SCALE = 1.0;
    }
}
