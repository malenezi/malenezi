// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.util;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.io.Serializable;

public class mxPoint implements Serializable, Cloneable
{
    protected double x;
    protected double y;
    
    public mxPoint() {
        this(0.0, 0.0);
    }
    
    public mxPoint(final Point2D point2D) {
        this(point2D.getX(), point2D.getY());
    }
    
    public mxPoint(final mxPoint mxPoint) {
        this(mxPoint.getX(), mxPoint.getY());
    }
    
    public mxPoint(final double x, final double y) {
        this.setX(x);
        this.setY(y);
    }
    
    public double getX() {
        return this.x;
    }
    
    public void setX(final double x) {
        this.x = x;
    }
    
    public double getY() {
        return this.y;
    }
    
    public void setY(final double y) {
        this.y = y;
    }
    
    public Point getPoint() {
        return new Point((int)Math.round(this.x), (int)Math.round(this.y));
    }
    
    public Object clone() {
        return new mxPoint(this);
    }
}
