// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.view;

import com.mxgraph.util.mxRectangle;
import com.mxgraph.model.mxGeometry;
import com.mxgraph.model.mxIGraphModel;
import com.mxgraph.util.mxPoint;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxConstants;
import java.util.List;

public class mxEdgeStyle
{
    public static mxEdgeStyleFunction EntityRelation;
    public static mxEdgeStyleFunction Loop;
    public static mxEdgeStyleFunction ElbowConnector;
    public static mxEdgeStyleFunction SideToSide;
    public static mxEdgeStyleFunction TopToBottom;
    
    static {
        mxEdgeStyle.EntityRelation = new mxEdgeStyleFunction() {
            public void apply(final mxCellState mxCellState, mxCellState mxCellState2, mxCellState mxCellState3, final List list, final List list2) {
                final mxIGraphModel model = mxCellState.view.graph.model;
                final int n = (int)(mxUtils.getDouble(mxCellState.getStyle(), mxConstants.STYLE_STARTSIZE, mxConstants.ENTITY_SEGMENT) * mxCellState.view.getScale());
                boolean b = false;
                if (mxCellState2 != null) {
                    final mxGeometry geometry = model.getGeometry(mxCellState2.cell);
                    if (geometry.isRelative()) {
                        b = (geometry.getX() <= 0.5);
                    }
                    else if (mxCellState3 != null) {
                        b = (mxCellState3.getX() + mxCellState3.getWidth() < mxCellState2.getX());
                    }
                }
                else {
                    final mxPoint mxPoint = mxCellState.absolutePoints.get(0);
                    if (mxPoint == null) {
                        return;
                    }
                    mxCellState2 = new mxCellState();
                    mxCellState2.setX(mxPoint.getX());
                    mxCellState2.setY(mxPoint.getY());
                }
                boolean b2 = true;
                if (mxCellState3 != null) {
                    final mxGeometry geometry2 = model.getGeometry(mxCellState3.cell);
                    if (geometry2.isRelative()) {
                        b2 = (geometry2.getX() <= 0.5);
                    }
                    else if (mxCellState2 != null) {
                        b2 = (mxCellState2.getX() + mxCellState2.getWidth() < mxCellState3.getX());
                    }
                }
                else {
                    final List absolutePoints = mxCellState.absolutePoints;
                    final mxPoint mxPoint2 = absolutePoints.get(absolutePoints.size() - 1);
                    if (mxPoint2 == null) {
                        return;
                    }
                    mxCellState3 = new mxCellState();
                    mxCellState3.setX(mxPoint2.getX());
                    mxCellState3.setY(mxPoint2.getY());
                }
                final double n2 = b ? mxCellState2.getX() : (mxCellState2.getX() + mxCellState2.getWidth());
                final double routingCenterY = mxCellState2.getRoutingCenterY();
                final double n3 = b2 ? mxCellState3.getX() : (mxCellState3.getX() + mxCellState3.getWidth());
                final double routingCenterY2 = mxCellState3.getRoutingCenterY();
                final double n4 = n;
                final mxPoint mxPoint3 = new mxPoint(n2 + (b ? (-n4) : n4), routingCenterY);
                list2.add(mxPoint3);
                final mxPoint mxPoint4 = new mxPoint(n3 + (b2 ? (-n4) : n4), routingCenterY2);
                if (b == b2) {
                    final double n5 = b ? (Math.min(n2, n3) - n) : (Math.max(n2, n3) + n);
                    list2.add(new mxPoint(n5, routingCenterY));
                    list2.add(new mxPoint(n5, routingCenterY2));
                }
                else if (mxPoint3.getX() < mxPoint4.getX() == b) {
                    final double n6 = routingCenterY + (routingCenterY2 - routingCenterY) / 2.0;
                    list2.add(new mxPoint(mxPoint3.getX(), n6));
                    list2.add(new mxPoint(mxPoint4.getX(), n6));
                }
                list2.add(mxPoint4);
            }
        };
        mxEdgeStyle.Loop = new mxEdgeStyleFunction() {
            public void apply(final mxCellState mxCellState, final mxCellState mxCellState2, final mxCellState mxCellState3, final List list, final List list2) {
                final mxGraphView view = mxCellState.getView();
                final mxGraph graph = view.getGraph();
                mxPoint mxPoint = (list != null) ? list.get(0) : null;
                final double scale = view.getScale();
                if (mxPoint != null) {
                    final mxPoint translate = view.getTranslate();
                    final mxPoint origin = mxCellState.getOrigin();
                    mxPoint = new mxPoint(scale * (translate.getX() + mxPoint.getX() + origin.getX()), scale * (translate.getY() + mxPoint.getY() + origin.getY()));
                    if (mxUtils.contains(mxCellState2, mxPoint.getX(), mxPoint.getY())) {
                        mxPoint = null;
                    }
                }
                double n = 0.0;
                double max = 0.0;
                double n2 = mxCellState2.getRoutingCenterY();
                double max2 = scale * graph.getGridSize();
                if (mxPoint == null || mxPoint.getX() < mxCellState2.getX() || mxPoint.getX() > mxCellState2.getX() + mxCellState2.getWidth()) {
                    if (mxPoint != null) {
                        n = mxPoint.getX();
                        max2 = Math.max(Math.abs(n2 - mxPoint.getY()), max2);
                    }
                    else {
                        n = mxCellState2.getX() + mxCellState2.getWidth() + 2.0 * max2;
                    }
                }
                else if (mxPoint != null) {
                    n = mxCellState2.getRoutingCenterX();
                    max = Math.max(Math.abs(n - mxPoint.getX()), max2);
                    n2 = mxPoint.getY();
                    max2 = 0.0;
                }
                list2.add(new mxPoint(n - max, n2 - max2));
                list2.add(new mxPoint(n + max, n2 + max2));
            }
        };
        mxEdgeStyle.ElbowConnector = new mxEdgeStyleFunction() {
            public void apply(final mxCellState mxCellState, final mxCellState mxCellState2, final mxCellState mxCellState3, final List list, final List list2) {
                final mxPoint mxPoint = (list != null) ? list.get(0) : null;
                boolean b = false;
                boolean b2 = false;
                if (mxCellState2 != null && mxCellState3 != null) {
                    if (mxPoint != null) {
                        final double min = Math.min(mxCellState2.getX(), mxCellState3.getX());
                        final double max = Math.max(mxCellState2.getX() + mxCellState2.getWidth(), mxCellState3.getX() + mxCellState3.getWidth());
                        final double min2 = Math.min(mxCellState2.getY(), mxCellState3.getY());
                        final double max2 = Math.max(mxCellState2.getY() + mxCellState2.getHeight(), mxCellState3.getY() + mxCellState3.getHeight());
                        final mxGraphView view = mxCellState.getView();
                        final double scale = view.getScale();
                        final mxPoint translate = view.getTranslate();
                        final mxPoint origin = mxCellState.getOrigin();
                        final mxPoint mxPoint2 = new mxPoint(scale * (translate.getX() + mxPoint.getX() + origin.getX()), scale * (translate.getY() + mxPoint.getY() + origin.getY()));
                        b = (mxPoint2.getY() < min2 || mxPoint2.getY() > max2);
                        b2 = (mxPoint2.getX() < min || mxPoint2.getX() > max);
                    }
                    else {
                        b = (Math.max(mxCellState2.getX(), mxCellState3.getX()) == Math.min(mxCellState2.getX() + mxCellState2.getWidth(), mxCellState3.getX() + mxCellState3.getWidth()));
                        if (!b) {
                            b2 = (Math.max(mxCellState2.getY(), mxCellState3.getY()) == Math.min(mxCellState2.getY() + mxCellState2.getHeight(), mxCellState3.getY() + mxCellState3.getHeight()));
                        }
                    }
                }
                if (!b2 && (b || mxUtils.getString(mxCellState.getStyle(), mxConstants.STYLE_ELBOW, "").equals("vertical"))) {
                    mxEdgeStyle.TopToBottom.apply(mxCellState, mxCellState2, mxCellState3, list, list2);
                }
                else {
                    mxEdgeStyle.SideToSide.apply(mxCellState, mxCellState2, mxCellState3, list, list2);
                }
            }
        };
        mxEdgeStyle.SideToSide = new mxEdgeStyleFunction() {
            public void apply(final mxCellState mxCellState, mxCellState mxCellState2, mxCellState mxCellState3, final List list, final List list2) {
                mxPoint mxPoint = (list != null) ? list.get(0) : null;
                if (mxPoint != null) {
                    final mxGraphView view = mxCellState.getView();
                    final mxPoint translate = view.getTranslate();
                    final mxPoint origin = mxCellState.getOrigin();
                    mxPoint = new mxPoint(view.getScale() * (translate.getX() + mxPoint.getX() + origin.getX()), view.getScale() * (translate.getY() + mxPoint.getY() + origin.getY()));
                }
                if (mxCellState2 == null) {
                    final mxPoint mxPoint2 = mxCellState.absolutePoints.get(0);
                    if (mxPoint2 == null) {
                        return;
                    }
                    mxCellState2 = new mxCellState();
                    mxCellState2.setX(mxPoint2.getX());
                    mxCellState2.setY(mxPoint2.getY());
                }
                if (mxCellState3 == null) {
                    final List absolutePoints = mxCellState.absolutePoints;
                    final mxPoint mxPoint3 = absolutePoints.get(absolutePoints.size() - 1);
                    if (mxPoint3 == null) {
                        return;
                    }
                    mxCellState3 = new mxCellState();
                    mxCellState3.setX(mxPoint3.getX());
                    mxCellState3.setY(mxPoint3.getY());
                }
                final double max = Math.max(mxCellState2.getX(), mxCellState3.getX());
                final double min = Math.min(mxCellState2.getX() + mxCellState2.getWidth(), mxCellState3.getX() + mxCellState3.getWidth());
                final double n = (mxPoint != null) ? mxPoint.getX() : (min + (max - min) / 2.0);
                double n2 = mxCellState2.getRoutingCenterY();
                double n3 = mxCellState3.getRoutingCenterY();
                if (mxPoint != null) {
                    if (mxPoint.getY() >= mxCellState2.getY() && mxPoint.getY() <= mxCellState2.getY() + mxCellState2.getHeight()) {
                        n2 = mxPoint.getY();
                    }
                    if (mxPoint.getY() >= mxCellState3.getY() && mxPoint.getY() <= mxCellState3.getY() + mxCellState3.getHeight()) {
                        n3 = mxPoint.getY();
                    }
                }
                if (!mxUtils.contains(mxCellState3, n, n2) && !mxUtils.contains(mxCellState2, n, n2)) {
                    list2.add(new mxPoint(n, n2));
                }
                if (!mxUtils.contains(mxCellState3, n, n3) && !mxUtils.contains(mxCellState2, n, n3)) {
                    list2.add(new mxPoint(n, n3));
                }
                if (list2.size() == 1) {
                    if (mxPoint != null) {
                        list2.add(new mxPoint(n, mxPoint.getY()));
                    }
                    else {
                        final double max2 = Math.max(mxCellState2.getY(), mxCellState3.getY());
                        list2.add(new mxPoint(n, max2 + (Math.min(mxCellState2.getY() + mxCellState2.getHeight(), mxCellState3.getY() + mxCellState3.getHeight()) - max2) / 2.0));
                    }
                }
            }
        };
        mxEdgeStyle.TopToBottom = new mxEdgeStyleFunction() {
            public void apply(final mxCellState mxCellState, mxCellState mxCellState2, mxCellState mxCellState3, final List list, final List list2) {
                mxPoint mxPoint = (list != null) ? list.get(0) : null;
                if (mxPoint != null) {
                    final mxGraphView view = mxCellState.getView();
                    final mxPoint translate = view.getTranslate();
                    final mxPoint origin = mxCellState.getOrigin();
                    mxPoint = new mxPoint(view.getScale() * (translate.getX() + mxPoint.getX() + origin.getX()), view.getScale() * (translate.getY() + mxPoint.getY() + origin.getY()));
                }
                if (mxCellState2 == null) {
                    final mxPoint mxPoint2 = mxCellState.absolutePoints.get(0);
                    if (mxPoint2 == null) {
                        return;
                    }
                    mxCellState2 = new mxCellState();
                    mxCellState2.setX(mxPoint2.getX());
                    mxCellState2.setY(mxPoint2.getY());
                }
                if (mxCellState3 == null) {
                    final List absolutePoints = mxCellState.absolutePoints;
                    final mxPoint mxPoint3 = absolutePoints.get(absolutePoints.size() - 1);
                    if (mxPoint3 == null) {
                        return;
                    }
                    mxCellState3 = new mxCellState();
                    mxCellState3.setX(mxPoint3.getX());
                    mxCellState3.setY(mxPoint3.getY());
                }
                final double max = Math.max(mxCellState2.getY(), mxCellState3.getY());
                final double min = Math.min(mxCellState2.getY() + mxCellState2.getHeight(), mxCellState3.getY() + mxCellState3.getHeight());
                double n = mxCellState2.getRoutingCenterX();
                if (mxPoint != null && mxPoint.getX() >= mxCellState2.getX() && mxPoint.getX() <= mxCellState2.getX() + mxCellState2.getWidth()) {
                    n = mxPoint.getX();
                }
                final double n2 = (mxPoint != null) ? mxPoint.getY() : (min + (max - min) / 2.0);
                if (!mxUtils.contains(mxCellState3, n, n2) && !mxUtils.contains(mxCellState2, n, n2)) {
                    list2.add(new mxPoint(n, n2));
                }
                double n3;
                if (mxPoint != null && mxPoint.getX() >= mxCellState3.getX() && mxPoint.getX() <= mxCellState3.getX() + mxCellState3.getWidth()) {
                    n3 = mxPoint.getX();
                }
                else {
                    n3 = mxCellState3.getRoutingCenterX();
                }
                if (!mxUtils.contains(mxCellState3, n3, n2) && !mxUtils.contains(mxCellState2, n3, n2)) {
                    list2.add(new mxPoint(n3, n2));
                }
                if (list2.size() == 1) {
                    if (mxPoint != null) {
                        list2.add(new mxPoint(mxPoint.getX(), n2));
                    }
                    else {
                        final double max2 = Math.max(mxCellState2.getX(), mxCellState3.getX());
                        list2.add(new mxPoint(max2 + (Math.min(mxCellState2.getX() + mxCellState2.getWidth(), mxCellState3.getX() + mxCellState3.getWidth()) - max2) / 2.0, n2));
                    }
                }
            }
        };
    }
    
    public interface mxEdgeStyleFunction
    {
        void apply(final mxCellState p0, final mxCellState p1, final mxCellState p2, final List p3, final List p4);
    }
}
