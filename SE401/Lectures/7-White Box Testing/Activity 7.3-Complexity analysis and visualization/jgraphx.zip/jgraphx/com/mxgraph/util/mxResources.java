// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.util;

import java.util.Iterator;
import java.util.MissingResourceException;
import java.util.PropertyResourceBundle;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.LinkedList;

public class mxResources
{
    protected static LinkedList bundles;
    
    public static LinkedList getBundles() {
        return mxResources.bundles;
    }
    
    public static void setBundles(final LinkedList bundles) {
        mxResources.bundles = bundles;
    }
    
    public static void add(final String baseName) {
        mxResources.bundles.addFirst(ResourceBundle.getBundle(baseName));
    }
    
    public static void add(final String baseName, final Locale locale) {
        mxResources.bundles.addFirst(ResourceBundle.getBundle(baseName, locale));
    }
    
    public static String get(final String s) {
        return get(s, null, null);
    }
    
    public static String get(final String s, final String s2) {
        return get(s, null, s2);
    }
    
    public static String get(final String s, final String[] array) {
        return get(s, array, null);
    }
    
    public static String get(final String s, final String[] array, final String s2) {
        String s3 = getResource(s);
        if (s3 == null) {
            s3 = s2;
        }
        if (s3 != null && array != null) {
            final StringBuffer sb = new StringBuffer();
            String string = null;
            for (int i = 0; i < s3.length(); ++i) {
                final char char1 = s3.charAt(i);
                if (char1 == '{') {
                    string = "";
                }
                else if (string != null && char1 == '}') {
                    final int n = Integer.parseInt(string) - 1;
                    if (n >= 0 && n < array.length) {
                        sb.append(array[n]);
                    }
                    string = null;
                }
                else if (string != null) {
                    string += char1;
                }
                else {
                    sb.append(char1);
                }
            }
            s3 = sb.toString();
        }
        return s3;
    }
    
    protected static String getResource(final String key) {
        final Iterator iterator = mxResources.bundles.iterator();
        while (iterator.hasNext()) {
            try {
                return iterator.next().getString(key);
            }
            catch (MissingResourceException ex) {
                continue;
            }
            break;
        }
        return null;
    }
    
    static {
        mxResources.bundles = new LinkedList();
    }
}
