// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import java.awt.Stroke;
import java.awt.Cursor;
import java.util.ArrayList;
import java.awt.Component;
import javax.swing.JOptionPane;
import com.mxgraph.model.mxGeometry;
import java.util.List;
import java.util.Arrays;
import java.awt.geom.Point2D;
import com.mxgraph.util.mxPoint;
import java.awt.Graphics2D;
import java.awt.Graphics;
import javax.swing.JPanel;
import javax.swing.JComponent;
import java.awt.Color;
import com.mxgraph.util.mxConstants;
import java.awt.Rectangle;
import com.mxgraph.model.mxIGraphModel;
import com.mxgraph.view.mxGraph;
import java.awt.event.MouseEvent;
import com.mxgraph.view.mxCellState;
import com.mxgraph.swing.mxGraphComponent;
import java.awt.Point;

public class mxEdgeHandler extends mxCellHandler
{
    protected boolean cloneEnabled;
    protected Point[] p;
    protected transient String error;
    protected transient boolean gridEnabledEvent;
    protected transient boolean constrainedEvent;
    protected mxCellMarker marker;
    
    public mxEdgeHandler(final mxGraphComponent mxGraphComponent, final mxCellState mxCellState) {
        super(mxGraphComponent, mxCellState);
        this.cloneEnabled = true;
        this.gridEnabledEvent = false;
        this.constrainedEvent = false;
        this.marker = new mxCellMarker(this.graphComponent) {
            @Override
            protected Object getCell(final MouseEvent mouseEvent) {
                final mxGraph graph = this.graphComponent.getGraph();
                final mxIGraphModel model = graph.getModel();
                Object cell = super.getCell(mouseEvent);
                if (cell == mxEdgeHandler.this.state.getCell() || (!graph.isConnectableEdges() && model.isEdge(cell))) {
                    cell = null;
                }
                return cell;
            }
            
            @Override
            protected boolean isValidState(final mxCellState mxCellState) {
                final mxIGraphModel model = this.graphComponent.getGraph().getModel();
                final Object cell = mxEdgeHandler.this.state.getCell();
                final boolean source = mxEdgeHandler.this.isSource(mxEdgeHandler.this.index);
                final Object terminal = model.getTerminal(cell, !source);
                mxEdgeHandler.this.error = mxEdgeHandler.this.validateConnection(source ? mxCellState.getCell() : terminal, source ? terminal : mxCellState.getCell());
                return mxEdgeHandler.this.error == null;
            }
        };
    }
    
    public void setCloneEnabled(final boolean cloneEnabled) {
        this.cloneEnabled = cloneEnabled;
    }
    
    public boolean isCloneEnabled() {
        return this.cloneEnabled;
    }
    
    @Override
    protected boolean isIgnoredEvent(final MouseEvent mouseEvent) {
        return !this.isFlipEvent(mouseEvent) && super.isIgnoredEvent(mouseEvent);
    }
    
    protected boolean isFlipEvent(final MouseEvent mouseEvent) {
        return false;
    }
    
    public String validateConnection(final Object o, final Object o2) {
        return this.graphComponent.getGraph().getEdgeValidationError(this.state.getCell(), o, o2);
    }
    
    public boolean isSource(final int n) {
        return n == 0;
    }
    
    public boolean isTarget(final int n) {
        return n == this.getHandleCount() - 2;
    }
    
    @Override
    protected Rectangle[] createHandles() {
        this.p = this.createPoints(this.state);
        final Rectangle[] array = new Rectangle[this.p.length + 1];
        for (int i = 0; i < array.length - 1; ++i) {
            array[i] = this.createHandle(this.p[i]);
        }
        array[this.p.length] = this.createHandle(this.state.getAbsoluteOffset().getPoint(), mxConstants.HANDLE_SIZE - 2);
        return array;
    }
    
    @Override
    protected Color getHandleFillColor(final int n) {
        final boolean source = this.isSource(n);
        if (source || this.isTarget(n)) {
            final Object terminal = this.graphComponent.getGraph().getModel().getTerminal(this.state.getCell(), source);
            if (terminal != null) {
                return this.graphComponent.getGraph().isDisconnectable(this.state.getCell(), terminal, source) ? mxConstants.CONNECT_HANDLE_FILLCOLOR : mxConstants.LOCKED_HANDLE_FILLCOLOR;
            }
        }
        return super.getHandleFillColor(n);
    }
    
    @Override
    protected int getIndexAt(final int x, final int y) {
        int index = super.getIndexAt(x, y);
        if (index < 0 && this.handles != null && this.handlesVisible && this.isLabelMovable() && this.state.getLabelBounds().getRectangle().contains(x, y)) {
            index = this.handles.length - 1;
        }
        return index;
    }
    
    protected Rectangle createHandle(final Point point) {
        return this.createHandle(point, mxConstants.HANDLE_SIZE);
    }
    
    protected Rectangle createHandle(final Point point, final int n) {
        return new Rectangle(point.x - n / 2, point.y - n / 2, n, n);
    }
    
    protected Point[] createPoints(final mxCellState mxCellState) {
        final Point[] array = new Point[mxCellState.getAbsolutePointCount()];
        for (int i = 0; i < array.length; ++i) {
            array[i] = mxCellState.getAbsolutePoint(i).getPoint();
        }
        return array;
    }
    
    @Override
    protected JComponent createPreview() {
        final JPanel panel = new JPanel() {
            @Override
            public void paint(final Graphics g) {
                super.paint(g);
                if (!mxEdgeHandler.this.isLabel(mxEdgeHandler.this.index) && mxEdgeHandler.this.p != null) {
                    ((Graphics2D)g).setStroke(mxConstants.PREVIEW_STROKE);
                    if (mxEdgeHandler.this.isSource(mxEdgeHandler.this.index) || mxEdgeHandler.this.isTarget(mxEdgeHandler.this.index)) {
                        if (mxEdgeHandler.this.marker.hasValidState() || mxEdgeHandler.this.graphComponent.getGraph().isAllowDanglingEdges()) {
                            g.setColor(mxConstants.DEFAULT_VALID_COLOR);
                        }
                        else {
                            g.setColor(mxConstants.DEFAULT_INVALID_COLOR);
                        }
                    }
                    else {
                        g.setColor(Color.BLACK);
                    }
                    final Point location = this.getLocation();
                    Point point = mxEdgeHandler.this.p[0];
                    for (int i = 1; i < mxEdgeHandler.this.p.length; ++i) {
                        g.drawLine(point.x - location.x, point.y - location.y, mxEdgeHandler.this.p[i].x - location.x, mxEdgeHandler.this.p[i].y - location.y);
                        point = mxEdgeHandler.this.p[i];
                    }
                }
            }
        };
        if (this.isLabel(this.index)) {
            panel.setBorder(mxConstants.SELECTION_BORDER);
        }
        panel.setOpaque(false);
        panel.setVisible(false);
        return panel;
    }
    
    protected mxPoint convertPoint(final mxPoint mxPoint, final boolean b) {
        final mxGraph graph = this.graphComponent.getGraph();
        final double scale = graph.getView().getScale();
        final mxPoint translate = graph.getView().getTranslate();
        double snap = mxPoint.getX() / scale - translate.getX();
        double snap2 = mxPoint.getY() / scale - translate.getY();
        if (b) {
            snap = graph.snap(snap);
            snap2 = graph.snap(snap2);
        }
        mxPoint.setX(snap - this.state.getOrigin().getX());
        mxPoint.setY(snap2 - this.state.getOrigin().getY());
        return mxPoint;
    }
    
    protected Rectangle getPreviewBounds() {
        Rectangle rectangle;
        if (this.isLabel(this.index)) {
            rectangle = this.state.getLabelBounds().getRectangle();
        }
        else {
            rectangle = new Rectangle(this.p[0]);
            for (int i = 0; i < this.p.length; ++i) {
                rectangle.add(this.p[i]);
            }
            final Rectangle rectangle2 = rectangle;
            ++rectangle2.height;
            final Rectangle rectangle3 = rectangle;
            ++rectangle3.width;
        }
        return rectangle;
    }
    
    @Override
    public void mousePressed(final MouseEvent mouseEvent) {
        super.mousePressed(mouseEvent);
        if (this.isSource(this.index) || this.isTarget(this.index)) {
            final mxGraph graph = this.graphComponent.getGraph();
            if (!graph.isDisconnectable(this.state.getCell(), graph.getModel().getTerminal(this.state.getCell(), this.isSource(this.index)), this.isSource(this.index))) {
                this.start = null;
            }
        }
    }
    
    @Override
    public void mouseDragged(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.start != null) {
            this.gridEnabledEvent = this.graphComponent.isGridEnabledEvent(mouseEvent);
            this.constrainedEvent = this.graphComponent.isConstrainedEvent(mouseEvent);
            final boolean source = this.isSource(this.index);
            Object o = null;
            if (this.isLabel(this.index)) {
                final mxPoint absoluteOffset = this.state.getAbsoluteOffset();
                final double n = absoluteOffset.getX() - this.start.x;
                final double n2 = absoluteOffset.getY() - this.start.y;
                mxPoint snapScaledPoint = new mxPoint(mouseEvent.getPoint());
                if (this.gridEnabledEvent) {
                    snapScaledPoint = this.graphComponent.snapScaledPoint(snapScaledPoint, n, n2);
                }
                if (this.constrainedEvent) {
                    if (Math.abs(mouseEvent.getX() - this.start.x) > Math.abs(mouseEvent.getY() - this.start.y)) {
                        snapScaledPoint.setY(absoluteOffset.getY());
                    }
                    else {
                        snapScaledPoint.setX(absoluteOffset.getX());
                    }
                }
                final Rectangle previewBounds = this.getPreviewBounds();
                previewBounds.translate((int)Math.round(snapScaledPoint.getX() - this.start.x), (int)Math.round(snapScaledPoint.getY() - this.start.y));
                this.preview.setBounds(previewBounds);
            }
            else {
                final mxGeometry cellGeometry = this.graphComponent.getGraph().getCellGeometry(this.state.getCell());
                final mxCellState mxCellState = (mxCellState)this.state.clone();
                List<mxPoint> list = (List<mxPoint>)cellGeometry.getPoints();
                Object o2;
                if (source || this.isTarget(this.index)) {
                    this.marker.process(mouseEvent);
                    final mxCellState validState = this.marker.getValidState();
                    o2 = mxCellState.getView().getVisibleTerminal(this.state.getCell(), !source);
                    if (validState != null) {
                        o = validState.getCell();
                    }
                    else {
                        mxPoint snapScaledPoint2 = new mxPoint(mouseEvent.getPoint());
                        if (this.gridEnabledEvent) {
                            snapScaledPoint2 = this.graphComponent.snapScaledPoint(snapScaledPoint2);
                        }
                        mxCellState.setAbsoluteTerminalPoint(snapScaledPoint2, source);
                    }
                    if (!source) {
                        final Object o3 = o;
                        o = o2;
                        o2 = o3;
                    }
                }
                else {
                    final mxPoint convertPoint = this.convertPoint(new mxPoint(mouseEvent.getPoint()), this.gridEnabledEvent);
                    if (list == null) {
                        list = Arrays.asList(convertPoint);
                    }
                    else {
                        list.set(this.index - 1, convertPoint);
                    }
                    o = mxCellState.getView().getVisibleTerminal(this.state.getCell(), true);
                    o2 = mxCellState.getView().getVisibleTerminal(this.state.getCell(), false);
                }
                mxCellState.getView().updatePoints(mxCellState, list, o, o2);
                mxCellState.getView().updateTerminalPoints(mxCellState, o, o2);
                this.p = this.createPoints(mxCellState);
                this.preview.setBounds(this.getPreviewBounds());
            }
            if (!this.preview.isVisible() && this.graphComponent.isSignificant(mouseEvent.getX() - this.start.x, mouseEvent.getY() - this.start.y)) {
                this.preview.setVisible(true);
            }
            else if (this.preview.isVisible()) {
                this.preview.repaint();
            }
            mouseEvent.consume();
        }
    }
    
    @Override
    public void mouseReleased(final MouseEvent mouseEvent) {
        final mxGraph graph = this.graphComponent.getGraph();
        if (!mouseEvent.isConsumed() && this.start != null) {
            if (this.graphComponent.isSignificant(mouseEvent.getX() - this.start.x, mouseEvent.getY() - this.start.y)) {
                if (this.error != null) {
                    if (this.error.length() > 0) {
                        JOptionPane.showMessageDialog(this.graphComponent, this.error);
                    }
                }
                else if (this.isLabel(this.index)) {
                    final mxPoint absoluteOffset = this.state.getAbsoluteOffset();
                    final double n = absoluteOffset.getX() - this.start.x;
                    final double n2 = absoluteOffset.getY() - this.start.y;
                    mxPoint snapScaledPoint = new mxPoint(mouseEvent.getPoint());
                    if (this.gridEnabledEvent) {
                        snapScaledPoint = this.graphComponent.snapScaledPoint(snapScaledPoint, n, n2);
                    }
                    if (this.constrainedEvent) {
                        if (Math.abs(mouseEvent.getX() - this.start.x) > Math.abs(mouseEvent.getY() - this.start.y)) {
                            snapScaledPoint.setY(absoluteOffset.getY());
                        }
                        else {
                            snapScaledPoint.setX(absoluteOffset.getX());
                        }
                    }
                    this.moveLabelTo(this.state, snapScaledPoint.getX() + n, snapScaledPoint.getY() + n2);
                }
                else if (this.marker.hasValidState() && (this.isSource(this.index) || this.isTarget(this.index))) {
                    this.connect(this.state.getCell(), this.marker.getValidState().getCell(), this.isSource(this.index), mouseEvent.isControlDown() && this.cloneEnabled);
                }
                else if ((!this.isSource(this.index) && !this.isTarget(this.index)) || this.graphComponent.getGraph().isAllowDanglingEdges()) {
                    this.movePoint(this.state.getCell(), this.index, this.convertPoint(new mxPoint(mouseEvent.getPoint()), this.gridEnabledEvent));
                }
                mouseEvent.consume();
            }
            else if (this.isFlipEvent(mouseEvent)) {
                graph.flip(this.state.getCell());
                mouseEvent.consume();
            }
        }
        this.marker.reset();
        this.error = null;
        super.mouseReleased(mouseEvent);
    }
    
    protected void movePoint(final Object o, final int n, final mxPoint mxPoint) {
        final mxIGraphModel model = this.graphComponent.getGraph().getModel();
        final mxGeometry geometry = model.getGeometry(o);
        if (geometry != null) {
            model.beginUpdate();
            try {
                final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                if (this.isSource(this.index) || this.isTarget(this.index)) {
                    this.connect(o, null, this.isSource(this.index), false);
                    mxGeometry.setTerminalPoint(mxPoint, this.isSource(this.index));
                }
                else {
                    List<mxPoint> points = (List<mxPoint>)mxGeometry.getPoints();
                    if (points == null) {
                        points = new ArrayList<mxPoint>();
                        mxGeometry.setPoints(points);
                    }
                    if (points != null) {
                        if (n <= points.size()) {
                            points.set(n - 1, mxPoint);
                        }
                        else {
                            points.add(n - 1, mxPoint);
                        }
                    }
                }
                model.setGeometry(o, mxGeometry);
            }
            finally {
                model.endUpdate();
            }
        }
    }
    
    protected void connect(Object o, final Object o2, final boolean b, final boolean b2) {
        final mxGraph graph = this.graphComponent.getGraph();
        final mxIGraphModel model = graph.getModel();
        model.beginUpdate();
        try {
            if (b2) {
                final Object selectionCell = graph.cloneCells(new Object[] { o })[0];
                graph.addCell(selectionCell, model.getParent(o));
                graph.connect(selectionCell, model.getTerminal(o, !b), !b);
                graph.setSelectionCell(selectionCell);
                o = selectionCell;
            }
            graph.connect(o, o2, b);
        }
        finally {
            model.endUpdate();
        }
    }
    
    protected void moveLabelTo(final mxCellState mxCellState, final double n, final double n2) {
        final mxGraph graph = this.graphComponent.getGraph();
        final mxIGraphModel model = graph.getModel();
        final mxGeometry geometry = model.getGeometry(this.state.getCell());
        if (geometry != null) {
            final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
            final mxPoint relativePoint = graph.getView().getRelativePoint(mxCellState, n, n2);
            mxGeometry.setX(relativePoint.getX());
            mxGeometry.setY(relativePoint.getY());
            final double scale = graph.getView().getScale();
            mxGeometry.setOffset(new mxPoint(0.0, 0.0));
            final mxPoint point = graph.getView().getPoint(mxCellState, mxGeometry);
            mxGeometry.setOffset(new mxPoint((double)Math.round((n - point.getX()) / scale), (double)Math.round((n2 - point.getY()) / scale)));
            model.setGeometry(mxCellState.getCell(), mxGeometry);
        }
    }
    
    @Override
    protected Cursor getCursor(final MouseEvent mouseEvent, final int n) {
        Cursor default_CURSOR;
        if (this.isSource(n) || this.isTarget(n)) {
            default_CURSOR = mxConnectionHandler.DEFAULT_CURSOR;
        }
        else if (this.isLabel(n)) {
            default_CURSOR = new Cursor(13);
        }
        else {
            default_CURSOR = new Cursor(12);
        }
        return default_CURSOR;
    }
    
    @Override
    public void paint(final Graphics graphics) {
        final Graphics2D graphics2D = (Graphics2D)graphics;
        final Stroke stroke = graphics2D.getStroke();
        graphics2D.setStroke(mxConstants.SELECTION_STROKE);
        graphics.setColor(mxConstants.SELECTION_COLOR);
        Point point = this.state.getAbsolutePoint(0).getPoint();
        for (int i = 1; i < this.state.getAbsolutePointCount(); ++i) {
            final Point point2 = this.state.getAbsolutePoint(i).getPoint();
            graphics.drawLine(point.x, point.y, point2.x, point2.y);
            point = point2;
        }
        graphics2D.setStroke(stroke);
        super.paint(graphics);
    }
}
