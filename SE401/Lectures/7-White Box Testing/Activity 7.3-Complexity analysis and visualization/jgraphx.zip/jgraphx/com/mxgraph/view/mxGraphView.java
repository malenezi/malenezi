// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.view;

import java.awt.geom.Point2D;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.List;
import com.mxgraph.util.mxConstants;
import com.mxgraph.util.mxUtils;
import com.mxgraph.model.mxGeometry;
import com.mxgraph.model.mxIGraphModel;
import com.mxgraph.util.mxUndoableEdit;
import java.util.Hashtable;
import com.mxgraph.util.mxPoint;
import com.mxgraph.util.mxRectangle;
import com.mxgraph.util.mxEventSource;

public class mxGraphView extends mxEventSource
{
    public static String EVENT_UNDO;
    public static String EVENT_UP;
    public static String EVENT_DOWN;
    public static String EVENT_SCALE;
    public static String EVENT_TRANSLATE;
    public static String EVENT_SCALE_AND_TRANSLATE;
    protected mxGraph graph;
    protected Object currentRoot;
    protected mxRectangle bounds;
    protected double scale;
    protected mxPoint translate;
    protected Hashtable states;
    
    public mxGraphView(final mxGraph graph) {
        this.currentRoot = null;
        this.bounds = new mxRectangle();
        this.scale = 1.0;
        this.translate = new mxPoint(0.0, 0.0);
        this.states = new Hashtable();
        this.graph = graph;
    }
    
    public mxGraph getGraph() {
        return this.graph;
    }
    
    public Hashtable getStates() {
        return this.states;
    }
    
    public void setStates(final Hashtable states) {
        this.states = states;
    }
    
    public mxRectangle getBounds() {
        return this.bounds;
    }
    
    public Object getCurrentRoot() {
        return this.currentRoot;
    }
    
    public Object setCurrentRoot(final Object o) {
        if (this.currentRoot != o) {
            final mxCurrentRootChange mxCurrentRootChange = new mxCurrentRootChange(this, o);
            mxCurrentRootChange.execute();
            final mxUndoableEdit mxUndoableEdit = new mxUndoableEdit(this, false);
            mxUndoableEdit.add(mxCurrentRootChange);
            this.fireEvent(mxGraphView.EVENT_UNDO, new Object[] { mxUndoableEdit });
        }
        return o;
    }
    
    public void scaleAndTranslate(final double d, final double n, final double n2) {
        final Object clone = this.translate.clone();
        if (d != this.scale || n != this.translate.getX() || n2 != this.translate.getY()) {
            this.scale = d;
            this.translate = new mxPoint(n, n2);
            if (this.isEventsEnabled()) {
                this.revalidate();
            }
        }
        this.fireEvent(mxGraphView.EVENT_SCALE_AND_TRANSLATE, new Object[] { d, d, clone, this.translate });
    }
    
    public double getScale() {
        return this.scale;
    }
    
    public void setScale(final double scale) {
        final double scale2 = this.scale;
        if (this.scale != scale) {
            this.scale = scale;
            if (this.isEventsEnabled()) {
                this.revalidate();
            }
        }
        this.fireEvent(mxGraphView.EVENT_SCALE, new Object[] { scale2, this.scale });
    }
    
    public mxPoint getTranslate() {
        return this.translate;
    }
    
    public void setTranslate(final mxPoint translate) {
        final Object clone = this.translate.clone();
        if (translate != null && (translate.getX() != this.translate.getX() || translate.getY() != this.translate.getY())) {
            this.translate = translate;
            if (this.isEventsEnabled()) {
                this.revalidate();
            }
        }
        this.fireEvent(mxGraphView.EVENT_TRANSLATE, new Object[] { clone, this.translate });
    }
    
    public mxRectangle getBounds(final Object[] array) {
        return this.getBounds(array, false);
    }
    
    public mxRectangle getBoundingBox(final Object[] array) {
        return this.getBounds(array, true);
    }
    
    public mxRectangle getBounds(final Object[] array, final boolean b) {
        mxRectangle mxRectangle = null;
        if (array != null && array.length > 0) {
            for (int i = 0; i < array.length; ++i) {
                final mxCellState state = this.getState(array[i]);
                if (state != null) {
                    final mxRectangle mxRectangle2 = b ? state.getBoundingBox() : state;
                    if (mxRectangle2 != null) {
                        if (mxRectangle == null) {
                            mxRectangle = new mxRectangle(mxRectangle2);
                        }
                        else {
                            mxRectangle.add(mxRectangle2);
                        }
                    }
                }
            }
        }
        return mxRectangle;
    }
    
    public void revalidate() {
        this.invalidate();
        this.validate();
    }
    
    public void invalidate() {
        this.states.clear();
    }
    
    public void clear(final Object o, final boolean b, final boolean b2) {
        this.removeState(o);
        if (b2 && (b || o != this.currentRoot)) {
            final mxIGraphModel model = this.graph.getModel();
            for (int childCount = model.getChildCount(o), i = 0; i < childCount; ++i) {
                this.clear(model.getChildAt(o, i), b, b2);
            }
        }
        else {
            this.invalidate(o);
        }
    }
    
    public void invalidate(final Object o) {
        final mxCellState state = this.getState(o);
        if (state == null || !state.isInvalid()) {
            final mxIGraphModel model = this.graph.getModel();
            if (state != null) {
                state.setInvalid(true);
            }
            for (int childCount = model.getChildCount(o), i = 0; i < childCount; ++i) {
                this.invalidate(model.getChildAt(o, i));
            }
            for (int edgeCount = model.getEdgeCount(o), j = 0; j < edgeCount; ++j) {
                this.invalidate(model.getEdgeAt(o, j));
            }
        }
    }
    
    public void validate() {
        final Object o = (this.currentRoot != null) ? this.currentRoot : this.graph.getModel().getRoot();
        if (o != null) {
            this.validateBounds(null, o);
            this.bounds = this.validatePoints(null, o);
        }
    }
    
    public void validateBounds(final mxCellState mxCellState, final Object o) {
        final mxIGraphModel model = this.graph.getModel();
        final mxCellState state = this.getState(o, true);
        if (state != null && state.isInvalid()) {
            if (!this.graph.isCellVisible(o)) {
                this.removeState(o);
            }
            else if (o != this.currentRoot && mxCellState != null) {
                state.setOrigin(new mxPoint(mxCellState.getOrigin()));
                final mxGeometry cellGeometry = this.graph.getCellGeometry(o);
                if (cellGeometry != null) {
                    if (!model.isEdge(o)) {
                        final mxPoint origin = state.getOrigin();
                        mxPoint offset = cellGeometry.getOffset();
                        if (offset == null) {
                            offset = new mxPoint();
                        }
                        if (cellGeometry.isRelative()) {
                            origin.setX(origin.getX() + cellGeometry.getX() * mxCellState.getWidth() / this.scale + offset.getX());
                            origin.setY(origin.getY() + cellGeometry.getY() * mxCellState.getHeight() / this.scale + offset.getY());
                        }
                        else {
                            state.setAbsoluteOffset(new mxPoint(this.scale * offset.getX(), this.scale * offset.getY()));
                            origin.setX(origin.getX() + cellGeometry.getX());
                            origin.setY(origin.getY() + cellGeometry.getY());
                        }
                    }
                    state.setX(this.scale * (this.translate.getX() + state.getOrigin().getX()));
                    state.setY(this.scale * (this.translate.getY() + state.getOrigin().getY()));
                    state.setWidth(this.scale * cellGeometry.getWidth());
                    state.setHeight(this.scale * cellGeometry.getHeight());
                }
            }
            final mxPoint childOffsetForCell = this.graph.getChildOffsetForCell(o);
            if (childOffsetForCell != null) {
                state.origin.setX(state.origin.getX() + childOffsetForCell.getX());
                state.origin.setY(state.origin.getY() + childOffsetForCell.getY());
            }
        }
        if (state != null && (!this.graph.isCellCollapsed(o) || o == this.currentRoot)) {
            for (int childCount = model.getChildCount(o), i = 0; i < childCount; ++i) {
                this.validateBounds(state, model.getChildAt(o, i));
            }
        }
    }
    
    public mxRectangle validatePoints(final mxCellState mxCellState, final Object o) {
        final mxCellState state = this.getState(o);
        double a = 0.0;
        double a2 = 0.0;
        double max = 0.0;
        double max2 = 0.0;
        final mxIGraphModel model = this.graph.getModel();
        final boolean edge = model.isEdge(o);
        if (state != null) {
            if (state.isInvalid()) {
                final mxGeometry cellGeometry = this.graph.getCellGeometry(o);
                if (edge) {
                    final Object visibleTerminal = this.getVisibleTerminal(o, true);
                    if (visibleTerminal != null && !model.isAncestor(visibleTerminal, o)) {
                        this.validatePoints(this.getState(model.getParent(visibleTerminal)), visibleTerminal);
                    }
                    final Object visibleTerminal2 = this.getVisibleTerminal(o, false);
                    if (visibleTerminal2 != null && !model.isAncestor(visibleTerminal2, o)) {
                        this.validatePoints(this.getState(model.getParent(visibleTerminal2)), visibleTerminal2);
                    }
                    this.setTerminalPoints(state);
                    this.updatePoints(state, cellGeometry.getPoints(), visibleTerminal, visibleTerminal2);
                    this.updateTerminalPoints(state, visibleTerminal, visibleTerminal2);
                    this.updateEdgeBounds(state);
                    state.setAbsoluteOffset(this.getPoint(state, cellGeometry));
                }
                else if (cellGeometry != null && cellGeometry.isRelative() && mxCellState != null && model.isEdge(mxCellState.getCell())) {
                    final mxPoint point = this.getPoint(mxCellState, cellGeometry);
                    state.setX(point.getX());
                    state.setY(point.getY());
                }
                state.setInvalid(false);
            }
            if (edge || model.isVertex(o)) {
                this.updateLabelBounds(state);
                final mxRectangle updateBoundingBox = this.updateBoundingBox(state);
                a = updateBoundingBox.getX();
                a2 = updateBoundingBox.getY();
                max = updateBoundingBox.getX() + updateBoundingBox.getWidth();
                max2 = updateBoundingBox.getY() + updateBoundingBox.getHeight();
            }
        }
        if (state != null && (!this.graph.isCellCollapsed(o) || o == this.currentRoot)) {
            for (int childCount = model.getChildCount(o), i = 0; i < childCount; ++i) {
                final mxRectangle validatePoints = this.validatePoints(state, model.getChildAt(o, i));
                a = Math.min(a, validatePoints.getX());
                a2 = Math.min(a2, validatePoints.getY());
                max = Math.max(max, validatePoints.getX() + validatePoints.getWidth());
                max2 = Math.max(max2, validatePoints.getY() + validatePoints.getHeight());
            }
        }
        return new mxRectangle(a, a2, max - a, max2 - a2);
    }
    
    public void updateLabelBounds(final mxCellState mxCellState) {
        final Object cell = mxCellState.getCell();
        final Hashtable style = mxCellState.getStyle();
        final mxRectangle labelSize = mxUtils.getLabelSize(this.graph.getLabel(cell), style, this.graph.isHtmlLabel(cell));
        final mxPoint absoluteOffset = mxCellState.getAbsoluteOffset();
        double x = absoluteOffset.getX();
        double y = absoluteOffset.getY();
        double n = 0.0;
        double n2 = 0.0;
        if (!this.graph.getModel().isEdge(cell)) {
            x += mxCellState.getX();
            y += mxCellState.getY();
            final double n3 = mxUtils.getDouble(style, mxConstants.STYLE_STARTSIZE) * this.scale;
            if (n3 > 0.0) {
                if (mxUtils.isTrue(style, mxConstants.STYLE_HORIZONTAL, true)) {
                    n += mxCellState.getWidth();
                    n2 += n3;
                }
                else {
                    n += n3;
                    n2 += mxCellState.getHeight();
                }
            }
            else {
                n += mxCellState.getWidth();
                n2 += mxCellState.getHeight();
            }
        }
        mxCellState.setLabelBounds(mxUtils.getScaledLabelBounds(x, y, labelSize, n, n2, style, this.scale));
    }
    
    public mxRectangle updateBoundingBox(final mxCellState mxCellState) {
        final mxRectangle boundingBox = new mxRectangle(mxCellState);
        final Hashtable style = mxCellState.getStyle();
        final double n = (double)Math.max(1L, Math.round(mxUtils.getInt(style, mxConstants.STYLE_STROKEWIDTH, 1) * this.scale));
        final double n2 = n - Math.max(1.0, n / 2.0);
        if (this.graph.getModel().isEdge(mxCellState.getCell())) {
            int n3 = 0;
            if (style.containsKey(mxConstants.STYLE_ENDARROW) || style.containsKey(mxConstants.STYLE_STARTARROW)) {
                n3 = (int)(mxConstants.DEFAULT_MARKERSIZE / 2 * this.scale);
            }
            boundingBox.grow(n3 + n2);
            if (mxUtils.getString(style, mxConstants.STYLE_SHAPE, "").equals("arrow")) {
                boundingBox.grow(mxConstants.ARROW_WIDTH / 2);
            }
        }
        else {
            boundingBox.grow(n2);
        }
        if (mxUtils.isTrue(style, mxConstants.STYLE_SHADOW)) {
            boundingBox.setWidth(boundingBox.getWidth() + mxConstants.SHADOW_OFFSETX);
            boundingBox.setHeight(boundingBox.getHeight() + mxConstants.SHADOW_OFFSETY);
        }
        if (mxUtils.getString(style, mxConstants.STYLE_SHAPE, "").equals("label") && mxUtils.getString(style, mxConstants.STYLE_IMAGE) != null) {
            final double n4 = mxUtils.getInt(style, mxConstants.STYLE_IMAGE_WIDTH, mxConstants.DEFAULT_IMAGESIZE) * this.scale;
            final double n5 = mxUtils.getInt(style, mxConstants.STYLE_IMAGE_HEIGHT, mxConstants.DEFAULT_IMAGESIZE) * this.scale;
            double x = mxCellState.getX();
            final String string = mxUtils.getString(style, mxConstants.STYLE_IMAGE_ALIGN, "center");
            final String string2 = mxUtils.getString(style, mxConstants.STYLE_IMAGE_VERTICAL_ALIGN, "middle");
            if (string.equals("right")) {
                x += mxCellState.getWidth() - n4;
            }
            else if (string.equals("center")) {
                x += (mxCellState.getWidth() - n4) / 2.0;
            }
            double y;
            if (string2.equals("top")) {
                y = mxCellState.getY();
            }
            else if (string2.equals("bottom")) {
                y = mxCellState.getY() + mxCellState.getHeight() - n5;
            }
            else {
                y = mxCellState.getY() + (mxCellState.getHeight() - n5) / 2.0;
            }
            boundingBox.add(new mxRectangle(x, y, n4, n5));
        }
        final mxRectangle boundingBox2 = mxUtils.getBoundingBox(boundingBox, mxUtils.getDouble(style, mxConstants.STYLE_ROTATION));
        if (boundingBox2 != null) {
            boundingBox.add(boundingBox2);
        }
        boundingBox.add(mxCellState.getLabelBounds());
        mxCellState.setBoundingBox(boundingBox);
        return boundingBox;
    }
    
    public void setTerminalPoints(final mxCellState mxCellState) {
        final mxGeometry cellGeometry = this.graph.getCellGeometry(mxCellState.getCell());
        final mxPoint origin = mxCellState.getOrigin();
        final mxPoint terminalPoint = cellGeometry.getTerminalPoint(true);
        if (terminalPoint != null) {
            mxCellState.setAbsoluteTerminalPoint(new mxPoint(this.scale * (this.translate.getX() + terminalPoint.getX() + origin.getX()), this.scale * (this.translate.getY() + terminalPoint.getY() + origin.getY())), true);
        }
        else {
            mxCellState.setAbsoluteTerminalPoint(null, true);
        }
        final mxPoint terminalPoint2 = cellGeometry.getTerminalPoint(false);
        if (terminalPoint2 != null) {
            mxCellState.setAbsoluteTerminalPoint(new mxPoint(this.scale * (this.translate.getX() + terminalPoint2.getX() + origin.getX()), this.scale * (this.translate.getY() + terminalPoint2.getY() + origin.getY())), false);
        }
        else {
            mxCellState.setAbsoluteTerminalPoint(null, false);
        }
    }
    
    public void updatePoints(final mxCellState mxCellState, final List list, final Object o, final Object o2) {
        if (mxCellState != null) {
            final ArrayList<Object> absolutePoints = new ArrayList<Object>();
            absolutePoints.add(mxCellState.absolutePoints.get(0));
            final mxEdgeStyle.mxEdgeStyleFunction edgeStyle = this.getEdgeStyle(mxCellState, o, o2);
            if (edgeStyle != null) {
                edgeStyle.apply(mxCellState, this.getState(o), this.getState(o2), list, absolutePoints);
            }
            else if (list != null) {
                for (int i = 0; i < list.size(); ++i) {
                    final mxPoint mxPoint = (mxPoint)list.get(i).clone();
                    mxPoint.setX(mxPoint.getX() + this.translate.getX() + mxCellState.getOrigin().getX());
                    mxPoint.setY(mxPoint.getY() + this.translate.getY() + mxCellState.getOrigin().getY());
                    mxPoint.setX(mxPoint.getX() * this.scale);
                    mxPoint.setY(mxPoint.getY() * this.scale);
                    absolutePoints.add(mxPoint);
                }
            }
            final List absolutePoints2 = mxCellState.absolutePoints;
            absolutePoints.add(absolutePoints2.get(absolutePoints2.size() - 1));
            mxCellState.setAbsolutePoints(absolutePoints);
        }
    }
    
    protected mxEdgeStyle.mxEdgeStyleFunction getEdgeStyle(final mxCellState mxCellState, final Object o, final Object o2) {
        Object obj = null;
        if (o != null && o == o2) {
            obj = mxCellState.getStyle().get(mxConstants.STYLE_LOOP);
            if (obj == null) {
                obj = this.graph.getDefaultLoopStyle();
            }
        }
        else if (!mxUtils.isTrue(mxCellState.getStyle(), mxConstants.STYLE_NOEDGESTYLE, false)) {
            obj = mxCellState.getStyle().get(mxConstants.STYLE_EDGE);
        }
        if (obj instanceof String) {
            final String value = String.valueOf(obj);
            final int index = value.indexOf(".");
            try {
                obj = Class.forName("com.mxgraph.view." + value.substring(0, index)).getField(value.substring(index + 1)).get(null);
            }
            catch (Exception ex) {}
        }
        if (obj instanceof mxEdgeStyle.mxEdgeStyleFunction) {
            return (mxEdgeStyle.mxEdgeStyleFunction)obj;
        }
        return null;
    }
    
    public void updateTerminalPoints(final mxCellState mxCellState, final Object o, final Object o2) {
        if (o2 != null) {
            this.updateTerminalPoint(mxCellState, o2, o, false);
        }
        if (o != null) {
            this.updateTerminalPoint(mxCellState, o, o2, true);
        }
    }
    
    public void updateTerminalPoint(final mxCellState mxCellState, final Object o, final Object o2, final boolean b) {
        mxCellState.setAbsolutePoint(b ? 0 : (mxCellState.getAbsolutePointCount() - 1), this.getPerimeterPoint(mxCellState, o, o2, b));
    }
    
    public mxPoint getPerimeterPoint(final mxCellState mxCellState, final Object o, final Object o2, final boolean b) {
        mxPoint mxPoint = null;
        final mxCellState state = this.getState(o);
        if (state != null) {
            final mxPerimeter.mxPerimeterFunction perimeterFunction = this.getPerimeterFunction(state);
            final mxPoint nextPoint = this.getNextPoint(mxCellState, o2, b);
            if (perimeterFunction != null && nextPoint != null) {
                mxPoint = perimeterFunction.apply(this.getPerimeterBounds(state, mxCellState, b), mxCellState, state, b, nextPoint);
            }
            if (mxPoint == null) {
                mxPoint = this.getPoint(state, null);
            }
        }
        return mxPoint;
    }
    
    public mxRectangle getPerimeterBounds(final mxCellState mxCellState, final mxCellState mxCellState2, final boolean b) {
        double n = 0.0;
        if (mxCellState2 != null) {
            n = mxUtils.getDouble(mxCellState2.getStyle(), mxConstants.STYLE_PERIMETER_SPACING) + mxUtils.getDouble(mxCellState2.getStyle(), b ? mxConstants.STYLE_SOURCE_PERIMETER_SPACING : mxConstants.STYLE_TARGET_PERIMETER_SPACING);
        }
        if (mxCellState != null) {
            n += mxUtils.getDouble(mxCellState.getStyle(), mxConstants.STYLE_PERIMETER_SPACING);
        }
        return mxCellState.getPerimeterBounds(n * this.scale);
    }
    
    public mxPerimeter.mxPerimeterFunction getPerimeterFunction(final mxCellState mxCellState) {
        Object obj = mxCellState.getStyle().get(mxConstants.STYLE_PERIMETER);
        if (obj instanceof String) {
            final String value = String.valueOf(obj);
            final int index = value.indexOf(".");
            try {
                obj = Class.forName("com.mxgraph.view." + value.substring(0, index)).getField(value.substring(index + 1)).get(null);
            }
            catch (Exception ex) {}
        }
        if (obj instanceof mxPerimeter.mxPerimeterFunction) {
            return (mxPerimeter.mxPerimeterFunction)obj;
        }
        return null;
    }
    
    public mxPoint getNextPoint(final mxCellState mxCellState, final Object o, final boolean b) {
        mxPoint mxPoint = null;
        final List absolutePoints = mxCellState.getAbsolutePoints();
        if (absolutePoints != null && (b || absolutePoints.size() > 2 || o == null)) {
            final int size = absolutePoints.size();
            mxPoint = absolutePoints.get(b ? Math.min(1, size - 1) : Math.max(0, size - 2));
        }
        if (mxPoint == null && o != null) {
            final mxCellState state = this.getState(o);
            if (state != null) {
                mxPoint = new mxPoint(state.getCenterX(), state.getCenterY());
            }
        }
        return mxPoint;
    }
    
    public Object getVisibleTerminal(final Object o, final boolean b) {
        final mxIGraphModel model = this.graph.getModel();
        Object terminal;
        for (Object parent = terminal = model.getTerminal(o, b); parent != null && parent != this.currentRoot; parent = model.getParent(parent)) {
            if (!this.graph.isCellVisible(terminal) || this.graph.isCellCollapsed(parent)) {
                terminal = parent;
            }
        }
        return terminal;
    }
    
    public void updateEdgeBounds(final mxCellState mxCellState) {
        final List absolutePoints = mxCellState.getAbsolutePoints();
        if (absolutePoints != null && absolutePoints.size() > 0) {
            final mxPoint mxPoint = absolutePoints.get(0);
            final mxPoint mxPoint2 = absolutePoints.get(absolutePoints.size() - 1);
            if (mxPoint == null || mxPoint2 == null) {
                this.states.remove(mxCellState.getCell());
            }
            else {
                if (mxPoint.getX() != mxPoint2.getX() || mxPoint.getY() != mxPoint2.getY()) {
                    final double n = mxPoint2.getX() - mxPoint.getX();
                    final double n2 = mxPoint2.getY() - mxPoint.getY();
                    mxCellState.setTerminalDistance(Math.sqrt(n * n + n2 * n2));
                }
                else {
                    mxCellState.setTerminalDistance(0.0);
                }
                double length = 0.0;
                final double[] segments = new double[absolutePoints.size() - 1];
                mxPoint mxPoint3 = mxPoint;
                if (mxPoint3 != null) {
                    double n3 = mxPoint3.getX();
                    double n4 = mxPoint3.getY();
                    double max = n3;
                    double max2 = n4;
                    for (int i = 1; i < absolutePoints.size(); ++i) {
                        final mxPoint mxPoint4 = absolutePoints.get(i);
                        if (mxPoint4 != null) {
                            final double n5 = mxPoint3.getX() - mxPoint4.getX();
                            final double n6 = mxPoint3.getY() - mxPoint4.getY();
                            final double sqrt = Math.sqrt(n5 * n5 + n6 * n6);
                            segments[i - 1] = sqrt;
                            length += sqrt;
                            mxPoint3 = mxPoint4;
                            n3 = Math.min(mxPoint3.getX(), n3);
                            n4 = Math.min(mxPoint3.getY(), n4);
                            max = Math.max(mxPoint3.getX(), max);
                            max2 = Math.max(mxPoint3.getY(), max2);
                        }
                    }
                    mxCellState.setLength(length);
                    mxCellState.setSegments(segments);
                    final double n7 = 1.0;
                    mxCellState.setX(n3);
                    mxCellState.setY(n4);
                    mxCellState.setWidth(Math.max(n7, max - n3));
                    mxCellState.setHeight(Math.max(n7, max2 - n4));
                }
                else {
                    mxCellState.setLength(0.0);
                }
            }
        }
    }
    
    public mxPoint getPoint(final mxCellState mxCellState) {
        return this.getPoint(mxCellState, null);
    }
    
    public mxPoint getPoint(final mxCellState mxCellState, final mxGeometry mxGeometry) {
        double centerX = mxCellState.getCenterX();
        double centerY = mxCellState.getCenterY();
        if (mxCellState.getSegments() != null && (mxGeometry == null || mxGeometry.isRelative())) {
            final double n = (mxGeometry != null) ? (mxGeometry.getX() / 2.0) : 0.0;
            int absolutePointCount;
            double n2;
            double[] segments;
            double n3;
            double n4;
            int n5;
            for (absolutePointCount = mxCellState.getAbsolutePointCount(), n2 = (n + 0.5) * mxCellState.getLength(), segments = mxCellState.getSegments(), n3 = segments[0], n4 = 0.0, n5 = 1; n2 > n4 + n3 && n5 < absolutePointCount - 1; n4 += n3, n3 = segments[n5++]) {}
            if (n3 != 0.0) {
                final double n6 = (n2 - n4) / n3;
                final mxPoint absolutePoint = mxCellState.getAbsolutePoint(n5 - 1);
                final mxPoint absolutePoint2 = mxCellState.getAbsolutePoint(n5);
                if (absolutePoint != null && absolutePoint2 != null) {
                    double y = 0.0;
                    double x = 0.0;
                    double y2 = 0.0;
                    if (mxGeometry != null) {
                        y = mxGeometry.getY();
                        final mxPoint offset = mxGeometry.getOffset();
                        if (offset != null) {
                            x = offset.getX();
                            y2 = offset.getY();
                        }
                    }
                    final double n7 = absolutePoint2.getX() - absolutePoint.getX();
                    final double n8 = absolutePoint2.getY() - absolutePoint.getY();
                    final double n9 = n8 / n3;
                    final double n10 = n7 / n3;
                    centerX = absolutePoint.getX() + n7 * n6 + (n9 * y + x) * this.scale;
                    centerY = absolutePoint.getY() + n8 * n6 - (n10 * y - y2) * this.scale;
                }
            }
        }
        else if (mxGeometry != null) {
            final mxPoint offset2 = mxGeometry.getOffset();
            if (offset2 != null) {
                centerX += offset2.getX();
                centerY += offset2.getY();
            }
        }
        return new mxPoint(centerX, centerY);
    }
    
    public mxPoint getRelativePoint(final mxCellState mxCellState, final double n, final double n2) {
        final mxGeometry geometry = this.graph.getModel().getGeometry(mxCellState.getCell());
        final double scale = this.graph.getView().getScale();
        if (geometry != null) {
            final int absolutePointCount = mxCellState.getAbsolutePointCount();
            if (geometry.isRelative() && absolutePointCount > 1) {
                final double length = mxCellState.getLength();
                final double[] segments = mxCellState.getSegments();
                mxPoint absolutePoint = mxCellState.getAbsolutePoint(0);
                double ptSegDistSq = new Line2D.Double(absolutePoint.getPoint(), mxCellState.getAbsolutePoint(1).getPoint()).ptSegDistSq(n, n2);
                int n3 = 0;
                double n4 = 0.0;
                double n5 = 0.0;
                for (int i = 2; i < absolutePointCount; ++i) {
                    n4 += segments[i - 2];
                    final mxPoint absolutePoint2 = mxCellState.getAbsolutePoint(i);
                    final double ptSegDistSq2 = new Line2D.Double(absolutePoint2.getPoint(), absolutePoint.getPoint()).ptSegDistSq(n, n2);
                    if (ptSegDistSq2 < ptSegDistSq) {
                        ptSegDistSq = ptSegDistSq2;
                        n3 = i - 1;
                        n5 = n4;
                    }
                    absolutePoint = absolutePoint2;
                }
                final double n6 = segments[n3];
                final mxPoint absolutePoint3 = mxCellState.getAbsolutePoint(n3);
                final mxPoint absolutePoint4 = mxCellState.getAbsolutePoint(n3 + 1);
                final double x = absolutePoint3.getX();
                final double y = absolutePoint3.getY();
                final double x2 = absolutePoint4.getX();
                final double y2 = absolutePoint4.getY();
                final double n7 = x - x2;
                final double n8 = y - y2;
                final double n9 = (n7 - (n - x2)) * n7 + (n8 - (n2 - y2)) * n8;
                double a;
                if (n9 <= 0.0) {
                    a = 0.0;
                }
                else {
                    a = n9 * n9 / (n7 * n7 + n8 * n8);
                }
                double sqrt = Math.sqrt(a);
                if (sqrt > n6) {
                    sqrt = n6;
                }
                double ptLineDist = Line2D.ptLineDist(absolutePoint3.getX(), absolutePoint3.getY(), absolutePoint4.getX(), absolutePoint4.getY(), n, n2);
                if (Line2D.relativeCCW(absolutePoint3.getX(), absolutePoint3.getY(), absolutePoint4.getX(), absolutePoint4.getY(), n, n2) == -1) {
                    ptLineDist = -ptLineDist;
                }
                return new mxPoint((double)Math.round((length / 2.0 - n5 - sqrt) / length * -2.0), (double)Math.round(ptLineDist / scale));
            }
        }
        return new mxPoint();
    }
    
    public mxCellState getState(final Object o) {
        return this.getState(o, false);
    }
    
    public mxCellState[] getStates(final Object[] array) {
        final ArrayList<mxCellState> list = new ArrayList<mxCellState>(array.length);
        for (int i = 0; i < array.length; ++i) {
            final mxCellState state = this.getState(array[i]);
            if (state != null) {
                list.add(state);
            }
        }
        return (mxCellState[])list.toArray();
    }
    
    public mxCellState getState(final Object o, final boolean b) {
        mxCellState state = null;
        if (o != null) {
            state = this.states.get(o);
            if (state == null && b && this.graph.isCellVisible(o)) {
                state = this.createState(o);
                this.states.put(o, state);
            }
        }
        return state;
    }
    
    public mxCellState removeState(final Object key) {
        return (key != null) ? this.states.remove(key) : null;
    }
    
    public mxCellState createState(final Object o) {
        return new mxCellState(this, o, this.graph.getCellStyle(o));
    }
    
    static {
        mxGraphView.EVENT_UNDO = "undo";
        mxGraphView.EVENT_UP = "up";
        mxGraphView.EVENT_DOWN = "down";
        mxGraphView.EVENT_SCALE = "scale";
        mxGraphView.EVENT_TRANSLATE = "translate";
        mxGraphView.EVENT_SCALE_AND_TRANSLATE = "scaleAndTranslate";
    }
    
    public static class mxCurrentRootChange implements mxUndoableEdit.mxUndoableChange
    {
        protected mxGraphView view;
        protected Object root;
        protected Object previous;
        protected boolean up;
        
        public mxCurrentRootChange(final mxGraphView view, final Object root) {
            this.view = view;
            this.root = root;
            this.previous = this.root;
            if (!(this.up = (root == null))) {
                Object o = view.getCurrentRoot();
                for (mxIGraphModel model = view.graph.getModel(); o != null; o = model.getParent(o)) {
                    if (o == root) {
                        this.up = true;
                        break;
                    }
                }
            }
        }
        
        public void execute() {
            final Object currentRoot = this.view.getCurrentRoot();
            this.view.currentRoot = this.previous;
            this.previous = currentRoot;
            final mxPoint translateForRoot = this.view.graph.getTranslateForRoot(this.view.getCurrentRoot());
            if (translateForRoot != null) {
                this.view.translate = new mxPoint(-translateForRoot.getX(), translateForRoot.getY());
            }
            this.view.revalidate();
            this.up = !this.up;
            this.view.fireEvent(this.up ? mxGraphView.EVENT_UP : mxGraphView.EVENT_DOWN, new Object[] { this.previous, this.view.currentRoot });
        }
    }
}
