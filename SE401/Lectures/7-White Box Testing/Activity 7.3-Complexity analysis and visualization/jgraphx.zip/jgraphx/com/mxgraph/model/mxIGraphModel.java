// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.model;

import com.mxgraph.util.mxUndoableEdit;
import com.mxgraph.util.mxEventSource;

public interface mxIGraphModel extends mxEventSource.mxIEventSource
{
    public static final String EVENT_CHANGE = "change";
    public static final String EVENT_BEFORE_EXECUTE = "beforeExecute";
    public static final String EVENT_EXECUTE = "execute";
    public static final String EVENT_AFTER_EXECUTE = "afterExecute";
    public static final String EVENT_BEFORE_UNDO = "beforeUndo";
    public static final String EVENT_UNDO = "undo";
    public static final String EVENT_NOTIFY = "notify";
    public static final String EVENT_BEGIN_UPDATE = "beginUpdate";
    public static final String EVENT_END_UPDATE = "endUpdate";
    
    Object getRoot();
    
    Object setRoot(final Object p0);
    
    Object[] cloneCells(final Object[] p0, final boolean p1);
    
    boolean isAncestor(final Object p0, final Object p1);
    
    boolean contains(final Object p0);
    
    Object getParent(final Object p0);
    
    Object add(final Object p0, final Object p1, final int p2);
    
    Object remove(final Object p0);
    
    int getChildCount(final Object p0);
    
    Object getChildAt(final Object p0, final int p1);
    
    Object getTerminal(final Object p0, final boolean p1);
    
    Object setTerminal(final Object p0, final Object p1, final boolean p2);
    
    int getEdgeCount(final Object p0);
    
    Object getEdgeAt(final Object p0, final int p1);
    
    boolean isVertex(final Object p0);
    
    boolean isEdge(final Object p0);
    
    boolean isConnectable(final Object p0);
    
    Object getValue(final Object p0);
    
    Object setValue(final Object p0, final Object p1);
    
    mxGeometry getGeometry(final Object p0);
    
    mxGeometry setGeometry(final Object p0, final mxGeometry p1);
    
    String getStyle(final Object p0);
    
    String setStyle(final Object p0, final String p1);
    
    boolean isCollapsed(final Object p0);
    
    boolean setCollapsed(final Object p0, final boolean p1);
    
    boolean isVisible(final Object p0);
    
    boolean setVisible(final Object p0, final boolean p1);
    
    void beginUpdate();
    
    void endUpdate();
    
    public abstract static class mxAtomicGraphModelChange implements mxUndoableEdit.mxUndoableChange
    {
        protected mxIGraphModel model;
        
        public mxAtomicGraphModelChange() {
            this(null);
        }
        
        public mxAtomicGraphModelChange(final mxIGraphModel model) {
            this.model = model;
        }
        
        public mxIGraphModel getModel() {
            return this.model;
        }
        
        public void setModel(final mxIGraphModel model) {
            this.model = model;
        }
        
        public abstract void execute();
    }
}
