// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.io;

import java.util.ArrayList;
import java.util.Map;
import java.util.Collection;
import java.util.List;
import java.util.Hashtable;

public class mxCodecRegistry
{
    static Hashtable codecs;
    static List packages;
    
    public static mxObjectCodec register(final mxObjectCodec value) {
        if (value != null) {
            mxCodecRegistry.codecs.put(getName(value.getTemplate().getClass()), value);
        }
        return value;
    }
    
    public static mxObjectCodec getCodec(final String key) {
        mxObjectCodec mxObjectCodec = mxCodecRegistry.codecs.get(key);
        if (mxObjectCodec == null) {
            final Object instanceForName = getInstanceForName(key);
            if (instanceForName != null) {
                try {
                    mxObjectCodec = new mxObjectCodec(instanceForName);
                    register(mxObjectCodec);
                }
                catch (Exception ex) {}
            }
        }
        return mxObjectCodec;
    }
    
    public static void addPackage(final String s) {
        mxCodecRegistry.packages.add(s);
    }
    
    public static Object getInstanceForName(final String s) {
        int i = 0;
        while (i < mxCodecRegistry.packages.size()) {
            try {
                return Class.forName(String.valueOf(mxCodecRegistry.packages.get(i)) + "." + s).newInstance();
            }
            catch (Exception ex) {
                try {
                    return Class.forName(s).newInstance();
                }
                catch (Exception ex2) {
                    ++i;
                }
            }
            break;
        }
        return null;
    }
    
    public static String getName(final Class clazz) {
        if (clazz.isArray() || Collection.class.isAssignableFrom(clazz) || Map.class.isAssignableFrom(clazz)) {
            return "Array";
        }
        if (mxCodecRegistry.packages.contains(clazz.getPackage().getName())) {
            return clazz.getSimpleName();
        }
        return clazz.getName();
    }
    
    static {
        mxCodecRegistry.codecs = new Hashtable();
        mxCodecRegistry.packages = new ArrayList();
        addPackage("com.mxgraph");
        addPackage("com.mxgraph.util");
        addPackage("com.mxgraph.model");
        addPackage("com.mxgraph.view");
        addPackage("java.lang");
        addPackage("java.util");
        register(new mxObjectCodec(new ArrayList()));
        register(new mxModelCodec());
        register(new mxCellCodec());
        register(new mxStylesheetCodec());
    }
}
