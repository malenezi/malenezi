// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import com.mxgraph.view.mxGraphView;
import java.util.List;
import com.mxgraph.util.mxConstants;
import com.mxgraph.util.mxPoint;
import java.awt.Point;
import java.awt.Rectangle;
import com.mxgraph.util.mxResources;
import java.awt.event.MouseEvent;
import com.mxgraph.view.mxCellState;
import com.mxgraph.swing.mxGraphComponent;

public class mxElbowEdgeHandler extends mxEdgeHandler
{
    protected boolean bendable;
    
    public mxElbowEdgeHandler(final mxGraphComponent mxGraphComponent, final mxCellState mxCellState) {
        super(mxGraphComponent, mxCellState);
        this.bendable = mxGraphComponent.getGraph().isBendable(mxCellState.getCell());
    }
    
    @Override
    public String getToolTipText(final MouseEvent mouseEvent) {
        if (this.getIndexAt(mouseEvent.getX(), mouseEvent.getY()) == 1) {
            return mxResources.get("doubleClickOrientation");
        }
        return null;
    }
    
    @Override
    protected boolean isFlipEvent(final MouseEvent mouseEvent) {
        return mouseEvent.getClickCount() == 2 && this.index == 1;
    }
    
    @Override
    protected boolean isHandleVisible(final int n) {
        return super.isHandleVisible(n) && (n != 1 || this.bendable);
    }
    
    @Override
    protected Rectangle[] createHandles() {
        this.p = this.createPoints(this.state);
        final Rectangle[] array = new Rectangle[4];
        final mxPoint absolutePoint = this.state.getAbsolutePoint(0);
        final mxPoint absolutePoint2 = this.state.getAbsolutePoint(this.state.getAbsolutePointCount() - 1);
        array[0] = this.createHandle(absolutePoint.getPoint());
        array[2] = this.createHandle(absolutePoint2.getPoint());
        final List points = this.graphComponent.getGraph().getModel().getGeometry(this.state.getCell()).getPoints();
        if (points == null || points.isEmpty()) {
            array[1] = this.createHandle(new Point((int)(Math.round(absolutePoint.getX()) + Math.round((absolutePoint2.getX() - absolutePoint.getX()) / 2.0)), (int)(Math.round(absolutePoint.getY()) + Math.round((absolutePoint2.getY() - absolutePoint.getY()) / 2.0))));
        }
        else {
            final mxGraphView view = this.graphComponent.getGraph().getView();
            final double scale = view.getScale();
            final mxPoint translate = view.getTranslate();
            final mxPoint mxPoint = points.get(0);
            array[1] = this.createHandle(new Point((int)Math.round(scale * (mxPoint.getX() + translate.getX() + this.state.getOrigin().getX())), (int)Math.round(scale * (mxPoint.getY() + translate.getY() + this.state.getOrigin().getY()))));
        }
        array[3] = this.createHandle(this.state.getAbsoluteOffset().getPoint(), mxConstants.HANDLE_SIZE - 2);
        return array;
    }
}
