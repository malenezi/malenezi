// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.algebra;

import com.mxgraph.util.mxPoint;
import java.awt.geom.Point2D;
import com.mxgraph.view.mxCellState;

public class mxDistanceCostFunction implements mxICostFunction
{
    public double getCost(final mxCellState mxCellState) {
        double n = 0.0;
        final int absolutePointCount = mxCellState.getAbsolutePointCount();
        if (absolutePointCount > 0) {
            mxPoint absolutePoint = mxCellState.getAbsolutePoint(0);
            for (int i = 1; i < absolutePointCount; ++i) {
                final mxPoint absolutePoint2 = mxCellState.getAbsolutePoint(i);
                n += absolutePoint2.getPoint().distance(absolutePoint.getPoint());
                absolutePoint = absolutePoint2;
            }
        }
        return n;
    }
}
