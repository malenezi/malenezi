// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.util;

import java.util.ArrayList;
import java.util.List;

public class mxUndoableEdit
{
    protected Object source;
    protected List changes;
    protected boolean significant;
    protected boolean undone;
    protected boolean redone;
    
    public mxUndoableEdit(final Object o) {
        this(o, true);
    }
    
    public mxUndoableEdit(final Object source, final boolean significant) {
        this.changes = new ArrayList();
        this.significant = true;
        this.source = source;
        this.significant = significant;
    }
    
    public void dispatch() {
    }
    
    public void die() {
    }
    
    public Object getSource() {
        return this.source;
    }
    
    public List getChanges() {
        return this.changes;
    }
    
    public boolean isSignificant() {
        return this.significant;
    }
    
    public boolean isUndone() {
        return this.undone;
    }
    
    public boolean isRedone() {
        return this.redone;
    }
    
    public boolean isEmpty() {
        return this.changes.isEmpty();
    }
    
    public void add(final mxUndoableChange mxUndoableChange) {
        this.changes.add(mxUndoableChange);
    }
    
    public void undo() {
        if (!this.undone) {
            for (int i = this.changes.size() - 1; i >= 0; --i) {
                ((mxUndoableChange)this.changes.get(i)).execute();
            }
            this.undone = true;
            this.redone = false;
        }
        this.dispatch();
    }
    
    public void redo() {
        if (!this.redone) {
            for (int size = this.changes.size(), i = 0; i < size; ++i) {
                ((mxUndoableChange)this.changes.get(i)).execute();
            }
            this.undone = false;
            this.redone = true;
        }
        this.dispatch();
    }
    
    public interface mxUndoableChange
    {
        void execute();
    }
}
