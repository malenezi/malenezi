// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.util;

import com.mxgraph.util.mxPoint;
import com.mxgraph.util.mxRectangle;
import com.mxgraph.view.mxCellState;
import java.awt.image.ImageObserver;
import java.awt.Graphics;
import java.awt.Cursor;
import javax.swing.ImageIcon;
import javax.swing.JComponent;

public class mxOverlay extends JComponent implements mxIOverlay
{
    protected ImageIcon imageIcon;
    protected Object align;
    protected Object verticalAlign;
    protected double defaultOverlap;
    
    public mxOverlay(final ImageIcon imageIcon, final String toolTipText) {
        this.align = "right";
        this.verticalAlign = "bottom";
        this.defaultOverlap = 0.5;
        this.imageIcon = imageIcon;
        this.setToolTipText(toolTipText);
        this.setCursor(new Cursor(0));
    }
    
    @Override
    public void paint(final Graphics graphics) {
        graphics.drawImage(this.imageIcon.getImage(), 0, 0, this.getWidth(), this.getHeight(), this);
    }
    
    public mxRectangle getBounds(final mxCellState mxCellState) {
        final boolean edge = mxCellState.getView().getGraph().getModel().isEdge(mxCellState.getCell());
        final double scale = mxCellState.getView().getScale();
        final int iconWidth = this.imageIcon.getIconWidth();
        final int iconHeight = this.imageIcon.getIconHeight();
        mxPoint absolutePoint;
        if (edge) {
            final int absolutePointCount = mxCellState.getAbsolutePointCount();
            if (absolutePointCount % 2 == 1) {
                absolutePoint = mxCellState.getAbsolutePoint(absolutePointCount / 2 + 1);
            }
            else {
                final int n = absolutePointCount / 2;
                final mxPoint absolutePoint2 = mxCellState.getAbsolutePoint(n - 1);
                final mxPoint absolutePoint3 = mxCellState.getAbsolutePoint(n);
                absolutePoint = new mxPoint(absolutePoint2.getX() + (absolutePoint3.getX() - absolutePoint2.getX()) / 2.0, absolutePoint2.getY() + (absolutePoint3.getY() - absolutePoint2.getY()) / 2.0);
            }
        }
        else {
            absolutePoint = new mxPoint();
            if (this.align.equals("left")) {
                absolutePoint.setX(mxCellState.getX());
            }
            else if (this.align.equals("center")) {
                absolutePoint.setX(mxCellState.getX() + mxCellState.getWidth() / 2.0);
            }
            else {
                absolutePoint.setX(mxCellState.getX() + mxCellState.getWidth());
            }
            if (this.verticalAlign.equals("top")) {
                absolutePoint.setY(mxCellState.getY());
            }
            else if (this.verticalAlign.equals("middle")) {
                absolutePoint.setY(mxCellState.getY() + mxCellState.getHeight() / 2.0);
            }
            else {
                absolutePoint.setY(mxCellState.getY() + mxCellState.getHeight());
            }
        }
        return new mxRectangle(absolutePoint.getX() - iconWidth * this.defaultOverlap * scale, absolutePoint.getY() - iconHeight * this.defaultOverlap * scale, iconWidth * scale, iconHeight * scale);
    }
}
