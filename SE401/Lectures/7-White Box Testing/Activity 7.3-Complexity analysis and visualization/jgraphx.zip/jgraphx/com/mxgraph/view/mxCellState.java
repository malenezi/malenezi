// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.view;

import java.util.ArrayList;
import java.awt.geom.Rectangle2D;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxConstants;
import java.util.List;
import com.mxgraph.util.mxPoint;
import java.util.Hashtable;
import com.mxgraph.util.mxRectangle;

public class mxCellState extends mxRectangle
{
    protected mxGraphView view;
    protected Object cell;
    protected Hashtable style;
    protected mxPoint origin;
    protected List absolutePoints;
    protected mxPoint absoluteOffset;
    protected double terminalDistance;
    protected double length;
    protected double[] segments;
    protected mxRectangle labelBounds;
    protected mxRectangle boundingBox;
    protected boolean invalid;
    
    public mxCellState() {
        this(null, null, null);
    }
    
    public mxCellState(final mxGraphView view, final Object cell, final Hashtable style) {
        this.origin = new mxPoint();
        this.absoluteOffset = new mxPoint();
        this.invalid = true;
        this.setView(view);
        this.setCell(cell);
        this.setStyle(style);
    }
    
    public boolean isInvalid() {
        return this.invalid;
    }
    
    public void setInvalid(final boolean invalid) {
        this.invalid = invalid;
    }
    
    public mxGraphView getView() {
        return this.view;
    }
    
    public void setView(final mxGraphView view) {
        this.view = view;
    }
    
    public Object getCell() {
        return this.cell;
    }
    
    public void setCell(final Object cell) {
        this.cell = cell;
    }
    
    public Hashtable getStyle() {
        return this.style;
    }
    
    public void setStyle(final Hashtable style) {
        this.style = style;
    }
    
    public mxPoint getOrigin() {
        return this.origin;
    }
    
    public void setOrigin(final mxPoint origin) {
        this.origin = origin;
    }
    
    public mxPoint getAbsolutePoint(final int n) {
        return this.absolutePoints.get(n);
    }
    
    public mxPoint setAbsolutePoint(final int n, final mxPoint mxPoint) {
        return this.absolutePoints.set(n, mxPoint);
    }
    
    public int getAbsolutePointCount() {
        return (this.absolutePoints != null) ? this.absolutePoints.size() : 0;
    }
    
    public List getAbsolutePoints() {
        return this.absolutePoints;
    }
    
    public void setAbsolutePoints(final List absolutePoints) {
        this.absolutePoints = absolutePoints;
    }
    
    public mxPoint getAbsoluteOffset() {
        return this.absoluteOffset;
    }
    
    public void setAbsoluteOffset(final mxPoint absoluteOffset) {
        this.absoluteOffset = absoluteOffset;
    }
    
    public double getTerminalDistance() {
        return this.terminalDistance;
    }
    
    public void setTerminalDistance(final double terminalDistance) {
        this.terminalDistance = terminalDistance;
    }
    
    public double getLength() {
        return this.length;
    }
    
    public void setLength(final double length) {
        this.length = length;
    }
    
    public double[] getSegments() {
        return this.segments;
    }
    
    public void setSegments(final double[] segments) {
        this.segments = segments;
    }
    
    public mxRectangle getLabelBounds() {
        return this.labelBounds;
    }
    
    public void setLabelBounds(final mxRectangle labelBounds) {
        this.labelBounds = labelBounds;
    }
    
    public mxRectangle getBoundingBox() {
        return this.boundingBox;
    }
    
    public void setBoundingBox(final mxRectangle boundingBox) {
        this.boundingBox = boundingBox;
    }
    
    public double getCenterX() {
        return (double)Math.round(this.getX() + this.getWidth() / 2.0);
    }
    
    public double getCenterY() {
        return (double)Math.round(this.getY() + this.getHeight() / 2.0);
    }
    
    public double getRoutingCenterX() {
        return this.getCenterX() + ((this.style != null) ? mxUtils.getFloat(this.style, mxConstants.STYLE_ROUTING_CENTER_X) : 0.0f) * this.width;
    }
    
    public double getRoutingCenterY() {
        return this.getCenterY() + ((this.style != null) ? mxUtils.getFloat(this.style, mxConstants.STYLE_ROUTING_CENTER_Y) : 0.0f) * this.height;
    }
    
    public mxRectangle getPerimeterBounds() {
        return this.getPerimeterBounds(0.0);
    }
    
    public mxRectangle getPerimeterBounds(final double n) {
        final mxRectangle mxRectangle = new mxRectangle(this.getRectangle());
        mxRectangle.grow(n);
        return mxRectangle;
    }
    
    public void setAbsoluteTerminalPoint(final mxPoint mxPoint, final boolean b) {
        if (b) {
            if (this.absolutePoints == null || this.absolutePoints.size() == 0) {
                (this.absolutePoints = new ArrayList()).add(mxPoint);
            }
            else {
                this.absolutePoints.set(0, mxPoint);
            }
        }
        else if (this.absolutePoints == null) {
            (this.absolutePoints = new ArrayList()).add(null);
            this.absolutePoints.add(mxPoint);
        }
        else if (this.absolutePoints.size() == 1) {
            this.absolutePoints.add(mxPoint);
        }
        else {
            this.absolutePoints.set(this.absolutePoints.size() - 1, mxPoint);
        }
    }
    
    @Override
    public Object clone() {
        final mxCellState mxCellState = new mxCellState(this.view, this.cell, this.style);
        if (this.absolutePoints != null) {
            mxCellState.absolutePoints = new ArrayList();
            for (int i = 0; i < this.absolutePoints.size(); ++i) {
                mxCellState.absolutePoints.add(((mxPoint)this.absolutePoints.get(i)).clone());
            }
        }
        if (this.origin != null) {
            mxCellState.origin = (mxPoint)this.origin.clone();
        }
        if (this.absoluteOffset != null) {
            mxCellState.absoluteOffset = (mxPoint)this.absoluteOffset.clone();
        }
        if (this.boundingBox != null) {
            mxCellState.boundingBox = (mxRectangle)this.boundingBox.clone();
        }
        mxCellState.terminalDistance = this.terminalDistance;
        mxCellState.segments = this.segments;
        mxCellState.length = this.length;
        mxCellState.x = this.x;
        mxCellState.y = this.y;
        mxCellState.width = this.width;
        mxCellState.height = this.height;
        return mxCellState;
    }
}
