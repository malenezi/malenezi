// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.algebra;

import java.util.List;
import java.util.Collections;
import java.util.Comparator;
import java.util.Arrays;
import com.mxgraph.view.mxCellState;
import com.mxgraph.view.mxGraphView;
import java.util.ArrayList;
import java.util.Hashtable;
import com.mxgraph.view.mxGraph;

public class mxGraphAlgebra
{
    protected static mxGraphAlgebra instance;
    
    protected mxGraphAlgebra() {
    }
    
    public static mxGraphAlgebra getInstance() {
        return mxGraphAlgebra.instance;
    }
    
    public static void setInstance(final mxGraphAlgebra instance) {
        mxGraphAlgebra.instance = instance;
    }
    
    public Object[] getShortestPath(final mxGraph mxGraph, final Object o, final Object o2, final mxICostFunction mxICostFunction, final int n, final boolean b) {
        final mxGraphView view = mxGraph.getView();
        final mxFibonacciHeap priorityQueue = this.createPriorityQueue();
        final Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>();
        priorityQueue.decreaseKey(priorityQueue.getNode(o, true), 0.0);
        for (int i = 0; i < n; ++i) {
            final mxFibonacciHeap.Node removeMin = priorityQueue.removeMin();
            final double key = removeMin.getKey();
            final Object userObject = removeMin.getUserObject();
            if (userObject == o2) {
                break;
            }
            final Object[] array = b ? mxGraph.getOutgoingEdges(userObject) : mxGraph.getConnections(userObject);
            final Object[] opposites = mxGraph.getOpposites(array, userObject);
            if (array != null) {
                for (int j = 0; j < array.length; ++j) {
                    final Object key2 = opposites[j];
                    if (key2 != null && key2 != userObject && key2 != o) {
                        final double n2 = key + ((mxICostFunction != null) ? mxICostFunction.getCost(view.getState(array[j])) : 1.0);
                        final mxFibonacciHeap.Node node = priorityQueue.getNode(key2, true);
                        if (n2 < node.getKey()) {
                            hashtable.put(key2, array[j]);
                            priorityQueue.decreaseKey(node, n2);
                        }
                    }
                }
            }
            if (priorityQueue.isEmpty()) {
                break;
            }
        }
        final ArrayList<Object> list = new ArrayList<Object>(2 * n);
        Object visibleTerminal = o2;
        Object element = hashtable.get(visibleTerminal);
        if (element != null) {
            list.add(visibleTerminal);
            while (element != null) {
                list.add(0, element);
                visibleTerminal = view.getVisibleTerminal(element, view.getVisibleTerminal(element, true) != visibleTerminal);
                list.add(0, visibleTerminal);
                element = hashtable.get(visibleTerminal);
            }
        }
        return list.toArray();
    }
    
    public Object[] getMinimumSpanningTree(final mxGraph mxGraph, final Object[] array, final mxICostFunction mxICostFunction, final boolean b) {
        final ArrayList<Object> list = new ArrayList<Object>(array.length);
        final mxFibonacciHeap priorityQueue = this.createPriorityQueue();
        final Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>();
        priorityQueue.decreaseKey(priorityQueue.getNode(array[0], true), 0.0);
        for (int i = 1; i < array.length; ++i) {
            priorityQueue.getNode(array[i], true);
        }
        while (!priorityQueue.isEmpty()) {
            final Object userObject = priorityQueue.removeMin().getUserObject();
            final Object value = hashtable.get(userObject);
            if (value != null) {
                list.add(value);
            }
            final Object[] array2 = b ? mxGraph.getOutgoingEdges(userObject) : mxGraph.getConnections(userObject);
            final Object[] opposites = mxGraph.getOpposites(array2, userObject);
            if (array2 != null) {
                for (int j = 0; j < array2.length; ++j) {
                    final Object key = opposites[j];
                    if (key != null && key != userObject) {
                        final mxFibonacciHeap.Node node = priorityQueue.getNode(key, false);
                        if (node != null) {
                            final double cost = mxICostFunction.getCost(mxGraph.getView().getState(array2[j]));
                            if (cost < node.getKey()) {
                                hashtable.put(key, array2[j]);
                                priorityQueue.decreaseKey(node, cost);
                            }
                        }
                    }
                }
            }
        }
        return list.toArray();
    }
    
    public Object[] getMinimumSpanningTree(final mxGraph mxGraph, final Object[] array, final Object[] array2, final mxICostFunction mxICostFunction) {
        final mxGraphView view = mxGraph.getView();
        final mxUnionFind unionFind = this.createUnionFind(array);
        final ArrayList<Object> list = new ArrayList<Object>(array2.length);
        final mxCellState[] sort = this.sort(view.getStates(array2), mxICostFunction);
        for (int i = 0; i < sort.length; ++i) {
            final Object cell = sort[i].getCell();
            final Object visibleTerminal = view.getVisibleTerminal(cell, true);
            final Object visibleTerminal2 = view.getVisibleTerminal(cell, false);
            final mxUnionFind.Node find = unionFind.find(unionFind.getNode(visibleTerminal));
            final mxUnionFind.Node find2 = unionFind.find(unionFind.getNode(visibleTerminal2));
            if (find == null || find2 == null || find != find2) {
                unionFind.union(find, find2);
                list.add(cell);
            }
        }
        return list.toArray();
    }
    
    public mxUnionFind getConnectionComponents(final mxGraph mxGraph, final Object[] array, final Object[] array2) {
        final mxGraphView view = mxGraph.getView();
        final mxUnionFind unionFind = this.createUnionFind(array);
        for (int i = 0; i < array2.length; ++i) {
            unionFind.union(unionFind.find(unionFind.getNode(view.getVisibleTerminal(array2[i], true))), unionFind.find(unionFind.getNode(view.getVisibleTerminal(array2[i], false))));
        }
        return unionFind;
    }
    
    public mxCellState[] sort(final mxCellState[] a, final mxICostFunction mxICostFunction) {
        final List<mxCellState> list = Arrays.asList(a);
        Collections.sort((List<Object>)list, new Comparator() {
            public int compare(final Object o, final Object o2) {
                return new Double(mxICostFunction.getCost((mxCellState)o)).compareTo(new Double(mxICostFunction.getCost((mxCellState)o2)));
            }
        });
        return (mxCellState[])list.toArray();
    }
    
    public double sum(final mxCellState[] array, final mxICostFunction mxICostFunction) {
        double n = 0.0;
        for (int i = 0; i < array.length; ++i) {
            n += mxICostFunction.getCost(array[i]);
        }
        return n;
    }
    
    protected mxUnionFind createUnionFind(final Object[] array) {
        return new mxUnionFind(array);
    }
    
    protected mxFibonacciHeap createPriorityQueue() {
        return new mxFibonacciHeap();
    }
    
    static {
        mxGraphAlgebra.instance = new mxGraphAlgebra();
    }
}
