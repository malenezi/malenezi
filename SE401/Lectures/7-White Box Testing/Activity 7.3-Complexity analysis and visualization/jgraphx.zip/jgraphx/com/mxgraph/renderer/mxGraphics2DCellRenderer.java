// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.renderer;

import com.mxgraph.util.mxRectangle;
import com.mxgraph.view.mxGraph;
import java.awt.image.BufferedImage;
import com.mxgraph.canvas.mxGraphics2DCanvas;
import com.mxgraph.canvas.mxICanvas;
import java.awt.Color;

public class mxGraphics2DCellRenderer extends mxAbstractCellRenderer
{
    protected boolean antiAlias;
    
    public mxGraphics2DCellRenderer(final boolean antiAlias) {
        this.antiAlias = antiAlias;
    }
    
    @Override
    protected mxICanvas createCanvas(final int n, final int n2, final int n3, final int n4, final double n5, final Color color) {
        final mxGraphics2DCanvas mxGraphics2DCanvas = new mxGraphics2DCanvas(n, n2, n3 + 1, n4 + 1, n5, color);
        if (mxGraphics2DCanvas.getGraphics() != null) {
            mxGraphics2DCanvas.setTextAntiAlias(true);
            mxGraphics2DCanvas.setAntiAlias(this.antiAlias);
            return mxGraphics2DCanvas;
        }
        return null;
    }
    
    public BufferedImage getImage(final mxICanvas mxICanvas) {
        BufferedImage image = null;
        if (mxICanvas instanceof mxGraphics2DCanvas) {
            final mxGraphics2DCanvas mxGraphics2DCanvas = (mxGraphics2DCanvas)mxICanvas;
            image = mxGraphics2DCanvas.getImage();
            mxGraphics2DCanvas.destroy();
        }
        return image;
    }
    
    public static BufferedImage render(final mxGraph mxGraph, final double n, final Color color, final boolean b, final Object[] array) {
        if (array != null) {
            final mxGraphics2DCellRenderer mxGraphics2DCellRenderer = new mxGraphics2DCellRenderer(b);
            return mxGraphics2DCellRenderer.getImage(mxGraphics2DCellRenderer.drawCells(mxGraph, array, n, color, null));
        }
        return null;
    }
    
    public static BufferedImage render(final mxGraph mxGraph, final double n, final Color color, final boolean b) {
        return render(mxGraph, n, color, b, new Object[] { mxGraph.getModel().getRoot() });
    }
}
