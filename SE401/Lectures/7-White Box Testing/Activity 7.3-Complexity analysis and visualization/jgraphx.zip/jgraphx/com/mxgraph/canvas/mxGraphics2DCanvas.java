// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.canvas;

import java.awt.FontMetrics;
import java.awt.Container;
import java.awt.Component;
import java.awt.Graphics;
import javax.swing.text.StyledDocument;
import com.mxgraph.util.mxLightweightTextPane;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Line2D;
import java.awt.GradientPaint;
import java.awt.geom.QuadCurve2D;
import com.mxgraph.util.mxPoint;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Area;
import java.awt.image.ImageObserver;
import java.awt.geom.GeneralPath;
import java.awt.Polygon;
import java.awt.Paint;
import java.awt.BasicStroke;
import java.awt.Font;
import java.util.List;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.util.Map;
import java.awt.Image;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxConstants;
import java.awt.Composite;
import java.awt.AlphaComposite;
import java.awt.Shape;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.CellRendererPane;
import java.util.Hashtable;

public class mxGraphics2DCanvas implements mxICanvas
{
    public static boolean INDEXED;
    public static boolean ANTIALIAS;
    public static String DEFAULT_IMAGEBASEPATH;
    public String imageBasePath;
    protected Hashtable imageCache;
    protected CellRendererPane rendererPane;
    protected BufferedImage image;
    protected Graphics2D g;
    protected int x;
    protected int y;
    protected int width;
    protected int height;
    protected double scale;
    protected Color background;
    
    public mxGraphics2DCanvas(final int n, final int n2, final double n3) {
        this(0, 0, n, n2, n3);
    }
    
    public mxGraphics2DCanvas(final int n, final int n2, final int n3, final int n4, final double n5) {
        this(n, n2, n3, n4, n5, null);
    }
    
    public mxGraphics2DCanvas(final int x, final int y, final int n, final int n2, final double scale, final Color background) {
        this.imageBasePath = mxGraphics2DCanvas.DEFAULT_IMAGEBASEPATH;
        this.imageCache = new Hashtable();
        this.x = x;
        this.y = y;
        this.width = n;
        this.height = n2;
        this.scale = scale;
        this.background = background;
        try {
            this.rendererPane = new CellRendererPane();
        }
        catch (Exception ex) {}
        if (n > 0 && n2 > 0) {
            final int imageType = (this.background != null) ? (mxGraphics2DCanvas.INDEXED ? 13 : 1) : 2;
            final Runtime runtime = Runtime.getRuntime();
            if (n * n2 * ((imageType == 13) ? 1 : 4) / 1024 <= (runtime.freeMemory() + (runtime.maxMemory() - runtime.totalMemory())) / 1024L) {
                try {
                    this.setImage(new BufferedImage(n, n2, imageType));
                    this.setGraphics(this.image.createGraphics());
                    this.setAntiAlias(mxGraphics2DCanvas.ANTIALIAS);
                    this.clear(x, y, n, n2);
                }
                catch (OutOfMemoryError outOfMemoryError) {}
            }
        }
    }
    
    public void setImage(final BufferedImage image) {
        this.image = image;
    }
    
    public BufferedImage getImage() {
        return this.image;
    }
    
    public Graphics2D getGraphics() {
        return this.g;
    }
    
    public void setGraphics(final Graphics2D g) {
        this.g = g;
    }
    
    public void setAntiAlias(final boolean b) {
        this.g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, b ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
    }
    
    public void setTextAntiAlias(final boolean b) {
        this.g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, b ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
    }
    
    public void setClip(final Rectangle clip) {
        this.g.setClip(clip);
    }
    
    public void clearClip() {
        this.g.setClip(null);
    }
    
    public void clear(final int n, final int n2, final int n3, final int n4) {
        if (this.background != null) {
            this.g.setColor(this.background);
            this.g.fillRect(n - this.x, n2 - this.y, n3, n4);
        }
        else {
            this.g.setComposite(AlphaComposite.getInstance(1, 0.0f));
            this.g.fillRect(n - this.x, n2 - this.y, n3, n4);
            this.g.setComposite(AlphaComposite.SrcOver);
        }
    }
    
    public String getImageForStyle(final Hashtable hashtable) {
        String str = mxUtils.getString(hashtable, mxConstants.STYLE_IMAGE);
        if (str != null && !str.startsWith("/")) {
            str = this.imageBasePath + str;
        }
        return str;
    }
    
    protected Image loadImage(final String s) {
        Image loadImage = this.imageCache.get(s);
        if (loadImage == null) {
            loadImage = mxUtils.loadImage(s);
            if (loadImage != null) {
                this.imageCache.put(s, loadImage);
            }
        }
        return loadImage;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public Object drawVertex(int n, int n2, final int n3, final int n4, final Hashtable t) {
        if (this.g != null) {
            n -= this.x;
            n2 -= this.y;
            AffineTransform transform = null;
            final double double1 = mxUtils.getDouble(t, mxConstants.STYLE_ROTATION, 0.0);
            if (double1 != 0.0) {
                transform = this.g.getTransform();
                this.g.rotate(Math.toRadians(double1), n + n3 / 2, n2 + n4 / 2);
            }
            Composite composite = null;
            final float float1 = mxUtils.getFloat(t, mxConstants.STYLE_OPACITY, 100.0f);
            if (float1 != 100.0f) {
                composite = this.g.getComposite();
                this.g.setComposite(AlphaComposite.getInstance(3, float1 / 100.0f));
            }
            final Stroke stroke = this.g.getStroke();
            final int int1 = mxUtils.getInt(t, mxConstants.STYLE_STARTSIZE);
            if (int1 == 0) {
                this.drawShape(n, n2, n3, n4, t);
            }
            else {
                final int n5 = (int)Math.round(int1 * this.scale);
                final Hashtable hashtable = new Hashtable(t);
                hashtable.remove(mxConstants.STYLE_FILLCOLOR);
                hashtable.remove(mxConstants.STYLE_ROUNDED);
                if (mxUtils.isTrue(t, mxConstants.STYLE_HORIZONTAL, true)) {
                    this.drawShape(n, n2, n3, n5, t);
                    this.drawShape(n, n2 + n5, n3, n4 - n5, hashtable);
                }
                else {
                    this.drawShape(n, n2, n5, n4, t);
                    this.drawShape(n + n5, n2, n3 - n5, n4, hashtable);
                }
            }
            this.g.setStroke(stroke);
            if (composite != null) {
                this.g.setComposite(composite);
            }
            if (transform != null) {
                this.g.setTransform(transform);
            }
        }
        return null;
    }
    
    public Object drawEdge(List translatePoints, final Hashtable hashtable) {
        if (this.g != null) {
            translatePoints = mxUtils.translatePoints(translatePoints, -this.x, -this.y);
            final float float1 = mxUtils.getFloat(hashtable, mxConstants.STYLE_OPACITY, 100.0f);
            Composite composite = null;
            if (float1 != 100.0f) {
                composite = this.g.getComposite();
                this.g.setComposite(AlphaComposite.getInstance(3, float1 / 100.0f));
            }
            final Stroke stroke = this.g.getStroke();
            this.drawLine(translatePoints, hashtable);
            this.g.setStroke(stroke);
            if (composite != null) {
                this.g.setComposite(composite);
            }
        }
        return null;
    }
    
    public Object drawLabel(final String s, int x, int y, final int width, final int height, final Hashtable hashtable, final boolean b) {
        if (this.g != null) {
            x -= this.x;
            y -= this.y;
            if (s != null && s.length() > 0) {
                Composite composite = null;
                final float float1 = mxUtils.getFloat(hashtable, mxConstants.STYLE_TEXT_OPACITY, 100.0f);
                if (float1 != 100.0f) {
                    composite = this.g.getComposite();
                    this.g.setComposite(AlphaComposite.getInstance(3, float1 / 100.0f));
                }
                final Color color = mxUtils.getColor(hashtable, mxConstants.STYLE_LABEL_BACKGROUNDCOLOR);
                final Color color2 = mxUtils.getColor(hashtable, mxConstants.STYLE_LABEL_BORDERCOLOR);
                if (color != null) {
                    this.g.setColor(color);
                    this.g.fillRect(x, y, width, height);
                }
                if (color2 != null) {
                    this.g.setColor(color2);
                    this.g.drawRect(x, y, width, height);
                }
                if (b) {
                    this.drawHtmlText(mxUtils.getBodyMarkup(s, true), x, y, width, height, hashtable);
                }
                else {
                    final Font font = mxUtils.getFont(hashtable, this.scale);
                    if (font.getSize() > 0) {
                        this.g.setFont(font);
                        this.drawPlainText(s, x, y, width, height, hashtable);
                    }
                }
                if (composite != null) {
                    this.g.setComposite(composite);
                }
            }
        }
        return null;
    }
    
    public void drawShape(int x, int y, int width, int height, final Hashtable hashtable) {
        final Color color = mxUtils.getColor(hashtable, mxConstants.STYLE_STROKECOLOR);
        final float float1 = mxUtils.getFloat(hashtable, mxConstants.STYLE_STROKEWIDTH, 1.0f);
        final int n = (int)Math.ceil(float1 * this.scale);
        if (this.g.hitClip(x - n, y - n, width + 2 * n, height + 2 * n)) {
            final boolean true = mxUtils.isTrue(hashtable, mxConstants.STYLE_SHADOW, false);
            final Color color2 = mxUtils.getColor(hashtable, mxConstants.STYLE_FILLCOLOR);
            final Paint fillPaint = this.getFillPaint(new Rectangle(x, y, width, height), color2, hashtable);
            if (float1 > 0.0f) {
                if (mxUtils.isTrue(hashtable, mxConstants.STYLE_DASHED, false)) {
                    this.g.setStroke(new BasicStroke((float)(float1 * this.scale), 0, 0, 10.0f, new float[] { (float)(3.0 * this.scale), (float)(3.0 * this.scale) }, 0.0f));
                }
                else {
                    this.g.setStroke(new BasicStroke((float)(float1 * this.scale)));
                }
            }
            final String string = mxUtils.getString(hashtable, mxConstants.STYLE_SHAPE, "");
            if (string.equals("image")) {
                final String imageForStyle = this.getImageForStyle(hashtable);
                if (imageForStyle != null) {
                    this.drawImage(x, y, width, height, imageForStyle);
                }
            }
            else if (string.equals("line")) {
                if (color != null) {
                    this.g.setColor(color);
                    final String string2 = mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, "east");
                    if (string2.equals("east") || string2.equals("west")) {
                        final int n2 = y + height / 2;
                        this.drawLine(x, n2, x + width, n2);
                    }
                    else {
                        final int n3 = x + width / 2;
                        this.drawLine(n3, y, n3, y + height);
                    }
                }
            }
            else if (string.equals("ellipse")) {
                this.drawOval(x, y, width, height, color2, fillPaint, color, true);
            }
            else if (string.equals("doubleEllipse")) {
                this.drawOval(x, y, width, height, color2, fillPaint, color, true);
                final int n4 = (int)((3.0f + float1) * this.scale);
                x += n4;
                y += n4;
                width -= 2 * n4;
                height -= 2 * n4;
                this.drawOval(x, y, width, height, null, null, color, false);
            }
            else if (string.equals("rhombus")) {
                this.drawRhombus(x, y, width, height, color2, fillPaint, color, true);
            }
            else if (string.equals("cylinder")) {
                this.drawCylinder(x, y, width, height, color2, fillPaint, color, true);
            }
            else if (string.equals("actor")) {
                this.drawActor(x, y, width, height, color2, fillPaint, color, true);
            }
            else if (string.equals("cloud")) {
                this.drawCloud(x, y, width, height, color2, fillPaint, color, true);
            }
            else if (string.equals("triangle")) {
                this.drawTriangle(x, y, width, height, color2, fillPaint, color, true, mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, ""));
            }
            else if (string.equals("hexagon")) {
                this.drawHexagon(x, y, width, height, color2, fillPaint, color, true, mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, ""));
            }
            else {
                this.drawRect(x, y, width, height, color2, fillPaint, color, true, mxUtils.isTrue(hashtable, mxConstants.STYLE_ROUNDED));
                if (string.equals("label")) {
                    final String imageForStyle2 = this.getImageForStyle(hashtable);
                    if (imageForStyle2 != null) {
                        final String string3 = mxUtils.getString(hashtable, mxConstants.STYLE_IMAGE_ALIGN, "center");
                        final String string4 = mxUtils.getString(hashtable, mxConstants.STYLE_IMAGE_VERTICAL_ALIGN, "middle");
                        final int n5 = (int)(mxUtils.getInt(hashtable, mxConstants.STYLE_IMAGE_WIDTH, mxConstants.DEFAULT_IMAGESIZE) * this.scale);
                        final int n6 = (int)(mxUtils.getInt(hashtable, mxConstants.STYLE_IMAGE_HEIGHT, mxConstants.DEFAULT_IMAGESIZE) * this.scale);
                        final int n7 = (int)(mxUtils.getInt(hashtable, mxConstants.STYLE_SPACING, 2) * this.scale);
                        final int n8 = x;
                        int n9;
                        if (string3.equals("right")) {
                            n9 = n8 + (width - n5 - n7);
                        }
                        else if (string3.equals("center")) {
                            n9 = n8 + (width - n5) / 2;
                        }
                        else {
                            n9 = n8 + n7;
                        }
                        final int n10 = y;
                        int n11;
                        if (string4.equals("top")) {
                            n11 = n10 + n7;
                        }
                        else if (string4.equals("bottom")) {
                            n11 = n10 + (height - n6 - n7);
                        }
                        else {
                            n11 = n10 + (height - n6) / 2;
                        }
                        this.drawImage(n9, n11, n5, n6, imageForStyle2);
                    }
                }
            }
        }
    }
    
    protected void drawPolygon(final Polygon p5, final Color color, final Paint paint, final Color color2, final boolean b) {
        if (color != null || paint != null) {
            if (b) {
                this.g.setColor(mxConstants.SHADOW_COLOR);
                this.g.translate(mxConstants.SHADOW_OFFSETX, mxConstants.SHADOW_OFFSETY);
                this.g.fillPolygon(p5);
                this.g.translate(-mxConstants.SHADOW_OFFSETX, -mxConstants.SHADOW_OFFSETY);
            }
            if (paint != null) {
                this.g.setPaint(paint);
            }
            else {
                this.g.setColor(color);
            }
            this.g.fillPolygon(p5);
        }
        if (color2 != null) {
            this.g.setColor(color2);
            this.g.drawPolygon(p5);
        }
    }
    
    protected void drawPath(final GeneralPath generalPath, final Color color, final Paint paint, final Color color2, final boolean b) {
        if (color != null || paint != null) {
            if (b) {
                this.g.setColor(mxConstants.SHADOW_COLOR);
                this.g.translate(mxConstants.SHADOW_OFFSETX, mxConstants.SHADOW_OFFSETY);
                this.g.fill(generalPath);
                this.g.translate(-mxConstants.SHADOW_OFFSETX, -mxConstants.SHADOW_OFFSETY);
            }
            if (paint != null) {
                this.g.setPaint(paint);
            }
            else {
                this.g.setColor(color);
            }
            this.g.fill(generalPath);
        }
        if (color2 != null) {
            this.g.setColor(color2);
            this.g.draw(generalPath);
        }
    }
    
    protected void drawRect(final int n, final int n2, final int n3, final int n4, final Color color, final Paint paint, final Color color2, final boolean b, final boolean b2) {
        final int n5 = b2 ? getArcSize(n3, n4) : 0;
        if (color != null || paint != null) {
            if (b) {
                this.g.setColor(mxConstants.SHADOW_COLOR);
                if (b2) {
                    this.g.fillRoundRect(n + mxConstants.SHADOW_OFFSETX, n2 + mxConstants.SHADOW_OFFSETY, n3, n4, n5, n5);
                }
                else {
                    this.g.fillRect(n + mxConstants.SHADOW_OFFSETX, n2 + mxConstants.SHADOW_OFFSETY, n3, n4);
                }
            }
            if (paint != null) {
                this.g.setPaint(paint);
            }
            else {
                this.g.setColor(color);
            }
            if (b2) {
                this.g.fillRoundRect(n, n2, n3, n4, n5, n5);
            }
            else if (this.g.getClipBounds() != null) {
                this.g.fill(new Rectangle(n, n2, n3, n4).intersection(this.g.getClipBounds()));
            }
            else {
                this.g.fillRect(n, n2, n3, n4);
            }
        }
        if (color2 != null) {
            this.g.setColor(color2);
            if (b2) {
                this.g.drawRoundRect(n, n2, n3, n4, n5, n5);
            }
            else {
                this.g.drawRect(n, n2, n3, n4);
            }
        }
    }
    
    protected void drawImage(final int n, final int n2, final int n3, final int n4, final String s) {
        final Image loadImage = this.loadImage(s);
        if (loadImage != null) {
            this.g.drawImage(loadImage, n, n2, n3, n4, null);
        }
    }
    
    protected void drawOval(final int n, final int n2, final int n3, final int n4, final Color color, final Paint paint, final Color color2, final boolean b) {
        if (color != null || paint != null) {
            if (b) {
                this.g.setColor(mxConstants.SHADOW_COLOR);
                this.g.fillOval(n + mxConstants.SHADOW_OFFSETX, n2 + mxConstants.SHADOW_OFFSETY, n3, n4);
            }
            if (paint != null) {
                this.g.setPaint(paint);
            }
            else {
                this.g.setColor(color);
            }
            this.g.fillOval(n, n2, n3, n4);
        }
        if (color2 != null) {
            this.g.setColor(color2);
            this.g.drawOval(n, n2, n3, n4);
        }
    }
    
    protected void drawRhombus(final int x, final int y, final int n, final int n2, final Color color, final Paint paint, final Color color2, final boolean b) {
        final int n3 = n / 2;
        final int n4 = n2 / 2;
        final Polygon polygon = new Polygon();
        polygon.addPoint(x + n3, y);
        polygon.addPoint(x + n, y + n4);
        polygon.addPoint(x + n3, y + n2);
        polygon.addPoint(x, y + n4);
        this.drawPolygon(polygon, color, paint, color2, b);
    }
    
    protected void drawCylinder(final int n, final int n2, final int n3, final int n4, final Color color, final Paint paint, final Color color2, final boolean b) {
        final int n5 = n4 / 4;
        final int n6 = n3 - 1;
        if (color != null || paint != null) {
            final Area area = new Area(new Rectangle(n, n2 + n5 / 2, n6, n4 - n5));
            area.add(new Area(new Rectangle(n, n2 + n5 / 2, n6, n4 - n5)));
            area.add(new Area(new Ellipse2D.Double(n, n2, n6, n5)));
            area.add(new Area(new Ellipse2D.Double(n, n2 + n4 - n5, n6, n5)));
            if (b) {
                this.g.setColor(mxConstants.SHADOW_COLOR);
                this.g.translate(mxConstants.SHADOW_OFFSETX, mxConstants.SHADOW_OFFSETY);
                this.g.fill(area);
                this.g.translate(-mxConstants.SHADOW_OFFSETX, -mxConstants.SHADOW_OFFSETY);
            }
            if (paint != null) {
                this.g.setPaint(paint);
            }
            else {
                this.g.setColor(color);
            }
            this.g.fill(area);
        }
        if (color2 != null) {
            this.g.setColor(color2);
            final int n7 = n5 / 2;
            this.g.drawOval(n, n2, n6, n5);
            this.g.drawLine(n, n2 + n7, n, n2 + n4 - n7);
            this.g.drawLine(n + n3 - 1, n2 + n7, n + n3 - 1, n2 + n4 - n7);
            this.g.drawArc(n, n2 + n4 - n5, n6, n5, 0, -180);
        }
    }
    
    protected void drawActor(final int n, final int n2, final int n3, final int n4, final Color color, final Paint paint, final Color color2, final boolean b) {
        final float n5 = (float)(n3 * 2 / 6);
        final GeneralPath generalPath = new GeneralPath();
        generalPath.moveTo((float)n, (float)(n2 + n4));
        generalPath.curveTo((float)n, (float)(n2 + 3 * n4 / 5), (float)n, (float)(n2 + 2 * n4 / 5), (float)(n + n3 / 2), (float)(n2 + 2 * n4 / 5));
        generalPath.curveTo(n + n3 / 2 - n5, (float)(n2 + 2 * n4 / 5), n + n3 / 2 - n5, (float)n2, (float)(n + n3 / 2), (float)n2);
        generalPath.curveTo(n + n3 / 2 + n5, (float)n2, n + n3 / 2 + n5, (float)(n2 + 2 * n4 / 5), (float)(n + n3 / 2), (float)(n2 + 2 * n4 / 5));
        generalPath.curveTo((float)(n + n3), (float)(n2 + 2 * n4 / 5), (float)(n + n3), (float)(n2 + 3 * n4 / 5), (float)(n + n3), (float)(n2 + n4));
        generalPath.closePath();
        this.drawPath(generalPath, color, paint, color2, b);
    }
    
    protected void drawCloud(final int n, final int n2, final int n3, final int n4, final Color color, final Paint paint, final Color color2, final boolean b) {
        final GeneralPath generalPath = new GeneralPath();
        generalPath.moveTo((float)(n + 0.25 * n3), (float)(n2 + 0.25 * n4));
        generalPath.curveTo((float)(n + 0.05 * n3), (float)(n2 + 0.25 * n4), (float)n, (float)(n2 + 0.5 * n4), (float)(n + 0.16 * n3), (float)(n2 + 0.55 * n4));
        generalPath.curveTo((float)n, (float)(n2 + 0.66 * n4), (float)(n + 0.18 * n3), (float)(n2 + 0.9 * n4), (float)(n + 0.31 * n3), (float)(n2 + 0.8 * n4));
        generalPath.curveTo((float)(n + 0.4 * n3), (float)(n2 + n4), (float)(n + 0.7 * n3), (float)(n2 + n4), (float)(n + 0.8 * n3), (float)(n2 + 0.8 * n4));
        generalPath.curveTo((float)(n + n3), (float)(n2 + 0.8 * n4), (float)(n + n3), (float)(n2 + 0.6 * n4), (float)(n + 0.875 * n3), (float)(n2 + 0.5 * n4));
        generalPath.curveTo((float)(n + n3), (float)(n2 + 0.3 * n4), (float)(n + 0.8 * n3), (float)(n2 + 0.1 * n4), (float)(n + 0.625 * n3), (float)(n2 + 0.2 * n4));
        generalPath.curveTo((float)(n + 0.5 * n3), (float)(n2 + 0.05 * n4), (float)(n + 0.3 * n3), (float)(n2 + 0.05 * n4), (float)(n + 0.25 * n3), (float)(n2 + 0.25 * n4));
        generalPath.closePath();
        this.drawPath(generalPath, color, paint, color2, b);
    }
    
    protected void drawTriangle(final int x, final int y, final int n, final int n2, final Color color, final Paint paint, final Color color2, final boolean b, final String s) {
        final Polygon polygon = new Polygon();
        if (s.equals("north")) {
            polygon.addPoint(x, y + n2);
            polygon.addPoint(x + n / 2, y);
            polygon.addPoint(x + n, y + n2);
        }
        else if (s.equals("south")) {
            polygon.addPoint(x, y);
            polygon.addPoint(x + n / 2, y + n2);
            polygon.addPoint(x + n, y);
        }
        else if (s.equals("west")) {
            polygon.addPoint(x + n, y);
            polygon.addPoint(x, y + n2 / 2);
            polygon.addPoint(x + n, y + n2);
        }
        else {
            polygon.addPoint(x, y);
            polygon.addPoint(x + n, y + n2 / 2);
            polygon.addPoint(x, y + n2);
        }
        this.drawPolygon(polygon, color, paint, color2, b);
    }
    
    protected void drawHexagon(final int x, final int y, final int n, final int n2, final Color color, final Paint paint, final Color color2, final boolean b, final String s) {
        final Polygon polygon = new Polygon();
        if (s.equals("north") || s.equals("south")) {
            polygon.addPoint(x + (int)(0.5 * n), y);
            polygon.addPoint(x + n, y + (int)(0.25 * n2));
            polygon.addPoint(x + n, y + (int)(0.75 * n2));
            polygon.addPoint(x + (int)(0.5 * n), y + n2);
            polygon.addPoint(x, y + (int)(0.75 * n2));
            polygon.addPoint(x, y + (int)(0.25 * n2));
        }
        else {
            polygon.addPoint(x + (int)(0.25 * n), y);
            polygon.addPoint(x + (int)(0.75 * n), y);
            polygon.addPoint(x + n, y + (int)(0.5 * n2));
            polygon.addPoint(x + (int)(0.75 * n), y + n2);
            polygon.addPoint(x + (int)(0.25 * n), y + n2);
            polygon.addPoint(x, y + (int)(0.5 * n2));
        }
        this.drawPolygon(polygon, color, paint, color2, b);
    }
    
    public static int getArcSize(final int n, final int n2) {
        int n3;
        if (n <= n2) {
            n3 = n2 / 5;
            if (n3 > n / 2) {
                n3 = n / 2;
            }
        }
        else {
            n3 = n / 5;
            if (n3 > n2 / 2) {
                n3 = n2 / 2;
            }
        }
        return n3;
    }
    
    protected void drawArrow(final List list, final Color color, final Paint paint, final Color color2, final boolean b) {
        final mxPoint mxPoint = list.get(0);
        final mxPoint mxPoint2 = list.get(list.size() - 1);
        final double n = mxConstants.ARROW_SPACING * this.scale;
        final double n2 = mxConstants.ARROW_WIDTH * this.scale;
        final double n3 = mxConstants.ARROW_SIZE * this.scale;
        final double n4 = mxPoint2.getX() - mxPoint.getX();
        final double n5 = mxPoint2.getY() - mxPoint.getY();
        final double sqrt = Math.sqrt(n4 * n4 + n5 * n5);
        final double n6 = sqrt - 2.0 * n - n3;
        final double n7 = n4 / sqrt;
        final double n8 = n5 / sqrt;
        final double n9 = n6 * n7;
        final double n10 = n6 * n8;
        final double n11 = n2 * n8 / 3.0;
        final double n12 = -n2 * n7 / 3.0;
        final double a = mxPoint.getX() - n11 / 2.0 + n * n7;
        final double a2 = mxPoint.getY() - n12 / 2.0 + n * n8;
        final double a3 = a + n11;
        final double a4 = a2 + n12;
        final double a5 = a3 + n9;
        final double a6 = a4 + n10;
        final double a7 = a5 + n11;
        final double a8 = a6 + n12;
        final double a9 = a7 - 3.0 * n11;
        final double a10 = a8 - 3.0 * n12;
        final Polygon polygon = new Polygon();
        polygon.addPoint((int)Math.round(a), (int)Math.round(a2));
        polygon.addPoint((int)Math.round(a3), (int)Math.round(a4));
        polygon.addPoint((int)Math.round(a5), (int)Math.round(a6));
        polygon.addPoint((int)Math.round(a7), (int)Math.round(a8));
        polygon.addPoint((int)Math.round(mxPoint2.getX() - n * n7), (int)Math.round(mxPoint2.getY() - n * n8));
        polygon.addPoint((int)Math.round(a9), (int)Math.round(a10));
        polygon.addPoint((int)Math.round(a9 + n11), (int)Math.round(a10 + n12));
        if (this.g.getClipBounds() == null || this.g.getClipBounds().intersects(polygon.getBounds())) {
            this.drawPolygon(polygon, color, paint, color2, b);
        }
    }
    
    protected void drawConnector(final List list, final float width, final Color color, final Object o, final float n, final Object o2, final float n2, final boolean b, final boolean b2) {
        this.g.setStroke(new BasicStroke((float)(width * this.scale)));
        this.g.setColor(color);
        mxPoint mxPoint = list.get(0);
        final mxPoint mxPoint2 = list.get(1);
        mxPoint drawMarker;
        if (o != null) {
            drawMarker = this.drawMarker(o, mxPoint2, mxPoint, n, width);
        }
        else {
            final double n3 = mxPoint2.getX() - mxPoint.getX();
            final double n4 = mxPoint2.getY() - mxPoint.getY();
            final double max = Math.max(1.0, Math.sqrt(n3 * n3 + n4 * n4));
            drawMarker = new mxPoint(n3 * width * this.scale / max / 2.0, n4 * width * this.scale / max / 2.0);
        }
        if (drawMarker != null) {
            mxPoint = (mxPoint)mxPoint.clone();
            mxPoint.setX(mxPoint.getX() + drawMarker.getX());
            mxPoint.setY(mxPoint.getY() + drawMarker.getY());
        }
        mxPoint mxPoint3 = list.get(list.size() - 1);
        final mxPoint mxPoint4 = list.get(list.size() - 2);
        mxPoint drawMarker2;
        if (o2 != null) {
            drawMarker2 = this.drawMarker(o2, mxPoint4, mxPoint3, n2, width);
        }
        else {
            final double n5 = mxPoint4.getX() - mxPoint.getX();
            final double n6 = mxPoint4.getY() - mxPoint.getY();
            final double max2 = Math.max(1.0, Math.sqrt(n5 * n5 + n6 * n6));
            drawMarker2 = new mxPoint(n5 * width * this.scale / max2 / 2.0, n6 * width * this.scale / max2 / 2.0);
        }
        if (drawMarker2 != null) {
            mxPoint3 = (mxPoint)mxPoint3.clone();
            mxPoint3.setX(mxPoint3.getX() + drawMarker2.getX());
            mxPoint3.setY(mxPoint3.getY() + drawMarker2.getY());
        }
        if (b) {
            this.g.setStroke(new BasicStroke(width, 0, 0, 10.0f, new float[] { (float)(3.0 * this.scale), (float)(3.0 * this.scale) }, 0.0f));
        }
        final double n7 = 10.0 * this.scale;
        mxPoint mxPoint5 = mxPoint;
        for (int i = 1; i < list.size() - 1; ++i) {
            mxPoint mxPoint6 = list.get(i);
            final double n8 = mxPoint5.getX() - mxPoint6.getX();
            final double n9 = mxPoint5.getY() - mxPoint6.getY();
            if (b2 && i < list.size() - 1 && (n8 != 0.0 || n9 != 0.0) && this.scale > 0.05) {
                final double sqrt = Math.sqrt(n8 * n8 + n9 * n9);
                final double n10 = n8 * Math.min(n7, sqrt / 2.0) / sqrt;
                final double n11 = n9 * Math.min(n7, sqrt / 2.0) / sqrt;
                this.drawLine((int)Math.round(mxPoint5.getX()), (int)Math.round(mxPoint5.getY()), (int)Math.round(mxPoint6.getX() + n10), (int)Math.round(mxPoint6.getY() + n11));
                final mxPoint mxPoint7 = list.get(i + 1);
                final double n12 = mxPoint7.getX() - mxPoint6.getX();
                final double n13 = mxPoint7.getY() - mxPoint6.getY();
                final double max3 = Math.max(1.0, Math.sqrt(n12 * n12 + n13 * n13));
                final double n14 = n12 * Math.min(n7, max3 / 2.0) / max3;
                final double n15 = n13 * Math.min(n7, max3 / 2.0) / max3;
                final QuadCurve2D.Float float1 = new QuadCurve2D.Float((float)(int)Math.round(mxPoint6.getX() + n10), (float)(int)Math.round(mxPoint6.getY() + n11), (float)(int)Math.round(mxPoint6.getX()), (float)(int)Math.round(mxPoint6.getY()), (float)(int)Math.round(mxPoint6.getX() + n14), (float)(int)Math.round(mxPoint6.getY() + n15));
                final Rectangle bounds = float1.getBounds();
                final int n16 = (int)Math.ceil(width * this.scale);
                bounds.grow(n16, n16);
                if (this.g.getClipBounds() == null || this.g.getClipBounds().intersects(bounds)) {
                    this.g.draw(float1);
                }
                mxPoint6 = new mxPoint(mxPoint6.getX() + n14, mxPoint6.getY() + n15);
            }
            else {
                this.drawLine((int)Math.round(mxPoint5.getX()), (int)Math.round(mxPoint5.getY()), (int)Math.round(mxPoint6.getX()), (int)Math.round(mxPoint6.getY()));
            }
            mxPoint5 = mxPoint6;
        }
        this.drawLine((int)Math.round(mxPoint5.getX()), (int)Math.round(mxPoint5.getY()), (int)Math.round(mxPoint3.getX()), (int)Math.round(mxPoint3.getY()));
    }
    
    protected Paint getFillPaint(final Rectangle rectangle, final Color color1, final Hashtable hashtable) {
        Paint paint = null;
        if (color1 != null) {
            final Color color2 = mxUtils.getColor(hashtable, mxConstants.STYLE_GRADIENTCOLOR);
            if (color2 != null) {
                final String string = mxUtils.getString(hashtable, mxConstants.STYLE_GRADIENT_DIRECTION);
                float x1 = (float)rectangle.x;
                float y1 = (float)rectangle.y;
                float x2 = (float)rectangle.x;
                float y2 = (float)rectangle.y;
                if (string == null || string.equals("south")) {
                    y2 = (float)(rectangle.y + rectangle.height);
                }
                else if (string.equals("east")) {
                    x2 = (float)(rectangle.x + rectangle.width);
                }
                else if (string.equals("north")) {
                    y1 = (float)(rectangle.y + rectangle.height);
                }
                else if (string.equals("west")) {
                    x1 = (float)(rectangle.x + rectangle.width);
                }
                paint = new GradientPaint(x1, y1, color1, x2, y2, color2, true);
            }
        }
        return paint;
    }
    
    public void drawLine(final List list, final Hashtable hashtable) {
        final Color color = mxUtils.getColor(hashtable, mxConstants.STYLE_STROKECOLOR, Color.black);
        final float float1 = mxUtils.getFloat(hashtable, mxConstants.STYLE_STROKEWIDTH, 1.0f);
        if (color != null && float1 > 0.0f) {
            if (mxUtils.getString(hashtable, mxConstants.STYLE_SHAPE, "").equals("arrow")) {
                if (mxUtils.isTrue(hashtable, mxConstants.STYLE_DASHED, false)) {
                    this.g.setStroke(new BasicStroke((float)(float1 * this.scale), 0, 0, 10.0f, new float[] { (float)(3.0 * this.scale), (float)(3.0 * this.scale) }, 0.0f));
                }
                else {
                    this.g.setStroke(new BasicStroke((float)(float1 * this.scale)));
                }
                final mxPoint mxPoint = list.get(0);
                final mxPoint mxPoint2 = list.get(list.size() - 1);
                final Rectangle rectangle = new Rectangle(mxPoint.getPoint());
                rectangle.add(mxPoint2.getPoint());
                final Color color2 = mxUtils.getColor(hashtable, mxConstants.STYLE_FILLCOLOR);
                this.drawArrow(list, color2, this.getFillPaint(rectangle, color2, hashtable), color, mxUtils.isTrue(hashtable, mxConstants.STYLE_SHADOW, false));
            }
            else {
                this.drawConnector(list, float1, color, hashtable.get(mxConstants.STYLE_STARTARROW), (float)(mxUtils.getFloat(hashtable, mxConstants.STYLE_STARTSIZE, (float)mxConstants.DEFAULT_MARKERSIZE) * this.scale), hashtable.get(mxConstants.STYLE_ENDARROW), (float)(mxUtils.getFloat(hashtable, mxConstants.STYLE_ENDSIZE, (float)mxConstants.DEFAULT_MARKERSIZE) * this.scale), mxUtils.isTrue(hashtable, mxConstants.STYLE_DASHED, false), mxUtils.isTrue(hashtable, mxConstants.STYLE_ROUNDED, false));
            }
        }
    }
    
    public void drawLine(final int n, final int n2, final int n3, final int n4) {
        final Line2D.Float float1 = new Line2D.Float((float)n, (float)n2, (float)n3, (float)n4);
        if (this.g.getClipBounds() == null || float1.intersects(this.g.getClipBounds())) {
            this.g.draw(float1);
        }
    }
    
    public mxPoint drawMarker(final Object o, final mxPoint mxPoint, mxPoint mxPoint2, final float n, final float n2) {
        mxPoint mxPoint3 = null;
        final double n3 = mxPoint2.getX() - mxPoint.getX();
        final double n4 = mxPoint2.getY() - mxPoint.getY();
        final double max = Math.max(1.0, Math.sqrt(n3 * n3 + n4 * n4));
        final double n5 = n * this.scale;
        final double n6 = n3 * n5 / max;
        final double n7 = n4 * n5 / max;
        mxPoint2 = (mxPoint)mxPoint2.clone();
        mxPoint2.setX(mxPoint2.getX() - n6 * n2 / (2.0f * n));
        mxPoint2.setY(mxPoint2.getY() - n7 * n2 / (2.0f * n));
        final double n8 = n6 * (0.5 + n2 / 2.0f);
        final double n9 = n7 * (0.5 + n2 / 2.0f);
        if (o.equals("classic") || o.equals("block")) {
            final Polygon polygon = new Polygon();
            polygon.addPoint((int)Math.round(mxPoint2.getX()), (int)Math.round(mxPoint2.getY()));
            polygon.addPoint((int)Math.round(mxPoint2.getX() - n8 - n9 / 2.0), (int)Math.round(mxPoint2.getY() - n9 + n8 / 2.0));
            if (o.equals("classic")) {
                polygon.addPoint((int)Math.round(mxPoint2.getX() - n8 * 3.0 / 4.0), (int)Math.round(mxPoint2.getY() - n9 * 3.0 / 4.0));
            }
            polygon.addPoint((int)Math.round(mxPoint2.getX() + n9 / 2.0 - n8), (int)Math.round(mxPoint2.getY() - n9 - n8 / 2.0));
            if (this.g.getClipBounds() == null || this.g.getClipBounds().intersects(polygon.getBounds())) {
                this.g.fillPolygon(polygon);
                this.g.drawPolygon(polygon);
            }
            mxPoint3 = new mxPoint(-n8 * 3.0 / 4.0, -n9 * 3.0 / 4.0);
        }
        else if (o.equals("open")) {
            final double n10 = n8 * 1.2;
            final double n11 = n9 * 1.2;
            this.drawLine((int)Math.round(mxPoint2.getX() - n10 - n11 / 2.0), (int)Math.round(mxPoint2.getY() - n11 + n10 / 2.0), (int)Math.round(mxPoint2.getX() - n10 / 6.0), (int)Math.round(mxPoint2.getY() - n11 / 6.0));
            this.drawLine((int)Math.round(mxPoint2.getX() - n10 / 6.0), (int)Math.round(mxPoint2.getY() - n11 / 6.0), (int)Math.round(mxPoint2.getX() + n11 / 2.0 - n10), (int)Math.round(mxPoint2.getY() - n11 - n10 / 2.0));
            mxPoint3 = new mxPoint(-n10 / 4.0, -n11 / 4.0);
        }
        else if (o.equals("oval")) {
            final double n12 = n8 * 1.2;
            final double n13 = n9 * 1.2;
            final double a = n5 * 1.2;
            final int n14 = (int)Math.round(mxPoint2.getX() - n12 / 2.0);
            final int n15 = (int)Math.round(mxPoint2.getY() - n13 / 2.0);
            final int n16 = (int)Math.round(a / 2.0);
            final int n17 = (int)Math.round(a);
            if (this.g.hitClip(n14 - n16, n15 - n16, n17, n17)) {
                this.g.fillOval(n14 - n16, n15 - n16, n17, n17);
                this.g.drawOval(n14 - n16, n15 - n16, n17, n17);
            }
            mxPoint3 = new mxPoint(-n12 / 2.0, -n13 / 2.0);
        }
        else if (o.equals("diamond")) {
            final double n18 = n8 * 1.2;
            final double n19 = n9 * 1.2;
            final Polygon polygon2 = new Polygon();
            polygon2.addPoint((int)Math.round(mxPoint2.getX() + n18 / 2.0), (int)Math.round(mxPoint2.getY() + n19 / 2.0));
            polygon2.addPoint((int)Math.round(mxPoint2.getX() - n19 / 2.0), (int)Math.round(mxPoint2.getY() + n18 / 2.0));
            polygon2.addPoint((int)Math.round(mxPoint2.getX() - n18 / 2.0), (int)Math.round(mxPoint2.getY() - n19 / 2.0));
            polygon2.addPoint((int)Math.round(mxPoint2.getX() + n19 / 2.0), (int)Math.round(mxPoint2.getY() - n18 / 2.0));
            if (this.g.getClipBounds() == null || this.g.getClipBounds().intersects(polygon2.getBounds())) {
                this.g.fillPolygon(polygon2);
                this.g.drawPolygon(polygon2);
            }
        }
        return mxPoint3;
    }
    
    protected void drawHtmlText(final String text, final int x, final int y, int width, int height, final Hashtable hashtable) {
        final mxLightweightTextPane sharedInstance = mxLightweightTextPane.getSharedInstance();
        if (sharedInstance != null && this.rendererPane != null) {
            final boolean true = mxUtils.isTrue(hashtable, mxConstants.STYLE_HORIZONTAL, true);
            if (this.g.hitClip(x, y, width, height)) {
                final AffineTransform transform = this.g.getTransform();
                if (!true) {
                    this.g.rotate(-1.5707963267948966, x + width / 2, y + height / 2);
                    this.g.translate(width / 2 - height / 2, height / 2 - width / 2);
                    final int n = width;
                    width = height;
                    height = n;
                }
                sharedInstance.setStyledDocument(mxUtils.createHtmlDocument(hashtable));
                sharedInstance.setText(text);
                this.g.scale(this.scale, this.scale);
                this.rendererPane.paintComponent(this.g, sharedInstance, this.rendererPane, (int)(x / this.scale) + mxConstants.LABEL_INSET, (int)(y / this.scale) + mxConstants.LABEL_INSET, (int)(width / this.scale), (int)(height / this.scale), true);
                this.g.setTransform(transform);
            }
        }
    }
    
    protected void drawPlainText(final String s, int x, int y, final int width, final int height, final Hashtable hashtable) {
        if (this.g.hitClip(x, y, width, height)) {
            final AffineTransform transform = this.g.getTransform();
            final boolean true = mxUtils.isTrue(hashtable, mxConstants.STYLE_HORIZONTAL, true);
            if (!true) {
                this.g.rotate(-1.5707963267948966, x + width / 2, y + height / 2);
                this.g.translate(width / 2 - height / 2, height / 2 - width / 2);
            }
            final FontMetrics fontMetrics = this.g.getFontMetrics();
            y += (int)(2 * fontMetrics.getMaxAscent() - fontMetrics.getHeight() + mxConstants.LABEL_INSET * this.scale);
            final String string = mxUtils.getString(hashtable, mxConstants.STYLE_ALIGN, "center");
            if (string.equals("left")) {
                x += mxConstants.LABEL_INSET;
            }
            else if (string.equals("right")) {
                x -= mxConstants.LABEL_INSET;
            }
            this.g.setColor(mxUtils.getColor(hashtable, mxConstants.STYLE_FONTCOLOR, Color.black));
            final String[] split = s.split("\n");
            for (int i = 0; i < split.length; ++i) {
                int n = 0;
                if (string.equals("center")) {
                    final int stringWidth = fontMetrics.stringWidth(split[i]);
                    if (true) {
                        n = (width - stringWidth) / 2;
                    }
                    else {
                        n = (height - stringWidth) / 2;
                    }
                }
                else if (string.equals("right")) {
                    n = (true ? width : height) - fontMetrics.stringWidth(split[i]);
                }
                this.g.drawString(split[i], x + n, y);
                y += fontMetrics.getHeight() + mxConstants.LINESPACING;
            }
            this.g.setTransform(transform);
        }
    }
    
    public void destroy() {
        if (this.g != null) {
            this.g.dispose();
        }
    }
    
    static {
        mxGraphics2DCanvas.INDEXED = false;
        mxGraphics2DCanvas.ANTIALIAS = true;
        mxGraphics2DCanvas.DEFAULT_IMAGEBASEPATH = "";
    }
}
