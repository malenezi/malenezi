// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.algebra;

import com.mxgraph.view.mxCellState;

public class mxConstantCostFunction implements mxICostFunction
{
    protected double cost;
    
    public mxConstantCostFunction(final double cost) {
        this.cost = 0.0;
        this.cost = cost;
    }
    
    public double getCost(final mxCellState mxCellState) {
        return this.cost;
    }
}
