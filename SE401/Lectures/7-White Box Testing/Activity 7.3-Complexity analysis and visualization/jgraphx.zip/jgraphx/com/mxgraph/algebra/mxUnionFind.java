// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.algebra;

import java.util.Hashtable;
import java.util.Map;

public class mxUnionFind
{
    protected Map nodes;
    
    public mxUnionFind(final Object[] array) {
        this.nodes = new Hashtable();
        for (int i = 0; i < array.length; ++i) {
            this.nodes.put(array[i], new Node());
        }
    }
    
    public Node getNode(final Object o) {
        return this.nodes.get(o);
    }
    
    public Node find(Node node) {
        while (node.getParent().getParent() != node.getParent()) {
            final Node parent = node.getParent().getParent();
            node.setParent(parent);
            node = parent;
        }
        return node.getParent();
    }
    
    public void union(final Node node, final Node node2) {
        final Node find = this.find(node);
        final Node find2 = this.find(node2);
        if (find != find2) {
            if (find.getSize() < find2.getSize()) {
                find2.setParent(find);
                find.setSize(find.getSize() + find2.getSize());
            }
            else {
                find.setParent(find2);
                find2.setSize(find.getSize() + find2.getSize());
            }
        }
    }
    
    public boolean differ(final Object o, final Object o2) {
        return this.find(this.getNode(o)) != this.find(this.getNode(o2));
    }
    
    public class Node
    {
        protected Node parent;
        protected int size;
        
        public Node() {
            this.parent = this;
            this.size = 1;
        }
        
        public Node getParent() {
            return this.parent;
        }
        
        public void setParent(final Node parent) {
            this.parent = parent;
        }
        
        public int getSize() {
            return this.size;
        }
        
        public void setSize(final int size) {
            this.size = size;
        }
    }
}
