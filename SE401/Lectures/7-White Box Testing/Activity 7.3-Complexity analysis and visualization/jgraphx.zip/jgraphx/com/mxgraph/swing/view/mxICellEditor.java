// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.view;

import java.util.EventObject;

public interface mxICellEditor
{
    Object getEditingCell();
    
    void startEditing(final Object p0, final EventObject p1);
    
    void stopEditing(final boolean p0);
}
