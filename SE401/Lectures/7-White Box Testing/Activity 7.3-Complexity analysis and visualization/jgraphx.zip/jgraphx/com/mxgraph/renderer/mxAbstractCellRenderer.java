// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.renderer;

import java.awt.Rectangle;
import com.mxgraph.view.mxCellState;
import com.mxgraph.view.mxGraphView;
import com.mxgraph.model.mxCell;
import java.util.Hashtable;
import com.mxgraph.util.mxRectangle;
import com.mxgraph.view.mxGraph;
import com.mxgraph.canvas.mxICanvas;
import java.awt.Color;

public abstract class mxAbstractCellRenderer
{
    protected abstract mxICanvas createCanvas(final int p0, final int p1, final int p2, final int p3, final double p4, final Color p5);
    
    public mxICanvas drawCells(final mxGraph mxGraph, final Object[] array) {
        return this.drawCells(mxGraph, array, 1.0);
    }
    
    public mxICanvas drawCells(final mxGraph mxGraph, final Object[] array, final double n) {
        return this.drawCells(mxGraph, array, n, null, null);
    }
    
    public mxICanvas drawCells(final mxGraph mxGraph, final Object[] array, final double scale, final Color color, mxRectangle paintBounds) {
        mxICanvas canvas = null;
        if (array != null) {
            final mxGraphView view = mxGraph.getView();
            final Hashtable states = view.getStates();
            final double scale2 = view.getScale();
            final boolean eventsEnabled = view.isEventsEnabled();
            view.setEventsEnabled(false);
            try {
                view.setStates(new Hashtable());
                view.setScale(scale);
                final mxCellState state = view.createState(new mxCell());
                for (int i = 0; i < array.length; ++i) {
                    view.validateBounds(state, array[i]);
                }
                for (int j = 0; j < array.length; ++j) {
                    view.validatePoints(state, array[j]);
                }
                if (paintBounds == null) {
                    paintBounds = mxGraph.getPaintBounds(array);
                }
                if (paintBounds != null && paintBounds.getWidth() > 0.0 && paintBounds.getHeight() > 0.0) {
                    final Rectangle rectangle = paintBounds.getRectangle();
                    canvas = this.createCanvas(rectangle.x, rectangle.y, rectangle.width + 1, rectangle.height + 1, view.getScale(), color);
                    if (canvas != null) {
                        for (int k = 0; k < array.length; ++k) {
                            mxGraph.drawCell(canvas, array[k]);
                        }
                    }
                }
            }
            finally {
                view.setScale(scale2);
                view.setStates(states);
                view.setEventsEnabled(eventsEnabled);
            }
        }
        return canvas;
    }
    
    public mxICanvas drawGraph(final mxGraph mxGraph, final double n) {
        return this.drawGraph(mxGraph, n, null, null);
    }
    
    public mxICanvas drawGraph(final mxGraph mxGraph, final double n, final Color color, final mxRectangle mxRectangle) {
        return this.drawCells(mxGraph, new Object[] { mxGraph.getModel().getRoot() }, n, color, mxRectangle);
    }
}
