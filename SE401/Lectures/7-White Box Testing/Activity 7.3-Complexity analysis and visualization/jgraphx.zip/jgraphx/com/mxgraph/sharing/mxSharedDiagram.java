// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.sharing;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

public class mxSharedDiagram
{
    protected List diagramChangeListeners;
    protected String initialState;
    protected StringBuffer history;
    
    public mxSharedDiagram(final String initialState) {
        this.history = new StringBuffer();
        this.initialState = initialState;
    }
    
    public String getInitialState() {
        return this.initialState;
    }
    
    public synchronized void clearHistory() {
        this.history = new StringBuffer();
    }
    
    public synchronized String getDelta() {
        return this.history.toString();
    }
    
    public void dispatch(final Object o, final String str) {
        synchronized (this) {
            this.history.append(str);
        }
        this.dispatchDiagramChangeEvent(o, str);
    }
    
    public void addDiagramChangeListener(final mxDiagramChangeListener mxDiagramChangeListener) {
        if (this.diagramChangeListeners == null) {
            this.diagramChangeListeners = new ArrayList();
        }
        this.diagramChangeListeners.add(mxDiagramChangeListener);
    }
    
    public void removeDiagramChangeListener(final mxDiagramChangeListener mxDiagramChangeListener) {
        if (this.diagramChangeListeners != null) {
            this.diagramChangeListeners.remove(mxDiagramChangeListener);
        }
    }
    
    void dispatchDiagramChangeEvent(final Object o, final String s) {
        if (this.diagramChangeListeners != null) {
            final Iterator<mxDiagramChangeListener> iterator = this.diagramChangeListeners.iterator();
            while (iterator.hasNext()) {
                iterator.next().diagramChanged(o, s);
            }
        }
    }
    
    public interface mxDiagramChangeListener
    {
        void diagramChanged(final Object p0, final String p1);
    }
}
