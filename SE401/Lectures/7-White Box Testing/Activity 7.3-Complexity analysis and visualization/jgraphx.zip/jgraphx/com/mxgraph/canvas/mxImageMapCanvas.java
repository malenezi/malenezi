// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.canvas;

import com.mxgraph.view.mxGraph;
import org.w3c.dom.Node;
import java.util.List;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxConstants;
import java.util.Hashtable;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Element;
import org.w3c.dom.Document;

public class mxImageMapCanvas implements mxICanvas
{
    protected Document document;
    protected Element map;
    protected String name;
    
    public mxImageMapCanvas(final String s) {
        this(s, null);
    }
    
    public mxImageMapCanvas(final String name, Document document) {
        this.name = name;
        try {
            if (document == null) {
                document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            }
            this.document = document;
            (this.map = document.createElement("map")).setAttribute("name", name);
        }
        catch (ParserConfigurationException ex) {}
    }
    
    public Document getDocument() {
        return this.document;
    }
    
    public Element getMap() {
        return this.map;
    }
    
    public String getName() {
        return this.name;
    }
    
    public Object drawVertex(final int n, final int n2, final int n3, int n4, final Hashtable hashtable) {
        final int int1 = mxUtils.getInt(hashtable, mxConstants.STYLE_STARTSIZE);
        if (int1 != 0) {
            n4 = int1;
        }
        return this.drawShape(n, n2, n3, n4, hashtable);
    }
    
    public Object drawEdge(final List list, final Hashtable hashtable) {
        return null;
    }
    
    public Object drawLabel(final String s, final int n, final int n2, final int n3, final int n4, final Hashtable hashtable, final boolean b) {
        return null;
    }
    
    public Element drawShape(final int i, final int j, final int n, final int n2, final Hashtable hashtable) {
        final Element element = this.document.createElement("area");
        element.setAttribute("shape", "rect");
        element.setAttribute("coords", i + "," + j + "," + (i + n) + "," + (j + n2));
        this.map.appendChild(element);
        return element;
    }
    
    public static Element drawGraph(final mxGraph mxGraph, final String s) {
        final mxImageMapCanvas mxImageMapCanvas = new mxImageMapCanvas(s);
        mxGraph.draw(mxImageMapCanvas);
        return mxImageMapCanvas.getMap();
    }
}
