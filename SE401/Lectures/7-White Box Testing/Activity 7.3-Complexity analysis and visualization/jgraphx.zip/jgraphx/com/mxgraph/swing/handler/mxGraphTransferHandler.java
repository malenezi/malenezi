// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import java.awt.image.BufferedImage;
import java.awt.Image;
import com.mxgraph.swing.view.mxGraphComponentCellRenderer;
import com.mxgraph.util.mxRectangle;
import javax.swing.ImageIcon;
import com.mxgraph.util.mxPoint;
import com.mxgraph.view.mxGraph;
import com.mxgraph.swing.mxGraphComponent;
import java.awt.datatransfer.Transferable;
import com.mxgraph.swing.util.mxGraphTransferable;
import java.awt.datatransfer.DataFlavor;
import javax.swing.JComponent;
import java.awt.Point;
import java.awt.Color;
import javax.swing.TransferHandler;

public class mxGraphTransferHandler extends TransferHandler
{
    public static boolean DEFAULT_TRANSFER_IMAGE_ENABLED;
    public static Color DEFAULT_BACKGROUNDCOLOR;
    protected Object[] originalCells;
    protected Object[] lastImported;
    protected int importCount;
    protected boolean transferImageEnabled;
    protected Color transferImageBackground;
    protected Point location;
    
    public mxGraphTransferHandler() {
        this.importCount = 0;
        this.transferImageEnabled = mxGraphTransferHandler.DEFAULT_TRANSFER_IMAGE_ENABLED;
        this.transferImageBackground = mxGraphTransferHandler.DEFAULT_BACKGROUNDCOLOR;
    }
    
    public void setTransferImageEnabled(final boolean transferImageEnabled) {
        this.transferImageEnabled = transferImageEnabled;
    }
    
    public boolean isTransferImageEnabled() {
        return this.transferImageEnabled;
    }
    
    public void setTransferImageBackground(final Color transferImageBackground) {
        this.transferImageBackground = transferImageBackground;
    }
    
    public Color getTransferImageBackground() {
        return this.transferImageBackground;
    }
    
    public boolean isLocalDrag() {
        return this.originalCells != null;
    }
    
    public void setLocation(final Point location) {
        this.location = location;
    }
    
    @Override
    public boolean canImport(final JComponent component, final DataFlavor[] array) {
        for (int i = 0; i < array.length; ++i) {
            if (array[i] == mxGraphTransferable.dataFlavor) {
                return true;
            }
        }
        return false;
    }
    
    public Transferable createTransferable(final JComponent component) {
        if (component instanceof mxGraphComponent) {
            final mxGraphComponent mxGraphComponent = (mxGraphComponent)component;
            final mxGraph graph = mxGraphComponent.getGraph();
            if (!graph.isSelectionEmpty()) {
                final mxPoint translate = graph.getView().getTranslate();
                final double scale = graph.getView().getScale();
                this.originalCells = graph.getSelectionCells();
                final ImageIcon imageIcon = this.transferImageEnabled ? this.createTransferableImage(mxGraphComponent, this.originalCells) : null;
                final mxRectangle paintBounds = graph.getPaintBounds(this.originalCells);
                paintBounds.setX(paintBounds.getX() / scale - translate.getX());
                paintBounds.setY(paintBounds.getY() / scale - translate.getY());
                paintBounds.setWidth(paintBounds.getWidth() / scale);
                paintBounds.setHeight(paintBounds.getHeight() / scale);
                return new mxGraphTransferable(graph.cloneCells(this.originalCells), paintBounds, imageIcon);
            }
        }
        return null;
    }
    
    public ImageIcon createTransferableImage(final mxGraphComponent mxGraphComponent, final Object[] array) {
        ImageIcon imageIcon = null;
        final BufferedImage render = mxGraphComponentCellRenderer.render(mxGraphComponent, 1.0, (this.transferImageBackground != null) ? this.transferImageBackground : mxGraphComponent.getBackground(), this.originalCells);
        if (render != null) {
            imageIcon = new ImageIcon(render);
        }
        return imageIcon;
    }
    
    public void exportDone(final JComponent component, final Transferable transferable, final int n) {
        if (component instanceof mxGraphComponent && transferable instanceof mxGraphTransferable) {
            final mxGraph graph = ((mxGraphComponent)component).getGraph();
            final boolean b = this.location != null;
            if (n == 2 && !b) {
                graph.remove(this.originalCells);
            }
        }
        this.originalCells = null;
        this.location = null;
    }
    
    @Override
    public int getSourceActions(final JComponent component) {
        return 3;
    }
    
    @Override
    public boolean importData(final JComponent component, final Transferable transferable) {
        boolean importCells = false;
        if (this.isLocalDrag()) {
            importCells = true;
        }
        else {
            try {
                if (component instanceof mxGraphComponent) {
                    final mxGraphComponent mxGraphComponent = (mxGraphComponent)component;
                    if (mxGraphComponent.isEnabled() && transferable.isDataFlavorSupported(mxGraphTransferable.dataFlavor)) {
                        final mxGraphTransferable mxGraphTransferable = (mxGraphTransferable)transferable.getTransferData(com.mxgraph.swing.util.mxGraphTransferable.dataFlavor);
                        if (mxGraphTransferable.getCells() != null) {
                            importCells = this.importCells(mxGraphComponent, mxGraphTransferable.getCells(), mxGraphTransferable.getBounds());
                        }
                    }
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return importCells;
    }
    
    protected boolean importCells(final mxGraphComponent mxGraphComponent, Object[] importCells, final mxRectangle mxRectangle) {
        boolean b = false;
        try {
            final mxGraph graph = mxGraphComponent.getGraph();
            final double scale = graph.getView().getScale();
            Object dropTarget = null;
            if (this.location != null) {
                dropTarget = graph.getDropTarget(importCells, this.location, graph.getCellAt(this.location.x, this.location.y));
                if (importCells.length > 0 && graph.getModel().getParent(importCells[0]) == dropTarget) {
                    dropTarget = null;
                }
            }
            double snap;
            double snap2;
            if (this.location != null && mxRectangle != null) {
                final mxPoint translate = graph.getView().getTranslate();
                final double n = this.location.getX() - (mxRectangle.getX() + translate.getX()) * scale;
                final double n2 = this.location.getY() - (mxRectangle.getY() + translate.getY()) * scale;
                snap = graph.snap(n / scale);
                snap2 = graph.snap(n2 / scale);
            }
            else {
                if (this.lastImported != importCells) {
                    this.importCount = 1;
                }
                else {
                    ++this.importCount;
                }
                final int gridSize = graph.getGridSize();
                snap = this.importCount * gridSize;
                snap2 = this.importCount * gridSize;
            }
            this.lastImported = importCells;
            importCells = mxGraphComponent.importCells(importCells, snap, snap2, dropTarget, this.location);
            graph.setSelectionCells(importCells);
            this.location = null;
            b = true;
            mxGraphComponent.requestFocus();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return b;
    }
    
    static {
        mxGraphTransferHandler.DEFAULT_TRANSFER_IMAGE_ENABLED = true;
        mxGraphTransferHandler.DEFAULT_BACKGROUNDCOLOR = Color.WHITE;
    }
}
