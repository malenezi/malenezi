// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.view;

import java.util.Iterator;
import com.mxgraph.util.mxUndoableEdit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import com.mxgraph.util.mxEventSource;

public class mxSelectionModel extends mxEventSource
{
    public static String EVENT_CHANGE;
    public static String EVENT_UNDO;
    protected mxGraph graph;
    protected boolean singleSelection;
    protected Set cells;
    
    public mxSelectionModel(final mxGraph graph) {
        this.singleSelection = false;
        this.cells = new LinkedHashSet();
        this.graph = graph;
    }
    
    public boolean isSingleSelection() {
        return this.singleSelection;
    }
    
    public void setSingleSelection(final boolean singleSelection) {
        this.singleSelection = singleSelection;
    }
    
    public boolean isSelected(final Object o) {
        return o != null && this.cells.contains(o);
    }
    
    public boolean isEmpty() {
        return this.cells.isEmpty();
    }
    
    public int size() {
        return this.cells.size();
    }
    
    public void clear() {
        this.changeSelection(null, this.cells);
    }
    
    public Object getCell() {
        return this.cells.isEmpty() ? null : this.cells.iterator().next();
    }
    
    public Object[] getCells() {
        return this.cells.toArray();
    }
    
    public void setCell(final Object o) {
        if (o != null) {
            this.setCells(new Object[] { o });
        }
        else {
            this.clear();
        }
    }
    
    public void setCells(Object[] array) {
        if (array != null) {
            if (this.singleSelection) {
                array = new Object[] { this.getFirstSelectableCell(array) };
            }
            final ArrayList<Object> list = new ArrayList<Object>(array.length);
            for (int i = 0; i < array.length; ++i) {
                if (this.graph.isSelectable(array[i])) {
                    list.add(array[i]);
                }
            }
            this.changeSelection(list, this.cells);
        }
        else {
            this.clear();
        }
    }
    
    protected Object getFirstSelectableCell(final Object[] array) {
        if (array != null) {
            for (int i = 0; i < array.length; ++i) {
                if (this.graph.isSelectable(array[i])) {
                    return array[i];
                }
            }
        }
        return null;
    }
    
    public void addCell(final Object o) {
        if (o != null) {
            this.addCells(new Object[] { o });
        }
    }
    
    public void addCells(Object[] array) {
        if (array != null) {
            Collection cells = null;
            if (this.singleSelection) {
                cells = this.cells;
                array = new Object[] { this.getFirstSelectableCell(array) };
            }
            final ArrayList<Object> list = new ArrayList<Object>(array.length);
            for (int i = 0; i < array.length; ++i) {
                if (!this.isSelected(array[i]) && this.graph.isSelectable(array[i])) {
                    list.add(array[i]);
                }
            }
            this.changeSelection(list, cells);
        }
    }
    
    public void removeCell(final Object o) {
        if (o != null) {
            this.removeCells(new Object[] { o });
        }
    }
    
    public void removeCells(final Object[] array) {
        if (array != null) {
            final ArrayList<Object> list = new ArrayList<Object>(array.length);
            for (int i = 0; i < array.length; ++i) {
                if (this.isSelected(array[i])) {
                    list.add(array[i]);
                }
            }
            this.changeSelection(null, list);
        }
    }
    
    protected void changeSelection(final Collection collection, final Collection collection2) {
        if ((collection != null && !collection.isEmpty()) || (collection2 != null && !collection2.isEmpty())) {
            final mxSelectionChange mxSelectionChange = new mxSelectionChange(this, collection, collection2);
            mxSelectionChange.execute();
            final mxUndoableEdit mxUndoableEdit = new mxUndoableEdit(this);
            mxUndoableEdit.add(mxSelectionChange);
            this.fireEvent(mxSelectionModel.EVENT_UNDO, new Object[] { mxUndoableEdit });
        }
    }
    
    protected void cellAdded(final Object o) {
        if (o != null) {
            this.cells.add(o);
        }
    }
    
    protected void cellRemoved(final Object o) {
        if (o != null) {
            this.cells.remove(o);
        }
    }
    
    static {
        mxSelectionModel.EVENT_CHANGE = "change";
        mxSelectionModel.EVENT_UNDO = "undo";
    }
    
    public static class mxSelectionChange implements mxUndoableEdit.mxUndoableChange
    {
        protected mxSelectionModel model;
        protected Collection added;
        protected Collection removed;
        
        public mxSelectionChange(final mxSelectionModel model, final Collection c, final Collection c2) {
            this.model = model;
            this.added = ((c != null) ? new ArrayList(c) : null);
            this.removed = ((c2 != null) ? new ArrayList(c2) : null);
        }
        
        public void execute() {
            if (this.removed != null) {
                final Iterator<Object> iterator = (Iterator<Object>)this.removed.iterator();
                while (iterator.hasNext()) {
                    this.model.cellRemoved(iterator.next());
                }
            }
            if (this.added != null) {
                final Iterator<Object> iterator2 = (Iterator<Object>)this.added.iterator();
                while (iterator2.hasNext()) {
                    this.model.cellAdded(iterator2.next());
                }
            }
            final Collection added = this.added;
            this.added = this.removed;
            this.removed = added;
            this.model.fireEvent(mxSelectionModel.EVENT_CHANGE, new Object[] { this.removed, this.added });
        }
    }
}
