// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.canvas;

import java.awt.Rectangle;
import com.mxgraph.util.mxPoint;
import java.util.List;
import java.util.Map;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxConstants;
import java.util.Hashtable;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Node;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.Color;
import org.w3c.dom.Element;
import org.w3c.dom.Document;

public class mxVmlCanvas implements mxICanvas
{
    public static String DEFAULT_IMAGEBASEPATH;
    public String imageBasePath;
    protected Document document;
    protected Element root;
    protected Element head;
    protected Element body;
    protected int x;
    protected int y;
    protected int width;
    protected int height;
    protected double scale;
    
    public mxVmlCanvas(final int n, final int n2, final double n3) {
        this(0, 0, n, n2, n3);
    }
    
    public mxVmlCanvas(final int n, final int n2, final int n3, final int n4, final double n5) {
        this(n, n2, n3, n4, n5, null);
    }
    
    public mxVmlCanvas(final int x, final int y, final int width, final int height, final double scale, final Color color) {
        this.imageBasePath = mxVmlCanvas.DEFAULT_IMAGEBASEPATH;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scale = scale;
        try {
            this.document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            (this.root = this.document.createElement("html")).setAttribute("xmlns:v", "urn:schemas-microsoft-com:vml");
            this.root.setAttribute("xmlns:o", "urn:schemas-microsoft-com:office:office");
            this.document.appendChild(this.root);
            this.head = this.document.createElement("head");
            final Element element = this.document.createElement("style");
            element.setAttribute("type", "text/css");
            element.appendChild(this.document.createTextNode("<!-- v\\:* {behavior: url(#default#VML);} -->"));
            this.head.appendChild(element);
            this.root.appendChild(this.head);
            this.body = this.document.createElement("body");
            this.root.appendChild(this.body);
        }
        catch (ParserConfigurationException ex) {}
    }
    
    public Document getDocument() {
        return this.document;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public Object drawVertex(int n, int n2, final int n3, final int n4, final Hashtable t) {
        final int int1 = mxUtils.getInt(t, mxConstants.STYLE_STARTSIZE);
        n -= this.x;
        n2 -= this.y;
        Element element;
        if (int1 == 0) {
            element = this.drawShape(n, n2, n3, n4, t);
        }
        else {
            final int n5 = (int)Math.round(int1 * this.scale);
            final Hashtable hashtable = new Hashtable(t);
            hashtable.remove(mxConstants.STYLE_FILLCOLOR);
            hashtable.remove(mxConstants.STYLE_ROUNDED);
            if (mxUtils.isTrue(t, mxConstants.STYLE_HORIZONTAL, true)) {
                element = this.drawShape(n, n2, n3, n5, t);
                this.drawShape(n, n2 + n5, n3, n4 - n5, hashtable);
            }
            else {
                element = this.drawShape(n, n2, n5, n4, t);
                this.drawShape(n + n5, n2, n3 - n5, n4, hashtable);
            }
        }
        return element;
    }
    
    public Object drawEdge(List translatePoints, final Hashtable hashtable) {
        translatePoints = mxUtils.translatePoints(translatePoints, -this.x, -this.y);
        final Element drawLine = this.drawLine(translatePoints, hashtable);
        final String string = mxUtils.getString(hashtable, mxConstants.STYLE_STARTARROW);
        final String string2 = mxUtils.getString(hashtable, mxConstants.STYLE_ENDARROW);
        if (string != null || string2 != null) {
            final Element element = this.document.createElement("v:stroke");
            if (string != null) {
                element.setAttribute("startarrow", string);
                String s = "medium";
                String s2 = "medium";
                final double n = mxUtils.getFloat(hashtable, mxConstants.STYLE_STARTSIZE, (float)mxConstants.DEFAULT_MARKERSIZE) * this.scale;
                if (n < 6.0) {
                    s = "narrow";
                    s2 = "short";
                }
                else if (n > 10.0) {
                    s = "wide";
                    s2 = "long";
                }
                element.setAttribute("startarrowwidth", s);
                element.setAttribute("startarrowlength", s2);
            }
            if (string2 != null) {
                element.setAttribute("endarrow", string2);
                String s3 = "medium";
                String s4 = "medium";
                final double n2 = mxUtils.getFloat(hashtable, mxConstants.STYLE_ENDSIZE, (float)mxConstants.DEFAULT_MARKERSIZE) * this.scale;
                if (n2 < 6.0) {
                    s3 = "narrow";
                    s4 = "short";
                }
                else if (n2 > 10.0) {
                    s3 = "wide";
                    s4 = "long";
                }
                element.setAttribute("endarrowwidth", s3);
                element.setAttribute("endarrowlength", s4);
            }
            drawLine.appendChild(element);
        }
        return drawLine;
    }
    
    public Object drawLabel(final String s, int n, int n2, final int n3, final int n4, final Hashtable hashtable, final boolean b) {
        n -= this.x;
        n2 -= this.y;
        return this.drawText(s, n, n2, n3, n4, hashtable);
    }
    
    public String getImageForStyle(final Hashtable hashtable) {
        String str = mxUtils.getString(hashtable, mxConstants.STYLE_IMAGE);
        if (str != null && !str.startsWith("/")) {
            str = this.imageBasePath + str;
        }
        return str;
    }
    
    public Element drawShape(final int i, final int j, final int k, final int n, final Hashtable hashtable) {
        final String string = mxUtils.getString(hashtable, mxConstants.STYLE_FILLCOLOR);
        mxUtils.getString(hashtable, mxConstants.STYLE_GRADIENTCOLOR);
        final String string2 = mxUtils.getString(hashtable, mxConstants.STYLE_STROKECOLOR);
        final float f = (float)(mxUtils.getFloat(hashtable, mxConstants.STYLE_STROKEWIDTH, 1.0f) * this.scale);
        final String string3 = mxUtils.getString(hashtable, mxConstants.STYLE_SHAPE);
        Element element = null;
        if (string3.equals("image")) {
            final String imageForStyle = this.getImageForStyle(hashtable);
            if (imageForStyle != null) {
                element = this.document.createElement("v:img");
                element.setAttribute("src", imageForStyle);
            }
        }
        else if (string3.equals("line")) {
            final String string4 = mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, "east");
            String str;
            if (string4.equals("east") || string4.equals("west")) {
                final int round = Math.round((float)(n / 2));
                str = "m 0 " + round + " l " + k + " " + round;
            }
            else {
                final int round2 = Math.round((float)(k / 2));
                str = "m " + round2 + " 0 L " + round2 + " " + n;
            }
            element = this.document.createElement("v:shape");
            element.setAttribute("coordsize", k + " " + n);
            element.setAttribute("path", str + " x e");
        }
        else if (string3.equals("ellipse")) {
            element = this.document.createElement("v:oval");
        }
        else if (string3.equals("doubleEllipse")) {
            element = this.document.createElement("v:shape");
            element.setAttribute("coordsize", k + " " + n);
            final int n2 = (int)((3.0f + f) * this.scale);
            element.setAttribute("path", "ar 0 0 " + k + " " + n + " 0 " + n / 2 + " " + k / 2 + " " + n / 2 + " e ar " + n2 + " " + n2 + " " + (k - n2) + " " + (n - n2) + " 0 " + n / 2 + " " + k / 2 + " " + n / 2 + " x e");
        }
        else if (string3.equals("rhombus")) {
            element = this.document.createElement("v:shape");
            element.setAttribute("coordsize", k + " " + n);
            element.setAttribute("path", "m " + k / 2 + " 0 l " + k + " " + n / 2 + " l " + k / 2 + " " + n + " l 0 " + n / 2 + " x e");
        }
        else if (string3.equals("triangle")) {
            element = this.document.createElement("v:shape");
            element.setAttribute("coordsize", k + " " + n);
            final String string5 = mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, "");
            String str2;
            if (string5.equals("north")) {
                str2 = "m 0 " + n + " l " + k / 2 + " 0 " + " l " + k + " " + n;
            }
            else if (string5.equals("south")) {
                str2 = "m 0 0 l " + k / 2 + " " + n + " l " + k + " 0";
            }
            else if (string5.equals("west")) {
                str2 = "m " + k + " 0 l " + k + " " + n / 2 + " l " + k + " " + n;
            }
            else {
                str2 = "m 0 0 l " + k + " " + n / 2 + " l 0 " + n;
            }
            element.setAttribute("path", str2 + " x e");
        }
        else if (string3.equals("hexagon")) {
            element = this.document.createElement("v:shape");
            element.setAttribute("coordsize", k + " " + n);
            final String string6 = mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, "");
            String str3;
            if (string6.equals("north") || string6.equals("south")) {
                str3 = "m " + (int)(0.5 * k) + " 0 l " + k + " " + (int)(0.25 * n) + " l " + k + " " + (int)(0.75 * n) + " l " + (int)(0.5 * k) + " " + n + " l 0 " + (int)(0.75 * n) + " l 0 " + (int)(0.25 * n);
            }
            else {
                str3 = "m " + (int)(0.25 * k) + " 0 l " + (int)(0.75 * k) + " 0 l " + k + " " + (int)(0.5 * n) + " l " + (int)(0.75 * k) + " " + n + " l " + (int)(0.25 * k) + " " + n + " l 0 " + (int)(0.5 * n);
            }
            element.setAttribute("path", str3 + " x e");
        }
        else if (string3.equals("cloud")) {
            element = this.document.createElement("v:shape");
            element.setAttribute("coordsize", k + " " + n);
            element.setAttribute("path", "m " + (int)(0.25 * k) + " " + (int)(0.25 * n) + " c " + (int)(0.05 * k) + " " + (int)(0.25 * n) + " 0 " + (int)(0.5 * n) + " " + (int)(0.16 * k) + " " + (int)(0.55 * n) + " c 0 " + (int)(0.66 * n) + " " + (int)(0.18 * k) + " " + (int)(0.9 * n) + " " + (int)(0.31 * k) + " " + (int)(0.8 * n) + " c " + (int)(0.4 * k) + " " + n + " " + (int)(0.7 * k) + " " + n + " " + (int)(0.8 * k) + " " + (int)(0.8 * n) + " c " + k + " " + (int)(0.8 * n) + " " + k + " " + (int)(0.6 * n) + " " + (int)(0.875 * k) + " " + (int)(0.5 * n) + " c " + k + " " + (int)(0.3 * n) + " " + (int)(0.8 * k) + " " + (int)(0.1 * n) + " " + (int)(0.625 * k) + " " + (int)(0.2 * n) + " c " + (int)(0.5 * k) + " " + (int)(0.05 * n) + " " + (int)(0.3 * k) + " " + (int)(0.05 * n) + " " + (int)(0.25 * k) + " " + (int)(0.25 * n) + " x e");
        }
        else if (string3.equals("actor")) {
            element = this.document.createElement("v:shape");
            element.setAttribute("coordsize", k + " " + n);
            final double n3 = k / 3;
            element.setAttribute("path", "m 0 " + n + " C 0 " + 3 * n / 5 + " 0 " + 2 * n / 5 + " " + k / 2 + " " + 2 * n / 5 + " c " + (int)(k / 2 - n3) + " " + 2 * n / 5 + " " + (int)(k / 2 - n3) + " 0 " + k / 2 + " 0 c " + (int)(k / 2 + n3) + " 0 " + (int)(k / 2 + n3) + " " + 2 * n / 5 + " " + k / 2 + " " + 2 * n / 5 + " c " + k + " " + 2 * n / 5 + " " + k + " " + 3 * n / 5 + " " + k + " " + n + " x e");
        }
        else if (string3.equals("cylinder")) {
            element = this.document.createElement("v:shape");
            element.setAttribute("coordsize", k + " " + n);
            final double min = Math.min(40.0, Math.floor(n / 5));
            element.setAttribute("path", "m 0 " + (int)min + " C 0 " + (int)(min / 3.0) + " " + k + " " + (int)(min / 3.0) + " " + k + " " + (int)min + " L " + k + " " + (int)(n - min) + " C " + k + " " + (int)(n + min / 3.0) + " 0 " + (int)(n + min / 3.0) + " 0 " + (int)(n - min) + " x e" + " m 0 " + (int)min + " C 0 " + (int)(2.0 * min) + " " + k + " " + (int)(2.0 * min) + " " + k + " " + (int)min + " e");
        }
        else {
            element = this.document.createElement("v:rect");
        }
        String str4 = "position:absolute;left:" + String.valueOf(i) + "px;top:" + String.valueOf(j) + "px;width:" + String.valueOf(k) + "px;height:" + String.valueOf(n) + "px;";
        final double double1 = mxUtils.getDouble(hashtable, mxConstants.STYLE_ROTATION);
        if (double1 != 0.0) {
            str4 = str4 + "rotation:" + double1 + ";";
        }
        element.setAttribute("style", str4);
        if (mxUtils.isTrue(hashtable, mxConstants.STYLE_SHADOW, false) && string != null) {
            final Element element2 = this.document.createElement("v:shadow");
            element2.setAttribute("on", "true");
            element.appendChild(element2);
        }
        final float float1 = mxUtils.getFloat(hashtable, mxConstants.STYLE_OPACITY, 100.0f);
        if (string != null) {
            final Element element3 = this.document.createElement("v:fill");
            element3.setAttribute("color", string);
            if (float1 != 100.0f) {
                element3.setAttribute("opacity", String.valueOf(float1 / 100.0f));
            }
            element.appendChild(element3);
        }
        else {
            element.setAttribute("filled", "false");
        }
        if (string2 != null) {
            element.setAttribute("strokecolor", string2);
            final Element element4 = this.document.createElement("v:stroke");
            if (float1 != 100.0f) {
                element4.setAttribute("opacity", String.valueOf(float1 / 100.0f));
            }
            element.appendChild(element4);
        }
        else {
            element.setAttribute("stroked", "false");
        }
        element.setAttribute("strokeweight", String.valueOf(f) + "pt");
        this.body.appendChild(element);
        return element;
    }
    
    public Element drawLine(final List list, final Hashtable hashtable) {
        final String string = mxUtils.getString(hashtable, mxConstants.STYLE_STROKECOLOR);
        final float f = (float)(mxUtils.getFloat(hashtable, mxConstants.STYLE_STROKEWIDTH, 1.0f) * this.scale);
        final Element element = this.document.createElement("v:shape");
        if (string != null && f > 0.0f) {
            final mxPoint mxPoint = list.get(0);
            Rectangle union = new Rectangle(mxPoint.getPoint());
            String str = "m " + Math.round(mxPoint.getX()) + " " + Math.round(mxPoint.getY());
            for (int i = 1; i < list.size(); ++i) {
                final mxPoint mxPoint2 = list.get(i);
                str = str + " l " + Math.round(mxPoint2.getX()) + " " + Math.round(mxPoint2.getY());
                union = union.union(new Rectangle(mxPoint2.getPoint()));
            }
            element.setAttribute("path", str);
            element.setAttribute("filled", "false");
            element.setAttribute("strokecolor", string);
            element.setAttribute("strokeweight", String.valueOf(f) + "pt");
            element.setAttribute("style", "position:absolute;left:" + String.valueOf(union.x) + "px;" + "top:" + String.valueOf(union.y) + "px;" + "width:" + String.valueOf(union.width) + "px;" + "height:" + String.valueOf(union.height) + "px;");
            element.setAttribute("coordorigin", String.valueOf(union.x) + " " + String.valueOf(union.y));
            element.setAttribute("coordsize", String.valueOf(union.width) + " " + String.valueOf(union.height));
        }
        this.body.appendChild(element);
        return element;
    }
    
    public Element drawText(final String s, final int n, final int n2, final int n3, final int n4, final Hashtable hashtable) {
        final Element table = mxUtils.createTable(this.document, s, n, n2, n3, n4, this.scale, hashtable);
        this.body.appendChild(table);
        return table;
    }
    
    static {
        mxVmlCanvas.DEFAULT_IMAGEBASEPATH = "";
    }
}
