// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import java.awt.BasicStroke;
import java.awt.Point;
import java.awt.Graphics2D;
import java.awt.Graphics;
import com.mxgraph.util.mxUtils;
import java.awt.Rectangle;
import java.awt.Component;
import java.awt.event.MouseEvent;
import com.mxgraph.util.mxConstants;
import com.mxgraph.view.mxCellState;
import java.awt.Color;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.util.mxEventSource;
import java.awt.Stroke;
import javax.swing.JComponent;

public class mxCellMarker extends JComponent
{
    public static String EVENT_MARK;
    public static Stroke DEFAULT_STROKE;
    protected mxEventSource eventSource;
    protected mxGraphComponent graphComponent;
    protected boolean enabled;
    protected double hotspot;
    protected boolean hotspotEnabled;
    protected boolean swimlaneContentEnabled;
    protected Color validColor;
    protected Color invalidColor;
    protected transient Color currentColor;
    protected transient mxCellState validState;
    protected transient mxCellState markedState;
    
    public mxCellMarker(final mxGraphComponent mxGraphComponent) {
        this(mxGraphComponent, mxConstants.DEFAULT_VALID_COLOR);
    }
    
    public mxCellMarker(final mxGraphComponent mxGraphComponent, final Color color) {
        this(mxGraphComponent, color, mxConstants.DEFAULT_INVALID_COLOR);
    }
    
    public mxCellMarker(final mxGraphComponent mxGraphComponent, final Color color, final Color color2) {
        this(mxGraphComponent, color, color2, mxConstants.DEFAULT_HOTSPOT);
    }
    
    public mxCellMarker(final mxGraphComponent graphComponent, final Color validColor, final Color invalidColor, final double hotspot) {
        this.eventSource = new mxEventSource(this);
        this.enabled = true;
        this.hotspotEnabled = false;
        this.swimlaneContentEnabled = false;
        this.graphComponent = graphComponent;
        this.validColor = validColor;
        this.invalidColor = invalidColor;
        this.hotspot = hotspot;
    }
    
    @Override
    public void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
    
    @Override
    public boolean isEnabled() {
        return this.enabled;
    }
    
    public void setHotspot(final double hotspot) {
        this.hotspot = hotspot;
    }
    
    public double getHotspot() {
        return this.hotspot;
    }
    
    public void setHotspotEnabled(final boolean hotspotEnabled) {
        this.hotspotEnabled = hotspotEnabled;
    }
    
    public boolean isHotspotEnabled() {
        return this.hotspotEnabled;
    }
    
    public void setSwimlaneContentEnabled(final boolean swimlaneContentEnabled) {
        this.swimlaneContentEnabled = swimlaneContentEnabled;
    }
    
    public boolean isSwimlaneContentEnabled() {
        return this.swimlaneContentEnabled;
    }
    
    public boolean hasValidState() {
        return this.validState != null;
    }
    
    public mxCellState getValidState() {
        return this.validState;
    }
    
    public mxCellState getMarkedState() {
        return this.markedState;
    }
    
    public void reset() {
        this.validState = null;
        if (this.markedState != null) {
            this.markedState = null;
            this.unmark();
        }
    }
    
    public mxCellState process(final MouseEvent mouseEvent) {
        mxCellState state = null;
        if (this.isEnabled()) {
            state = this.getState(mouseEvent);
            final boolean b = state != null && this.isValidState(state);
            final Color markerColor = this.getMarkerColor(mouseEvent, state, b);
            if (b) {
                this.validState = state;
            }
            else {
                this.validState = null;
            }
            if (state != this.markedState || markerColor != this.currentColor) {
                this.currentColor = markerColor;
                if (state != null && this.currentColor != null) {
                    this.markedState = state;
                    this.mark();
                }
                else if (this.markedState != null) {
                    this.markedState = null;
                    this.unmark();
                }
            }
        }
        return state;
    }
    
    protected void mark() {
        if (this.markedState != null) {
            final Rectangle rectangle = this.markedState.getRectangle();
            rectangle.grow(3, 3);
            final Rectangle rectangle2 = rectangle;
            ++rectangle2.width;
            final Rectangle rectangle3 = rectangle;
            ++rectangle3.height;
            this.setBounds(rectangle);
            if (this.getParent() == null) {
                this.setVisible(true);
                this.graphComponent.getControl().add(this);
            }
            this.repaint();
            this.eventSource.fireEvent(mxCellMarker.EVENT_MARK, new Object[] { this.markedState });
        }
    }
    
    protected void unmark() {
        if (this.getParent() != null) {
            this.setVisible(false);
            this.getParent().remove(this);
            this.eventSource.fireEvent(mxCellMarker.EVENT_MARK);
        }
    }
    
    protected boolean isValidState(final mxCellState mxCellState) {
        return true;
    }
    
    protected Color getMarkerColor(final MouseEvent mouseEvent, final mxCellState mxCellState, final boolean b) {
        return b ? this.validColor : this.invalidColor;
    }
    
    protected mxCellState getState(final MouseEvent mouseEvent) {
        final mxCellState stateToMark = this.getStateToMark(this.graphComponent.getGraph().getView().getState(this.getCell(mouseEvent)));
        return (stateToMark != null && this.intersects(stateToMark, mouseEvent)) ? stateToMark : null;
    }
    
    protected Object getCell(final MouseEvent mouseEvent) {
        return this.graphComponent.getGraph().getCellAt(mouseEvent.getX(), mouseEvent.getY(), this.swimlaneContentEnabled);
    }
    
    protected mxCellState getStateToMark(final mxCellState mxCellState) {
        return mxCellState;
    }
    
    protected boolean intersects(final mxCellState mxCellState, final MouseEvent mouseEvent) {
        if (this.hotspotEnabled && this.hotspot > 0.0) {
            int n = (int)mxCellState.getCenterX();
            int n2 = (int)mxCellState.getCenterY();
            int n3 = (int)mxCellState.getWidth();
            int n4 = (int)mxCellState.getHeight();
            final int int1 = mxUtils.getInt(mxCellState.getStyle(), mxConstants.STYLE_STARTSIZE);
            if (int1 > 0) {
                if (mxUtils.isTrue(mxCellState.getStyle(), mxConstants.STYLE_HORIZONTAL, true)) {
                    n2 = (int)(mxCellState.getY() + int1 / 2);
                    n4 = int1;
                }
                else {
                    n = (int)(mxCellState.getX() + int1 / 2);
                    n3 = int1;
                }
            }
            int min = (int)Math.max(mxConstants.MIN_HOTSPOT_SIZE, n3 * this.hotspot);
            int min2 = (int)Math.max(mxConstants.MIN_HOTSPOT_SIZE, n4 * this.hotspot);
            if (mxConstants.MAX_HOTSPOT_SIZE > 0) {
                min = Math.min(min, mxConstants.MAX_HOTSPOT_SIZE);
                min2 = Math.min(min2, mxConstants.MAX_HOTSPOT_SIZE);
            }
            return new Rectangle(n - min / 2, n2 - min2 / 2, min, min2).contains(mouseEvent.getPoint());
        }
        return true;
    }
    
    public void addListener(final String s, final mxEventSource.mxEventListener mxEventListener) {
        this.eventSource.addListener(s, mxEventListener);
    }
    
    public void removeListener(final mxEventSource.mxEventListener mxEventListener) {
        this.eventSource.removeListener(mxEventListener);
    }
    
    public void removeListener(final String s, final mxEventSource.mxEventListener mxEventListener) {
        this.eventSource.removeListener(s, mxEventListener);
    }
    
    @Override
    public void paint(final Graphics graphics) {
        if (this.markedState != null && this.currentColor != null) {
            ((Graphics2D)graphics).setStroke(mxCellMarker.DEFAULT_STROKE);
            graphics.setColor(this.currentColor);
            if (this.markedState.getAbsolutePointCount() > 0) {
                Point point = this.markedState.getAbsolutePoint(0).getPoint();
                for (int i = 1; i < this.markedState.getAbsolutePointCount(); ++i) {
                    final Point point2 = this.markedState.getAbsolutePoint(i).getPoint();
                    graphics.drawLine(point.x - this.getX(), point.y - this.getY(), point2.x - this.getX(), point2.y - this.getY());
                    point = point2;
                }
            }
            else {
                graphics.drawRect(1, 1, this.getWidth() - 3, this.getHeight() - 3);
            }
        }
    }
    
    static {
        mxCellMarker.EVENT_MARK = "mark";
        mxCellMarker.DEFAULT_STROKE = new BasicStroke(3.0f);
    }
}
