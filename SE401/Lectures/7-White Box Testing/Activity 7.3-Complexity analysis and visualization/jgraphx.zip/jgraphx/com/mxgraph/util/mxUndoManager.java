// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.util;

import java.util.ArrayList;
import java.util.List;

public class mxUndoManager extends mxEventSource
{
    public static final String EVENT_ADD = "add";
    public static final String EVENT_UNDO = "undo";
    public static final String EVENT_REDO = "redo";
    protected int size;
    protected List history;
    protected int indexOfNextAdd;
    
    public mxUndoManager() {
        this(100);
    }
    
    public mxUndoManager(final int size) {
        this.size = size;
        this.reset();
    }
    
    public void reset() {
        this.history = new ArrayList(this.size);
        this.indexOfNextAdd = 0;
    }
    
    public boolean canUndo() {
        return this.indexOfNextAdd > 0;
    }
    
    public void undo() {
        while (this.indexOfNextAdd > 0) {
            final List history = this.history;
            final int indexOfNextAdd = this.indexOfNextAdd - 1;
            this.indexOfNextAdd = indexOfNextAdd;
            final mxUndoableEdit mxUndoableEdit = history.get(indexOfNextAdd);
            mxUndoableEdit.undo();
            if (mxUndoableEdit.isSignificant()) {
                this.fireEvent("undo", new Object[] { mxUndoableEdit });
                break;
            }
        }
    }
    
    public boolean canRedo() {
        return this.indexOfNextAdd < this.history.size();
    }
    
    public void redo() {
        while (this.indexOfNextAdd < this.history.size()) {
            final mxUndoableEdit mxUndoableEdit = this.history.get(this.indexOfNextAdd++);
            mxUndoableEdit.redo();
            if (mxUndoableEdit.isSignificant()) {
                this.fireEvent("redo", new Object[] { mxUndoableEdit });
                break;
            }
        }
    }
    
    public void undoableEditHappened(final mxUndoableEdit mxUndoableEdit) {
        this.trim();
        if (this.size == this.history.size()) {
            this.history.remove(0);
        }
        this.history.add(mxUndoableEdit);
        this.indexOfNextAdd = this.history.size();
        this.fireEvent("add", new Object[] { mxUndoableEdit });
    }
    
    protected void trim() {
        while (this.history.size() > this.indexOfNextAdd) {
            this.history.remove(this.indexOfNextAdd).die();
        }
    }
}
