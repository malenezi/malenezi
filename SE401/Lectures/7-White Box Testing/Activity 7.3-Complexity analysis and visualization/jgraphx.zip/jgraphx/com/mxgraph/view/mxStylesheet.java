// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.view;

import java.util.Map;
import com.mxgraph.util.mxConstants;
import java.util.Hashtable;

public class mxStylesheet
{
    public static final Hashtable EMPTY_STYLE;
    protected Hashtable styles;
    
    public mxStylesheet() {
        this.styles = new Hashtable();
        this.setDefaultVertexStyle(this.createDefaultVertexStyle());
        this.setDefaultEdgeStyle(this.createDefaultEdgeStyle());
    }
    
    public Hashtable getStyles() {
        return this.styles;
    }
    
    public void setStyles(final Hashtable styles) {
        this.styles = styles;
    }
    
    protected Hashtable createDefaultVertexStyle() {
        final Hashtable<String, String> hashtable = new Hashtable<String, String>();
        hashtable.put(mxConstants.STYLE_SHAPE, "rectangle");
        hashtable.put(mxConstants.STYLE_PERIMETER, (String)mxPerimeter.RectanglePerimeter);
        hashtable.put(mxConstants.STYLE_VERTICAL_ALIGN, "middle");
        hashtable.put(mxConstants.STYLE_ALIGN, "center");
        hashtable.put(mxConstants.STYLE_FILLCOLOR, "#C3D9FF");
        hashtable.put(mxConstants.STYLE_STROKECOLOR, "#6482B9");
        hashtable.put(mxConstants.STYLE_FONTCOLOR, "#774400");
        return hashtable;
    }
    
    protected Hashtable createDefaultEdgeStyle() {
        final Hashtable<String, String> hashtable = new Hashtable<String, String>();
        hashtable.put(mxConstants.STYLE_SHAPE, "connector");
        hashtable.put(mxConstants.STYLE_ENDARROW, "classic");
        hashtable.put(mxConstants.STYLE_VERTICAL_ALIGN, "middle");
        hashtable.put(mxConstants.STYLE_ALIGN, "center");
        hashtable.put(mxConstants.STYLE_STROKECOLOR, "#6482B9");
        hashtable.put(mxConstants.STYLE_FONTCOLOR, "#446299");
        hashtable.put(mxConstants.STYLE_FONTSIZE, "11");
        return hashtable;
    }
    
    public Hashtable getDefaultVertexStyle() {
        return this.styles.get("defaultVertex");
    }
    
    public void setDefaultVertexStyle(final Hashtable hashtable) {
        this.putCellStyle("defaultVertex", hashtable);
    }
    
    public Hashtable getDefaultEdgeStyle() {
        return this.styles.get("defaultEdge");
    }
    
    public void setDefaultEdgeStyle(final Hashtable hashtable) {
        this.putCellStyle("defaultEdge", hashtable);
    }
    
    public void putCellStyle(final String key, final Hashtable value) {
        this.styles.put(key, value);
    }
    
    public Hashtable getCellStyle(final String s, final Hashtable hashtable) {
        Hashtable<Object, Object> t = (Hashtable<Object, Object>)hashtable;
        if (s != null && s.length() > 0) {
            final String[] split = s.split(";");
            if (split != null && split.length > 0) {
                if (t != null && split[0].indexOf(61) >= 0) {
                    t = (Hashtable<Object, Object>)new Hashtable<String, String>(t);
                }
                else {
                    t = (Hashtable<Object, Object>)new Hashtable<String, String>();
                }
                for (int i = 0; i < split.length; ++i) {
                    final String key = split[i];
                    final int index = key.indexOf(61);
                    if (index >= 0) {
                        final String substring = key.substring(0, index);
                        final String substring2 = key.substring(index + 1);
                        if (substring2.equals(mxConstants.NONE)) {
                            t.remove(substring);
                        }
                        else {
                            t.put(substring, substring2);
                        }
                    }
                    else {
                        final Hashtable<? extends String, ? extends String> t2 = this.styles.get(key);
                        if (t2 != null) {
                            t.putAll(t2);
                        }
                    }
                }
            }
        }
        return t;
    }
    
    static {
        EMPTY_STYLE = new Hashtable();
    }
}
