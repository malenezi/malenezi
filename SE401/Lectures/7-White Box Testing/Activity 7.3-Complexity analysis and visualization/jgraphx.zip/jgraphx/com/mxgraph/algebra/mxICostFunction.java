// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.algebra;

import com.mxgraph.view.mxCellState;

public interface mxICostFunction
{
    double getCost(final mxCellState p0);
}
