// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.view;

import java.util.Iterator;
import com.mxgraph.model.mxIGraphModel;
import com.mxgraph.util.mxUtils;
import java.util.Collection;

public class mxMultiplicity
{
    protected String type;
    protected String attr;
    protected String value;
    protected boolean source;
    protected int min;
    protected String max;
    protected Collection validNeighbors;
    protected boolean validNeighborsAllowed;
    protected String countError;
    protected String typeError;
    
    public mxMultiplicity(final boolean source, final String type, final String attr, final String value, final int min, final String max, final Collection validNeighbors, final String countError, final String typeError, final boolean validNeighborsAllowed) {
        this.min = 0;
        this.max = "n";
        this.validNeighborsAllowed = true;
        this.source = source;
        this.type = type;
        this.attr = attr;
        this.value = value;
        this.min = min;
        this.max = max;
        this.validNeighbors = validNeighbors;
        this.countError = countError;
        this.typeError = typeError;
        this.validNeighborsAllowed = validNeighborsAllowed;
    }
    
    public String check(final mxGraph mxGraph, final Object o, final Object o2, final Object o3, final int n, final int n2) {
        final StringBuffer sb = new StringBuffer();
        final mxIGraphModel model = mxGraph.getModel();
        final Object value = model.getValue(o2);
        final Object value2 = model.getValue(o3);
        if (value != null && value2 != null && ((this.source && mxUtils.isNode(value, this.type, this.attr, this.value)) || (!this.source && mxUtils.isNode(value2, this.type, this.attr, this.value)))) {
            if (!this.isUnlimited()) {
                final int maxValue = this.getMaxValue();
                if (maxValue == 0 || (this.source && n >= maxValue) || (!this.source && n2 >= maxValue)) {
                    sb.append(this.countError + "\n");
                }
            }
            final boolean b = !this.validNeighborsAllowed;
            for (final Object next : this.validNeighbors) {
                if (this.source && mxUtils.isNode(value2, String.valueOf(next))) {
                    final boolean validNeighborsAllowed = this.validNeighborsAllowed;
                    break;
                }
                if (!this.source && mxUtils.isNode(value, String.valueOf(next))) {
                    final boolean validNeighborsAllowed2 = this.validNeighborsAllowed;
                    break;
                }
                if (b) {
                    continue;
                }
                sb.append(this.typeError + "\n");
            }
        }
        return (sb.length() > 0) ? sb.toString() : null;
    }
    
    public boolean isUnlimited() {
        return this.max == null || this.max == "n";
    }
    
    public int getMaxValue() {
        try {
            return Integer.parseInt(this.max);
        }
        catch (NumberFormatException ex) {
            return 0;
        }
    }
}
