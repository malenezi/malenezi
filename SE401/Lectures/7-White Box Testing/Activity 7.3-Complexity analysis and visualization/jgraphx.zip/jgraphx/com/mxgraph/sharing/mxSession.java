// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.sharing;

import com.mxgraph.util.mxUtils;

public class mxSession implements mxSharedDiagram.mxDiagramChangeListener
{
    protected String id;
    protected mxSharedDiagram diagram;
    protected StringBuffer buffer;
    protected long lastTimeMillis;
    
    public mxSession(final String id, final mxSharedDiagram diagram) {
        this.buffer = new StringBuffer();
        this.lastTimeMillis = 0L;
        this.id = id;
        (this.diagram = diagram).addDiagramChangeListener(this);
        this.lastTimeMillis = System.currentTimeMillis();
    }
    
    public String getId() {
        return this.id;
    }
    
    public String getInitialState() {
        final StringBuffer sb = new StringBuffer("<state session-id=\"" + this.id + "\" namespace=\"" + mxUtils.getMd5Hash(this.id) + "\">");
        sb.append(this.diagram.getInitialState());
        sb.append("<delta>");
        sb.append(this.diagram.getDelta());
        sb.append("</delta>");
        sb.append("</state>");
        return sb.toString();
    }
    
    public synchronized String init() {
        synchronized (this) {
            this.buffer = new StringBuffer();
            this.notify();
        }
        return this.getInitialState();
    }
    
    public void post(final String s) {
        this.diagram.dispatch(this, s);
    }
    
    public String poll() throws InterruptedException {
        return this.poll(10000L);
    }
    
    public String poll(final long n) throws InterruptedException {
        this.lastTimeMillis = System.currentTimeMillis();
        String string = "<delta/>";
        synchronized (this) {
            if (this.buffer.length() == 0) {
                this.wait(n);
            }
            if (this.buffer.length() > 0) {
                string = "<delta>" + this.buffer.toString() + "</delta>";
                this.buffer = new StringBuffer();
            }
            this.notify();
        }
        return string;
    }
    
    public long inactiveTimeMillis() {
        return System.currentTimeMillis() - this.lastTimeMillis;
    }
    
    public synchronized void diagramChanged(final Object o, final String str) {
        if (o != this) {
            synchronized (this) {
                this.buffer.append(str);
                this.notify();
            }
        }
    }
    
    public void destroy() {
        this.diagram.removeDiagramChangeListener(this);
    }
}
