// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.util;

import java.io.IOException;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.Reader;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream;
import java.awt.image.RenderedImage;
import javax.swing.ImageIcon;
import com.mxgraph.util.mxRectangle;
import java.awt.datatransfer.DataFlavor;
import java.io.Serializable;
import javax.swing.plaf.UIResource;
import java.awt.datatransfer.Transferable;

public class mxGraphTransferable implements Transferable, UIResource, Serializable
{
    private static final long serialVersionUID = 5123819419918087664L;
    public static DataFlavor dataFlavor;
    private static DataFlavor[] htmlFlavors;
    private static DataFlavor[] stringFlavors;
    private static DataFlavor[] plainFlavors;
    private static DataFlavor[] imageFlavors;
    protected Object[] cells;
    protected mxRectangle bounds;
    protected ImageIcon image;
    
    public mxGraphTransferable(final Object[] array, final mxRectangle mxRectangle) {
        this(array, mxRectangle, null);
    }
    
    public mxGraphTransferable(final Object[] cells, final mxRectangle bounds, final ImageIcon image) {
        this.cells = cells;
        this.bounds = bounds;
        this.image = image;
    }
    
    public Object[] getCells() {
        return this.cells;
    }
    
    public mxRectangle getBounds() {
        return this.bounds;
    }
    
    public ImageIcon getImage() {
        return this.image;
    }
    
    public DataFlavor[] getTransferDataFlavors() {
        final DataFlavor[] richerFlavors = this.getRicherFlavors();
        final int n = (richerFlavors != null) ? richerFlavors.length : 0;
        final int n2 = this.isHTMLSupported() ? mxGraphTransferable.htmlFlavors.length : 0;
        final int n3 = this.isPlainSupported() ? mxGraphTransferable.plainFlavors.length : 0;
        final int n4 = this.isPlainSupported() ? mxGraphTransferable.stringFlavors.length : 0;
        final int n5 = this.isImageSupported() ? mxGraphTransferable.stringFlavors.length : 0;
        final DataFlavor[] array = new DataFlavor[n + n2 + n3 + n4 + n5];
        int n6 = 0;
        if (n > 0) {
            System.arraycopy(richerFlavors, 0, array, n6, n);
            n6 += n;
        }
        if (n2 > 0) {
            System.arraycopy(mxGraphTransferable.htmlFlavors, 0, array, n6, n2);
            n6 += n2;
        }
        if (n3 > 0) {
            System.arraycopy(mxGraphTransferable.plainFlavors, 0, array, n6, n3);
            n6 += n3;
        }
        if (n4 > 0) {
            System.arraycopy(mxGraphTransferable.stringFlavors, 0, array, n6, n4);
            n6 += n4;
        }
        if (n5 > 0) {
            System.arraycopy(mxGraphTransferable.imageFlavors, 0, array, n6, n5);
        }
        return array;
    }
    
    protected DataFlavor[] getRicherFlavors() {
        return new DataFlavor[] { mxGraphTransferable.dataFlavor };
    }
    
    public boolean isDataFlavorSupported(final DataFlavor that) {
        final DataFlavor[] transferDataFlavors = this.getTransferDataFlavors();
        for (int i = 0; i < transferDataFlavors.length; ++i) {
            if (transferDataFlavors[i] != null && transferDataFlavors[i].equals(that)) {
                return true;
            }
        }
        return false;
    }
    
    public Object getTransferData(final DataFlavor flavor) throws UnsupportedFlavorException, IOException {
        if (this.isRicherFlavor(flavor)) {
            return this.getRicherData(flavor);
        }
        if (this.isImageFlavor(flavor)) {
            if (this.image != null && this.image.getImage() instanceof RenderedImage) {
                if (flavor.equals(DataFlavor.imageFlavor)) {
                    return this.image.getImage();
                }
                final ByteArrayOutputStream output = new ByteArrayOutputStream();
                ImageIO.write((RenderedImage)this.image.getImage(), "bmp", output);
                return new ByteArrayInputStream(output.toByteArray());
            }
        }
        else if (this.isHTMLFlavor(flavor)) {
            final String htmlData = this.getHTMLData();
            final String s = (htmlData == null) ? "" : htmlData;
            if (String.class.equals(flavor.getRepresentationClass())) {
                return s;
            }
            if (Reader.class.equals(flavor.getRepresentationClass())) {
                return new StringReader(s);
            }
            if (InputStream.class.equals(flavor.getRepresentationClass())) {
                return new ByteArrayInputStream(s.getBytes());
            }
        }
        else if (this.isPlainFlavor(flavor)) {
            final String plainData = this.getPlainData();
            final String s2 = (plainData == null) ? "" : plainData;
            if (String.class.equals(flavor.getRepresentationClass())) {
                return s2;
            }
            if (Reader.class.equals(flavor.getRepresentationClass())) {
                return new StringReader(s2);
            }
            if (InputStream.class.equals(flavor.getRepresentationClass())) {
                return new ByteArrayInputStream(s2.getBytes());
            }
        }
        else if (this.isStringFlavor(flavor)) {
            final String plainData2 = this.getPlainData();
            return (plainData2 == null) ? "" : plainData2;
        }
        throw new UnsupportedFlavorException(flavor);
    }
    
    protected boolean isRicherFlavor(final DataFlavor that) {
        final DataFlavor[] richerFlavors = this.getRicherFlavors();
        for (int n = (richerFlavors != null) ? richerFlavors.length : 0, i = 0; i < n; ++i) {
            if (richerFlavors[i].equals(that)) {
                return true;
            }
        }
        return false;
    }
    
    public Object getRicherData(final DataFlavor flavor) throws UnsupportedFlavorException {
        if (flavor.equals(mxGraphTransferable.dataFlavor)) {
            return this;
        }
        throw new UnsupportedFlavorException(flavor);
    }
    
    protected boolean isHTMLFlavor(final DataFlavor that) {
        final DataFlavor[] htmlFlavors = mxGraphTransferable.htmlFlavors;
        for (int i = 0; i < htmlFlavors.length; ++i) {
            if (htmlFlavors[i].equals(that)) {
                return true;
            }
        }
        return false;
    }
    
    protected boolean isHTMLSupported() {
        return false;
    }
    
    protected String getHTMLData() {
        return null;
    }
    
    protected boolean isImageFlavor(final DataFlavor that) {
        for (int n = (mxGraphTransferable.imageFlavors != null) ? mxGraphTransferable.imageFlavors.length : 0, i = 0; i < n; ++i) {
            if (mxGraphTransferable.imageFlavors[i].equals(that)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean isImageSupported() {
        return this.image != null;
    }
    
    protected boolean isPlainFlavor(final DataFlavor that) {
        final DataFlavor[] plainFlavors = mxGraphTransferable.plainFlavors;
        for (int i = 0; i < plainFlavors.length; ++i) {
            if (plainFlavors[i].equals(that)) {
                return true;
            }
        }
        return false;
    }
    
    protected boolean isPlainSupported() {
        return false;
    }
    
    protected String getPlainData() {
        return null;
    }
    
    protected boolean isStringFlavor(final DataFlavor that) {
        final DataFlavor[] stringFlavors = mxGraphTransferable.stringFlavors;
        for (int i = 0; i < stringFlavors.length; ++i) {
            if (stringFlavors[i].equals(that)) {
                return true;
            }
        }
        return false;
    }
    
    static {
        try {
            (mxGraphTransferable.htmlFlavors = new DataFlavor[3])[0] = new DataFlavor("text/html;class=java.lang.String");
            mxGraphTransferable.htmlFlavors[1] = new DataFlavor("text/html;class=java.io.Reader");
            mxGraphTransferable.htmlFlavors[2] = new DataFlavor("text/html;charset=unicode;class=java.io.InputStream");
            (mxGraphTransferable.plainFlavors = new DataFlavor[3])[0] = new DataFlavor("text/plain;class=java.lang.String");
            mxGraphTransferable.plainFlavors[1] = new DataFlavor("text/plain;class=java.io.Reader");
            mxGraphTransferable.plainFlavors[2] = new DataFlavor("text/plain;charset=unicode;class=java.io.InputStream");
            (mxGraphTransferable.stringFlavors = new DataFlavor[2])[0] = new DataFlavor("application/x-java-jvm-local-objectref;class=java.lang.String");
            mxGraphTransferable.stringFlavors[1] = DataFlavor.stringFlavor;
            (mxGraphTransferable.imageFlavors = new DataFlavor[2])[0] = DataFlavor.imageFlavor;
            mxGraphTransferable.imageFlavors[1] = new DataFlavor("image/bmp");
        }
        catch (ClassNotFoundException ex) {
            System.err.println("error initializing javax.swing.plaf.basic.BasicTranserable");
        }
        try {
            mxGraphTransferable.dataFlavor = new DataFlavor("application/x-java-jvm-local-objectref; class=com.mxgraph.swing.util.mxGraphTransferable");
        }
        catch (ClassNotFoundException ex2) {}
    }
}
