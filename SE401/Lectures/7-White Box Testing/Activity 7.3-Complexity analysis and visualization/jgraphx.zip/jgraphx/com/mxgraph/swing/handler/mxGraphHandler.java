// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import java.awt.AWTEvent;
import java.util.ArrayList;
import com.mxgraph.view.mxCellState;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.geom.Point2D;
import com.mxgraph.util.mxPoint;
import java.awt.Rectangle;
import javax.swing.SwingUtilities;
import java.util.Collection;
import java.util.Arrays;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetDragEvent;
import java.util.Iterator;
import java.awt.image.BufferedImage;
import java.awt.Image;
import com.mxgraph.swing.view.mxGraphComponentCellRenderer;
import java.awt.image.ImageObserver;
import java.awt.Graphics;
import javax.swing.JPanel;
import java.awt.dnd.DropTarget;
import java.util.TooManyListenersException;
import java.awt.dnd.DragSourceListener;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceAdapter;
import com.mxgraph.util.mxConstants;
import com.mxgraph.swing.util.mxGraphTransferable;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import com.mxgraph.view.mxSelectionModel;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import java.awt.Component;
import com.mxgraph.view.mxGraph;
import javax.swing.TransferHandler;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.util.LinkedHashMap;
import com.mxgraph.util.mxEventSource;
import com.mxgraph.util.mxRectangle;
import java.awt.Point;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import java.util.Map;
import com.mxgraph.swing.mxGraphComponent;
import java.awt.Cursor;
import java.awt.dnd.DropTargetListener;
import com.mxgraph.swing.util.mxMouseControl;

public class mxGraphHandler extends mxMouseControl implements DropTargetListener
{
    public static Cursor DEFAULT_CURSOR;
    public static int DEFAULT_MAX_HANDLES;
    protected mxGraphComponent graphComponent;
    protected boolean cloneEnabled;
    protected boolean imagePreview;
    protected int maxHandles;
    protected boolean centerPreview;
    protected boolean keepOnTop;
    protected transient Map handlers;
    protected transient Object[] cells;
    protected transient JComponent preview;
    protected transient ImageIcon dragImage;
    protected transient Point start;
    protected transient Object cell;
    protected transient Object initialCell;
    protected transient Object[] dragCells;
    protected transient mxCellMarker marker;
    protected transient boolean canImport;
    protected transient mxRectangle cellBounds;
    protected transient mxRectangle bbox;
    protected transient mxRectangle previewBounds;
    protected transient mxRectangle previewBbox;
    protected transient mxRectangle transferBounds;
    private transient boolean gridEnabledEvent;
    protected transient boolean constrainedEvent;
    protected transient mxEventSource.mxEventListener refreshHandler;
    
    public mxGraphHandler(final mxGraphComponent graphComponent) {
        this.cloneEnabled = true;
        this.imagePreview = true;
        this.maxHandles = mxGraphHandler.DEFAULT_MAX_HANDLES;
        this.centerPreview = true;
        this.keepOnTop = true;
        this.handlers = new LinkedHashMap();
        this.cells = null;
        this.gridEnabledEvent = false;
        this.constrainedEvent = false;
        this.refreshHandler = new mxEventSource.mxEventListener() {
            public void invoke(final Object o, final Object[] array) {
                mxGraphHandler.this.refresh();
            }
        };
        this.graphComponent = graphComponent;
        (this.marker = new mxCellMarker(graphComponent, Color.BLUE) {
            @Override
            public boolean isEnabled() {
                return this.graphComponent.getGraph().isDropEnabled();
            }
            
            public Object getCell(final MouseEvent mouseEvent) {
                final TransferHandler transferHandler = this.graphComponent.getTransferHandler();
                final boolean b = transferHandler instanceof mxGraphTransferHandler && ((mxGraphTransferHandler)transferHandler).isLocalDrag();
                final Object cell = super.getCell(mouseEvent);
                final Object[] array = b ? mxGraphHandler.this.handlers.keySet().toArray() : mxGraphHandler.this.dragCells;
                final mxGraph graph = this.graphComponent.getGraph();
                Object dropTarget = graph.getDropTarget(array, mouseEvent.getPoint(), cell);
                final boolean b2 = mouseEvent.isControlDown() && mxGraphHandler.this.cloneEnabled;
                if (b && dropTarget != null && array.length > 0 && !b2 && (mxGraphHandler.this.handlers.keySet().contains(dropTarget) || graph.getModel().getParent(array[0]) == dropTarget)) {
                    dropTarget = null;
                }
                return dropTarget;
            }
        }).setSwimlaneContentEnabled(true);
        graphComponent.getControl().add(this, 0);
        graphComponent.getControl().addMouseListener(this);
        graphComponent.getControl().addMouseMotionListener(this);
        final MouseRedirector mouseRedirector = new MouseRedirector();
        this.addMouseMotionListener(mouseRedirector);
        this.addMouseListener(mouseRedirector);
        graphComponent.getGraph().getSelection().addListener(mxSelectionModel.EVENT_CHANGE, this.refreshHandler);
        graphComponent.getGraph().addListener(mxGraph.EVENT_REPAINT, this.refreshHandler);
        graphComponent.getGraph().addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(final PropertyChangeEvent propertyChangeEvent) {
                if (propertyChangeEvent.getPropertyName().equals("vertexLabelsMovable") || propertyChangeEvent.getPropertyName().equals("edgeLabelsMovable")) {
                    mxGraphHandler.this.refresh();
                }
            }
        });
        new DragSource().createDefaultDragGestureRecognizer(graphComponent.getControl(), 3, new DragGestureListener() {
            public void dragGestureRecognized(final DragGestureEvent dragGestureEvent) {
                if (graphComponent.isDragEnabled() && mxGraphHandler.this.preview != null && mxGraphHandler.this.start != null) {
                    final TransferHandler transferHandler = graphComponent.getTransferHandler();
                    if (transferHandler instanceof mxGraphTransferHandler) {
                        final mxGraphTransferable transferable = (mxGraphTransferable)((mxGraphTransferHandler)transferHandler).createTransferable(graphComponent);
                        if (transferable != null) {
                            dragGestureEvent.startDrag(null, mxConstants.EMPTY_IMAGE, new Point(), transferable, new DragSourceAdapter() {
                                @Override
                                public void dragDropEnd(final DragSourceDropEvent dragSourceDropEvent) {
                                    ((mxGraphTransferHandler)transferHandler).exportDone(graphComponent, transferable, 0);
                                }
                            });
                        }
                    }
                }
            }
        });
        final DropTarget dropTarget = graphComponent.getDropTarget();
        try {
            if (dropTarget != null) {
                dropTarget.addDropTargetListener(this);
            }
        }
        catch (TooManyListenersException ex) {}
        this.setVisible(false);
    }
    
    public void setKeepOnTop(final boolean keepOnTop) {
        this.keepOnTop = keepOnTop;
    }
    
    public boolean isKeepOnTop() {
        return this.keepOnTop;
    }
    
    public void setCloneEnabled(final boolean cloneEnabled) {
        this.cloneEnabled = cloneEnabled;
    }
    
    public boolean isCloneEnabled() {
        return this.cloneEnabled;
    }
    
    public void setImagePreview(final boolean imagePreview) {
        this.imagePreview = imagePreview;
    }
    
    public boolean isImagePreview() {
        return this.imagePreview;
    }
    
    public void setCenterPreview(final boolean centerPreview) {
        this.centerPreview = centerPreview;
    }
    
    public boolean isCenterPreview() {
        return this.centerPreview;
    }
    
    public int getMaxHandles() {
        return this.maxHandles;
    }
    
    public void setMaxHandles(final int maxHandles) {
        this.maxHandles = maxHandles;
    }
    
    protected void createPreview() {
        if (this.preview == null) {
            (this.preview = new JPanel() {
                @Override
                public void paint(final Graphics g) {
                    if (mxGraphHandler.this.dragImage != null) {
                        g.drawImage(mxGraphHandler.this.dragImage.getImage(), 0, 0, mxGraphHandler.this.dragImage.getIconWidth(), mxGraphHandler.this.dragImage.getIconHeight(), this);
                    }
                    else if (!mxGraphHandler.this.imagePreview) {
                        super.paint(g);
                    }
                }
            }).setOpaque(false);
            this.preview.setVisible(false);
            this.preview.setBorder(mxConstants.PREVIEW_BORDER);
            this.graphComponent.getControl().add(this.preview, 0);
        }
    }
    
    public void updateDragImage(final Object[] array) {
        final BufferedImage render = mxGraphComponentCellRenderer.render(this.graphComponent, this.graphComponent.getGraph().getView().getScale(), null, array);
        if (render != null) {
            this.dragImage = new ImageIcon(render);
            this.preview.setSize(this.dragImage.getIconWidth(), this.dragImage.getIconHeight());
            this.preview.getParent().setComponentZOrder(this.preview, 0);
        }
    }
    
    protected void destroyPreview() {
        if (this.preview != null) {
            this.preview.setVisible(false);
            this.preview.getParent().remove(this.preview);
            this.dragImage = null;
            this.preview = null;
        }
        this.marker.reset();
    }
    
    @Override
    public void mouseMoved(final MouseEvent mouseEvent) {
        if (this.graphComponent.isEnabled() && this.isEnabled()) {
            final Iterator<mxCellHandler> iterator = this.handlers.values().iterator();
            while (iterator.hasNext() && !mouseEvent.isConsumed()) {
                iterator.next().mouseMoved(mouseEvent);
            }
            if (!mouseEvent.isConsumed()) {
                this.graphComponent.getControl().setCursor(this.getCursor(mouseEvent));
                mouseEvent.consume();
            }
        }
    }
    
    protected Cursor getCursor(final MouseEvent mouseEvent) {
        final Object cell = this.graphComponent.getGraph().getCellAt(mouseEvent.getX(), mouseEvent.getY(), false);
        Cursor default_CURSOR = null;
        if (cell != null) {
            if (this.graphComponent.isFoldingEnabled() && this.graphComponent.hitsFoldingIcon(cell, mouseEvent.getX(), mouseEvent.getY())) {
                default_CURSOR = new Cursor(12);
            }
            else if (this.graphComponent.getGraph().isMovable(cell)) {
                default_CURSOR = mxGraphHandler.DEFAULT_CURSOR;
            }
        }
        return default_CURSOR;
    }
    
    public void dragEnter(final DropTargetDragEvent dropTargetDragEvent) {
        final JComponent dropTarget = getDropTarget(dropTargetDragEvent);
        final TransferHandler transferHandler = dropTarget.getTransferHandler();
        final boolean b = transferHandler instanceof mxGraphTransferHandler && ((mxGraphTransferHandler)transferHandler).isLocalDrag();
        if (b) {
            this.canImport = true;
        }
        else {
            this.canImport = (this.graphComponent.isDropEnabled() && transferHandler.canImport(dropTarget, dropTargetDragEvent.getCurrentDataFlavors()));
        }
        if (this.canImport) {
            dropTargetDragEvent.acceptDrag(3);
            this.transferBounds = null;
            this.createPreview();
            try {
                final Transferable transferable = dropTargetDragEvent.getTransferable();
                if (transferable.isDataFlavorSupported(mxGraphTransferable.dataFlavor)) {
                    final mxGraphTransferable mxGraphTransferable = (mxGraphTransferable)transferable.getTransferData(com.mxgraph.swing.util.mxGraphTransferable.dataFlavor);
                    this.dragCells = mxGraphTransferable.getCells();
                    if (mxGraphTransferable.getBounds() != null) {
                        final double scale = this.graphComponent.getGraph().getView().getScale();
                        this.transferBounds = mxGraphTransferable.getBounds();
                        final mxRectangle mxRectangle = new mxRectangle(this.transferBounds);
                        mxRectangle.setWidth(mxRectangle.getWidth() * scale);
                        mxRectangle.setHeight(mxRectangle.getHeight() * scale);
                        this.preview.setBounds(mxRectangle.getRectangle());
                        if (this.imagePreview) {
                            if (b) {
                                this.updateDragImage(this.getMovableCells(Arrays.asList(this.dragCells)).toArray());
                            }
                            else {
                                this.updateDragImage(this.dragCells);
                            }
                        }
                        this.preview.setVisible(true);
                    }
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        else {
            dropTargetDragEvent.rejectDrag();
        }
    }
    
    @Override
    public String getToolTipText(final MouseEvent sourceEvent) {
        return this.graphComponent.getControl().getToolTipText(SwingUtilities.convertMouseEvent(sourceEvent.getComponent(), sourceEvent, this.graphComponent.getControl()));
    }
    
    public String getHandleToolTipText(final MouseEvent mouseEvent) {
        String toolTipText = null;
        for (Iterator<mxCellHandler> iterator = this.handlers.values().iterator(); iterator.hasNext() && toolTipText == null; toolTipText = iterator.next().getToolTipText(mouseEvent)) {}
        return toolTipText;
    }
    
    public void dispatchMousePressed(final MouseEvent mouseEvent) {
        final Iterator<mxCellHandler> iterator = this.handlers.values().iterator();
        while (iterator.hasNext() && !mouseEvent.isConsumed()) {
            iterator.next().mousePressed(mouseEvent);
        }
    }
    
    @Override
    public void mousePressed(final MouseEvent mouseEvent) {
        if (this.graphComponent.isEnabled() && this.isEnabled() && !mouseEvent.isConsumed()) {
            final mxGraph graph = this.graphComponent.getGraph();
            this.cell = graph.getCellAt(mouseEvent.getX(), mouseEvent.getY(), false);
            this.initialCell = this.cell;
            if (this.cell != null) {
                if (!graph.isSelected(this.cell) && !this.graphComponent.isToggleEvent(mouseEvent)) {
                    this.graphComponent.selectCellForEvent(this.cell, mouseEvent);
                    this.cell = null;
                }
                if (!mouseEvent.isPopupTrigger()) {
                    this.start(mouseEvent);
                    mouseEvent.consume();
                }
            }
            else if (mouseEvent.isPopupTrigger()) {
                this.graphComponent.getGraph().clearSelection();
            }
        }
    }
    
    public void start(final MouseEvent mouseEvent) {
        this.start = mouseEvent.getPoint();
        this.createPreview();
        final Rectangle bounds = this.getBounds();
        bounds.grow(-5, -5);
        this.preview.setBounds(bounds);
    }
    
    public void dropActionChanged(final DropTargetDragEvent dropTargetDragEvent) {
    }
    
    public void dragOver(final DropTargetDragEvent dropTargetDragEvent) {
        if (this.canImport) {
            this.mouseDragged(this.createEvent(dropTargetDragEvent));
            final mxGraphTransferHandler graphTransferHandler = getGraphTransferHandler(dropTargetDragEvent);
            if (graphTransferHandler != null) {
                final double scale = this.graphComponent.getGraph().getView().getScale();
                final Point convertPoint = SwingUtilities.convertPoint(this.graphComponent, dropTargetDragEvent.getLocation(), this.graphComponent.getControl());
                if (this.centerPreview && this.transferBounds != null) {
                    final Point point = convertPoint;
                    point.x -= (int)Math.round(this.transferBounds.getWidth() * scale / 2.0);
                    final Point point2 = convertPoint;
                    point2.y -= (int)Math.round(this.transferBounds.getHeight() * scale / 2.0);
                }
                final Point point3 = this.graphComponent.snapScaledPoint(new mxPoint(convertPoint)).getPoint();
                graphTransferHandler.setLocation(new Point(point3));
                if (this.transferBounds != null && this.dragImage != null) {
                    point3.translate(-(int)Math.round((this.dragImage.getIconWidth() - 2 - this.transferBounds.getWidth() * scale) / 2.0), -(int)Math.round((this.dragImage.getIconHeight() - 2 - this.transferBounds.getHeight() * scale) / 2.0));
                }
                if (!graphTransferHandler.isLocalDrag()) {
                    this.preview.setLocation(point3.x, point3.y);
                }
            }
        }
        else {
            dropTargetDragEvent.rejectDrag();
        }
    }
    
    public Point convertPoint(Point aPoint) {
        final Point convertPoint;
        aPoint = (convertPoint = SwingUtilities.convertPoint(this.graphComponent, aPoint, this.graphComponent.getControl()));
        convertPoint.x -= this.graphComponent.getHorizontalScrollBar().getValue();
        final Point point = aPoint;
        point.y -= this.graphComponent.getVerticalScrollBar().getValue();
        return aPoint;
    }
    
    @Override
    public void mouseDragged(MouseEvent mouseEvent) {
        this.graphComponent.getControl().scrollRectToVisible(new Rectangle(mouseEvent.getPoint()));
        final Iterator<mxCellHandler> iterator = this.handlers.values().iterator();
        while (iterator.hasNext() && !mouseEvent.isConsumed()) {
            iterator.next().mouseDragged(mouseEvent);
        }
        if (!mouseEvent.isConsumed() && this.preview != null) {
            this.gridEnabledEvent = this.graphComponent.isGridEnabledEvent(mouseEvent);
            this.constrainedEvent = this.graphComponent.isConstrainedEvent(mouseEvent);
            if (this.constrainedEvent && this.start != null) {
                int x = mouseEvent.getX();
                int y = mouseEvent.getY();
                if (Math.abs(mouseEvent.getX() - this.start.x) > Math.abs(mouseEvent.getY() - this.start.y)) {
                    y = this.start.y;
                }
                else {
                    x = this.start.x;
                }
                mouseEvent = new MouseEvent(mouseEvent.getComponent(), mouseEvent.getID(), mouseEvent.getWhen(), mouseEvent.getModifiers(), x, y, mouseEvent.getClickCount(), mouseEvent.isPopupTrigger(), mouseEvent.getButton());
            }
            if (this.preview.isVisible()) {
                this.marker.process(mouseEvent);
            }
            else if (this.cell != null && !this.graphComponent.getGraph().isSelected(this.cell) && this.graphComponent.isToggleEvent(mouseEvent)) {
                this.graphComponent.selectCellForEvent(this.cell, mouseEvent);
                this.cell = null;
            }
            if (this.start != null) {
                final double n = mouseEvent.getX() - this.start.x;
                final double n2 = mouseEvent.getY() - this.start.y;
                this.preview.setLocation(this.getPreviewLocation(mouseEvent, this.gridEnabledEvent));
                if (!this.preview.isVisible() && this.graphComponent.isSignificant(n, n2)) {
                    if (this.imagePreview && this.dragImage == null && !this.graphComponent.isDragEnabled()) {
                        this.updateDragImage(this.cells);
                    }
                    this.preview.setVisible(true);
                }
                mouseEvent.consume();
            }
        }
    }
    
    protected Point getPreviewLocation(final MouseEvent mouseEvent, final boolean b) {
        int x = 0;
        int y = 0;
        if (this.start != null && this.previewBounds != null) {
            final mxGraph graph = this.graphComponent.getGraph();
            final double scale = graph.getView().getScale();
            final mxPoint translate = graph.getView().getTranslate();
            final double n = mouseEvent.getX() - this.start.x;
            final double n2 = mouseEvent.getY() - this.start.y;
            double snap = (this.previewBounds.getX() + n) / scale - translate.getX();
            double snap2 = (this.previewBounds.getY() + n2) / scale - translate.getY();
            if (this.gridEnabledEvent) {
                snap = graph.snap(snap);
                snap2 = graph.snap(snap2);
            }
            x = (int)Math.round((snap + translate.getX()) * scale) + (int)Math.round(this.previewBbox.getX()) - (int)Math.round(this.previewBounds.getX());
            y = (int)Math.round((snap2 + translate.getY()) * scale) + (int)Math.round(this.previewBbox.getY()) - (int)Math.round(this.previewBounds.getY());
        }
        return new Point(x, y);
    }
    
    public void dragExit(final DropTargetEvent dropTargetEvent) {
        final mxGraphTransferHandler graphTransferHandler = getGraphTransferHandler(dropTargetEvent);
        if (graphTransferHandler != null) {
            graphTransferHandler.setLocation(null);
        }
        this.dragCells = null;
        this.destroyPreview();
    }
    
    public void drop(final DropTargetDropEvent dropTargetDropEvent) {
        if (this.canImport) {
            final mxGraphTransferHandler graphTransferHandler = getGraphTransferHandler(dropTargetDropEvent);
            final MouseEvent event = this.createEvent(dropTargetDropEvent);
            if (graphTransferHandler != null && !graphTransferHandler.isLocalDrag()) {
                event.consume();
            }
            this.mouseReleased(event);
        }
    }
    
    @Override
    public void mouseReleased(final MouseEvent mouseEvent) {
        if (this.graphComponent.isEnabled() && this.isEnabled()) {
            final mxGraph graph = this.graphComponent.getGraph();
            final Iterator<mxCellHandler> iterator = this.handlers.values().iterator();
            while (iterator.hasNext() && !mouseEvent.isConsumed()) {
                iterator.next().mouseReleased(mouseEvent);
            }
            if (!mouseEvent.isConsumed()) {
                double a = 0.0;
                double a2 = 0.0;
                if (this.start != null && this.cellBounds != null) {
                    final double scale = graph.getView().getScale();
                    final mxPoint translate = graph.getView().getTranslate();
                    final double n = mouseEvent.getX() - this.start.x;
                    final double n2 = mouseEvent.getY() - this.start.y;
                    double snap = (this.cellBounds.getX() + n) / scale - translate.getX();
                    double snap2 = (this.cellBounds.getY() + n2) / scale - translate.getY();
                    if (this.gridEnabledEvent) {
                        snap = graph.snap(snap);
                        snap2 = graph.snap(snap2);
                    }
                    final double n3 = (snap + translate.getX()) * scale + this.bbox.getX() - this.cellBounds.getX();
                    final double n4 = (snap2 + translate.getY()) * scale + this.bbox.getY() - this.cellBounds.getY();
                    a = (double)Math.round((n3 - this.bbox.getX()) / scale);
                    a2 = (double)Math.round((n4 - this.bbox.getY()) / scale);
                }
                if (this.preview != null && this.preview.isVisible()) {
                    if (this.constrainedEvent) {
                        if (Math.abs(a) > Math.abs(a2)) {
                            a2 = 0.0;
                        }
                        else {
                            a = 0.0;
                        }
                    }
                    this.move(this.cells, a, a2, mouseEvent);
                    mouseEvent.consume();
                }
                else if (this.start == null || !this.graphComponent.isSignificant(mouseEvent.getX() - this.start.x, mouseEvent.getY() - this.start.y)) {
                    if (this.cell != null && !mouseEvent.isPopupTrigger() && this.start != null) {
                        this.graphComponent.selectCellForEvent(this.cell, mouseEvent);
                    }
                    if (this.graphComponent.isFoldingEnabled() && this.graphComponent.hitsFoldingIcon(this.initialCell, mouseEvent.getX(), mouseEvent.getY())) {
                        this.fold(this.initialCell);
                    }
                    else {
                        final Object cell = graph.getCellAt(mouseEvent.getX(), mouseEvent.getY(), graph.isSwimlaneSelectionEnabled());
                        if (this.cell == null && this.start == null) {
                            if (cell == null) {
                                graph.clearSelection();
                            }
                            else if (graph.isSwimlane(cell) && this.graphComponent.getGraph().hitsSwimlaneContent(cell, mouseEvent.getX(), mouseEvent.getY())) {
                                this.graphComponent.selectCellForEvent(cell, mouseEvent);
                            }
                        }
                        if (this.graphComponent.isFoldingEnabled() && this.graphComponent.hitsFoldingIcon(cell, mouseEvent.getX(), mouseEvent.getY())) {
                            this.fold(cell);
                            mouseEvent.consume();
                        }
                    }
                }
            }
            this.reset();
        }
    }
    
    protected void fold(final Object o) {
        if (this.graphComponent.getGraph().isCellCollapsed(o)) {
            this.graphComponent.getGraph().expand(new Object[] { o });
        }
        else {
            this.graphComponent.getGraph().collapse(new Object[] { o });
        }
    }
    
    public void reset() {
        final Iterator<mxCellHandler> iterator = this.handlers.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().reset();
        }
        this.destroyPreview();
        this.initialCell = null;
        this.dragCells = null;
        this.start = null;
        this.cell = null;
    }
    
    protected void move(final Object[] array, final double n, final double n2, final MouseEvent mouseEvent) {
        final mxGraph graph = this.graphComponent.getGraph();
        final mxCellState validState = this.marker.getValidState();
        final Object o = (validState != null) ? validState.getCell() : null;
        final boolean b = mouseEvent.isControlDown() && this.cloneEnabled;
        final Object[] move = graph.move(array, n, n2, b, o, mouseEvent.getPoint());
        if (b && move.length == array.length) {
            graph.setSelectionCells(move);
        }
        else {
            this.refresh();
        }
    }
    
    public mxCellHandler getHandler(final Object o) {
        return this.handlers.get(o);
    }
    
    public void refresh() {
        final mxGraph graph = this.graphComponent.getGraph();
        this.handlers.clear();
        final Object[] selectionCells = graph.getSelectionCells();
        final boolean handlesVisible = selectionCells.length <= this.maxHandles;
        for (int i = 0; i < selectionCells.length; ++i) {
            final mxCellState state = graph.getView().getState(selectionCells[i]);
            if (state != null) {
                final mxCellHandler handler = this.graphComponent.createHandler(state);
                handler.setHandlesVisible(handlesVisible);
                if (handler != null) {
                    this.handlers.put(selectionCells[i], handler);
                }
            }
        }
        this.cells = this.getMovableCells(this.handlers.keySet()).toArray();
        this.setVisible(!this.handlers.isEmpty());
        if (this.isVisible()) {
            if (this.keepOnTop) {
                this.getParent().setComponentZOrder(this, 0);
            }
            this.cellBounds = graph.getView().getBounds(selectionCells);
            this.bbox = graph.getView().getBoundingBox(selectionCells);
            this.previewBounds = graph.getView().getBounds(this.cells);
            this.previewBbox = graph.getView().getBoundingBox(this.cells);
            if (this.bbox != null) {
                final Rectangle rectangle = this.bbox.getRectangle();
                final int n = Math.round((float)(mxConstants.HANDLE_SIZE / 2)) + 1;
                rectangle.grow(n, n);
                this.setBounds(rectangle);
            }
            else {
                this.setBounds(this.graphComponent.getViewport().getVisibleRect());
            }
            this.repaint();
        }
    }
    
    protected final Collection getMovableCells(final Collection collection) {
        final mxGraph graph = this.graphComponent.getGraph();
        final Iterator<Object> iterator = collection.iterator();
        final ArrayList<Object> list = new ArrayList<Object>(collection.size());
        while (iterator.hasNext()) {
            final Object next = iterator.next();
            if (graph.isMovable(next)) {
                list.add(next);
            }
        }
        return list;
    }
    
    public void paintComponent(final Graphics g) {
        super.paintComponent(g);
        g.translate(-this.getX(), -this.getY());
        final Iterator<mxCellHandler> iterator = this.handlers.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().paint(g);
        }
        g.translate(this.getX(), this.getY());
    }
    
    protected MouseEvent createEvent(final DropTargetEvent dropTargetEvent) {
        final JComponent dropTarget = getDropTarget(dropTargetEvent);
        Point point = null;
        int n = 0;
        if (dropTargetEvent instanceof DropTargetDropEvent) {
            point = ((DropTargetDropEvent)dropTargetEvent).getLocation();
            n = ((DropTargetDropEvent)dropTargetEvent).getDropAction();
        }
        else if (dropTargetEvent instanceof DropTargetDragEvent) {
            point = ((DropTargetDragEvent)dropTargetEvent).getLocation();
            n = ((DropTargetDragEvent)dropTargetEvent).getDropAction();
        }
        if (point != null) {
            point = this.convertPoint(point);
            final Rectangle viewRect = this.graphComponent.getViewport().getViewRect();
            point.translate(viewRect.x, viewRect.y);
        }
        return new MouseEvent(dropTarget, 0, System.currentTimeMillis(), (n == 1) ? 2 : 0, (int)point.getX(), (int)point.getY(), 1, false, 1);
    }
    
    protected static final mxGraphTransferHandler getGraphTransferHandler(final DropTargetEvent dropTargetEvent) {
        final TransferHandler transferHandler = getDropTarget(dropTargetEvent).getTransferHandler();
        if (transferHandler instanceof mxGraphTransferHandler) {
            return (mxGraphTransferHandler)transferHandler;
        }
        return null;
    }
    
    protected static final JComponent getDropTarget(final DropTargetEvent dropTargetEvent) {
        return (JComponent)dropTargetEvent.getDropTargetContext().getComponent();
    }
    
    static {
        mxGraphHandler.DEFAULT_CURSOR = new Cursor(13);
        mxGraphHandler.DEFAULT_MAX_HANDLES = 100;
    }
    
    public class MouseRedirector implements MouseListener, MouseMotionListener
    {
        public void mouseClicked(final MouseEvent sourceEvent) {
            mxGraphHandler.this.graphComponent.getControl().dispatchEvent(SwingUtilities.convertMouseEvent(sourceEvent.getComponent(), sourceEvent, mxGraphHandler.this.graphComponent.getControl()));
        }
        
        public void mouseEntered(final MouseEvent mouseEvent) {
        }
        
        public void mouseExited(final MouseEvent mouseEvent) {
            this.mouseClicked(mouseEvent);
        }
        
        public void mousePressed(final MouseEvent mouseEvent) {
            this.mouseClicked(mouseEvent);
        }
        
        public void mouseReleased(final MouseEvent mouseEvent) {
            this.mouseClicked(mouseEvent);
        }
        
        public void mouseDragged(final MouseEvent mouseEvent) {
            this.mouseClicked(mouseEvent);
        }
        
        public void mouseMoved(final MouseEvent mouseEvent) {
            this.mouseClicked(mouseEvent);
        }
    }
}
