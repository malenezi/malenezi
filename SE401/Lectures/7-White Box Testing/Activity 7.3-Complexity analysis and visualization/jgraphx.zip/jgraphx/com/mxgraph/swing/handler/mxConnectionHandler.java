// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import java.awt.image.ImageObserver;
import javax.swing.JOptionPane;
import com.mxgraph.view.mxPerimeter;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import com.mxgraph.util.mxPoint;
import com.mxgraph.model.mxIGraphModel;
import com.mxgraph.view.mxGraph;
import com.mxgraph.model.mxGeometry;
import java.awt.Color;
import java.awt.event.MouseEvent;
import com.mxgraph.view.mxGraphView;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.Graphics;
import com.mxgraph.util.mxConstants;
import com.mxgraph.util.mxEventSource;
import javax.swing.JPanel;
import com.mxgraph.view.mxCellState;
import java.awt.Point;
import javax.swing.ImageIcon;
import com.mxgraph.swing.mxGraphComponent;
import java.awt.Cursor;
import com.mxgraph.swing.util.mxMouseControl;

public class mxConnectionHandler extends mxMouseControl
{
    public static Cursor DEFAULT_CURSOR;
    protected mxGraphComponent graphComponent;
    protected ImageIcon connectIcon;
    protected int handleSize;
    protected boolean handleEnabled;
    protected boolean select;
    protected boolean createTarget;
    protected boolean keepOnTop;
    protected transient Point start;
    protected transient Point current;
    protected transient mxCellState source;
    protected transient mxCellMarker marker;
    protected transient String error;
    protected transient JPanel preview;
    protected transient mxEventSource.mxEventListener resetHandler;
    
    public mxConnectionHandler(final mxGraphComponent graphComponent) {
        this.connectIcon = null;
        this.handleSize = mxConstants.CONNECT_HANDLE_SIZE;
        this.handleEnabled = mxConstants.CONNECT_HANDLE_ENABLED;
        this.select = true;
        this.createTarget = false;
        this.keepOnTop = true;
        this.preview = new JPanel() {
            @Override
            public void paint(final Graphics g) {
                super.paint(g);
                ((Graphics2D)g).setStroke(mxConstants.PREVIEW_STROKE);
                if (mxConnectionHandler.this.start != null && mxConnectionHandler.this.current != null) {
                    if (mxConnectionHandler.this.marker.hasValidState() || mxConnectionHandler.this.createTarget || mxConnectionHandler.this.graphComponent.getGraph().isAllowDanglingEdges()) {
                        g.setColor(mxConstants.DEFAULT_VALID_COLOR);
                    }
                    else {
                        g.setColor(mxConstants.DEFAULT_INVALID_COLOR);
                    }
                    g.drawLine(mxConnectionHandler.this.start.x - this.getX(), mxConnectionHandler.this.start.y - this.getY(), mxConnectionHandler.this.current.x - this.getX(), mxConnectionHandler.this.current.y - this.getY());
                }
            }
        };
        this.resetHandler = new mxEventSource.mxEventListener() {
            public void invoke(final Object o, final Object[] array) {
                mxConnectionHandler.this.reset();
            }
        };
        this.graphComponent = graphComponent;
        final mxGraphComponent.mxGraphControl control = graphComponent.getControl();
        control.add(this, 0);
        control.addMouseListener(this);
        control.addMouseMotionListener(this);
        final mxGraphView view = graphComponent.getGraph().getView();
        view.addListener(mxGraphView.EVENT_SCALE, this.resetHandler);
        view.addListener(mxGraphView.EVENT_TRANSLATE, this.resetHandler);
        view.addListener(mxGraphView.EVENT_SCALE_AND_TRANSLATE, this.resetHandler);
        graphComponent.getGraph().getModel().addListener("change", this.resetHandler);
        (this.marker = new mxCellMarker(graphComponent) {
            @Override
            protected Object getCell(final MouseEvent mouseEvent) {
                Object cell = super.getCell(mouseEvent);
                if (mxConnectionHandler.this.isConnecting()) {
                    if (mxConnectionHandler.this.source != null) {
                        mxConnectionHandler.this.error = mxConnectionHandler.this.validateConnection(mxConnectionHandler.this.source.getCell(), cell);
                        if (mxConnectionHandler.this.error != null && mxConnectionHandler.this.error.length() == 0) {
                            cell = null;
                            if (mxConnectionHandler.this.createTarget) {
                                mxConnectionHandler.this.error = null;
                            }
                        }
                    }
                }
                else if (!mxConnectionHandler.this.isValidSource(cell)) {
                    cell = null;
                }
                return cell;
            }
            
            @Override
            protected boolean isValidState(final mxCellState mxCellState) {
                if (mxConnectionHandler.this.isConnecting()) {
                    return mxConnectionHandler.this.error == null;
                }
                return super.isValidState(mxCellState);
            }
            
            @Override
            protected Color getMarkerColor(final MouseEvent mouseEvent, final mxCellState mxCellState, final boolean b) {
                return (mxConnectionHandler.this.isHighlighting() || mxConnectionHandler.this.isConnecting()) ? super.getMarkerColor(mouseEvent, mxCellState, b) : null;
            }
            
            @Override
            protected boolean intersects(final mxCellState mxCellState, final MouseEvent mouseEvent) {
                return !mxConnectionHandler.this.isHighlighting() || mxConnectionHandler.this.isConnecting() || super.intersects(mxCellState, mouseEvent);
            }
        }).setHotspotEnabled(true);
        this.setCursor(mxConnectionHandler.DEFAULT_CURSOR);
    }
    
    public boolean isConnecting() {
        return this.start != null && this.preview != null && this.preview.isVisible();
    }
    
    public boolean isHighlighting() {
        return this.connectIcon == null && !this.handleEnabled;
    }
    
    public boolean isKeepOnTop() {
        return this.keepOnTop;
    }
    
    public void setKeepOnTop(final boolean keepOnTop) {
        this.keepOnTop = keepOnTop;
    }
    
    public void setConnectIcon(final ImageIcon connectIcon) {
        this.connectIcon = connectIcon;
    }
    
    public ImageIcon getConnecIcon() {
        return this.connectIcon;
    }
    
    public void setHandleEnabled(final boolean handleEnabled) {
        this.handleEnabled = handleEnabled;
    }
    
    public boolean isHandleEnabled() {
        return this.handleEnabled;
    }
    
    public void setHandleSize(final int handleSize) {
        this.handleSize = handleSize;
    }
    
    public int getHandleSize() {
        return this.handleSize;
    }
    
    public mxCellMarker getMarker() {
        return this.marker;
    }
    
    public void setMarker(final mxCellMarker marker) {
        this.marker = marker;
    }
    
    public void setCreateTarget(final boolean createTarget) {
        this.createTarget = createTarget;
    }
    
    public boolean isCreateTarget() {
        return this.createTarget;
    }
    
    public void setSelect(final boolean select) {
        this.select = select;
    }
    
    public boolean isSelect() {
        return this.select;
    }
    
    public void reset() {
        if (this.preview.getParent() != null) {
            this.preview.setVisible(false);
            this.preview.getParent().remove(this.preview);
        }
        this.setVisible(false);
        this.marker.reset();
        this.source = null;
        this.start = null;
        this.error = null;
    }
    
    protected void connect(final Object o, Object targetVertex, final MouseEvent mouseEvent) {
        final mxGraph graph = this.graphComponent.getGraph();
        final mxIGraphModel model = graph.getModel();
        Object o2 = null;
        Object insertEdge = null;
        if (targetVertex == null && this.createTarget) {
            o2 = (targetVertex = this.createTargetVertex(mouseEvent, o));
        }
        if (targetVertex != null || graph.isAllowDanglingEdges()) {
            model.beginUpdate();
            try {
                Object o3 = graph.getDropTarget(new Object[] { o2 }, mouseEvent.getPoint(), graph.getCellAt(mouseEvent.getX(), mouseEvent.getY()));
                if (o2 != null) {
                    if (o3 == null || !graph.getModel().isEdge(o3)) {
                        final mxCellState state = graph.getView().getState(o3);
                        if (state != null) {
                            final mxGeometry geometry = model.getGeometry(o2);
                            final mxPoint origin = state.getOrigin();
                            geometry.setX(geometry.getX() - origin.getX());
                            geometry.setY(geometry.getY() - origin.getY());
                        }
                    }
                    else {
                        o3 = graph.getDefaultParent();
                    }
                    graph.addCell(o2, o3);
                }
                Object o4 = graph.getDefaultParent();
                if (model.getParent(o) == model.getParent(targetVertex)) {
                    o4 = model.getParent(o);
                }
                insertEdge = this.insertEdge(o4, null, "", o, targetVertex);
                if (insertEdge != null) {
                    mxGeometry geometry2 = model.getGeometry(insertEdge);
                    if (geometry2 == null) {
                        geometry2 = new mxGeometry();
                        geometry2.setRelative(true);
                        model.setGeometry(insertEdge, geometry2);
                    }
                    if (targetVertex == null) {
                        geometry2.setTerminalPoint(this.graphComponent.getPointForEvent(mouseEvent), false);
                    }
                }
            }
            finally {
                model.endUpdate();
            }
        }
        if (this.select) {
            graph.setSelectionCell(insertEdge);
        }
    }
    
    protected Object insertEdge(final Object o, final String s, final Object o2, final Object o3, final Object o4) {
        return this.graphComponent.getGraph().insertEdge(o, s, o2, o3, o4);
    }
    
    public Object createTargetVertex(final MouseEvent mouseEvent, final Object o) {
        final mxGraph graph = this.graphComponent.getGraph();
        final Object o2 = graph.cloneCells(new Object[] { o })[0];
        final mxGeometry geometry = graph.getModel().getGeometry(o2);
        if (geometry != null) {
            final mxPoint pointForEvent = this.graphComponent.getPointForEvent(mouseEvent);
            geometry.setX(graph.snap(pointForEvent.getX() - geometry.getWidth() / 2.0));
            geometry.setY(graph.snap(pointForEvent.getY() - geometry.getHeight() / 2.0));
        }
        return o2;
    }
    
    public boolean isValidSource(final Object o) {
        return this.graphComponent.getGraph().isValidSource(o);
    }
    
    public boolean isValidTarget(final Object o) {
        return true;
    }
    
    public String validateConnection(final Object o, final Object o2) {
        if (o2 == null && this.createTarget) {
            return null;
        }
        if (!this.isValidTarget(o2)) {
            return "";
        }
        return this.graphComponent.getGraph().getEdgeValidationError(null, o, o2);
    }
    
    @Override
    public void mousePressed(final MouseEvent mouseEvent) {
        if (!this.keepOnTop) {
            this.graphComponent.getGraphHandler().dispatchMousePressed(mouseEvent);
        }
        if (!mouseEvent.isConsumed() && this.source != null && !mouseEvent.isPopupTrigger() && ((this.isHighlighting() && this.marker.hasValidState()) || (!this.isHighlighting() && this.getBounds().contains(mouseEvent.getPoint())))) {
            this.start = mouseEvent.getPoint();
            this.preview.setOpaque(false);
            this.preview.setVisible(false);
            this.graphComponent.getControl().add(this.preview, 0);
            this.getParent().setComponentZOrder(this, 0);
            this.graphComponent.getControl().setCursor(mxConnectionHandler.DEFAULT_CURSOR);
            this.marker.reset();
            mouseEvent.consume();
        }
        if (this.keepOnTop) {
            this.graphComponent.getGraphHandler().dispatchMousePressed(mouseEvent);
        }
    }
    
    @Override
    public void mouseDragged(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.source != null && this.start != null) {
            final int n = mouseEvent.getX() - this.start.x;
            final int n2 = mouseEvent.getY() - this.start.y;
            if (!this.preview.isVisible() && this.graphComponent.isSignificant(n, n2)) {
                this.preview.setVisible(true);
                this.marker.reset();
            }
            this.current = mouseEvent.getPoint();
            final mxGraph graph = this.graphComponent.getGraph();
            final mxGraphView view = graph.getView();
            final double scale = view.getScale();
            final mxPoint translate = view.getTranslate();
            this.current.x = (int)Math.round((graph.snap(this.current.x / scale - translate.getX()) + translate.getX()) * scale);
            this.current.y = (int)Math.round((graph.snap(this.current.y / scale - translate.getY()) + translate.getY()) * scale);
            this.marker.process(mouseEvent);
            final mxCellState validState = this.marker.getValidState();
            if (validState != null) {
                this.current.x = (int)validState.getCenterX();
                this.current.y = (int)validState.getCenterY();
                final mxPerimeter.mxPerimeterFunction perimeterFunction = view.getPerimeterFunction(validState);
                if (perimeterFunction != null) {
                    final mxPoint apply = perimeterFunction.apply(view.getPerimeterBounds(validState, null, false), null, validState, false, new mxPoint(this.source.getCenterX(), this.source.getCenterY()));
                    if (apply != null) {
                        this.current = apply.getPoint();
                    }
                }
            }
            final mxPerimeter.mxPerimeterFunction perimeterFunction2 = view.getPerimeterFunction(this.source);
            if (perimeterFunction2 != null) {
                final mxPoint apply2 = perimeterFunction2.apply(view.getPerimeterBounds(this.source, null, true), null, this.source, true, new mxPoint(this.current));
                if (apply2 != null) {
                    this.start = apply2.getPoint();
                }
            }
            else {
                this.start = new Point((int)Math.round(this.source.getCenterX()), (int)Math.round(this.source.getCenterY()));
            }
            this.setVisible(false);
            final Rectangle bounds = new Rectangle(this.current);
            bounds.add(this.start);
            bounds.grow(1, 1);
            this.preview.setBounds(bounds);
            mouseEvent.consume();
        }
    }
    
    @Override
    public void mouseReleased(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.isConnecting()) {
            if (this.error != null) {
                if (this.error.length() > 0) {
                    JOptionPane.showMessageDialog(this.graphComponent, this.error);
                }
            }
            else {
                this.connect(this.source.getCell(), this.marker.hasValidState() ? this.marker.getValidState().getCell() : null, mouseEvent);
            }
            mouseEvent.consume();
        }
        else if (this.source != null) {
            this.graphComponent.selectCellForEvent(this.source.getCell(), mouseEvent);
        }
        this.reset();
    }
    
    @Override
    public void mouseMoved(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.graphComponent.isEnabled() && this.isEnabled()) {
            this.source = this.marker.process(mouseEvent);
            if (this.isHighlighting() && !this.marker.hasValidState()) {
                this.source = null;
            }
            if (this.source != null) {
                if (this.isHighlighting()) {
                    this.setBounds(this.source.getRectangle());
                }
                else {
                    int width = this.handleSize;
                    int height = this.handleSize;
                    if (this.connectIcon != null) {
                        width = this.connectIcon.getIconWidth();
                        height = this.connectIcon.getIconHeight();
                    }
                    this.setBounds((int)this.source.getCenterX() - width / 2, (int)this.source.getCenterY() - height / 2, width, height);
                }
                if (this.keepOnTop) {
                    this.getParent().setComponentZOrder(this, 0);
                }
            }
            this.setVisible(this.source != null);
        }
    }
    
    @Override
    public void paint(final Graphics graphics) {
        if (this.start == null) {
            if (this.connectIcon != null) {
                graphics.drawImage(this.connectIcon.getImage(), 0, 0, this.getWidth(), this.getHeight(), this);
            }
            else if (this.handleEnabled) {
                graphics.setColor(Color.BLACK);
                graphics.draw3DRect(0, 0, this.getWidth() - 1, this.getHeight() - 1, true);
                graphics.setColor(Color.GREEN);
                graphics.fill3DRect(1, 1, this.getWidth() - 2, this.getHeight() - 2, true);
                graphics.setColor(Color.BLUE);
                graphics.drawRect(this.getWidth() / 2 - 1, this.getHeight() / 2 - 1, 1, 1);
            }
        }
    }
    
    static {
        mxConnectionHandler.DEFAULT_CURSOR = new Cursor(12);
    }
}
