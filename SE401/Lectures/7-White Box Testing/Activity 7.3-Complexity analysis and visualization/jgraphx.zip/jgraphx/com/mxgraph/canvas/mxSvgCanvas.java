// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.canvas;

import com.mxgraph.util.mxPoint;
import java.util.List;
import java.util.Map;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxConstants;
import java.util.Hashtable;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Node;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.Color;
import org.w3c.dom.Element;
import org.w3c.dom.Document;

public class mxSvgCanvas implements mxICanvas
{
    public static String DEFAULT_IMAGEBASEPATH;
    public String imageBasePath;
    protected Document document;
    protected Element root;
    protected int x;
    protected int y;
    protected int width;
    protected int height;
    protected double scale;
    
    public mxSvgCanvas(final int n, final int n2, final double n3) {
        this(0, 0, n, n2, n3);
    }
    
    public mxSvgCanvas(final int n, final int n2, final int n3, final int n4, final double n5) {
        this(n, n2, n3, n4, n5, null);
    }
    
    public mxSvgCanvas(final int x, final int y, final int width, final int height, final double scale, final Color color) {
        this.imageBasePath = mxSvgCanvas.DEFAULT_IMAGEBASEPATH;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scale = scale;
        try {
            this.document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            this.root = this.document.createElement("svg");
            final String value = String.valueOf(width + 2);
            final String value2 = String.valueOf(height + 3);
            this.root.setAttribute("width", value);
            this.root.setAttribute("height", value2);
            this.root.setAttribute("viewBox", "0 0 " + value + " " + value2);
            this.root.setAttribute("version", "1.1");
            this.root.setAttribute("xmlns", "http://www.w3.org/2000/svg");
            this.root.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink");
            this.document.appendChild(this.root);
        }
        catch (ParserConfigurationException ex) {}
    }
    
    public Document getDocument() {
        return this.document;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public Object drawVertex(int n, int n2, final int n3, final int n4, final Hashtable t) {
        final int int1 = mxUtils.getInt(t, mxConstants.STYLE_STARTSIZE);
        n -= this.x;
        n2 -= this.y;
        Element element;
        if (int1 == 0) {
            element = this.drawShape(n, n2, n3, n4, t);
        }
        else {
            final int n5 = (int)Math.round(int1 * this.scale);
            final Hashtable hashtable = new Hashtable(t);
            hashtable.remove(mxConstants.STYLE_FILLCOLOR);
            hashtable.remove(mxConstants.STYLE_ROUNDED);
            if (mxUtils.isTrue(t, mxConstants.STYLE_HORIZONTAL, true)) {
                element = this.drawShape(n, n2, n3, n5, t);
                this.drawShape(n, n2 + n5, n3, n4 - n5, hashtable);
            }
            else {
                element = this.drawShape(n, n2, n5, n4, t);
                this.drawShape(n + n5, n2, n3 - n5, n4, hashtable);
            }
        }
        return element;
    }
    
    public Object drawEdge(List translatePoints, final Hashtable hashtable) {
        translatePoints = mxUtils.translatePoints(translatePoints, -this.x, -this.y);
        final Element drawLine = this.drawLine(translatePoints, hashtable);
        final float float1 = mxUtils.getFloat(hashtable, mxConstants.STYLE_OPACITY, 100.0f);
        if (float1 != 100.0f) {
            final String value = String.valueOf(float1 / 100.0f);
            drawLine.setAttribute("fill-opacity", value);
            drawLine.setAttribute("stroke-opacity", value);
        }
        return drawLine;
    }
    
    public Object drawLabel(final String s, int n, int n2, final int n3, final int n4, final Hashtable hashtable, final boolean b) {
        n -= this.x;
        n2 -= this.y;
        return this.drawText(s, n, n2, n3, n4, hashtable);
    }
    
    public String getImageForStyle(final Hashtable hashtable) {
        String str = mxUtils.getString(hashtable, mxConstants.STYLE_IMAGE);
        if (str != null && !str.startsWith("/")) {
            str = this.imageBasePath + str;
        }
        return str;
    }
    
    public Element drawShape(final int i, final int j, final int n, final int n2, final Hashtable hashtable) {
        final String string = mxUtils.getString(hashtable, mxConstants.STYLE_FILLCOLOR, "none");
        mxUtils.getString(hashtable, mxConstants.STYLE_GRADIENTCOLOR);
        final String string2 = mxUtils.getString(hashtable, mxConstants.STYLE_STROKECOLOR);
        final float n3 = (float)(mxUtils.getFloat(hashtable, mxConstants.STYLE_STROKEWIDTH, 1.0f) * this.scale);
        final String string3 = mxUtils.getString(hashtable, mxConstants.STYLE_SHAPE);
        Element element = null;
        Element element2 = null;
        if (string3.equals("image")) {
            final String imageForStyle = this.getImageForStyle(hashtable);
            if (imageForStyle != null) {
                element = this.document.createElement("image");
                element.setAttribute("x", String.valueOf(i));
                element.setAttribute("y", String.valueOf(j));
                element.setAttribute("width", String.valueOf(n));
                element.setAttribute("height", String.valueOf(n2));
                element.setAttributeNS(mxConstants.NS_XLINK, "href", imageForStyle);
            }
        }
        else if (string3.equals("line")) {
            final String string4 = mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, "east");
            String str;
            if (string4.equals("east") || string4.equals("west")) {
                final int n4 = j + n2 / 2;
                str = "M " + i + " " + n4 + " L " + (i + n) + " " + n4;
            }
            else {
                final int n5 = i + n / 2;
                str = "M " + n5 + " " + j + " L " + n5 + " " + (j + n2);
            }
            element = this.document.createElement("path");
            element.setAttribute("d", str + " Z");
        }
        else if (string3.equals("ellipse")) {
            element = this.document.createElement("ellipse");
            element.setAttribute("cx", String.valueOf(i + n / 2));
            element.setAttribute("cy", String.valueOf(j + n2 / 2));
            element.setAttribute("rx", String.valueOf(n / 2));
            element.setAttribute("ry", String.valueOf(n2 / 2));
        }
        else if (string3.equals("doubleEllipse")) {
            element = this.document.createElement("g");
            element2 = this.document.createElement("ellipse");
            element2.setAttribute("cx", String.valueOf(i + n / 2));
            element2.setAttribute("cy", String.valueOf(j + n2 / 2));
            element2.setAttribute("rx", String.valueOf(n / 2));
            element2.setAttribute("ry", String.valueOf(n2 / 2));
            element.appendChild(element2);
            final int n6 = (int)((3.0f + n3) * this.scale);
            final Element element3 = this.document.createElement("ellipse");
            element3.setAttribute("fill", "none");
            element3.setAttribute("stroke", string2);
            element3.setAttribute("stroke-width", String.valueOf(n3));
            element3.setAttribute("cx", String.valueOf(i + n / 2));
            element3.setAttribute("cy", String.valueOf(j + n2 / 2));
            element3.setAttribute("rx", String.valueOf(n / 2 - n6));
            element3.setAttribute("ry", String.valueOf(n2 / 2 - n6));
            element.appendChild(element3);
        }
        else if (string3.equals("rhombus")) {
            element = this.document.createElement("path");
            element.setAttribute("d", "M " + (i + n / 2) + " " + j + " L " + (i + n) + " " + (j + n2 / 2) + " L " + (i + n / 2) + " " + (j + n2) + " L " + i + " " + (j + n2 / 2) + " Z");
        }
        else if (string3.equals("triangle")) {
            element = this.document.createElement("path");
            final String string5 = mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, "");
            String str2;
            if (string5.equals("north")) {
                str2 = "M " + i + " " + (j + n2) + " L " + (i + n / 2) + " " + j + " L " + (i + n) + " " + (j + n2);
            }
            else if (string5.equals("south")) {
                str2 = "M " + i + " " + j + " L " + (i + n / 2) + " " + (j + n2) + " L " + (i + n) + " " + j;
            }
            else if (string5.equals("west")) {
                str2 = "M " + (i + n) + " " + j + " L " + i + " " + (j + n2 / 2) + " L " + (i + n) + " " + (j + n2);
            }
            else {
                str2 = "M " + i + " " + j + " L " + (i + n) + " " + (j + n2 / 2) + " L " + i + " " + (j + n2);
            }
            element.setAttribute("d", str2 + " Z");
        }
        else if (string3.equals("hexagon")) {
            element = this.document.createElement("path");
            final String string6 = mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, "");
            String str3;
            if (string6.equals("north") || string6.equals("south")) {
                str3 = "M " + (i + 0.5 * n) + " " + j + " L " + (i + n) + " " + (j + 0.25 * n2) + " L " + (i + n) + " " + (j + 0.75 * n2) + " L " + (i + 0.5 * n) + " " + (j + n2) + " L " + i + " " + (j + 0.75 * n2) + " L " + i + " " + (j + 0.25 * n2);
            }
            else {
                str3 = "M " + (i + 0.25 * n) + " " + j + " L " + (i + 0.75 * n) + " " + j + " L " + (i + n) + " " + (j + 0.5 * n2) + " L " + (i + 0.75 * n) + " " + (j + n2) + " L " + (i + 0.25 * n) + " " + (j + n2) + " L " + i + " " + (j + 0.5 * n2);
            }
            element.setAttribute("d", str3 + " Z");
        }
        else if (string3.equals("cloud")) {
            element = this.document.createElement("path");
            element.setAttribute("d", "M " + (i + 0.25 * n) + " " + (j + 0.25 * n2) + " C " + (i + 0.05 * n) + " " + (j + 0.25 * n2) + " " + i + " " + (j + 0.5 * n2) + " " + (i + 0.16 * n) + " " + (j + 0.55 * n2) + " C " + i + " " + (j + 0.66 * n2) + " " + (i + 0.18 * n) + " " + (j + 0.9 * n2) + " " + (i + 0.31 * n) + " " + (j + 0.8 * n2) + " C " + (i + 0.4 * n) + " " + (j + n2) + " " + (i + 0.7 * n) + " " + (j + n2) + " " + (i + 0.8 * n) + " " + (j + 0.8 * n2) + " C " + (i + n) + " " + (j + 0.8 * n2) + " " + (i + n) + " " + (j + 0.6 * n2) + " " + (i + 0.875 * n) + " " + (j + 0.5 * n2) + " C " + (i + n) + " " + (j + 0.3 * n2) + " " + (i + 0.8 * n) + " " + (j + 0.1 * n2) + " " + (i + 0.625 * n) + " " + (j + 0.2 * n2) + " C " + (i + 0.5 * n) + " " + (j + 0.05 * n2) + " " + (i + 0.3 * n) + " " + (j + 0.05 * n2) + " " + (i + 0.25 * n) + " " + (j + 0.25 * n2) + " Z");
        }
        else if (string3.equals("actor")) {
            element = this.document.createElement("path");
            final double n7 = n / 3;
            element.setAttribute("d", " M " + i + " " + (j + n2) + " C " + i + " " + (j + 3 * n2 / 5) + " " + i + " " + (j + 2 * n2 / 5) + " " + (i + n / 2) + " " + (j + 2 * n2 / 5) + " C " + (i + n / 2 - n7) + " " + (j + 2 * n2 / 5) + " " + (i + n / 2 - n7) + " " + j + " " + (i + n / 2) + " " + j + " C " + (i + n / 2 + n7) + " " + j + " " + (i + n / 2 + n7) + " " + (j + 2 * n2 / 5) + " " + (i + n / 2) + " " + (j + 2 * n2 / 5) + " C " + (i + n) + " " + (j + 2 * n2 / 5) + " " + (i + n) + " " + (j + 3 * n2 / 5) + " " + (i + n) + " " + (j + n2) + " Z");
        }
        else if (string3.equals("cylinder")) {
            element = this.document.createElement("g");
            element2 = this.document.createElement("path");
            final double min = Math.min(40.0, Math.floor(n2 / 5));
            element2.setAttribute("d", " M " + i + " " + (j + min) + " C " + i + " " + (j - min / 3.0) + " " + (i + n) + " " + (j - min / 3.0) + " " + (i + n) + " " + (j + min) + " L " + (i + n) + " " + (j + n2 - min) + " C " + (i + n) + " " + (j + n2 + min / 3.0) + " " + i + " " + (j + n2 + min / 3.0) + " " + i + " " + (j + n2 - min) + " Z");
            element.appendChild(element2);
            final Element element4 = this.document.createElement("path");
            element4.setAttribute("d", "M " + i + " " + (j + min) + " C " + i + " " + (j + 2.0 * min) + " " + (i + n) + " " + (j + 2.0 * min) + " " + (i + n) + " " + (j + min));
            element4.setAttribute("fill", "none");
            element4.setAttribute("stroke", string2);
            element4.setAttribute("stroke-width", String.valueOf(n3));
            element.appendChild(element4);
        }
        else {
            element = this.document.createElement("rect");
            element.setAttribute("x", String.valueOf(i));
            element.setAttribute("y", String.valueOf(j));
            element.setAttribute("width", String.valueOf(n));
            element.setAttribute("height", String.valueOf(n2));
        }
        Element element5 = element2;
        if (element5 == null) {
            element5 = element;
        }
        element5.setAttribute("fill", string);
        element5.setAttribute("stroke", string2);
        element5.setAttribute("stroke-width", String.valueOf(n3));
        Element element6 = null;
        if (mxUtils.isTrue(hashtable, mxConstants.STYLE_SHADOW, false) && !string.equals("none")) {
            element6 = (Element)element5.cloneNode(true);
            element6.setAttribute("transform", mxConstants.SVG_SHADOWTRANSFORM);
            element6.setAttribute("fill", mxConstants.W3C_SHADOWCOLOR);
            element6.setAttribute("stroke", mxConstants.W3C_SHADOWCOLOR);
            element6.setAttribute("stroke-width", String.valueOf(n3));
            this.root.appendChild(element6);
        }
        final double double1 = mxUtils.getDouble(hashtable, mxConstants.STYLE_ROTATION);
        if (double1 != 0.0) {
            final int n8 = i + n / 2;
            final int n9 = j + n2 / 2;
            element.setAttribute("transform", "rotate(" + double1 + "," + n8 + "," + n9 + ")");
            if (element6 != null) {
                element6.setAttribute("transform", "rotate(" + double1 + "," + n8 + "," + n9 + ") " + mxConstants.SVG_SHADOWTRANSFORM);
            }
        }
        final float float1 = mxUtils.getFloat(hashtable, mxConstants.STYLE_OPACITY, 100.0f);
        if (float1 != 100.0f) {
            final String value = String.valueOf(float1 / 100.0f);
            element.setAttribute("fill-opacity", value);
            element.setAttribute("stroke-opacity", value);
            if (element6 != null) {
                element6.setAttribute("fill-opacity", value);
                element6.setAttribute("stroke-opacity", value);
            }
        }
        this.root.appendChild(element);
        return element;
    }
    
    public Element drawLine(final List list, final Hashtable hashtable) {
        final Element element = this.document.createElement("g");
        final Element element2 = this.document.createElement("path");
        final String string = mxUtils.getString(hashtable, mxConstants.STYLE_STROKECOLOR);
        final float f = (float)(mxUtils.getFloat(hashtable, mxConstants.STYLE_STROKEWIDTH, 1.0f) * this.scale);
        if (string != null && f > 0.0f) {
            final Object value = hashtable.get(mxConstants.STYLE_STARTARROW);
            final mxPoint mxPoint = list.get(1);
            mxPoint mxPoint2 = list.get(0);
            mxPoint drawMarker;
            if (value != null) {
                drawMarker = this.drawMarker(element, value, mxPoint, mxPoint2, (float)(mxUtils.getFloat(hashtable, mxConstants.STYLE_STARTSIZE, (float)mxConstants.DEFAULT_MARKERSIZE) * this.scale), f, string);
            }
            else {
                final double n = mxPoint.getX() - mxPoint2.getX();
                final double n2 = mxPoint.getY() - mxPoint2.getY();
                final double max = Math.max(1.0, Math.sqrt(n * n + n2 * n2));
                drawMarker = new mxPoint(n * f / max / 2.0, n2 * f / max / 2.0);
            }
            if (drawMarker != null) {
                mxPoint2 = (mxPoint)mxPoint2.clone();
                mxPoint2.setX(mxPoint2.getX() + drawMarker.getX());
                mxPoint2.setY(mxPoint2.getY() + drawMarker.getY());
            }
            final Object value2 = hashtable.get(mxConstants.STYLE_ENDARROW);
            final mxPoint mxPoint3 = list.get(list.size() - 2);
            mxPoint mxPoint4 = list.get(list.size() - 1);
            mxPoint drawMarker2;
            if (value2 != null) {
                drawMarker2 = this.drawMarker(element, value2, mxPoint3, mxPoint4, (float)(mxUtils.getFloat(hashtable, mxConstants.STYLE_ENDSIZE, (float)mxConstants.DEFAULT_MARKERSIZE) * this.scale), f, string);
            }
            else {
                final double n3 = mxPoint3.getX() - mxPoint2.getX();
                final double n4 = mxPoint3.getY() - mxPoint2.getY();
                final double max2 = Math.max(1.0, Math.sqrt(n3 * n3 + n4 * n4));
                drawMarker2 = new mxPoint(n3 * f / max2 / 2.0, n4 * f / max2 / 2.0);
            }
            if (drawMarker2 != null) {
                mxPoint4 = (mxPoint)mxPoint4.clone();
                mxPoint4.setX(mxPoint4.getX() + drawMarker2.getX());
                mxPoint4.setY(mxPoint4.getY() + drawMarker2.getY());
            }
            final mxPoint mxPoint5 = mxPoint2;
            String s = "M " + mxPoint5.getX() + " " + mxPoint5.getY();
            for (int i = 1; i < list.size() - 1; ++i) {
                final mxPoint mxPoint6 = list.get(i);
                s = s + " L " + mxPoint6.getX() + " " + mxPoint6.getY();
            }
            element2.setAttribute("d", s + " L " + mxPoint4.getX() + " " + mxPoint4.getY());
            element2.setAttribute("stroke", string);
            element2.setAttribute("fill", "none");
            element2.setAttribute("stroke-width", String.valueOf(f));
            element.appendChild(element2);
            this.root.appendChild(element);
        }
        return element;
    }
    
    public mxPoint drawMarker(final Element element, final Object o, final mxPoint mxPoint, mxPoint mxPoint2, final float n, final float n2, final String s) {
        final mxPoint mxPoint3 = null;
        final double n3 = mxPoint2.getX() - mxPoint.getX();
        final double n4 = mxPoint2.getY() - mxPoint.getY();
        final double max = Math.max(1.0, Math.sqrt(n3 * n3 + n4 * n4));
        final double n5 = n * this.scale;
        final double n6 = n3 * n5 / max;
        final double n7 = n4 * n5 / max;
        mxPoint2 = (mxPoint)mxPoint2.clone();
        mxPoint2.setX(mxPoint2.getX() - n6 * n2 / (2.0f * n));
        mxPoint2.setY(mxPoint2.getY() - n7 * n2 / (2.0f * n));
        final double n8 = n6 * (0.5 + n2 / 2.0f);
        final double n9 = n7 * (0.5 + n2 / 2.0f);
        final Element element2 = this.document.createElement("path");
        element2.setAttribute("stroke-width", String.valueOf(n2 * this.scale));
        element2.setAttribute("stroke", s);
        element2.setAttribute("fill", s);
        String s2 = null;
        if (o.equals("classic") || o.equals("block")) {
            s2 = "M " + mxPoint2.getX() + " " + mxPoint2.getY() + " L " + (mxPoint2.getX() - n8 - n9 / 2.0) + " " + (mxPoint2.getY() - n9 + n8 / 2.0) + (o.equals("classic") ? (" L " + (mxPoint2.getX() - n8 * 3.0 / 4.0) + " " + (mxPoint2.getY() - n9 * 3.0 / 4.0)) : "") + " L " + (mxPoint2.getX() + n9 / 2.0 - n8) + " " + (mxPoint2.getY() - n9 - n8 / 2.0) + " z";
        }
        else if (o.equals("open")) {
            final double n10 = n8 * 1.2;
            final double n11 = n9 * 1.2;
            s2 = "M " + (mxPoint2.getX() - n10 - n11 / 2.0) + " " + (mxPoint2.getY() - n11 + n10 / 2.0) + " L " + (mxPoint2.getX() - n10 / 6.0) + " " + (mxPoint2.getY() - n11 / 6.0) + " L " + (mxPoint2.getX() + n11 / 2.0 - n10) + " " + (mxPoint2.getY() - n11 - n10 / 2.0) + " M " + mxPoint2.getX() + " " + mxPoint2.getY();
            element2.setAttribute("fill", "none");
        }
        else if (o.equals("oval")) {
            final double n12 = n8 * 1.2;
            final double n13 = n9 * 1.2;
            final double n14 = n5 * 1.2;
            s2 = "M " + (mxPoint2.getX() - n13 / 2.0) + " " + (mxPoint2.getY() + n12 / 2.0) + " a " + n14 / 2.0 + " " + n14 / 2.0 + " 0  1,1 " + n12 / 8.0 + " " + n13 / 8.0 + " z";
        }
        else if (o.equals("diamond")) {
            s2 = "M " + (mxPoint2.getX() + n8 / 2.0) + " " + (mxPoint2.getY() + n9 / 2.0) + " L " + (mxPoint2.getX() - n9 / 2.0) + " " + (mxPoint2.getY() + n8 / 2.0) + " L " + (mxPoint2.getX() - n8 / 2.0) + " " + (mxPoint2.getY() - n9 / 2.0) + " L " + (mxPoint2.getX() + n9 / 2.0) + " " + (mxPoint2.getY() - n8 / 2.0) + " z";
        }
        if (s2 != null) {
            element2.setAttribute("d", s2);
            element.appendChild(element2);
        }
        return mxPoint3;
    }
    
    public Object drawText(final String s, final int n, int i, final int n2, final int n3, final Hashtable hashtable) {
        Element element = null;
        final String string = mxUtils.getString(hashtable, mxConstants.STYLE_FONTCOLOR, "black");
        final String string2 = mxUtils.getString(hashtable, mxConstants.STYLE_FONTFAMILY, mxConstants.DEFAULT_FONTFAMILIES);
        final int j = (int)(mxUtils.getInt(hashtable, mxConstants.STYLE_FONTSIZE, mxConstants.DEFAULT_FONTSIZE) * this.scale);
        if (s != null && s.length() > 0) {
            element = this.document.createElement("text");
            final float float1 = mxUtils.getFloat(hashtable, mxConstants.STYLE_TEXT_OPACITY, 100.0f);
            if (float1 != 100.0f) {
                final String value = String.valueOf(float1 / 100.0f);
                element.setAttribute("fill-opacity", value);
                element.setAttribute("stroke-opacity", value);
            }
            element.setAttribute("text-anchor", "middle");
            element.setAttribute("font-weight", "normal");
            element.setAttribute("font-decoration", "none");
            element.setAttribute("font-size", String.valueOf(j));
            element.setAttribute("font-family", string2);
            element.setAttribute("fill", string);
            final String[] split = s.split("\n");
            i += j + (n3 - split.length * (j + mxConstants.LINESPACING)) / 2 - 2;
            for (int k = 0; k < split.length; ++k) {
                final Element element2 = this.document.createElement("tspan");
                element2.setAttribute("x", String.valueOf(n + n2 / 2));
                element2.setAttribute("y", String.valueOf(i));
                element2.appendChild(this.document.createTextNode(split[k]));
                element.appendChild(element2);
                i += j + mxConstants.LINESPACING;
            }
            this.root.appendChild(element);
        }
        return element;
    }
    
    static {
        mxSvgCanvas.DEFAULT_IMAGEBASEPATH = "";
    }
}
