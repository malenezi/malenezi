// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.swing.handler;

import java.awt.Stroke;
import java.awt.Graphics2D;
import java.awt.Graphics;
import java.awt.geom.Rectangle2D;
import com.mxgraph.model.mxGeometry;
import com.mxgraph.view.mxGraph;
import java.awt.geom.Point2D;
import com.mxgraph.util.mxPoint;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import javax.swing.JComponent;
import com.mxgraph.util.mxRectangle;
import com.mxgraph.util.mxConstants;
import java.awt.Rectangle;
import com.mxgraph.view.mxCellState;
import com.mxgraph.swing.mxGraphComponent;
import java.awt.Cursor;

public class mxVertexHandler extends mxCellHandler
{
    public static Cursor[] CURSORS;
    protected transient boolean gridEnabledEvent;
    protected transient boolean constrainedEvent;
    
    public mxVertexHandler(final mxGraphComponent mxGraphComponent, final mxCellState mxCellState) {
        super(mxGraphComponent, mxCellState);
        this.gridEnabledEvent = false;
        this.constrainedEvent = false;
    }
    
    @Override
    protected Rectangle[] createHandles() {
        Rectangle[] array;
        if (this.graphComponent.getGraph().isSizable(this.getState().getCell())) {
            final Rectangle rectangle = this.getState().getRectangle();
            final int n = mxConstants.HANDLE_SIZE / 2;
            final int x = rectangle.x - n;
            final int y = rectangle.y - n;
            final int n2 = rectangle.x + rectangle.width / 2 - n;
            final int n3 = rectangle.y + rectangle.height / 2 - n;
            final int x2 = rectangle.x + rectangle.width - n;
            final int y2 = rectangle.y + rectangle.height - n;
            array = new Rectangle[9];
            final int handle_SIZE = mxConstants.HANDLE_SIZE;
            array[0] = new Rectangle(x, y, handle_SIZE, handle_SIZE);
            array[1] = new Rectangle(n2, y, handle_SIZE, handle_SIZE);
            array[2] = new Rectangle(x2, y, handle_SIZE, handle_SIZE);
            array[3] = new Rectangle(x, n3, handle_SIZE, handle_SIZE);
            array[4] = new Rectangle(x2, n3, handle_SIZE, handle_SIZE);
            array[5] = new Rectangle(x, y2, handle_SIZE, handle_SIZE);
            array[6] = new Rectangle(n2, y2, handle_SIZE, handle_SIZE);
            array[7] = new Rectangle(x2, y2, handle_SIZE, handle_SIZE);
        }
        else {
            array = new Rectangle[] { null };
        }
        final int n4 = mxConstants.HANDLE_SIZE / 2;
        final mxRectangle labelBounds = this.state.getLabelBounds();
        array[array.length - 1] = new Rectangle((int)(labelBounds.getX() + labelBounds.getWidth() / 2.0 - n4), (int)(labelBounds.getY() + labelBounds.getHeight() / 2.0 - n4), 2 * n4, 2 * n4);
        return array;
    }
    
    @Override
    protected JComponent createPreview() {
        final JPanel panel = new JPanel();
        panel.setBorder(mxConstants.SELECTION_BORDER);
        panel.setOpaque(false);
        panel.setVisible(false);
        return panel;
    }
    
    @Override
    public void mouseDragged(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.start != null) {
            this.gridEnabledEvent = this.graphComponent.isGridEnabledEvent(mouseEvent);
            this.constrainedEvent = this.graphComponent.isConstrainedEvent(mouseEvent);
            double n = mouseEvent.getX() - this.start.x;
            double n2 = mouseEvent.getY() - this.start.y;
            if (this.isLabel(this.index)) {
                mxPoint snapScaledPoint = new mxPoint(mouseEvent.getPoint());
                if (this.gridEnabledEvent) {
                    snapScaledPoint = this.graphComponent.snapScaledPoint(snapScaledPoint);
                }
                int n3 = (int)Math.round(snapScaledPoint.getX() - this.start.x);
                int n4 = (int)Math.round(snapScaledPoint.getY() - this.start.y);
                if (this.constrainedEvent) {
                    if (Math.abs(n3) > Math.abs(n4)) {
                        n4 = 0;
                    }
                    else {
                        n3 = 0;
                    }
                }
                final Rectangle rectangle = this.state.getLabelBounds().getRectangle();
                rectangle.translate(n3, n4);
                this.preview.setBounds(rectangle);
            }
            else {
                final mxGraph graph = this.graphComponent.getGraph();
                final double scale = graph.getView().getScale();
                if (this.gridEnabledEvent) {
                    n = graph.snap(n / scale) * scale;
                    n2 = graph.snap(n2 / scale) * scale;
                }
                final mxRectangle union = this.union(this.getState(), n, n2, this.index);
                union.setWidth(union.getWidth() + 1.0);
                union.setHeight(union.getHeight() + 1.0);
                this.preview.setBounds(union.getRectangle());
            }
            if (!this.preview.isVisible() && this.graphComponent.isSignificant(n, n2)) {
                this.preview.setVisible(true);
            }
            mouseEvent.consume();
        }
    }
    
    @Override
    public void mouseReleased(final MouseEvent mouseEvent) {
        if (!mouseEvent.isConsumed() && this.start != null) {
            if (this.preview != null && this.preview.isVisible()) {
                if (this.isLabel(this.index)) {
                    this.moveLabel(mouseEvent);
                }
                else {
                    this.resizeCell(mouseEvent);
                }
            }
            mouseEvent.consume();
        }
        super.mouseReleased(mouseEvent);
    }
    
    protected void moveLabel(final MouseEvent mouseEvent) {
        final mxGraph graph = this.graphComponent.getGraph();
        final mxGeometry geometry = graph.getModel().getGeometry(this.state.getCell());
        if (geometry != null) {
            final double scale = graph.getView().getScale();
            mxPoint snapScaledPoint = new mxPoint(mouseEvent.getPoint());
            if (this.gridEnabledEvent) {
                snapScaledPoint = this.graphComponent.snapScaledPoint(snapScaledPoint);
            }
            double a = (snapScaledPoint.getX() - this.start.x) / scale;
            double a2 = (snapScaledPoint.getY() - this.start.y) / scale;
            if (this.constrainedEvent) {
                if (Math.abs(a) > Math.abs(a2)) {
                    a2 = 0.0;
                }
                else {
                    a = 0.0;
                }
            }
            mxPoint offset = geometry.getOffset();
            if (offset == null) {
                offset = new mxPoint();
            }
            final double a3 = a + offset.getX();
            final double a4 = a2 + offset.getY();
            final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
            mxGeometry.setOffset(new mxPoint((double)Math.round(a3), (double)Math.round(a4)));
            graph.getModel().setGeometry(this.state.getCell(), mxGeometry);
        }
    }
    
    protected void resizeCell(final MouseEvent mouseEvent) {
        final mxGraph graph = this.graphComponent.getGraph();
        final double scale = graph.getView().getScale();
        final Object cell = this.state.getCell();
        final mxGeometry geometry = graph.getModel().getGeometry(cell);
        if (geometry != null) {
            double snap = (mouseEvent.getX() - this.start.x) / scale;
            double snap2 = (mouseEvent.getY() - this.start.y) / scale;
            if (this.isLabel(this.index)) {
                final mxGeometry mxGeometry = (mxGeometry)geometry.clone();
                if (mxGeometry.getOffset() != null) {
                    snap += mxGeometry.getOffset().getX();
                    snap2 += mxGeometry.getOffset().getY();
                }
                if (this.gridEnabledEvent) {
                    snap = graph.snap(snap);
                    snap2 = graph.snap(snap2);
                }
                mxGeometry.setOffset(new mxPoint(snap, snap2));
                graph.getModel().setGeometry(cell, mxGeometry);
            }
            else {
                final Rectangle rectangle = this.union(geometry, snap, snap2, this.index).getRectangle();
                if (this.gridEnabledEvent) {
                    final int x = (int)graph.snap(rectangle.x);
                    final int y = (int)graph.snap(rectangle.y);
                    rectangle.width = (int)graph.snap(rectangle.width - x + rectangle.x);
                    rectangle.height = (int)graph.snap(rectangle.height - y + rectangle.y);
                    rectangle.x = x;
                    rectangle.y = y;
                }
                graph.resize(cell, new mxRectangle(rectangle));
            }
        }
    }
    
    @Override
    protected Cursor getCursor(final MouseEvent mouseEvent, final int n) {
        if (n >= 0 && n <= mxVertexHandler.CURSORS.length) {
            return mxVertexHandler.CURSORS[n];
        }
        return null;
    }
    
    protected mxRectangle union(final mxRectangle mxRectangle, final double n, final double n2, final int n3) {
        double x = mxRectangle.getX();
        double n4 = x + mxRectangle.getWidth();
        double y = mxRectangle.getY();
        double n5 = y + mxRectangle.getHeight();
        if (n3 > 4) {
            n5 += n2;
        }
        else if (n3 < 3) {
            y += n2;
        }
        if (n3 == 0 || n3 == 3 || n3 == 5) {
            x += n;
        }
        else if (n3 == 2 || n3 == 4 || n3 == 7) {
            n4 += n;
        }
        double abs = n4 - x;
        double abs2 = n5 - y;
        if (abs < 0.0) {
            x += abs;
            abs = Math.abs(abs);
        }
        if (abs2 < 0.0) {
            y += abs2;
            abs2 = Math.abs(abs2);
        }
        return new mxRectangle(x, y, abs, abs2);
    }
    
    @Override
    public void paint(final Graphics graphics) {
        final Graphics2D graphics2D = (Graphics2D)graphics;
        final Stroke stroke = graphics2D.getStroke();
        graphics2D.setStroke(mxConstants.SELECTION_STROKE);
        graphics.setColor(mxConstants.SELECTION_COLOR);
        final Rectangle rectangle = this.getState().getRectangle();
        graphics.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
        graphics2D.setStroke(stroke);
        super.paint(graphics);
    }
    
    static {
        mxVertexHandler.CURSORS = new Cursor[] { new Cursor(6), new Cursor(8), new Cursor(7), new Cursor(10), new Cursor(11), new Cursor(4), new Cursor(9), new Cursor(5), new Cursor(13) };
    }
}
