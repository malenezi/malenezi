// 
// Decompiled by Procyon v0.5.36
// 

package com.mxgraph.canvas;

import com.mxgraph.util.mxPoint;
import java.util.List;
import java.util.Map;
import com.mxgraph.util.mxUtils;
import com.mxgraph.util.mxConstants;
import java.util.Hashtable;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Node;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.Color;
import org.w3c.dom.Element;
import org.w3c.dom.Document;

public class mxHtmlCanvas implements mxICanvas
{
    public static String DEFAULT_IMAGEBASEPATH;
    public String imageBasePath;
    protected Document document;
    protected Element root;
    protected Element head;
    protected Element body;
    protected int x;
    protected int y;
    protected int width;
    protected int height;
    protected double scale;
    
    public mxHtmlCanvas(final int n, final int n2, final double n3) {
        this(0, 0, n, n2, n3);
    }
    
    public mxHtmlCanvas(final int n, final int n2, final int n3, final int n4, final double n5) {
        this(n, n2, n3, n4, n5, null);
    }
    
    public mxHtmlCanvas(final int x, final int y, final int width, final int height, final double scale, final Color color) {
        this.imageBasePath = mxHtmlCanvas.DEFAULT_IMAGEBASEPATH;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.scale = scale;
        try {
            this.document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            this.root = this.document.createElement("html");
            this.document.appendChild(this.root);
            this.head = this.document.createElement("head");
            this.root.appendChild(this.head);
            this.body = this.document.createElement("body");
            this.root.appendChild(this.body);
        }
        catch (ParserConfigurationException ex) {}
    }
    
    public Document getDocument() {
        return this.document;
    }
    
    public int getWidth() {
        return this.width;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public Object drawVertex(int n, int n2, final int n3, final int n4, final Hashtable t) {
        final int int1 = mxUtils.getInt(t, mxConstants.STYLE_STARTSIZE);
        n -= this.x;
        n2 -= this.y;
        if (int1 == 0) {
            this.drawShape(n, n2, n3, n4, t);
        }
        else {
            final int n5 = (int)Math.round(int1 * this.scale);
            final Hashtable hashtable = new Hashtable(t);
            hashtable.remove(mxConstants.STYLE_FILLCOLOR);
            hashtable.remove(mxConstants.STYLE_ROUNDED);
            if (mxUtils.isTrue(t, mxConstants.STYLE_HORIZONTAL, true)) {
                this.drawShape(n, n2, n3, n5, t);
                this.drawShape(n, n2 + n5, n3, n4 - n5, hashtable);
            }
            else {
                this.drawShape(n, n2, n5, n4, t);
                this.drawShape(n + n5, n2, n3 - n5, n4, hashtable);
            }
        }
        return null;
    }
    
    public Object drawEdge(List translatePoints, final Hashtable hashtable) {
        translatePoints = mxUtils.translatePoints(translatePoints, -this.x, -this.y);
        this.drawLine(translatePoints, hashtable);
        return null;
    }
    
    public Object drawLabel(final String s, int n, int n2, final int n3, final int n4, final Hashtable hashtable, final boolean b) {
        n -= this.x;
        n2 -= this.y;
        return this.drawText(s, n, n2, n3, n4, hashtable);
    }
    
    public String getImageForStyle(final Hashtable hashtable) {
        String str = mxUtils.getString(hashtable, mxConstants.STYLE_IMAGE);
        if (str != null && !str.startsWith("/")) {
            str = this.imageBasePath + str;
        }
        return str;
    }
    
    public Element drawShape(int round, int round2, int n, int n2, final Hashtable hashtable) {
        final String string = mxUtils.getString(hashtable, mxConstants.STYLE_FILLCOLOR);
        mxUtils.getString(hashtable, mxConstants.STYLE_GRADIENTCOLOR);
        final String string2 = mxUtils.getString(hashtable, mxConstants.STYLE_STROKECOLOR);
        final float n3 = (float)(mxUtils.getFloat(hashtable, mxConstants.STYLE_STROKEWIDTH, 1.0f) * this.scale);
        final String string3 = mxUtils.getString(hashtable, mxConstants.STYLE_SHAPE);
        Element element = this.document.createElement("div");
        if (string3.equals("line")) {
            final String string4 = mxUtils.getString(hashtable, mxConstants.STYLE_DIRECTION, "east");
            if (string4.equals("east") || string4.equals("west")) {
                round2 = Math.round((float)(round2 + n2 / 2));
                n2 = 1;
            }
            else {
                round = Math.round((float)(round2 + n / 2));
                n = 1;
            }
        }
        if (mxUtils.isTrue(hashtable, mxConstants.STYLE_SHADOW, false) && string != null) {
            final Element element2 = (Element)element.cloneNode(true);
            element2.setAttribute("style", "overflow:hidden;position:absolute;left:" + String.valueOf(round + mxConstants.SHADOW_OFFSETX) + "px;" + "top:" + String.valueOf(round2 + mxConstants.SHADOW_OFFSETY) + "px;" + "width:" + String.valueOf(n) + "px;" + "height:" + String.valueOf(n2) + "px;background:" + mxConstants.W3C_SHADOWCOLOR + ";border-style:solid;border-color:" + mxConstants.W3C_SHADOWCOLOR + ";border-width:" + String.valueOf(Math.round(n3)) + ";");
            this.body.appendChild(element2);
        }
        if (string3.equals("image")) {
            final String imageForStyle = this.getImageForStyle(hashtable);
            if (imageForStyle != null) {
                element = this.document.createElement("img");
                element.setAttribute("border", "0");
                element.setAttribute("src", imageForStyle);
            }
        }
        element.setAttribute("style", "overflow:hidden;position:absolute;left:" + String.valueOf(round) + "px;" + "top:" + String.valueOf(round2) + "px;" + "width:" + String.valueOf(n) + "px;" + "height:" + String.valueOf(n2) + "px;background:" + string + ";" + ";border-style:solid;border-color:" + string2 + ";border-width:" + String.valueOf(Math.round(n3)) + ";");
        this.body.appendChild(element);
        return element;
    }
    
    public void drawLine(final List list, final Hashtable hashtable) {
        final String string = mxUtils.getString(hashtable, mxConstants.STYLE_STROKECOLOR);
        final int n = (int)(mxUtils.getInt(hashtable, mxConstants.STYLE_STROKEWIDTH, 1) * this.scale);
        if (string != null && n > 0) {
            mxPoint mxPoint = list.get(0);
            for (int i = 1; i < list.size(); ++i) {
                final mxPoint mxPoint2 = list.get(i);
                this.drawSegment((int)mxPoint.getX(), (int)mxPoint.getY(), (int)mxPoint2.getX(), (int)mxPoint2.getY(), string, n);
                mxPoint = mxPoint2;
            }
        }
    }
    
    protected void drawSegment(int i, int j, final int n, final int n2, final String str, final int n3) {
        final int min = Math.min(i, n);
        final int min2 = Math.min(j, n2);
        final int k = Math.max(i, n) - min;
        final int l = Math.max(j, n2) - min2;
        i = min;
        j = min2;
        if (k == 0 || l == 0) {
            final String string = "overflow:hidden;position:absolute;left:" + String.valueOf(i) + "px;" + "top:" + String.valueOf(j) + "px;" + "width:" + String.valueOf(k) + "px;" + "height:" + String.valueOf(l) + "px;" + "border-color:" + str + ";" + "border-style:solid;" + "border-width:1 1 0 0px;";
            final Element element = this.document.createElement("div");
            element.setAttribute("style", string);
            this.body.appendChild(element);
        }
        else {
            final int n4 = i + (n - i) / 2;
            this.drawSegment(i, j, n4, j, str, n3);
            this.drawSegment(n4, j, n4, n2, str, n3);
            this.drawSegment(n4, n2, n, n2, str, n3);
        }
    }
    
    public Element drawText(final String s, final int n, final int n2, final int n3, final int n4, final Hashtable hashtable) {
        final Element table = mxUtils.createTable(this.document, s, n, n2, n3, n4, this.scale, hashtable);
        this.body.appendChild(table);
        return table;
    }
    
    static {
        mxHtmlCanvas.DEFAULT_IMAGEBASEPATH = "";
    }
}
