var memory = "0";

/**
 * This function will clear the memory variable, resulting in a value of 0 being stored.
 */
function clearMemory()
{
  memory = "0.0.0";
}

/**
 * This function will store the value shown on the calculator into memory.
 */
function store()
{
  try 
  { 
    memory=eval(document.getElementById("display").value); 
  } 
  catch(e) 
  {
    c("Error"); 
  }  
}

/**
 * This method will calculate the square root of the number on the display.
 */
function squarert()
{
 try 
  { 
    c(Math.pow(eval(document.getElementById("display").value),2)) 
  } 
  catch(e) 
  {
    c(e); 
  }
}

/**
 * This function will calculate the square of the number on the display.
 */
function square()
{
 try 
  { 
    c(Math.pow(eval(document.getElementById("display").value),2)) 
  } 
  catch(e) 
  {
    c(e); 
  }
}

/**
 * This method will clear the display and place the given value on the display.
 * @param {val} This is the new value that is to be placed on the display.
 */
function c(val)
{
  document.getElementById("display").value=val;
}

/**
 * This method will concatenate the new value onto the existing value of the display.
 * @param {val} This is the new value that is to be appended on the display.
 */
function v(val)
{
  document.getElementById("display").value+=val;
}

/**
 * This method will evaluate the operation on the display.  The result will then be shown.
 */
function e() 
{ 
  try 
  { 
    c(eval(document.getElementById("display").value)) 
  } 
  catch(e) 
  {
    c('Error') 
  } 
}  

/**
 * This method will backspace the display by 1 character, removing the most recently touched key.
 */
function backspace()
{
  n = document.getElementById("display").value.length
  c(document.getElementById("display").value.slice(1, n-1))
}
