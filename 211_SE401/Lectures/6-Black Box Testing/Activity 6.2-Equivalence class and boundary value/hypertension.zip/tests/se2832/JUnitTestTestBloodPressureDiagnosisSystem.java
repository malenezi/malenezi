package se2832;
/**
 * @author Dr. Walt Schilling
 */

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class JUnitTestTestBloodPressureDiagnosisSystem {

	private BloodPressureDiagnosisSystem patient;

	@Before
	public void setup() throws Exception {
		// Create a new valid patient.
		patient = new BloodPressureDiagnosisSystem("Ima Tester", 0x21);
	}

	@Test
	/**
	 * This test will insure that the normal constructor works properly.
	 */
	public void testNormalConstructor() throws Exception {
		String patientName = "Janice Tester";
		patient = new BloodPressureDiagnosisSystem(patientName, 21);
		// Make sure the patient is not null.
		assertNotNull(patient);

		// Make sure the age is set correctly.
		assertEquals(21, patient.getAge());

		// Make sure the name is set correctly.
		assertEquals(patientName, patient.getPatientName());
	}

	@Test(expected = Exception.class)
	/**
	 * This test will ensure that a negative age fails properly.
	 */
	public void testNegativeAgeOutOfBoundsInConstructor() throws Exception {
		String patientName = "Janice Tester";
		patient = new BloodPressureDiagnosisSystem(patientName, -1);
	}

	@Test(expected = Exception.class)
	/**
	 * This test will ensure that a single name fails.
	 */
	public void testNoSpaceInName() throws Exception {
		String patientName = "JaniceTester";
		patient = new BloodPressureDiagnosisSystem(patientName, 21);

		fail("An Exception should have been thrown by the line above.");
	}

	@Test(expected = Exception.class)
	/**
	 * Thsi test will ensure that a first initial only results in a failure.
	 */
	public void testFirstInitialInName() throws Exception {
		String patientName = "J Tester";
		patient = new BloodPressureDiagnosisSystem(patientName, 21);

		fail("An Exception should have been thrown by the line above.");
	}

	@Test(expected = Exception.class)
	/**
	 * This test will ensure that a last initial in anme results in an exception.
	 */
	public void testLastInitialInName() throws Exception {
		String patientName = "Tester J";
		patient = new BloodPressureDiagnosisSystem(patientName, 21);

		fail("An Exception should have been thrown by the line above.");
	}

	@Test
	/**
	 * This will test that a normal blood pressure is diagnosed as normal.
	 */
	public void testNormalBloodPressure() {
		assertEquals(
				BloodPressureDiagnosisSystem.BloodPressureDiagnosis.NORMAL,
				patient.diagnoseBP(110, 60));
	}
	
	@Test
	/**
	 * This will test that a high systolic and normal diastolic blood pressure is diagnosed correctly.
	 */
	public void testHighSystolic1BloodPressure() {
		assertEquals(
				BloodPressureDiagnosisSystem.BloodPressureDiagnosis.PREHYPERTENSION,
				patient.diagnoseBP(125, 60));
	}
	
	@Test
	/**
	 * This will test that a high diastolic and normal systolic blood pressure is diagnosed correctly.
	 */
	public void testHighDiastolic1BloodPressure() {
		assertEquals(
				BloodPressureDiagnosisSystem.BloodPressureDiagnosis.PREHYPERTENSION,
				patient.diagnoseBP(112, 85));
	}

	

	
	
	
	

}
