package se2832;

/**
 * @author Dr. Walt Schilling
 */

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertNotNull;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import se2832.BloodPressureDiagnosisSystem.BloodPressureDiagnosis;

public class BloodPressureDiagnosisSystemTest {

	private BloodPressureDiagnosisSystem patient;

	@BeforeMethod
	public void setup() throws Exception {
		// Create a new valid patient.
		patient = new BloodPressureDiagnosisSystem("Ima Tester", 0x21);
	}
	
	@DataProvider(name="constructorTests")
	public static Object[][] createConstructorData()
	{
		return new Object[][] {
				{"Janice Tester", new Integer(21)},
				{"Janice Tester", new Integer(0)},
				{"Janice Tester", new Integer(1)},
				{"Ja Tester", new Integer(21)},
				{"Ja Te", new Integer(21)}
		};
	}
	
	
	@Test(dataProvider="constructorTests")
	/**
	 * This test will insure that the normal constructor works properly.
	 */
	public void testNormalConstructor(String name, int age) throws Exception {
		patient = new BloodPressureDiagnosisSystem(name, age);
		// Make sure the patient is not null.
		assertNotNull(patient);

		// Make sure the age is set correctly.
		assertEquals(age, patient.getAge());

		// Make sure the name is set correctly.
		assertEquals(name, patient.getPatientName());
	}
	
	@DataProvider(name="invalidconstructorTests")
	public static Object[][] createInvalidConstructorData()
	{
		return new Object[][] {
				{"Janice Tester", new Integer(-1)},
				{"J Tester", new Integer(21)},
				{"Ja T", new Integer(21)},
				{"JaT", new Integer(21)}
		};
	}

	@Test(dataProvider="invalidconstructorTests", expectedExceptions = Exception.class)
	/**
	 * This test will ensure that a negative age fails properly.
	 */
	public void testInvalidConstructor(String name, int age) throws Exception {
		patient = new BloodPressureDiagnosisSystem(name, age);
	}

	
	@DataProvider(name="validBPReadings")
	public static Object[][] createvalidBPData()
	{
		return new Object[][] {
				{new Integer(119), new Integer(79), BloodPressureDiagnosis.NORMAL},
		};
	}
	
	@Test(dataProvider="validBPReadings")
  public void diagnoseBP(int systolic, int diastolic, BloodPressureDiagnosis diagnosis) {
    throw new RuntimeException("Test not implemented");
  }
}
