package se2832;
/**
 * @author Dr. Walt Schilling
 * 
 */
public class BloodPressureDiagnosisSystem {
	private String patientName;
	private int age;

	public enum BloodPressureDiagnosis {
		NORMAL, PREHYPERTENSION, STAGE_1_HBP, STAGE_2_HBP, HYPERTENSIVE_CRISIS
	};

	/**
	 * This will instantiate a new instance of the Blood Pressure Diagnosis
	 * system.
	 * 
	 * @param patientName
	 *            This is the name of the patient. Must consist of a first and a
	 *            last name separated by a space, and each of the first and last
	 *            names must be 2 or more characters in length.
	 * @param patientAge
	 *            This is the age of the patient in years. Must be greater than
	 *            or equal to 0.
	 * @throws Exception
	 *             An Exception will be thrown if the age is out of range or if
	 *             the name is incorrectly formatted.
	 */
	public BloodPressureDiagnosisSystem(String patientName, int patientAge)
			throws Exception {
		// Check that the age is in range.
		if (patientAge >= 0) {
			this.age = patientAge;
		} else {
			throw new Exception("Age must be greater than or equal to 0.");
		}
		// Check that the name is in range and formatted properly.
		// Split the string at the middle space.
		String[] names = patientName.split("\\s+");

		if ((names.length == 2) && (names[0].length() >= 2)
				&& (names[1].length() >= 2)) {
			this.patientName = patientName;
		} else {
			throw new Exception("Imporperly formatted name field.");
		}
	}

	/**
	 * This method will obtain the patient name.
	 * 
	 * @return This is the name of the given patient.
	 */
	public String getPatientName() {
		return patientName;
	}

	/**
	 * This is the age of the given patient.
	 * 
	 * @return The age of the patient will be returned.
	 */
	public int getAge() {
		return age;
	}

	/**
	 * This method will diagnose a person's blood pressure condition based upon
	 * the American Heart Association clinical definitions.
	 * (http://www.heart.org
	 * /HEARTORG/Conditions/HighBloodPressure/AboutHighBloodPressure
	 * /Understanding-Blood-Pressure-Readings_UCM_301764_Article.jsp)
	 * 
	 * @param systolic
	 *            This is the systolic blood pressure, the upper number, which
	 *            is the pressure in the arteries when the heart is beating.
	 * @param diastolic
	 *            This is the diastolic blood pressure, which is the pressure
	 *            between heart beats.
	 * @return The return will be a diagnosis of the given blood pressure.
	 * @throws ArithmeticException
	 *             An Arithmetic exception will be thrown if the pressure is
	 *             negative, or if the systolic pressure is less than or equal
	 *             to the diastolic pressure.
	 */
	public BloodPressureDiagnosis diagnoseBP(int systolic, int diastolic)
			throws ArithmeticException {
		// Start by checking the inputs.
		if (systolic <= 0) {
			throw new ArithmeticException(
					"The Systolic Blood Pressure can not be negative.");
		}
		if (diastolic <= 0) {
			throw new ArithmeticException(
					"The Diastolic Blood Pressure can not be negative.");
		}
		if (systolic <= diastolic) {
			throw new ArithmeticException(
					"The Systolic reading must be greater than the Diastolic Blood Pressure reading.");
		}

		BloodPressureDiagnosis systolicDiagnosis = BloodPressureDiagnosis.NORMAL;
		BloodPressureDiagnosis diastolicDiagnosis = BloodPressureDiagnosis.NORMAL;

		// First assign a reading based on the systolic diagnosis.
		if (systolic < 120) {
			systolicDiagnosis = BloodPressureDiagnosis.NORMAL;
		} else if (systolic < 140) {
			systolicDiagnosis = BloodPressureDiagnosis.PREHYPERTENSION;
		} else if (systolic < 160) {
			systolicDiagnosis = BloodPressureDiagnosis.STAGE_1_HBP;
		} else if (systolic >= 160) {
			systolicDiagnosis = BloodPressureDiagnosis.STAGE_2_HBP;
		} else if (systolic > 180) {
			systolicDiagnosis = BloodPressureDiagnosis.HYPERTENSIVE_CRISIS;
		}

		// Now assign a reading based on the diastolic diagnosis.
		if (diastolic < 80) {
			diastolicDiagnosis = BloodPressureDiagnosis.NORMAL;
		} else if (diastolic < 90) {
			diastolicDiagnosis = BloodPressureDiagnosis.PREHYPERTENSION;
		} else if (diastolic < 100) {
			diastolicDiagnosis = BloodPressureDiagnosis.STAGE_1_HBP;
		} else if (diastolic >= 100) {
			diastolicDiagnosis = BloodPressureDiagnosis.STAGE_2_HBP;
		} else if (diastolic > 110) {
			diastolicDiagnosis = BloodPressureDiagnosis.HYPERTENSIVE_CRISIS;
		}

		// Determine which is the higher classification and apply that
		// diagnosis.
		BloodPressureDiagnosis finalDiagnosis;

		if (diastolicDiagnosis.ordinal() >= systolicDiagnosis.ordinal()) {
			finalDiagnosis = diastolicDiagnosis;
		} else {
			finalDiagnosis = systolicDiagnosis;
		}
		return finalDiagnosis;
	}
}
