if a:
  if b:
else

# At the end of line 3 type :
# "else" statement should stay.
if a:
  if b:
else:
