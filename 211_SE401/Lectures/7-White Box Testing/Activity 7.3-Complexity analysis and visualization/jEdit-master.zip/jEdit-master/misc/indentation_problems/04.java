if (true
    && s.equals("xxxx")) break;

/*
Inserting : inside the string or wrapping break in {} brackets should not
reindent.
*/