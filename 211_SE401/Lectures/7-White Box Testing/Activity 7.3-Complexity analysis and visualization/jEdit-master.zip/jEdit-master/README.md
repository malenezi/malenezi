#jedit

A mature programmer's text editor

## Official web site

http://www.jedit.org
